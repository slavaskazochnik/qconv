--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

SET default_with_oids = false;

--
-- Name: autos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE autos (
    id integer NOT NULL,
    car_id integer NOT NULL,
    driver_id integer NOT NULL,
    r_waiting smallint,
    r_route smallint,
    position_lat character varying(15),
    position_lng character varying(15),
    position_address character varying(100),
    sign_active integer,
    creation_date timestamp without time zone
);


--
-- Name: TABLE autos; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE autos IS 'Список автомобилей готовых к выполнению заказов';


--
-- Name: COLUMN autos.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN autos.id IS 'PK';


--
-- Name: COLUMN autos.car_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN autos.car_id IS 'FK cars';


--
-- Name: COLUMN autos.driver_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN autos.driver_id IS 'FK drivers';


--
-- Name: COLUMN autos.r_waiting; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN autos.r_waiting IS 'Радиус ожидания, км';


--
-- Name: COLUMN autos.r_route; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN autos.r_route IS 'Радиус выполнения заказа, км';


--
-- Name: COLUMN autos.position_lat; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN autos.position_lat IS 'Текущее положение авто (широта)';


--
-- Name: COLUMN autos.position_lng; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN autos.position_lng IS 'Текущее положение авто (долгота)';


--
-- Name: COLUMN autos.sign_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN autos.sign_active IS 'Признак участия в исполнении заказа';


--
-- Name: COLUMN autos.creation_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN autos.creation_date IS 'Дата создания записи';


--
-- Name: autos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE autos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: autos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE autos_id_seq OWNED BY autos.id;


--
-- Name: car; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE car (
    id integer NOT NULL,
    reg_num character varying(10),
    seats_quan integer NOT NULL,
    child_seats_quan integer,
    suitcases_quan integer,
    car_type integer NOT NULL,
    car_model character varying(100),
    sign_active integer,
    creation_date timestamp without time zone
);


--
-- Name: TABLE car; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE car IS 'Справочник транспортных средств';


--
-- Name: COLUMN car.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN car.id IS 'PK';


--
-- Name: COLUMN car.reg_num; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN car.reg_num IS 'Регистрационный номер';


--
-- Name: COLUMN car.seats_quan; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN car.seats_quan IS 'Количество пассажирских мест';


--
-- Name: COLUMN car.child_seats_quan; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN car.child_seats_quan IS 'Кол-во детских сидений';


--
-- Name: COLUMN car.suitcases_quan; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN car.suitcases_quan IS 'Количество сумок в багаже';


--
-- Name: COLUMN car.car_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN car.car_type IS 'Тип авто';


--
-- Name: COLUMN car.car_model; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN car.car_model IS 'Модель автомобиля';


--
-- Name: COLUMN car.sign_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN car.sign_active IS 'Признак используемости авто';


--
-- Name: COLUMN car.creation_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN car.creation_date IS 'Дата создания записи';


--
-- Name: car_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE car_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: car_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE car_id_seq OWNED BY car.id;


--
-- Name: city; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE city (
    id integer NOT NULL,
    name character varying(50)
);


--
-- Name: TABLE city; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE city IS 'Справочник населённых пунктов';


--
-- Name: COLUMN city.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN city.id IS 'PK';


--
-- Name: COLUMN city.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN city.name IS 'Название населённого пункта';


--
-- Name: city_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE city_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: city_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE city_id_seq OWNED BY city.id;


--
-- Name: customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE customer (
    id integer NOT NULL,
    avg_rating numeric(2,1),
    sign_active integer,
    creation_date timestamp without time zone
);


--
-- Name: TABLE customer; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE customer IS 'Справочник заказчиков';


--
-- Name: COLUMN customer.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN customer.id IS 'PK';


--
-- Name: COLUMN customer.avg_rating; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN customer.avg_rating IS 'Средняя оценка заказчику';


--
-- Name: COLUMN customer.sign_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN customer.sign_active IS 'Признак активности водителя в системе';


--
-- Name: COLUMN customer.creation_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN customer.creation_date IS 'Дата создания записи';


--
-- Name: customer_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE customer_id_seq OWNED BY customer.id;


--
-- Name: driver; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE driver (
    id integer NOT NULL,
    avg_rating numeric(2,1),
    sign_active integer,
    creation_date timestamp without time zone
);


--
-- Name: TABLE driver; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE driver IS 'Справочник водителей';


--
-- Name: COLUMN driver.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN driver.id IS 'PK';


--
-- Name: COLUMN driver.avg_rating; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN driver.avg_rating IS 'Средняя оценка водителю';


--
-- Name: COLUMN driver.sign_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN driver.sign_active IS 'Признак активности водителя в системе';


--
-- Name: COLUMN driver.creation_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN driver.creation_date IS 'Дата создания записи';


--
-- Name: driver_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE driver_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: driver_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE driver_id_seq OWNED BY driver.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE orders (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    autos_id integer,
    price_id integer NOT NULL,
    order_status integer NOT NULL,
    order_result integer NOT NULL,
    route_length integer,
    order_price integer,
    customer_rating integer,
    driver_rating integer,
    creation_date timestamp without time zone NOT NULL,
    begin_date timestamp without time zone,
    end_date timestamp without time zone
);


--
-- Name: TABLE orders; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE orders IS 'Заказы';


--
-- Name: COLUMN orders.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN orders.id IS 'PK';


--
-- Name: COLUMN orders.customer_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN orders.customer_id IS 'Заказчик';


--
-- Name: COLUMN orders.autos_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN orders.autos_id IS 'Исполнитель заказа';


--
-- Name: COLUMN orders.price_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN orders.price_id IS 'Цены';


--
-- Name: COLUMN orders.order_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN orders.order_status IS 'Состояние заказа: новый, принят, прибыл, в пути, закрыт';


--
-- Name: COLUMN orders.order_result; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN orders.order_result IS 'Результат: заказ принят, заказ выполнен, заказ отменён';


--
-- Name: COLUMN orders.route_length; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN orders.route_length IS 'Длина маршрута';


--
-- Name: COLUMN orders.order_price; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN orders.order_price IS 'Стоимость заказа';


--
-- Name: COLUMN orders.customer_rating; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN orders.customer_rating IS 'Оценка заказчику';


--
-- Name: COLUMN orders.driver_rating; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN orders.driver_rating IS 'Оценка водителю';


--
-- Name: COLUMN orders.creation_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN orders.creation_date IS 'Дата создания записи';


--
-- Name: COLUMN orders.begin_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN orders.begin_date IS 'Дата начала выполнения заказа';


--
-- Name: COLUMN orders.end_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN orders.end_date IS 'Дата закрытия заказа';


--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE orders_id_seq OWNED BY orders.id;


--
-- Name: orders_timetable; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE orders_timetable (
    id integer NOT NULL,
    orders_id integer NOT NULL,
    order_status integer NOT NULL,
    creation_date timestamp without time zone
);


--
-- Name: TABLE orders_timetable; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE orders_timetable IS 'График выполнения заказа';


--
-- Name: COLUMN orders_timetable.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN orders_timetable.id IS 'PK';


--
-- Name: COLUMN orders_timetable.orders_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN orders_timetable.orders_id IS 'ID заказа';


--
-- Name: COLUMN orders_timetable.order_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN orders_timetable.order_status IS 'Состояние заказа';


--
-- Name: COLUMN orders_timetable.creation_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN orders_timetable.creation_date IS 'Дата проставления состояния';


--
-- Name: orders_timetable_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE orders_timetable_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orders_timetable_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE orders_timetable_id_seq OWNED BY orders_timetable.id;


--
-- Name: point; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE point (
    id integer NOT NULL,
    street_id integer NOT NULL,
    name character varying(10),
    point_lat character varying(15),
    point_lng character varying(15)
);


--
-- Name: TABLE point; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE point IS 'Справочник пунктов назначений';


--
-- Name: COLUMN point.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN point.id IS 'PK';


--
-- Name: COLUMN point.street_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN point.street_id IS 'FK Улица';


--
-- Name: COLUMN point.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN point.name IS 'Номер дома/корпуса';


--
-- Name: COLUMN point.point_lat; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN point.point_lat IS 'Положение на карте: Широта [-90, 90]';


--
-- Name: COLUMN point.point_lng; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN point.point_lng IS 'Положение на карте: Долгота [-180, 180]';


--
-- Name: point_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE point_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: point_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE point_id_seq OWNED BY point.id;


--
-- Name: price; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE price (
    id integer NOT NULL,
    car_type integer NOT NULL,
    cost_before integer,
    cost_km integer,
    cost_for_waiting integer,
    begin_date timestamp without time zone,
    end_date timestamp without time zone,
    creation_date timestamp without time zone
);


--
-- Name: TABLE price; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE price IS 'Цены на услуги';


--
-- Name: COLUMN price.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN price.id IS 'PK';


--
-- Name: COLUMN price.car_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN price.car_type IS 'Тип авто';


--
-- Name: COLUMN price.cost_before; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN price.cost_before IS 'Цена посадки';


--
-- Name: COLUMN price.cost_km; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN price.cost_km IS 'Цена за 1 км';


--
-- Name: COLUMN price.cost_for_waiting; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN price.cost_for_waiting IS 'Цена ожидания за минуту';


--
-- Name: COLUMN price.begin_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN price.begin_date IS 'Действует с';


--
-- Name: COLUMN price.end_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN price.end_date IS 'Действует по';


--
-- Name: COLUMN price.creation_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN price.creation_date IS 'Дата создания';


--
-- Name: price_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE price_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: price_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE price_id_seq OWNED BY price.id;


--
-- Name: route; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE route (
    id integer NOT NULL,
    orders_id integer NOT NULL,
    point_index integer,
    src_point_id integer,
    src_point_address character varying(100),
    src_descr character varying(100),
    dst_point_id integer,
    dst_point_address character varying(100),
    est_length integer,
    fact_length integer,
    est_time integer
);


--
-- Name: TABLE route; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE route IS 'Маршрут следования';


--
-- Name: COLUMN route.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN route.id IS 'PK';


--
-- Name: COLUMN route.orders_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN route.orders_id IS 'FK на Заказ';


--
-- Name: COLUMN route.point_index; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN route.point_index IS 'Порядок следования пунктов';


--
-- Name: COLUMN route.src_point_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN route.src_point_id IS 'Начальный пункт';


--
-- Name: COLUMN route.src_descr; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN route.src_descr IS 'Примечания для пункта отправления';


--
-- Name: COLUMN route.dst_point_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN route.dst_point_id IS 'Конечный пункт';


--
-- Name: COLUMN route.est_length; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN route.est_length IS 'Планируемая Длина пути';


--
-- Name: COLUMN route.fact_length; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN route.fact_length IS 'Фактическая Длина пути';


--
-- Name: COLUMN route.est_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN route.est_time IS 'Планируемое время (минут)';


--
-- Name: route_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE route_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: route_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE route_id_seq OWNED BY route.id;


--
-- Name: street; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE street (
    id integer NOT NULL,
    name character varying(50),
    city_id integer NOT NULL
);


--
-- Name: TABLE street; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE street IS 'Справочник улиц';


--
-- Name: COLUMN street.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN street.id IS 'PK';


--
-- Name: COLUMN street.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN street.name IS 'Название улицы';


--
-- Name: COLUMN street.city_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN street.city_id IS 'FK Населённый пункт';


--
-- Name: street_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE street_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: street_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE street_id_seq OWNED BY street.id;


--
-- Name: user_account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE user_account (
    id integer NOT NULL,
    name character varying(30) NOT NULL,
    password character varying(128) NOT NULL,
    email character varying(255) NOT NULL,
    creation_date timestamp without time zone
);


--
-- Name: TABLE user_account; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE user_account IS 'Справочник аккаунтов';


--
-- Name: COLUMN user_account.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN user_account.id IS 'PK';


--
-- Name: COLUMN user_account.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN user_account.name IS 'Логин пользователя';


--
-- Name: COLUMN user_account.password; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN user_account.password IS 'Пароль (HASH)';


--
-- Name: COLUMN user_account.email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN user_account.email IS 'Контактный email';


--
-- Name: COLUMN user_account.creation_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN user_account.creation_date IS 'Дата создания';


--
-- Name: user_account_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE user_account_id_seq OWNED BY user_account.id;


--
-- Name: user_profile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE user_profile (
    id integer NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30),
    tel_num character varying(30) NOT NULL,
    creation_date timestamp without time zone
);


--
-- Name: TABLE user_profile; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE user_profile IS 'Справочник персон';


--
-- Name: COLUMN user_profile.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN user_profile.id IS 'PK';


--
-- Name: COLUMN user_profile.first_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN user_profile.first_name IS 'Имя';


--
-- Name: COLUMN user_profile.last_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN user_profile.last_name IS 'Фамилия';


--
-- Name: COLUMN user_profile.tel_num; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN user_profile.tel_num IS 'Контактный телефон';


--
-- Name: COLUMN user_profile.creation_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN user_profile.creation_date IS 'Дата создания записи';


--
-- Name: user_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_profile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE user_profile_id_seq OWNED BY user_profile.id;


--
-- Name: user_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE user_role (
    id integer NOT NULL,
    user_profile_id integer NOT NULL,
    app_role integer NOT NULL
);


--
-- Name: TABLE user_role; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE user_role IS 'Роли пользователя';


--
-- Name: COLUMN user_role.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN user_role.id IS 'Аккаунт';


--
-- Name: COLUMN user_role.user_profile_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN user_role.user_profile_id IS 'Пользователь';


--
-- Name: COLUMN user_role.app_role; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN user_role.app_role IS 'Роль';


--
-- Name: user_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE user_role_id_seq OWNED BY user_role.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY autos ALTER COLUMN id SET DEFAULT nextval('autos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY car ALTER COLUMN id SET DEFAULT nextval('car_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY city ALTER COLUMN id SET DEFAULT nextval('city_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY customer ALTER COLUMN id SET DEFAULT nextval('customer_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY driver ALTER COLUMN id SET DEFAULT nextval('driver_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY orders ALTER COLUMN id SET DEFAULT nextval('orders_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY orders_timetable ALTER COLUMN id SET DEFAULT nextval('orders_timetable_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY point ALTER COLUMN id SET DEFAULT nextval('point_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY price ALTER COLUMN id SET DEFAULT nextval('price_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY route ALTER COLUMN id SET DEFAULT nextval('route_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY street ALTER COLUMN id SET DEFAULT nextval('street_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_account ALTER COLUMN id SET DEFAULT nextval('user_account_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_profile ALTER COLUMN id SET DEFAULT nextval('user_profile_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_role ALTER COLUMN id SET DEFAULT nextval('user_role_id_seq'::regclass);


--
-- Data for Name: autos; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO autos VALUES (1, 1, 2, NULL, NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO autos VALUES (2, 2, 5, NULL, NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO autos VALUES (3, 3, 8, NULL, NULL, NULL, NULL, 'ул. Лиможа, 22', 1, NULL);


--
-- Name: autos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('autos_id_seq', 3, true);


--
-- Data for Name: car; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO car VALUES (1, '4321 AC-4', 4, 1, NULL, 0, 'Skoda Octavia', NULL, NULL);
INSERT INTO car VALUES (2, '1122 KM-4', 4, NULL, NULL, 0, 'Audi 100', NULL, NULL);
INSERT INTO car VALUES (3, '5533 CI-4', 4, 1, NULL, 0, 'VW Passat', NULL, NULL);
INSERT INTO car VALUES (4, '3276 CA-4', 4, NULL, NULL, 0, 'VW Jetta', NULL, NULL);
INSERT INTO car VALUES (5, '9831 EC-4', 6, NULL, NULL, 0, 'Ford Galaxy', NULL, NULL);


--
-- Name: car_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('car_id_seq', 5, true);


--
-- Data for Name: city; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO city VALUES (1, 'Гродно');


--
-- Name: city_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('city_id_seq', 1, true);


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO customer VALUES (1, 5.0, NULL, '2015-05-24 13:05:09.59');
INSERT INTO customer VALUES (3, NULL, NULL, '2015-05-24 13:33:22.888');
INSERT INTO customer VALUES (7, NULL, NULL, '2015-05-24 13:40:45.913');


--
-- Name: customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('customer_id_seq', 1, false);


--
-- Data for Name: driver; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO driver VALUES (2, 4.0, NULL, '2015-05-24 13:12:45.576');
INSERT INTO driver VALUES (5, NULL, NULL, '2015-05-24 13:35:46.038');
INSERT INTO driver VALUES (8, NULL, NULL, '2015-05-24 14:07:31.658');


--
-- Name: driver_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('driver_id_seq', 1, false);


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO orders VALUES (1, 1, 1, 2, 4, 1, 5219, 55000, 5, 5, '2015-05-24 13:20:43.578', NULL, NULL);
INSERT INTO orders VALUES (2, 1, 1, 2, 4, 1, 9037, 75000, NULL, 4, '2015-05-24 13:21:57.865', NULL, NULL);
INSERT INTO orders VALUES (3, 1, 1, 2, 4, 3, 4933, 50000, 5, 4, '2015-05-24 13:25:22.904', NULL, NULL);
INSERT INTO orders VALUES (4, 1, 1, 2, 0, 0, 3694, 45000, NULL, NULL, '2015-05-24 15:18:34.592', NULL, NULL);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('orders_id_seq', 4, true);


--
-- Data for Name: orders_timetable; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO orders_timetable VALUES (1, 1, 0, '2015-05-24 13:20:43.591');
INSERT INTO orders_timetable VALUES (2, 1, 1, '2015-05-24 13:20:50.859');
INSERT INTO orders_timetable VALUES (3, 1, 2, '2015-05-24 13:20:58.972');
INSERT INTO orders_timetable VALUES (4, 1, 3, '2015-05-24 13:21:00.681');
INSERT INTO orders_timetable VALUES (5, 1, 4, '2015-05-24 13:21:04.289');
INSERT INTO orders_timetable VALUES (6, 2, 0, '2015-05-24 13:21:57.873');
INSERT INTO orders_timetable VALUES (7, 2, 1, '2015-05-24 13:22:07.109');
INSERT INTO orders_timetable VALUES (8, 2, 2, '2015-05-24 13:24:03.549');
INSERT INTO orders_timetable VALUES (9, 2, 3, '2015-05-24 13:24:10.745');
INSERT INTO orders_timetable VALUES (10, 2, 4, '2015-05-24 13:24:12.043');
INSERT INTO orders_timetable VALUES (11, 3, 0, '2015-05-24 13:25:22.914');
INSERT INTO orders_timetable VALUES (12, 3, 4, '2015-05-24 13:26:06.884');
INSERT INTO orders_timetable VALUES (13, 4, 0, '2015-05-24 15:18:34.645');


--
-- Name: orders_timetable_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('orders_timetable_id_seq', 13, true);


--
-- Data for Name: point; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO point VALUES (1, 340, '9', NULL, NULL);
INSERT INTO point VALUES (2, 150, '24', NULL, NULL);
INSERT INTO point VALUES (3, 183, '45', NULL, NULL);
INSERT INTO point VALUES (4, 262, '9Б', NULL, NULL);
INSERT INTO point VALUES (5, 664, '14А', NULL, NULL);
INSERT INTO point VALUES (6, 189, '16', NULL, NULL);
INSERT INTO point VALUES (7, 110, '28Б', NULL, NULL);
INSERT INTO point VALUES (8, 40, '30', NULL, NULL);
INSERT INTO point VALUES (9, 396, '26', NULL, NULL);
INSERT INTO point VALUES (10, 542, '4', NULL, NULL);
INSERT INTO point VALUES (11, 657, '3', NULL, NULL);
INSERT INTO point VALUES (12, 152, '13', NULL, NULL);
INSERT INTO point VALUES (13, 87, '17', NULL, NULL);
INSERT INTO point VALUES (14, 125, '20', NULL, NULL);
INSERT INTO point VALUES (15, 656, '9', NULL, NULL);
INSERT INTO point VALUES (16, 20, '5', NULL, NULL);
INSERT INTO point VALUES (17, 464, '35', NULL, NULL);
INSERT INTO point VALUES (18, 366, '23', NULL, NULL);
INSERT INTO point VALUES (19, 25, '10', NULL, NULL);
INSERT INTO point VALUES (20, 483, '4', NULL, NULL);
INSERT INTO point VALUES (21, 552, '11', NULL, NULL);
INSERT INTO point VALUES (22, 8, '4', NULL, NULL);
INSERT INTO point VALUES (23, 518, '5', NULL, NULL);
INSERT INTO point VALUES (24, 67, '18', NULL, NULL);
INSERT INTO point VALUES (25, 604, '15/199', NULL, NULL);
INSERT INTO point VALUES (26, 161, '12', NULL, NULL);
INSERT INTO point VALUES (27, 658, '18', NULL, NULL);
INSERT INTO point VALUES (28, 373, '7', NULL, NULL);
INSERT INTO point VALUES (29, 636, '20', NULL, NULL);
INSERT INTO point VALUES (30, 496, '82', NULL, NULL);
INSERT INTO point VALUES (31, 518, '2', NULL, NULL);
INSERT INTO point VALUES (32, 585, '4', NULL, NULL);
INSERT INTO point VALUES (33, 464, '32/2', NULL, NULL);
INSERT INTO point VALUES (34, 265, '15', NULL, NULL);
INSERT INTO point VALUES (35, 254, '26', NULL, NULL);
INSERT INTO point VALUES (36, 20, '2', NULL, NULL);
INSERT INTO point VALUES (37, 372, '27', NULL, NULL);
INSERT INTO point VALUES (38, 451, '81а', NULL, NULL);
INSERT INTO point VALUES (39, 57, '14', NULL, NULL);
INSERT INTO point VALUES (40, 120, '21', NULL, NULL);
INSERT INTO point VALUES (41, 419, '16', NULL, NULL);
INSERT INTO point VALUES (42, 81, '18', NULL, NULL);
INSERT INTO point VALUES (43, 236, '142', NULL, NULL);
INSERT INTO point VALUES (44, 455, '58А', NULL, NULL);
INSERT INTO point VALUES (45, 339, '7', NULL, NULL);
INSERT INTO point VALUES (46, 268, '15', NULL, NULL);
INSERT INTO point VALUES (47, 37, '1', NULL, NULL);
INSERT INTO point VALUES (48, 643, '84', NULL, NULL);
INSERT INTO point VALUES (49, 131, '6', NULL, NULL);
INSERT INTO point VALUES (50, 137, '2', NULL, NULL);
INSERT INTO point VALUES (51, 465, '88', NULL, NULL);
INSERT INTO point VALUES (52, 415, '31/1', NULL, NULL);
INSERT INTO point VALUES (53, 130, '3', NULL, NULL);
INSERT INTO point VALUES (54, 469, '3А', NULL, NULL);
INSERT INTO point VALUES (55, 598, '20В', NULL, NULL);
INSERT INTO point VALUES (56, 283, '3', NULL, NULL);
INSERT INTO point VALUES (57, 382, '5', NULL, NULL);
INSERT INTO point VALUES (58, 213, '25', NULL, NULL);
INSERT INTO point VALUES (59, 566, '8', NULL, NULL);
INSERT INTO point VALUES (60, 464, '74', NULL, NULL);
INSERT INTO point VALUES (61, 119, '7', NULL, NULL);
INSERT INTO point VALUES (62, 584, '24', NULL, NULL);
INSERT INTO point VALUES (63, 558, '36', NULL, NULL);
INSERT INTO point VALUES (64, 542, '7А', NULL, NULL);
INSERT INTO point VALUES (65, 277, '40', NULL, NULL);
INSERT INTO point VALUES (66, 231, '17', NULL, NULL);
INSERT INTO point VALUES (67, 236, '42', NULL, NULL);
INSERT INTO point VALUES (68, 137, '5', NULL, NULL);
INSERT INTO point VALUES (69, 406, '11', NULL, NULL);
INSERT INTO point VALUES (70, 548, '45/1', NULL, NULL);
INSERT INTO point VALUES (71, 158, '10А', NULL, NULL);
INSERT INTO point VALUES (72, 601, '120А', NULL, NULL);
INSERT INTO point VALUES (73, 437, '10', NULL, NULL);
INSERT INTO point VALUES (74, 347, '27', NULL, NULL);
INSERT INTO point VALUES (75, 183, '3', NULL, NULL);
INSERT INTO point VALUES (76, 496, '1/4', NULL, NULL);
INSERT INTO point VALUES (77, 169, '39', NULL, NULL);
INSERT INTO point VALUES (78, 382, '2', NULL, NULL);
INSERT INTO point VALUES (79, 323, '27', NULL, NULL);
INSERT INTO point VALUES (80, 374, '123А', NULL, NULL);
INSERT INTO point VALUES (81, 354, '18', NULL, NULL);
INSERT INTO point VALUES (82, 435, '43А', NULL, NULL);
INSERT INTO point VALUES (83, 562, '28', NULL, NULL);
INSERT INTO point VALUES (84, 653, '59', NULL, NULL);
INSERT INTO point VALUES (85, 468, '20', NULL, NULL);
INSERT INTO point VALUES (86, 166, '39/1', NULL, NULL);
INSERT INTO point VALUES (87, 505, '21', NULL, NULL);
INSERT INTO point VALUES (88, 34, '21', NULL, NULL);
INSERT INTO point VALUES (89, 180, '31', NULL, NULL);
INSERT INTO point VALUES (90, 100, '40', NULL, NULL);
INSERT INTO point VALUES (91, 604, '15/204а', NULL, NULL);
INSERT INTO point VALUES (92, 92, '3', NULL, NULL);
INSERT INTO point VALUES (93, 170, '13', NULL, NULL);
INSERT INTO point VALUES (94, 663, '12', NULL, NULL);
INSERT INTO point VALUES (95, 19, '22', NULL, NULL);
INSERT INTO point VALUES (96, 536, '1', NULL, NULL);
INSERT INTO point VALUES (97, 447, '54', NULL, NULL);
INSERT INTO point VALUES (98, 180, '41', NULL, NULL);
INSERT INTO point VALUES (99, 44, '3', NULL, NULL);
INSERT INTO point VALUES (100, 386, '4', NULL, NULL);
INSERT INTO point VALUES (101, 654, '22', NULL, NULL);
INSERT INTO point VALUES (102, 302, '4', NULL, NULL);
INSERT INTO point VALUES (103, 27, '14', NULL, NULL);
INSERT INTO point VALUES (104, 232, '16', NULL, NULL);
INSERT INTO point VALUES (105, 523, '25', NULL, NULL);
INSERT INTO point VALUES (106, 560, '90', NULL, NULL);
INSERT INTO point VALUES (107, 277, '13/1', NULL, NULL);
INSERT INTO point VALUES (108, 104, '7', NULL, NULL);
INSERT INTO point VALUES (109, 664, '14Б', NULL, NULL);
INSERT INTO point VALUES (110, 326, '13', NULL, NULL);
INSERT INTO point VALUES (111, 76, '4', NULL, NULL);
INSERT INTO point VALUES (112, 292, '14', NULL, NULL);
INSERT INTO point VALUES (113, 334, '4', NULL, NULL);
INSERT INTO point VALUES (114, 96, '22', NULL, NULL);
INSERT INTO point VALUES (115, 115, '3', NULL, NULL);
INSERT INTO point VALUES (116, 51, '38', NULL, NULL);
INSERT INTO point VALUES (117, 536, '19', NULL, NULL);
INSERT INTO point VALUES (118, 433, '64', NULL, NULL);
INSERT INTO point VALUES (119, 421, '20А', NULL, NULL);
INSERT INTO point VALUES (120, 589, '8', NULL, NULL);
INSERT INTO point VALUES (121, 277, '46', NULL, NULL);
INSERT INTO point VALUES (122, 280, '141', NULL, NULL);
INSERT INTO point VALUES (123, 598, '46А', NULL, NULL);
INSERT INTO point VALUES (124, 303, '32/1', NULL, NULL);
INSERT INTO point VALUES (125, 464, '28Б', NULL, NULL);
INSERT INTO point VALUES (126, 455, '37', NULL, NULL);
INSERT INTO point VALUES (127, 620, '14', NULL, NULL);
INSERT INTO point VALUES (128, 548, '28', NULL, NULL);
INSERT INTO point VALUES (129, 338, '4', NULL, NULL);
INSERT INTO point VALUES (130, 601, '139', NULL, NULL);
INSERT INTO point VALUES (131, 604, '35', NULL, NULL);
INSERT INTO point VALUES (132, 447, '31', NULL, NULL);
INSERT INTO point VALUES (133, 670, '51', NULL, NULL);
INSERT INTO point VALUES (134, 489, '10', NULL, NULL);
INSERT INTO point VALUES (135, 433, '26', NULL, NULL);
INSERT INTO point VALUES (136, 95, '36', NULL, NULL);
INSERT INTO point VALUES (137, 236, '24', NULL, NULL);
INSERT INTO point VALUES (138, 317, '13', NULL, NULL);
INSERT INTO point VALUES (139, 694, '16', NULL, NULL);
INSERT INTO point VALUES (140, 192, '4', NULL, NULL);
INSERT INTO point VALUES (141, 416, '8', NULL, NULL);
INSERT INTO point VALUES (142, 245, '63', NULL, NULL);
INSERT INTO point VALUES (143, 578, '8А', NULL, NULL);
INSERT INTO point VALUES (144, 384, '14', NULL, NULL);
INSERT INTO point VALUES (145, 206, '3', NULL, NULL);
INSERT INTO point VALUES (146, 561, '12', NULL, NULL);
INSERT INTO point VALUES (147, 692, '20', NULL, NULL);
INSERT INTO point VALUES (148, 531, '11', NULL, NULL);
INSERT INTO point VALUES (149, 9, '73', NULL, NULL);
INSERT INTO point VALUES (150, 374, '103/2', NULL, NULL);
INSERT INTO point VALUES (151, 389, '18', NULL, NULL);
INSERT INTO point VALUES (152, 285, '14', NULL, NULL);
INSERT INTO point VALUES (153, 30, '11', NULL, NULL);
INSERT INTO point VALUES (154, 525, '39', NULL, NULL);
INSERT INTO point VALUES (155, 452, '14', NULL, NULL);
INSERT INTO point VALUES (156, 374, '52', NULL, NULL);
INSERT INTO point VALUES (157, 394, '38', NULL, NULL);
INSERT INTO point VALUES (158, 408, '19', NULL, NULL);
INSERT INTO point VALUES (159, 191, '46', NULL, NULL);
INSERT INTO point VALUES (160, 451, '27Б', NULL, NULL);
INSERT INTO point VALUES (161, 342, '38', NULL, NULL);
INSERT INTO point VALUES (162, 425, '7А', NULL, NULL);
INSERT INTO point VALUES (163, 295, '9', NULL, NULL);
INSERT INTO point VALUES (164, 335, '13', NULL, NULL);
INSERT INTO point VALUES (165, 174, '75', NULL, NULL);
INSERT INTO point VALUES (166, 274, '2', NULL, NULL);
INSERT INTO point VALUES (167, 444, '2', NULL, NULL);
INSERT INTO point VALUES (168, 374, '88', NULL, NULL);
INSERT INTO point VALUES (169, 114, '27', NULL, NULL);
INSERT INTO point VALUES (170, 389, '27', NULL, NULL);
INSERT INTO point VALUES (171, 468, '10', NULL, NULL);
INSERT INTO point VALUES (172, 236, '76', NULL, NULL);
INSERT INTO point VALUES (173, 531, '108', NULL, NULL);
INSERT INTO point VALUES (174, 91, '15', NULL, NULL);
INSERT INTO point VALUES (175, 578, '7', NULL, NULL);
INSERT INTO point VALUES (176, 169, '35', NULL, NULL);
INSERT INTO point VALUES (177, 496, '62', NULL, NULL);
INSERT INTO point VALUES (178, 172, '14', NULL, NULL);
INSERT INTO point VALUES (179, 421, '29', NULL, NULL);
INSERT INTO point VALUES (180, 474, '2', NULL, NULL);
INSERT INTO point VALUES (181, 333, '7', NULL, NULL);
INSERT INTO point VALUES (182, 304, '25', NULL, NULL);
INSERT INTO point VALUES (183, 223, '11', NULL, NULL);
INSERT INTO point VALUES (184, 477, '12', NULL, NULL);
INSERT INTO point VALUES (185, 277, '13А', NULL, NULL);
INSERT INTO point VALUES (186, 525, '34', NULL, NULL);
INSERT INTO point VALUES (187, 82, '8', NULL, NULL);
INSERT INTO point VALUES (188, 604, '15/218', NULL, NULL);
INSERT INTO point VALUES (189, 694, '6', NULL, NULL);
INSERT INTO point VALUES (190, 303, '43', NULL, NULL);
INSERT INTO point VALUES (191, 57, '1', NULL, NULL);
INSERT INTO point VALUES (192, 369, '49', NULL, NULL);
INSERT INTO point VALUES (193, 37, '14', NULL, NULL);
INSERT INTO point VALUES (194, 433, '5', NULL, NULL);
INSERT INTO point VALUES (195, 396, '29', NULL, NULL);
INSERT INTO point VALUES (196, 261, '15', NULL, NULL);
INSERT INTO point VALUES (197, 464, '39', NULL, NULL);
INSERT INTO point VALUES (198, 183, '52/22', NULL, NULL);
INSERT INTO point VALUES (199, 181, '32', NULL, NULL);
INSERT INTO point VALUES (200, 329, '42', NULL, NULL);
INSERT INTO point VALUES (201, 594, '46', NULL, NULL);
INSERT INTO point VALUES (202, 643, '56', NULL, NULL);
INSERT INTO point VALUES (203, 46, '15', NULL, NULL);
INSERT INTO point VALUES (204, 67, '104А', NULL, NULL);
INSERT INTO point VALUES (205, 497, '13', NULL, NULL);
INSERT INTO point VALUES (206, 664, '26/1', NULL, NULL);
INSERT INTO point VALUES (207, 324, '26', NULL, NULL);
INSERT INTO point VALUES (208, 50, '33', NULL, NULL);
INSERT INTO point VALUES (209, 310, '40', NULL, NULL);
INSERT INTO point VALUES (210, 235, '17', NULL, NULL);
INSERT INTO point VALUES (211, 146, '23', NULL, NULL);
INSERT INTO point VALUES (212, 395, '15А', NULL, NULL);
INSERT INTO point VALUES (213, 168, '22', NULL, NULL);
INSERT INTO point VALUES (214, 566, '32', NULL, NULL);
INSERT INTO point VALUES (215, 40, '21', NULL, NULL);
INSERT INTO point VALUES (216, 696, '15', NULL, NULL);
INSERT INTO point VALUES (217, 496, 'a', NULL, NULL);
INSERT INTO point VALUES (218, 203, '33', NULL, NULL);
INSERT INTO point VALUES (219, 265, '22', NULL, NULL);
INSERT INTO point VALUES (220, 521, '3', NULL, NULL);
INSERT INTO point VALUES (221, 435, '37', NULL, NULL);
INSERT INTO point VALUES (222, 61, '36', NULL, NULL);
INSERT INTO point VALUES (223, 70, '38', NULL, NULL);
INSERT INTO point VALUES (224, 25, '20', NULL, NULL);
INSERT INTO point VALUES (225, 496, '27/2', NULL, NULL);
INSERT INTO point VALUES (226, 594, '40', NULL, NULL);
INSERT INTO point VALUES (227, 203, '66', NULL, NULL);
INSERT INTO point VALUES (228, 183, '52/15', NULL, NULL);
INSERT INTO point VALUES (229, 692, '10', NULL, NULL);
INSERT INTO point VALUES (230, 390, '3', NULL, NULL);
INSERT INTO point VALUES (231, 462, '14', NULL, NULL);
INSERT INTO point VALUES (232, 231, '1/1', NULL, NULL);
INSERT INTO point VALUES (233, 78, '21', NULL, NULL);
INSERT INTO point VALUES (234, 189, '6', NULL, NULL);
INSERT INTO point VALUES (235, 99, '3', NULL, NULL);
INSERT INTO point VALUES (236, 643, '43', NULL, NULL);
INSERT INTO point VALUES (237, 323, '18', NULL, NULL);
INSERT INTO point VALUES (238, 178, '8', NULL, NULL);
INSERT INTO point VALUES (239, 604, '39', NULL, NULL);
INSERT INTO point VALUES (240, 525, '35', NULL, NULL);
INSERT INTO point VALUES (241, 531, '198', NULL, NULL);
INSERT INTO point VALUES (242, 53, '50', NULL, NULL);
INSERT INTO point VALUES (243, 250, '63-119а', NULL, NULL);
INSERT INTO point VALUES (244, 294, '206', NULL, NULL);
INSERT INTO point VALUES (245, 531, '238', NULL, NULL);
INSERT INTO point VALUES (246, 262, '17', NULL, NULL);
INSERT INTO point VALUES (247, 32, '7', NULL, NULL);
INSERT INTO point VALUES (248, 303, '6', NULL, NULL);
INSERT INTO point VALUES (249, 27, '19', NULL, NULL);
INSERT INTO point VALUES (250, 496, '6/2', NULL, NULL);
INSERT INTO point VALUES (251, 389, '23Б', NULL, NULL);
INSERT INTO point VALUES (252, 169, '34', NULL, NULL);
INSERT INTO point VALUES (253, 535, '10', NULL, NULL);
INSERT INTO point VALUES (254, 254, '5', NULL, NULL);
INSERT INTO point VALUES (255, 625, '5', NULL, NULL);
INSERT INTO point VALUES (256, 75, '53', NULL, NULL);
INSERT INTO point VALUES (257, 496, '59', NULL, NULL);
INSERT INTO point VALUES (258, 620, '1', NULL, NULL);
INSERT INTO point VALUES (259, 658, '27', NULL, NULL);
INSERT INTO point VALUES (260, 250, '82А', NULL, NULL);
INSERT INTO point VALUES (261, 214, '1', NULL, NULL);
INSERT INTO point VALUES (262, 260, '4', NULL, NULL);
INSERT INTO point VALUES (263, 100, '79', NULL, NULL);
INSERT INTO point VALUES (264, 465, '13', NULL, NULL);
INSERT INTO point VALUES (265, 19, '15', NULL, NULL);
INSERT INTO point VALUES (266, 601, '78', NULL, NULL);
INSERT INTO point VALUES (267, 582, '30', NULL, NULL);
INSERT INTO point VALUES (268, 405, '9', NULL, NULL);
INSERT INTO point VALUES (269, 419, '6', NULL, NULL);
INSERT INTO point VALUES (270, 285, '19', NULL, NULL);
INSERT INTO point VALUES (271, 191, '40', NULL, NULL);
INSERT INTO point VALUES (272, 654, '15', NULL, NULL);
INSERT INTO point VALUES (273, 455, '72', NULL, NULL);
INSERT INTO point VALUES (274, 329, '44', NULL, NULL);
INSERT INTO point VALUES (275, 384, '1', NULL, NULL);
INSERT INTO point VALUES (276, 601, '141А', NULL, NULL);
INSERT INTO point VALUES (277, 480, '6', NULL, NULL);
INSERT INTO point VALUES (278, 687, '14', NULL, NULL);
INSERT INTO point VALUES (279, 188, '4', NULL, NULL);
INSERT INTO point VALUES (280, 375, '34', NULL, NULL);
INSERT INTO point VALUES (281, 620, '19', NULL, NULL);
INSERT INTO point VALUES (282, 434, '17', NULL, NULL);
INSERT INTO point VALUES (283, 250, '22', NULL, NULL);
INSERT INTO point VALUES (284, 329, '24', NULL, NULL);
INSERT INTO point VALUES (285, 531, '49', NULL, NULL);
INSERT INTO point VALUES (286, 572, '31', NULL, NULL);
INSERT INTO point VALUES (287, 480, '56', NULL, NULL);
INSERT INTO point VALUES (288, 153, '6', NULL, NULL);
INSERT INTO point VALUES (289, 492, '5', NULL, NULL);
INSERT INTO point VALUES (290, 299, '24', NULL, NULL);
INSERT INTO point VALUES (291, 561, '51', NULL, NULL);
INSERT INTO point VALUES (292, 294, '240А', NULL, NULL);
INSERT INTO point VALUES (293, 277, '3б', NULL, NULL);
INSERT INTO point VALUES (294, 411, '19', NULL, NULL);
INSERT INTO point VALUES (295, 295, '18', NULL, NULL);
INSERT INTO point VALUES (296, 573, '9', NULL, NULL);
INSERT INTO point VALUES (297, 98, '11', NULL, NULL);
INSERT INTO point VALUES (298, 367, '17', NULL, NULL);
INSERT INTO point VALUES (299, 572, '40', NULL, NULL);
INSERT INTO point VALUES (300, 544, '16', NULL, NULL);
INSERT INTO point VALUES (301, 183, '59', NULL, NULL);
INSERT INTO point VALUES (302, 110, '25', NULL, NULL);
INSERT INTO point VALUES (303, 67, '146', NULL, NULL);
INSERT INTO point VALUES (304, 552, '37', NULL, NULL);
INSERT INTO point VALUES (305, 291, '9', NULL, NULL);
INSERT INTO point VALUES (306, 604, '186', NULL, NULL);
INSERT INTO point VALUES (307, 374, '35/1', NULL, NULL);
INSERT INTO point VALUES (308, 120, '38', NULL, NULL);
INSERT INTO point VALUES (309, 525, '8', NULL, NULL);
INSERT INTO point VALUES (310, 236, '93', NULL, NULL);
INSERT INTO point VALUES (311, 170, '4/3', NULL, NULL);
INSERT INTO point VALUES (312, 531, '68', NULL, NULL);
INSERT INTO point VALUES (313, 376, '61А', NULL, NULL);
INSERT INTO point VALUES (314, 429, '3', NULL, NULL);
INSERT INTO point VALUES (315, 594, '54', NULL, NULL);
INSERT INTO point VALUES (316, 139, '9/3', NULL, NULL);
INSERT INTO point VALUES (317, 12, '36', NULL, NULL);
INSERT INTO point VALUES (318, 186, '11', NULL, NULL);
INSERT INTO point VALUES (319, 496, '75', NULL, NULL);
INSERT INTO point VALUES (320, 383, '19', NULL, NULL);
INSERT INTO point VALUES (321, 208, '20', NULL, NULL);
INSERT INTO point VALUES (322, 564, '6', NULL, NULL);
INSERT INTO point VALUES (323, 372, '20А', NULL, NULL);
INSERT INTO point VALUES (324, 236, '22', NULL, NULL);
INSERT INTO point VALUES (325, 451, '8', NULL, NULL);
INSERT INTO point VALUES (326, 563, '18', NULL, NULL);
INSERT INTO point VALUES (327, 663, '20', NULL, NULL);
INSERT INTO point VALUES (328, 643, '12', NULL, NULL);
INSERT INTO point VALUES (329, 342, '30', NULL, NULL);
INSERT INTO point VALUES (330, 310, '38', NULL, NULL);
INSERT INTO point VALUES (331, 170, '15А', NULL, NULL);
INSERT INTO point VALUES (332, 263, '4Б', NULL, NULL);
INSERT INTO point VALUES (333, 304, '69', NULL, NULL);
INSERT INTO point VALUES (334, 191, '31', NULL, NULL);
INSERT INTO point VALUES (335, 151, '4', NULL, NULL);
INSERT INTO point VALUES (336, 366, '17', NULL, NULL);
INSERT INTO point VALUES (337, 262, '25', NULL, NULL);
INSERT INTO point VALUES (338, 643, '58', NULL, NULL);
INSERT INTO point VALUES (339, 74, '9а', NULL, NULL);
INSERT INTO point VALUES (340, 561, '16', NULL, NULL);
INSERT INTO point VALUES (341, 49, '13', NULL, NULL);
INSERT INTO point VALUES (342, 438, '15', NULL, NULL);
INSERT INTO point VALUES (343, 250, '2/1', NULL, NULL);
INSERT INTO point VALUES (344, 393, '14', NULL, NULL);
INSERT INTO point VALUES (345, 270, '4', NULL, NULL);
INSERT INTO point VALUES (346, 74, '6', NULL, NULL);
INSERT INTO point VALUES (347, 67, '51/1', NULL, NULL);
INSERT INTO point VALUES (348, 23, '8', NULL, NULL);
INSERT INTO point VALUES (349, 169, '23', NULL, NULL);
INSERT INTO point VALUES (350, 87, '23', NULL, NULL);
INSERT INTO point VALUES (351, 523, '29А', NULL, NULL);
INSERT INTO point VALUES (352, 539, '22', NULL, NULL);
INSERT INTO point VALUES (353, 548, '59', NULL, NULL);
INSERT INTO point VALUES (354, 561, '20', NULL, NULL);
INSERT INTO point VALUES (355, 303, '1А', NULL, NULL);
INSERT INTO point VALUES (356, 342, '40', NULL, NULL);
INSERT INTO point VALUES (357, 294, '162', NULL, NULL);
INSERT INTO point VALUES (358, 560, '94', NULL, NULL);
INSERT INTO point VALUES (359, 692, '12', NULL, NULL);
INSERT INTO point VALUES (360, 231, '23', NULL, NULL);
INSERT INTO point VALUES (361, 311, '16', NULL, NULL);
INSERT INTO point VALUES (362, 601, '145', NULL, NULL);
INSERT INTO point VALUES (363, 329, '15', NULL, NULL);
INSERT INTO point VALUES (364, 656, '4А', NULL, NULL);
INSERT INTO point VALUES (365, 96, '24', NULL, NULL);
INSERT INTO point VALUES (366, 598, '18А', NULL, NULL);
INSERT INTO point VALUES (367, 494, '3', NULL, NULL);
INSERT INTO point VALUES (368, 208, '16', NULL, NULL);
INSERT INTO point VALUES (369, 250, '63-317', NULL, NULL);
INSERT INTO point VALUES (370, 643, '57', NULL, NULL);
INSERT INTO point VALUES (371, 511, '6', NULL, NULL);
INSERT INTO point VALUES (372, 299, '15', NULL, NULL);
INSERT INTO point VALUES (373, 99, '8/1', NULL, NULL);
INSERT INTO point VALUES (374, 262, '7', NULL, NULL);
INSERT INTO point VALUES (375, 205, '5', NULL, NULL);
INSERT INTO point VALUES (376, 183, '42А', NULL, NULL);
INSERT INTO point VALUES (377, 374, '133', NULL, NULL);
INSERT INTO point VALUES (378, 663, '16', NULL, NULL);
INSERT INTO point VALUES (379, 389, '5', NULL, NULL);
INSERT INTO point VALUES (380, 693, '21', NULL, NULL);
INSERT INTO point VALUES (381, 496, '60', NULL, NULL);
INSERT INTO point VALUES (382, 434, '32', NULL, NULL);
INSERT INTO point VALUES (383, 171, '11А', NULL, NULL);
INSERT INTO point VALUES (384, 19, '24', NULL, NULL);
INSERT INTO point VALUES (385, 375, '23', NULL, NULL);
INSERT INTO point VALUES (386, 654, '33', NULL, NULL);
INSERT INTO point VALUES (387, 236, '77', NULL, NULL);
INSERT INTO point VALUES (388, 23, '11А', NULL, NULL);
INSERT INTO point VALUES (389, 250, '72/4', NULL, NULL);
INSERT INTO point VALUES (390, 572, '30', NULL, NULL);
INSERT INTO point VALUES (391, 269, '29', NULL, NULL);
INSERT INTO point VALUES (392, 88, '9', NULL, NULL);
INSERT INTO point VALUES (393, 560, '43', NULL, NULL);
INSERT INTO point VALUES (394, 670, '43', NULL, NULL);
INSERT INTO point VALUES (395, 110, '7', NULL, NULL);
INSERT INTO point VALUES (396, 447, '79', NULL, NULL);
INSERT INTO point VALUES (397, 409, '2', NULL, NULL);
INSERT INTO point VALUES (398, 334, '37', NULL, NULL);
INSERT INTO point VALUES (399, 604, '204', NULL, NULL);
INSERT INTO point VALUES (400, 315, '18', NULL, NULL);
INSERT INTO point VALUES (401, 170, '4/1', NULL, NULL);
INSERT INTO point VALUES (402, 376, '28', NULL, NULL);
INSERT INTO point VALUES (403, 389, '2', NULL, NULL);
INSERT INTO point VALUES (404, 653, '45', NULL, NULL);
INSERT INTO point VALUES (405, 477, '6', NULL, NULL);
INSERT INTO point VALUES (406, 67, '29', NULL, NULL);
INSERT INTO point VALUES (407, 279, '63', NULL, NULL);
INSERT INTO point VALUES (408, 146, '35', NULL, NULL);
INSERT INTO point VALUES (409, 678, '13', NULL, NULL);
INSERT INTO point VALUES (410, 435, '49', NULL, NULL);
INSERT INTO point VALUES (411, 434, '25', NULL, NULL);
INSERT INTO point VALUES (412, 234, '18', NULL, NULL);
INSERT INTO point VALUES (413, 535, '12', NULL, NULL);
INSERT INTO point VALUES (414, 362, '10', NULL, NULL);
INSERT INTO point VALUES (415, 654, '24', NULL, NULL);
INSERT INTO point VALUES (416, 67, '61', NULL, NULL);
INSERT INTO point VALUES (417, 447, '48', NULL, NULL);
INSERT INTO point VALUES (418, 205, '2', NULL, NULL);
INSERT INTO point VALUES (419, 544, '20', NULL, NULL);
INSERT INTO point VALUES (420, 658, '5', NULL, NULL);
INSERT INTO point VALUES (421, 304, '67', NULL, NULL);
INSERT INTO point VALUES (422, 681, '18', NULL, NULL);
INSERT INTO point VALUES (423, 215, '73', NULL, NULL);
INSERT INTO point VALUES (424, 376, '45', NULL, NULL);
INSERT INTO point VALUES (425, 455, '50', NULL, NULL);
INSERT INTO point VALUES (426, 653, '28', NULL, NULL);
INSERT INTO point VALUES (427, 480, '58', NULL, NULL);
INSERT INTO point VALUES (428, 447, '83', NULL, NULL);
INSERT INTO point VALUES (429, 347, '9', NULL, NULL);
INSERT INTO point VALUES (430, 334, '31/2', NULL, NULL);
INSERT INTO point VALUES (431, 303, '57', NULL, NULL);
INSERT INTO point VALUES (432, 469, '1', NULL, NULL);
INSERT INTO point VALUES (433, 49, '19', NULL, NULL);
INSERT INTO point VALUES (434, 531, '25б', NULL, NULL);
INSERT INTO point VALUES (435, 269, '2', NULL, NULL);
INSERT INTO point VALUES (436, 161, '20', NULL, NULL);
INSERT INTO point VALUES (437, 641, '14', NULL, NULL);
INSERT INTO point VALUES (438, 235, '7', NULL, NULL);
INSERT INTO point VALUES (439, 114, '29', NULL, NULL);
INSERT INTO point VALUES (440, 419, '12', NULL, NULL);
INSERT INTO point VALUES (441, 342, '46', NULL, NULL);
INSERT INTO point VALUES (442, 451, '38А', NULL, NULL);
INSERT INTO point VALUES (443, 389, '29', NULL, NULL);
INSERT INTO point VALUES (444, 473, '17', NULL, NULL);
INSERT INTO point VALUES (445, 425, '44В', NULL, NULL);
INSERT INTO point VALUES (446, 472, '20', NULL, NULL);
INSERT INTO point VALUES (447, 67, '2', NULL, NULL);
INSERT INTO point VALUES (448, 248, '15', NULL, NULL);
INSERT INTO point VALUES (449, 569, '24', NULL, NULL);
INSERT INTO point VALUES (450, 191, '38', NULL, NULL);
INSERT INTO point VALUES (451, 598, '20', NULL, NULL);
INSERT INTO point VALUES (452, 169, '8', NULL, NULL);
INSERT INTO point VALUES (453, 534, '5', NULL, NULL);
INSERT INTO point VALUES (454, 451, '8А', NULL, NULL);
INSERT INTO point VALUES (455, 564, '10', NULL, NULL);
INSERT INTO point VALUES (456, 394, '21', NULL, NULL);
INSERT INTO point VALUES (457, 227, '23', NULL, NULL);
INSERT INTO point VALUES (458, 139, '9/1', NULL, NULL);
INSERT INTO point VALUES (459, 176, '20', NULL, NULL);
INSERT INTO point VALUES (460, 269, '5', NULL, NULL);
INSERT INTO point VALUES (461, 458, '60', NULL, NULL);
INSERT INTO point VALUES (462, 658, '2', NULL, NULL);
INSERT INTO point VALUES (463, 431, '20', NULL, NULL);
INSERT INTO point VALUES (464, 215, '55', NULL, NULL);
INSERT INTO point VALUES (465, 304, '17', NULL, NULL);
INSERT INTO point VALUES (466, 394, '32А', NULL, NULL);
INSERT INTO point VALUES (467, 415, '59', NULL, NULL);
INSERT INTO point VALUES (468, 509, '10', NULL, NULL);
INSERT INTO point VALUES (469, 49, '1', NULL, NULL);
INSERT INTO point VALUES (470, 74, '10', NULL, NULL);
INSERT INTO point VALUES (471, 504, '4', NULL, NULL);
INSERT INTO point VALUES (472, 445, '13', NULL, NULL);
INSERT INTO point VALUES (473, 120, '31', NULL, NULL);
INSERT INTO point VALUES (474, 425, '44А', NULL, NULL);
INSERT INTO point VALUES (475, 425, '72', NULL, NULL);
INSERT INTO point VALUES (476, 411, '13', NULL, NULL);
INSERT INTO point VALUES (477, 51, '48', NULL, NULL);
INSERT INTO point VALUES (478, 273, '7', NULL, NULL);
INSERT INTO point VALUES (479, 125, '12', NULL, NULL);
INSERT INTO point VALUES (480, 323, '26', NULL, NULL);
INSERT INTO point VALUES (481, 556, '39', NULL, NULL);
INSERT INTO point VALUES (482, 120, '41', NULL, NULL);
INSERT INTO point VALUES (483, 20, '18', NULL, NULL);
INSERT INTO point VALUES (484, 117, '14', NULL, NULL);
INSERT INTO point VALUES (485, 451, '60/6', NULL, NULL);
INSERT INTO point VALUES (486, 525, '23', NULL, NULL);
INSERT INTO point VALUES (487, 542, '37', NULL, NULL);
INSERT INTO point VALUES (488, 674, '4', NULL, NULL);
INSERT INTO point VALUES (489, 48, '118', NULL, NULL);
INSERT INTO point VALUES (490, 170, '3А', NULL, NULL);
INSERT INTO point VALUES (491, 67, '150', NULL, NULL);
INSERT INTO point VALUES (492, 411, '52', NULL, NULL);
INSERT INTO point VALUES (493, 502, '13А', NULL, NULL);
INSERT INTO point VALUES (494, 95, '29', NULL, NULL);
INSERT INTO point VALUES (495, 696, '33', NULL, NULL);
INSERT INTO point VALUES (496, 175, '6', NULL, NULL);
INSERT INTO point VALUES (497, 40, '17А', NULL, NULL);
INSERT INTO point VALUES (498, 203, '15', NULL, NULL);
INSERT INTO point VALUES (499, 98, '4', NULL, NULL);
INSERT INTO point VALUES (500, 396, '27', NULL, NULL);
INSERT INTO point VALUES (501, 304, '39', NULL, NULL);
INSERT INTO point VALUES (502, 546, '15/183а', NULL, NULL);
INSERT INTO point VALUES (503, 594, '38', NULL, NULL);
INSERT INTO point VALUES (504, 678, '19', NULL, NULL);
INSERT INTO point VALUES (505, 236, '59В', NULL, NULL);
INSERT INTO point VALUES (506, 137, '18', NULL, NULL);
INSERT INTO point VALUES (507, 538, '22', NULL, NULL);
INSERT INTO point VALUES (508, 682, '9', NULL, NULL);
INSERT INTO point VALUES (509, 405, '18', NULL, NULL);
INSERT INTO point VALUES (510, 176, '16', NULL, NULL);
INSERT INTO point VALUES (511, 189, '12', NULL, NULL);
INSERT INTO point VALUES (512, 50, '15', NULL, NULL);
INSERT INTO point VALUES (513, 483, '37', NULL, NULL);
INSERT INTO point VALUES (514, 503, '13', NULL, NULL);
INSERT INTO point VALUES (515, 372, '9', NULL, NULL);
INSERT INTO point VALUES (516, 268, '2/1', NULL, NULL);
INSERT INTO point VALUES (517, 356, '14', NULL, NULL);
INSERT INTO point VALUES (518, 280, '45', NULL, NULL);
INSERT INTO point VALUES (519, 267, '5', NULL, NULL);
INSERT INTO point VALUES (520, 200, '1', NULL, NULL);
INSERT INTO point VALUES (521, 157, '13', NULL, NULL);
INSERT INTO point VALUES (522, 572, '46', NULL, NULL);
INSERT INTO point VALUES (523, 321, '38', NULL, NULL);
INSERT INTO point VALUES (524, 458, '75', NULL, NULL);
INSERT INTO point VALUES (525, 468, '12', NULL, NULL);
INSERT INTO point VALUES (526, 246, '5', NULL, NULL);
INSERT INTO point VALUES (527, 45, '9', NULL, NULL);
INSERT INTO point VALUES (528, 643, '85', NULL, NULL);
INSERT INTO point VALUES (529, 250, '76', NULL, NULL);
INSERT INTO point VALUES (530, 571, '14', NULL, NULL);
INSERT INTO point VALUES (531, 465, '114', NULL, NULL);
INSERT INTO point VALUES (532, 531, '37', NULL, NULL);
INSERT INTO point VALUES (533, 601, '36', NULL, NULL);
INSERT INTO point VALUES (534, 472, '16', NULL, NULL);
INSERT INTO point VALUES (535, 376, '3', NULL, NULL);
INSERT INTO point VALUES (536, 660, '21', NULL, NULL);
INSERT INTO point VALUES (537, 338, '70', NULL, NULL);
INSERT INTO point VALUES (538, 345, '20', NULL, NULL);
INSERT INTO point VALUES (539, 81, '5', NULL, NULL);
INSERT INTO point VALUES (540, 515, '3', NULL, NULL);
INSERT INTO point VALUES (541, 303, '58', NULL, NULL);
INSERT INTO point VALUES (542, 213, '35', NULL, NULL);
INSERT INTO point VALUES (543, 351, '7', NULL, NULL);
INSERT INTO point VALUES (544, 267, '2', NULL, NULL);
INSERT INTO point VALUES (545, 270, '11', NULL, NULL);
INSERT INTO point VALUES (546, 582, '38', NULL, NULL);
INSERT INTO point VALUES (547, 477, '10', NULL, NULL);
INSERT INTO point VALUES (548, 246, '2', NULL, NULL);
INSERT INTO point VALUES (549, 303, '12', NULL, NULL);
INSERT INTO point VALUES (550, 235, '25', NULL, NULL);
INSERT INTO point VALUES (551, 53, '72', NULL, NULL);
INSERT INTO point VALUES (552, 338, '68', NULL, NULL);
INSERT INTO point VALUES (553, 161, '16', NULL, NULL);
INSERT INTO point VALUES (554, 699, '6', NULL, NULL);
INSERT INTO point VALUES (555, 473, '39', NULL, NULL);
INSERT INTO point VALUES (556, 372, '26', NULL, NULL);
INSERT INTO point VALUES (557, 464, '30А', NULL, NULL);
INSERT INTO point VALUES (558, 245, '9', NULL, NULL);
INSERT INTO point VALUES (559, 362, '6', NULL, NULL);
INSERT INTO point VALUES (560, 294, '218', NULL, NULL);
INSERT INTO point VALUES (561, 340, '18', NULL, NULL);
INSERT INTO point VALUES (562, 304, '34', NULL, NULL);
INSERT INTO point VALUES (563, 184, '11', NULL, NULL);
INSERT INTO point VALUES (564, 24, '11', NULL, NULL);
INSERT INTO point VALUES (565, 560, '16', NULL, NULL);
INSERT INTO point VALUES (566, 389, '20А', NULL, NULL);
INSERT INTO point VALUES (567, 294, '240', NULL, NULL);
INSERT INTO point VALUES (568, 658, '26', NULL, NULL);
INSERT INTO point VALUES (569, 131, '12', NULL, NULL);
INSERT INTO point VALUES (570, 23, '32', NULL, NULL);
INSERT INTO point VALUES (571, 345, '6', NULL, NULL);
INSERT INTO point VALUES (572, 269, '9', NULL, NULL);
INSERT INTO point VALUES (573, 88, '29', NULL, NULL);
INSERT INTO point VALUES (574, 489, '12', NULL, NULL);
INSERT INTO point VALUES (575, 525, '25', NULL, NULL);
INSERT INTO point VALUES (576, 534, '9', NULL, NULL);
INSERT INTO point VALUES (577, 180, '30', NULL, NULL);
INSERT INTO point VALUES (578, 250, '24', NULL, NULL);
INSERT INTO point VALUES (579, 342, '48', NULL, NULL);
INSERT INTO point VALUES (580, 278, '11', NULL, NULL);
INSERT INTO point VALUES (581, 299, '22', NULL, NULL);
INSERT INTO point VALUES (582, 531, '172', NULL, NULL);
INSERT INTO point VALUES (583, 376, '60', NULL, NULL);
INSERT INTO point VALUES (584, 306, '6', NULL, NULL);
INSERT INTO point VALUES (585, 364, '21', NULL, NULL);
INSERT INTO point VALUES (586, 325, '3', NULL, NULL);
INSERT INTO point VALUES (587, 600, '59А', NULL, NULL);
INSERT INTO point VALUES (588, 250, '33', NULL, NULL);
INSERT INTO point VALUES (589, 338, '72', NULL, NULL);
INSERT INTO point VALUES (590, 142, '3', NULL, NULL);
INSERT INTO point VALUES (591, 362, '20', NULL, NULL);
INSERT INTO point VALUES (592, 495, '7', NULL, NULL);
INSERT INTO point VALUES (593, 67, '80', NULL, NULL);
INSERT INTO point VALUES (594, 110, '8', NULL, NULL);
INSERT INTO point VALUES (595, 572, '21', NULL, NULL);
INSERT INTO point VALUES (596, 544, '10', NULL, NULL);
INSERT INTO point VALUES (597, 67, '9', NULL, NULL);
INSERT INTO point VALUES (598, 464, '38А', NULL, NULL);
INSERT INTO point VALUES (599, 693, '30', NULL, NULL);
INSERT INTO point VALUES (600, 352, '46', NULL, NULL);
INSERT INTO point VALUES (601, 561, '10', NULL, NULL);
INSERT INTO point VALUES (602, 615, '6', NULL, NULL);
INSERT INTO point VALUES (603, 117, '13', NULL, NULL);
INSERT INTO point VALUES (604, 525, '32', NULL, NULL);
INSERT INTO point VALUES (605, 411, '14', NULL, NULL);
INSERT INTO point VALUES (606, 256, '11', NULL, NULL);
INSERT INTO point VALUES (607, 531, '230', NULL, NULL);
INSERT INTO point VALUES (608, 347, '5', NULL, NULL);
INSERT INTO point VALUES (609, 658, '9', NULL, NULL);
INSERT INTO point VALUES (610, 277, '38', NULL, NULL);
INSERT INTO point VALUES (611, 67, '154', NULL, NULL);
INSERT INTO point VALUES (612, 393, '1', NULL, NULL);
INSERT INTO point VALUES (613, 600, '50', NULL, NULL);
INSERT INTO point VALUES (614, 441, '1', NULL, NULL);
INSERT INTO point VALUES (615, 280, '75', NULL, NULL);
INSERT INTO point VALUES (616, 265, '42', NULL, NULL);
INSERT INTO point VALUES (617, 643, '51', NULL, NULL);
INSERT INTO point VALUES (618, 51, '46', NULL, NULL);
INSERT INTO point VALUES (619, 208, '43', NULL, NULL);
INSERT INTO point VALUES (620, 496, '28', NULL, NULL);
INSERT INTO point VALUES (621, 548, '45/7', NULL, NULL);
INSERT INTO point VALUES (622, 252, '3', NULL, NULL);
INSERT INTO point VALUES (623, 283, '8-21', NULL, NULL);
INSERT INTO point VALUES (624, 478, '45', NULL, NULL);
INSERT INTO point VALUES (625, 435, '50', NULL, NULL);
INSERT INTO point VALUES (626, 512, '4/1', NULL, NULL);
INSERT INTO point VALUES (627, 71, '3', NULL, NULL);
INSERT INTO point VALUES (628, 12, '189', NULL, NULL);
INSERT INTO point VALUES (629, 421, '18', NULL, NULL);
INSERT INTO point VALUES (630, 176, '6', NULL, NULL);
INSERT INTO point VALUES (631, 425, '70', NULL, NULL);
INSERT INTO point VALUES (632, 157, '14', NULL, NULL);
INSERT INTO point VALUES (633, 531, '234', NULL, NULL);
INSERT INTO point VALUES (634, 208, '10', NULL, NULL);
INSERT INTO point VALUES (635, 235, '23', NULL, NULL);
INSERT INTO point VALUES (636, 602, '25/3', NULL, NULL);
INSERT INTO point VALUES (637, 146, '17', NULL, NULL);
INSERT INTO point VALUES (638, 460, '1', NULL, NULL);
INSERT INTO point VALUES (639, 663, '10', NULL, NULL);
INSERT INTO point VALUES (640, 626, '3', NULL, NULL);
INSERT INTO point VALUES (641, 280, '60', NULL, NULL);
INSERT INTO point VALUES (642, 373, '69', NULL, NULL);
INSERT INTO point VALUES (643, 112, '11', NULL, NULL);
INSERT INTO point VALUES (644, 501, '26', NULL, NULL);
INSERT INTO point VALUES (645, 45, '5', NULL, NULL);
INSERT INTO point VALUES (646, 598, '56', NULL, NULL);
INSERT INTO point VALUES (647, 561, '43', NULL, NULL);
INSERT INTO point VALUES (648, 342, '21', NULL, NULL);
INSERT INTO point VALUES (649, 279, '18', NULL, NULL);
INSERT INTO point VALUES (650, 464, '50Г', NULL, NULL);
INSERT INTO point VALUES (651, 117, '52', NULL, NULL);
INSERT INTO point VALUES (652, 133, '18', NULL, NULL);
INSERT INTO point VALUES (653, 512, '4/3', NULL, NULL);
INSERT INTO point VALUES (654, 425, '68', NULL, NULL);
INSERT INTO point VALUES (655, 572, '13А', NULL, NULL);
INSERT INTO point VALUES (656, 67, '64', NULL, NULL);
INSERT INTO point VALUES (657, 395, '1', NULL, NULL);
INSERT INTO point VALUES (658, 181, '34', NULL, NULL);
INSERT INTO point VALUES (659, 458, '3', NULL, NULL);
INSERT INTO point VALUES (660, 294, '15', NULL, NULL);
INSERT INTO point VALUES (661, 220, '6', NULL, NULL);
INSERT INTO point VALUES (662, 572, '48', NULL, NULL);
INSERT INTO point VALUES (663, 629, '3', NULL, NULL);
INSERT INTO point VALUES (664, 26, '28', NULL, NULL);
INSERT INTO point VALUES (665, 100, '31', NULL, NULL);
INSERT INTO point VALUES (666, 236, '15', NULL, NULL);
INSERT INTO point VALUES (667, 180, '40', NULL, NULL);
INSERT INTO point VALUES (668, 528, '10', NULL, NULL);
INSERT INTO point VALUES (669, 362, '16', NULL, NULL);
INSERT INTO point VALUES (670, 681, '27', NULL, NULL);
INSERT INTO point VALUES (671, 161, '6', NULL, NULL);
INSERT INTO point VALUES (672, 146, '67', NULL, NULL);
INSERT INTO point VALUES (673, 525, '7', NULL, NULL);
INSERT INTO point VALUES (674, 434, '8', NULL, NULL);
INSERT INTO point VALUES (675, 376, '75', NULL, NULL);
INSERT INTO point VALUES (676, 100, '41', NULL, NULL);
INSERT INTO point VALUES (677, 227, '7', NULL, NULL);
INSERT INTO point VALUES (678, 171, '7', NULL, NULL);
INSERT INTO point VALUES (679, 604, '8', NULL, NULL);
INSERT INTO point VALUES (680, 438, '22', NULL, NULL);
INSERT INTO point VALUES (681, 601, '92', NULL, NULL);
INSERT INTO point VALUES (682, 395, '19', NULL, NULL);
INSERT INTO point VALUES (683, 458, '111', NULL, NULL);
INSERT INTO point VALUES (684, 61, '29', NULL, NULL);
INSERT INTO point VALUES (685, 183, '6А', NULL, NULL);
INSERT INTO point VALUES (686, 296, '3', NULL, NULL);
INSERT INTO point VALUES (687, 254, '36', NULL, NULL);
INSERT INTO point VALUES (688, 267, '9', NULL, NULL);
INSERT INTO point VALUES (689, 560, '20', NULL, NULL);
INSERT INTO point VALUES (690, 78, '31', NULL, NULL);
INSERT INTO point VALUES (691, 291, '29', NULL, NULL);
INSERT INTO point VALUES (692, 695, '4', NULL, NULL);
INSERT INTO point VALUES (693, 372, '5', NULL, NULL);
INSERT INTO point VALUES (694, 600, '11', NULL, NULL);
INSERT INTO point VALUES (695, 472, '6', NULL, NULL);
INSERT INTO point VALUES (696, 203, '22', NULL, NULL);
INSERT INTO point VALUES (697, 351, '8', NULL, NULL);
INSERT INTO point VALUES (698, 480, '51', NULL, NULL);
INSERT INTO point VALUES (699, 262, '23', NULL, NULL);
INSERT INTO point VALUES (700, 181, '74', NULL, NULL);
INSERT INTO point VALUES (701, 433, '36', NULL, NULL);
INSERT INTO point VALUES (702, 360, '6', NULL, NULL);
INSERT INTO point VALUES (703, 147, '82', NULL, NULL);
INSERT INTO point VALUES (704, 513, '30', NULL, NULL);
INSERT INTO point VALUES (705, 262, '9А', NULL, NULL);
INSERT INTO point VALUES (706, 405, '4А', NULL, NULL);
INSERT INTO point VALUES (707, 169, '25', NULL, NULL);
INSERT INTO point VALUES (708, 51, '30', NULL, NULL);
INSERT INTO point VALUES (709, 469, '14', NULL, NULL);
INSERT INTO point VALUES (710, 496, '111', NULL, NULL);
INSERT INTO point VALUES (711, 277, '41', NULL, NULL);
INSERT INTO point VALUES (712, 112, '4', NULL, NULL);
INSERT INTO point VALUES (713, 234, '27', NULL, NULL);
INSERT INTO point VALUES (714, 291, '2', NULL, NULL);
INSERT INTO point VALUES (715, 26, '45', NULL, NULL);
INSERT INTO point VALUES (716, 477, '20', NULL, NULL);
INSERT INTO point VALUES (717, 496, '45/1', NULL, NULL);
INSERT INTO point VALUES (718, 352, '30', NULL, NULL);
INSERT INTO point VALUES (719, 265, '24', NULL, NULL);
INSERT INTO point VALUES (720, 117, '19', NULL, NULL);
INSERT INTO point VALUES (721, 168, '33', NULL, NULL);
INSERT INTO point VALUES (722, 544, '6', NULL, NULL);
INSERT INTO point VALUES (723, 231, '7', NULL, NULL);
INSERT INTO point VALUES (724, 304, '35', NULL, NULL);
INSERT INTO point VALUES (725, 75, '6', NULL, NULL);
INSERT INTO point VALUES (726, 496, '3', NULL, NULL);
INSERT INTO point VALUES (727, 601, '63', NULL, NULL);
INSERT INTO point VALUES (728, 615, '10', NULL, NULL);
INSERT INTO point VALUES (729, 259, '5', NULL, NULL);
INSERT INTO point VALUES (730, 561, '6', NULL, NULL);
INSERT INTO point VALUES (731, 265, '44', NULL, NULL);
INSERT INTO point VALUES (732, 110, '38А', NULL, NULL);
INSERT INTO point VALUES (733, 213, '39', NULL, NULL);
INSERT INTO point VALUES (734, 393, '13', NULL, NULL);
INSERT INTO point VALUES (735, 303, '53', NULL, NULL);
INSERT INTO point VALUES (736, 473, '35', NULL, NULL);
INSERT INTO point VALUES (737, 294, '86', NULL, NULL);
INSERT INTO point VALUES (738, 49, '14', NULL, NULL);
INSERT INTO point VALUES (739, 150, '15', NULL, NULL);
INSERT INTO point VALUES (740, 599, '3', NULL, NULL);
INSERT INTO point VALUES (741, 425, '37', NULL, NULL);
INSERT INTO point VALUES (742, 87, '32', NULL, NULL);
INSERT INTO point VALUES (743, 437, '12', NULL, NULL);
INSERT INTO point VALUES (744, 602, '25', NULL, NULL);
INSERT INTO point VALUES (745, 67, '65', NULL, NULL);
INSERT INTO point VALUES (746, 169, '32', NULL, NULL);
INSERT INTO point VALUES (747, 251, '3', NULL, NULL);
INSERT INTO point VALUES (748, 564, '16', NULL, NULL);
INSERT INTO point VALUES (749, 560, '84', NULL, NULL);
INSERT INTO point VALUES (750, 610, '11', NULL, NULL);
INSERT INTO point VALUES (751, 61, '5', NULL, NULL);
INSERT INTO point VALUES (752, 176, '43', NULL, NULL);
INSERT INTO point VALUES (753, 375, '7', NULL, NULL);
INSERT INTO point VALUES (754, 431, '43', NULL, NULL);
INSERT INTO point VALUES (755, 372, '29', NULL, NULL);
INSERT INTO point VALUES (756, 464, '46Б', NULL, NULL);
INSERT INTO point VALUES (757, 110, '23', NULL, NULL);
INSERT INTO point VALUES (758, 682, '29', NULL, NULL);
INSERT INTO point VALUES (759, 554, '66', NULL, NULL);
INSERT INTO point VALUES (760, 695, '11', NULL, NULL);
INSERT INTO point VALUES (761, 600, '4', NULL, NULL);
INSERT INTO point VALUES (762, 509, '16', NULL, NULL);
INSERT INTO point VALUES (763, 208, '6', NULL, NULL);
INSERT INTO point VALUES (764, 458, '28', NULL, NULL);
INSERT INTO point VALUES (765, 273, '8', NULL, NULL);
INSERT INTO point VALUES (766, 176, '10', NULL, NULL);
INSERT INTO point VALUES (767, 601, '104А', NULL, NULL);
INSERT INTO point VALUES (768, 598, '34А', NULL, NULL);
INSERT INTO point VALUES (769, 277, '54', NULL, NULL);
INSERT INTO point VALUES (770, 24, '4', NULL, NULL);
INSERT INTO point VALUES (771, 79, '8', NULL, NULL);
INSERT INTO point VALUES (772, 236, '98', NULL, NULL);
INSERT INTO point VALUES (773, 88, '5', NULL, NULL);
INSERT INTO point VALUES (774, 434, '23', NULL, NULL);
INSERT INTO point VALUES (775, 496, '45', NULL, NULL);
INSERT INTO point VALUES (776, 509, '20', NULL, NULL);
INSERT INTO point VALUES (777, 541, '3', NULL, NULL);
INSERT INTO point VALUES (778, 663, '6', NULL, NULL);
INSERT INTO point VALUES (779, 205, '26', NULL, NULL);
INSERT INTO point VALUES (780, 294, '252А', NULL, NULL);
INSERT INTO point VALUES (781, 460, '13', NULL, NULL);
INSERT INTO point VALUES (782, 664, '24', NULL, NULL);
INSERT INTO point VALUES (783, 554, '109', NULL, NULL);
INSERT INTO point VALUES (784, 531, '100', NULL, NULL);
INSERT INTO point VALUES (785, 220, '10', NULL, NULL);
INSERT INTO point VALUES (786, 25, '12', NULL, NULL);
INSERT INTO point VALUES (787, 247, '6', NULL, NULL);
INSERT INTO point VALUES (788, 435, '7А', NULL, NULL);
INSERT INTO point VALUES (789, 601, '4А', NULL, NULL);
INSERT INTO point VALUES (790, 394, '30', NULL, NULL);
INSERT INTO point VALUES (791, 389, '26', NULL, NULL);
INSERT INTO point VALUES (792, 311, '6', NULL, NULL);
INSERT INTO point VALUES (793, 634, '7', NULL, NULL);
INSERT INTO point VALUES (794, 183, '39а', NULL, NULL);
INSERT INTO point VALUES (795, 571, '1', NULL, NULL);
INSERT INTO point VALUES (796, 528, '6', NULL, NULL);
INSERT INTO point VALUES (797, 231, '1/3', NULL, NULL);
INSERT INTO point VALUES (798, 235, '8', NULL, NULL);
INSERT INTO point VALUES (799, 477, '16', NULL, NULL);
INSERT INTO point VALUES (800, 51, '40', NULL, NULL);
INSERT INTO point VALUES (801, 433, '18', NULL, NULL);
INSERT INTO point VALUES (802, 303, '51', NULL, NULL);
INSERT INTO point VALUES (803, 347, '29', NULL, NULL);
INSERT INTO point VALUES (804, 271, '3/1', NULL, NULL);
INSERT INTO point VALUES (805, 161, '10', NULL, NULL);
INSERT INTO point VALUES (806, 169, '7', NULL, NULL);
INSERT INTO point VALUES (807, 262, '25А', NULL, NULL);
INSERT INTO point VALUES (808, 87, '7', NULL, NULL);
INSERT INTO point VALUES (809, 250, '80/3', NULL, NULL);
INSERT INTO point VALUES (810, 256, '4', NULL, NULL);
INSERT INTO point VALUES (811, 3, '15', NULL, NULL);
INSERT INTO point VALUES (812, 604, '183', NULL, NULL);
INSERT INTO point VALUES (813, 294, '98', NULL, NULL);
INSERT INTO point VALUES (814, 352, '40', NULL, NULL);
INSERT INTO point VALUES (815, 374, '88/1', NULL, NULL);
INSERT INTO point VALUES (816, 375, '32', NULL, NULL);
INSERT INTO point VALUES (817, 48, '19', NULL, NULL);
INSERT INTO point VALUES (818, 389, '9', NULL, NULL);
INSERT INTO point VALUES (819, 472, '10', NULL, NULL);
INSERT INTO point VALUES (820, 26, '3', NULL, NULL);
INSERT INTO point VALUES (821, 205, '9', NULL, NULL);
INSERT INTO point VALUES (822, 100, '47', NULL, NULL);
INSERT INTO point VALUES (823, 231, '25', NULL, NULL);
INSERT INTO point VALUES (824, 496, '10Б', NULL, NULL);
INSERT INTO point VALUES (825, 496, '96', NULL, NULL);
INSERT INTO point VALUES (826, 598, '10', NULL, NULL);
INSERT INTO point VALUES (827, 520, '13', NULL, NULL);
INSERT INTO point VALUES (828, 114, '9', NULL, NULL);
INSERT INTO point VALUES (829, 447, '46', NULL, NULL);
INSERT INTO point VALUES (830, 693, '4', NULL, NULL);
INSERT INTO point VALUES (831, 279, '59', NULL, NULL);
INSERT INTO point VALUES (832, 478, '61', NULL, NULL);
INSERT INTO point VALUES (833, 601, '131', NULL, NULL);
INSERT INTO point VALUES (834, 370, '4', NULL, NULL);
INSERT INTO point VALUES (835, 657, '31А', NULL, NULL);
INSERT INTO point VALUES (836, 334, '41', NULL, NULL);
INSERT INTO point VALUES (837, 653, '26', NULL, NULL);
INSERT INTO point VALUES (838, 334, '31', NULL, NULL);
INSERT INTO point VALUES (839, 424, '6', NULL, NULL);
INSERT INTO point VALUES (840, 458, '61', NULL, NULL);
INSERT INTO point VALUES (841, 696, '8', NULL, NULL);
INSERT INTO point VALUES (842, 654, '23', NULL, NULL);
INSERT INTO point VALUES (843, 601, '135', NULL, NULL);
INSERT INTO point VALUES (844, 292, '10', NULL, NULL);
INSERT INTO point VALUES (845, 236, '69', NULL, NULL);
INSERT INTO point VALUES (846, 692, '19', NULL, NULL);
INSERT INTO point VALUES (847, 429, '9', NULL, NULL);
INSERT INTO point VALUES (848, 455, '48', NULL, NULL);
INSERT INTO point VALUES (849, 201, '17', NULL, NULL);
INSERT INTO point VALUES (850, 19, '23', NULL, NULL);
INSERT INTO point VALUES (851, 451, '66', NULL, NULL);
INSERT INTO point VALUES (852, 496, '2', NULL, NULL);
INSERT INTO point VALUES (853, 535, '1', NULL, NULL);
INSERT INTO point VALUES (854, 502, '11', NULL, NULL);
INSERT INTO point VALUES (855, 687, '20', NULL, NULL);
INSERT INTO point VALUES (856, 425, '86Б', NULL, NULL);
INSERT INTO point VALUES (857, 50, '35', NULL, NULL);
INSERT INTO point VALUES (858, 531, '47', NULL, NULL);
INSERT INTO point VALUES (859, 304, '22', NULL, NULL);
INSERT INTO point VALUES (860, 565, '1', NULL, NULL);
INSERT INTO point VALUES (861, 374, '84', NULL, NULL);
INSERT INTO point VALUES (862, 3, '17', NULL, NULL);
INSERT INTO point VALUES (863, 480, '52', NULL, NULL);
INSERT INTO point VALUES (864, 223, '17А', NULL, NULL);
INSERT INTO point VALUES (865, 189, '13', NULL, NULL);
INSERT INTO point VALUES (866, 141, '11', NULL, NULL);
INSERT INTO point VALUES (867, 46, '8', NULL, NULL);
INSERT INTO point VALUES (868, 51, '50', NULL, NULL);
INSERT INTO point VALUES (869, 338, '54', NULL, NULL);
INSERT INTO point VALUES (870, 353, '59', NULL, NULL);
INSERT INTO point VALUES (871, 369, '41', NULL, NULL);
INSERT INTO point VALUES (872, 601, '82', NULL, NULL);
INSERT INTO point VALUES (873, 335, '10', NULL, NULL);
INSERT INTO point VALUES (874, 600, '46', NULL, NULL);
INSERT INTO point VALUES (875, 220, '22/8', NULL, NULL);
INSERT INTO point VALUES (876, 388, '31А', NULL, NULL);
INSERT INTO point VALUES (877, 61, '3', NULL, NULL);
INSERT INTO point VALUES (878, 530, '9', NULL, NULL);
INSERT INTO point VALUES (879, 483, '47', NULL, NULL);
INSERT INTO point VALUES (880, 157, '12', NULL, NULL);
INSERT INTO point VALUES (881, 251, '5', NULL, NULL);
INSERT INTO point VALUES (882, 117, '11/1', NULL, NULL);
INSERT INTO point VALUES (883, 473, '22', NULL, NULL);
INSERT INTO point VALUES (884, 250, '74а', NULL, NULL);
INSERT INTO point VALUES (885, 213, '15', NULL, NULL);
INSERT INTO point VALUES (886, 180, '23А', NULL, NULL);
INSERT INTO point VALUES (887, 535, '19', NULL, NULL);
INSERT INTO point VALUES (888, 139, '25/3', NULL, NULL);
INSERT INTO point VALUES (889, 166, '31А', NULL, NULL);
INSERT INTO point VALUES (890, 323, '28', NULL, NULL);
INSERT INTO point VALUES (891, 325, '2А', NULL, NULL);
INSERT INTO point VALUES (892, 294, '69', NULL, NULL);
INSERT INTO point VALUES (893, 152, '16', NULL, NULL);
INSERT INTO point VALUES (894, 280, '65', NULL, NULL);
INSERT INTO point VALUES (895, 496, '91а', NULL, NULL);
INSERT INTO point VALUES (896, 259, '3', NULL, NULL);
INSERT INTO point VALUES (897, 394, '11', NULL, NULL);
INSERT INTO point VALUES (898, 231, '24', NULL, NULL);
INSERT INTO point VALUES (899, 100, '100', NULL, NULL);
INSERT INTO point VALUES (900, 88, '45', NULL, NULL);
INSERT INTO point VALUES (901, 562, '27', NULL, NULL);
INSERT INTO point VALUES (902, 573, '3', NULL, NULL);
INSERT INTO point VALUES (903, 496, '5', NULL, NULL);
INSERT INTO point VALUES (904, 27, '10', NULL, NULL);
INSERT INTO point VALUES (905, 265, '7', NULL, NULL);
INSERT INTO point VALUES (906, 9, '57', NULL, NULL);
INSERT INTO point VALUES (907, 598, '36А', NULL, NULL);
INSERT INTO point VALUES (908, 565, '19', NULL, NULL);
INSERT INTO point VALUES (909, 294, '220А', NULL, NULL);
INSERT INTO point VALUES (910, 411, '12', NULL, NULL);
INSERT INTO point VALUES (911, 451, '8В', NULL, NULL);
INSERT INTO point VALUES (912, 506, '3Б', NULL, NULL);
INSERT INTO point VALUES (913, 181, '22', NULL, NULL);
INSERT INTO point VALUES (914, 168, '25', NULL, NULL);
INSERT INTO point VALUES (915, 76, '34/1', NULL, NULL);
INSERT INTO point VALUES (916, 152, '20', NULL, NULL);
INSERT INTO point VALUES (917, 61, '45', NULL, NULL);
INSERT INTO point VALUES (918, 76, '54', NULL, NULL);
INSERT INTO point VALUES (919, 548, '63', NULL, NULL);
INSERT INTO point VALUES (920, 545, '38', NULL, NULL);
INSERT INTO point VALUES (921, 169, '24', NULL, NULL);
INSERT INTO point VALUES (922, 694, '19', NULL, NULL);
INSERT INTO point VALUES (923, 87, '24', NULL, NULL);
INSERT INTO point VALUES (924, 569, '8', NULL, NULL);
INSERT INTO point VALUES (925, 26, '2', NULL, NULL);
INSERT INTO point VALUES (926, 508, '6', NULL, NULL);
INSERT INTO point VALUES (927, 262, '9/1', NULL, NULL);
INSERT INTO point VALUES (928, 174, '27', NULL, NULL);
INSERT INTO point VALUES (929, 233, '8', NULL, NULL);
INSERT INTO point VALUES (930, 452, '10', NULL, NULL);
INSERT INTO point VALUES (931, 169, '33', NULL, NULL);
INSERT INTO point VALUES (932, 87, '33', NULL, NULL);
INSERT INTO point VALUES (933, 469, '1А', NULL, NULL);
INSERT INTO point VALUES (934, 541, '5', NULL, NULL);
INSERT INTO point VALUES (935, 607, '31', NULL, NULL);
INSERT INTO point VALUES (936, 88, '3', NULL, NULL);
INSERT INTO point VALUES (937, 304, '77', NULL, NULL);
INSERT INTO point VALUES (938, 265, '25', NULL, NULL);
INSERT INTO point VALUES (939, 386, '8Г', NULL, NULL);
INSERT INTO point VALUES (940, 285, '10', NULL, NULL);
INSERT INTO point VALUES (941, 433, '62', NULL, NULL);
INSERT INTO point VALUES (942, 131, '14', NULL, NULL);
INSERT INTO point VALUES (943, 494, '9', NULL, NULL);
INSERT INTO point VALUES (944, 71, '2А', NULL, NULL);
INSERT INTO point VALUES (945, 643, '19', NULL, NULL);
INSERT INTO point VALUES (946, 486, '10', NULL, NULL);
INSERT INTO point VALUES (947, 139, '22/2', NULL, NULL);
INSERT INTO point VALUES (948, 26, '5', NULL, NULL);
INSERT INTO point VALUES (949, 419, '13', NULL, NULL);
INSERT INTO point VALUES (950, 687, '16', NULL, NULL);
INSERT INTO point VALUES (951, 168, '32', NULL, NULL);
INSERT INTO point VALUES (952, 447, '4', NULL, NULL);
INSERT INTO point VALUES (953, 624, '2А', NULL, NULL);
INSERT INTO point VALUES (954, 451, '41Б', NULL, NULL);
INSERT INTO point VALUES (955, 694, '1', NULL, NULL);
INSERT INTO point VALUES (956, 270, '21', NULL, NULL);
INSERT INTO point VALUES (957, 496, '87А', NULL, NULL);
INSERT INTO point VALUES (958, 374, '58Б', NULL, NULL);
INSERT INTO point VALUES (959, 384, '10', NULL, NULL);
INSERT INTO point VALUES (960, 660, '11', NULL, NULL);
INSERT INTO point VALUES (961, 512, '6', NULL, NULL);
INSERT INTO point VALUES (962, 465, '6', NULL, NULL);
INSERT INTO point VALUES (963, 541, '2', NULL, NULL);
INSERT INTO point VALUES (964, 636, '13', NULL, NULL);
INSERT INTO point VALUES (965, 221, '19', NULL, NULL);
INSERT INTO point VALUES (966, 47, '13', NULL, NULL);
INSERT INTO point VALUES (967, 372, '28', NULL, NULL);
INSERT INTO point VALUES (968, 499, '8', NULL, NULL);
INSERT INTO point VALUES (969, 265, '32', NULL, NULL);
INSERT INTO point VALUES (970, 531, '31', NULL, NULL);
INSERT INTO point VALUES (971, 565, '13', NULL, NULL);
INSERT INTO point VALUES (972, 283, '27', NULL, NULL);
INSERT INTO point VALUES (973, 37, '20', NULL, NULL);
INSERT INTO point VALUES (974, 294, '67', NULL, NULL);
INSERT INTO point VALUES (975, 142, '5', NULL, NULL);
INSERT INTO point VALUES (976, 548, '27', NULL, NULL);
INSERT INTO point VALUES (977, 635, '20', NULL, NULL);
INSERT INTO point VALUES (978, 325, '5', NULL, NULL);
INSERT INTO point VALUES (979, 252, '2', NULL, NULL);
INSERT INTO point VALUES (980, 589, '22', NULL, NULL);
INSERT INTO point VALUES (981, 9, '85', NULL, NULL);
INSERT INTO point VALUES (982, 211, '26', NULL, NULL);
INSERT INTO point VALUES (983, 329, '35', NULL, NULL);
INSERT INTO point VALUES (984, 207, '7Б', NULL, NULL);
INSERT INTO point VALUES (985, 408, '10', NULL, NULL);
INSERT INTO point VALUES (986, 652, '13', NULL, NULL);
INSERT INTO point VALUES (987, 292, '6', NULL, NULL);
INSERT INTO point VALUES (988, 531, '41', NULL, NULL);
INSERT INTO point VALUES (989, 424, '10', NULL, NULL);
INSERT INTO point VALUES (990, 236, '17', NULL, NULL);
INSERT INTO point VALUES (991, 261, '23', NULL, NULL);
INSERT INTO point VALUES (992, 435, '30', NULL, NULL);
INSERT INTO point VALUES (993, 172, '16', NULL, NULL);
INSERT INTO point VALUES (994, 299, '35', NULL, NULL);
INSERT INTO point VALUES (995, 144, '27', NULL, NULL);
INSERT INTO point VALUES (996, 203, '34', NULL, NULL);
INSERT INTO point VALUES (997, 96, '8', NULL, NULL);
INSERT INTO point VALUES (998, 449, '14', NULL, NULL);
INSERT INTO point VALUES (999, 76, '38', NULL, NULL);
INSERT INTO point VALUES (1000, 335, '6', NULL, NULL);
INSERT INTO point VALUES (1001, 325, '2', NULL, NULL);
INSERT INTO point VALUES (1002, 371, '12', NULL, NULL);
INSERT INTO point VALUES (1003, 245, '45', NULL, NULL);
INSERT INTO point VALUES (1004, 447, '11', NULL, NULL);
INSERT INTO point VALUES (1005, 679, '8', NULL, NULL);
INSERT INTO point VALUES (1006, 26, '29', NULL, NULL);
INSERT INTO point VALUES (1007, 334, '38', NULL, NULL);
INSERT INTO point VALUES (1008, 250, '7', NULL, NULL);
INSERT INTO point VALUES (1009, 294, '17', NULL, NULL);
INSERT INTO point VALUES (1010, 696, '23', NULL, NULL);
INSERT INTO point VALUES (1011, 170, '16', NULL, NULL);
INSERT INTO point VALUES (1012, 465, '94', NULL, NULL);
INSERT INTO point VALUES (1013, 163, '21', NULL, NULL);
INSERT INTO point VALUES (1014, 224, '4', NULL, NULL);
INSERT INTO point VALUES (1015, 483, '31', NULL, NULL);
INSERT INTO point VALUES (1016, 61, '28', NULL, NULL);
INSERT INTO point VALUES (1017, 692, '13', NULL, NULL);
INSERT INTO point VALUES (1018, 660, '4', NULL, NULL);
INSERT INTO point VALUES (1019, 25, '14', NULL, NULL);
INSERT INTO point VALUES (1020, 146, '15', NULL, NULL);
INSERT INTO point VALUES (1021, 369, '47', NULL, NULL);
INSERT INTO point VALUES (1022, 375, '42', NULL, NULL);
INSERT INTO point VALUES (1023, 390, '18', NULL, NULL);
INSERT INTO point VALUES (1024, 189, '1', NULL, NULL);
INSERT INTO point VALUES (1025, 27, '6', NULL, NULL);
INSERT INTO point VALUES (1026, 352, '4', NULL, NULL);
INSERT INTO point VALUES (1027, 236, '67', NULL, NULL);
INSERT INTO point VALUES (1028, 483, '41', NULL, NULL);
INSERT INTO point VALUES (1029, 139, '7', NULL, NULL);
INSERT INTO point VALUES (1030, 303, '19', NULL, NULL);
INSERT INTO point VALUES (1031, 370, '11', NULL, NULL);
INSERT INTO point VALUES (1032, 296, '2', NULL, NULL);
INSERT INTO point VALUES (1033, 374, '101', NULL, NULL);
INSERT INTO point VALUES (1034, 250, '72/2', NULL, NULL);
INSERT INTO point VALUES (1035, 629, '5', NULL, NULL);
INSERT INTO point VALUES (1036, 569, '8А', NULL, NULL);
INSERT INTO point VALUES (1037, 282, '2', NULL, NULL);
INSERT INTO point VALUES (1038, 49, '12', NULL, NULL);
INSERT INTO point VALUES (1039, 636, '19', NULL, NULL);
INSERT INTO point VALUES (1040, 464, '52Б', NULL, NULL);
INSERT INTO point VALUES (1041, 437, '14', NULL, NULL);
INSERT INTO point VALUES (1042, 693, '11', NULL, NULL);
INSERT INTO point VALUES (1043, 458, '5', NULL, NULL);
INSERT INTO point VALUES (1044, 601, '126', NULL, NULL);
INSERT INTO point VALUES (1045, 338, '38', NULL, NULL);
INSERT INTO point VALUES (1046, 525, '24', NULL, NULL);
INSERT INTO point VALUES (1047, 639, '16/1', NULL, NULL);
INSERT INTO point VALUES (1048, 496, '89', NULL, NULL);
INSERT INTO point VALUES (1049, 280, '64', NULL, NULL);
INSERT INTO point VALUES (1050, 250, '25', NULL, NULL);
INSERT INTO point VALUES (1051, 280, '78', NULL, NULL);
INSERT INTO point VALUES (1052, 245, '3', NULL, NULL);
INSERT INTO point VALUES (1053, 236, '102', NULL, NULL);
INSERT INTO point VALUES (1054, 120, '37', NULL, NULL);
INSERT INTO point VALUES (1055, 45, '3', NULL, NULL);
INSERT INTO point VALUES (1056, 42, '4', NULL, NULL);
INSERT INTO point VALUES (1057, 502, '4', NULL, NULL);
INSERT INTO point VALUES (1058, 604, '15/1', NULL, NULL);
INSERT INTO point VALUES (1059, 657, '27', NULL, NULL);
INSERT INTO point VALUES (1060, 525, '33', NULL, NULL);
INSERT INTO point VALUES (1061, 480, '19', NULL, NULL);
INSERT INTO point VALUES (1062, 626, '5', NULL, NULL);
INSERT INTO point VALUES (1063, 106, '6', NULL, NULL);
INSERT INTO point VALUES (1064, 374, '143', NULL, NULL);
INSERT INTO point VALUES (1065, 390, '36', NULL, NULL);
INSERT INTO point VALUES (1066, 419, '19', NULL, NULL);
INSERT INTO point VALUES (1067, 285, '6', NULL, NULL);
INSERT INTO point VALUES (1068, 277, '100', NULL, NULL);
INSERT INTO point VALUES (1069, 125, '1', NULL, NULL);
INSERT INTO point VALUES (1070, 643, '13', NULL, NULL);
INSERT INTO point VALUES (1071, 610, '10А', NULL, NULL);
INSERT INTO point VALUES (1072, 71, '5', NULL, NULL);
INSERT INTO point VALUES (1073, 515, '9', NULL, NULL);
INSERT INTO point VALUES (1074, 542, '54', NULL, NULL);
INSERT INTO point VALUES (1075, 433, '42А', NULL, NULL);
INSERT INTO point VALUES (1076, 427, '30', NULL, NULL);
INSERT INTO point VALUES (1077, 682, '3', NULL, NULL);
INSERT INTO point VALUES (1078, 166, '27', NULL, NULL);
INSERT INTO point VALUES (1079, 169, '42', NULL, NULL);
INSERT INTO point VALUES (1080, 531, '236', NULL, NULL);
INSERT INTO point VALUES (1081, 451, '33', NULL, NULL);
INSERT INTO point VALUES (1082, 486, '6', NULL, NULL);
INSERT INTO point VALUES (1083, 141, '4', NULL, NULL);
INSERT INTO point VALUES (1084, 178, '15', NULL, NULL);
INSERT INTO point VALUES (1085, 372, '3', NULL, NULL);
INSERT INTO point VALUES (1086, 296, '5', NULL, NULL);
INSERT INTO point VALUES (1087, 620, '6', NULL, NULL);
INSERT INTO point VALUES (1088, 250, '32', NULL, NULL);
INSERT INTO point VALUES (1089, 629, '2', NULL, NULL);
INSERT INTO point VALUES (1090, 458, '2', NULL, NULL);
INSERT INTO point VALUES (1091, 572, '24А', NULL, NULL);
INSERT INTO point VALUES (1092, 163, '48', NULL, NULL);
INSERT INTO point VALUES (1093, 37, '16', NULL, NULL);
INSERT INTO point VALUES (1094, 496, '61', NULL, NULL);
INSERT INTO point VALUES (1095, 376, '26', NULL, NULL);
INSERT INTO point VALUES (1096, 635, '16', NULL, NULL);
INSERT INTO point VALUES (1097, 694, '13', NULL, NULL);
INSERT INTO point VALUES (1098, 236, '39', NULL, NULL);
INSERT INTO point VALUES (1099, 604, '206', NULL, NULL);
INSERT INTO point VALUES (1100, 71, '2', NULL, NULL);
INSERT INTO point VALUES (1101, 294, '102', NULL, NULL);
INSERT INTO point VALUES (1102, 76, '44/1', NULL, NULL);
INSERT INTO point VALUES (1103, 435, '40', NULL, NULL);
INSERT INTO point VALUES (1104, 570, '9', NULL, NULL);
INSERT INTO point VALUES (1105, 39, '7', NULL, NULL);
INSERT INTO point VALUES (1106, 639, '18', NULL, NULL);
INSERT INTO point VALUES (1107, 277, '72', NULL, NULL);
INSERT INTO point VALUES (1108, 624, '2', NULL, NULL);
INSERT INTO point VALUES (1109, 32, '22', NULL, NULL);
INSERT INTO point VALUES (1110, 419, '1', NULL, NULL);
INSERT INTO point VALUES (1111, 449, '13', NULL, NULL);
INSERT INTO point VALUES (1112, 339, '22', NULL, NULL);
INSERT INTO point VALUES (1113, 100, '37', NULL, NULL);
INSERT INTO point VALUES (1114, 664, '8', NULL, NULL);
INSERT INTO point VALUES (1115, 277, '70', NULL, NULL);
INSERT INTO point VALUES (1116, 374, '56', NULL, NULL);
INSERT INTO point VALUES (1117, 235, '44', NULL, NULL);
INSERT INTO point VALUES (1118, 342, '4', NULL, NULL);
INSERT INTO point VALUES (1119, 499, '7', NULL, NULL);
INSERT INTO point VALUES (1120, 252, '9', NULL, NULL);
INSERT INTO point VALUES (1121, 294, '27Б', NULL, NULL);
INSERT INTO point VALUES (1122, 548, '36', NULL, NULL);
INSERT INTO point VALUES (1123, 434, '42', NULL, NULL);
INSERT INTO point VALUES (1124, 451, '76', NULL, NULL);
INSERT INTO point VALUES (1125, 649, '41', NULL, NULL);
INSERT INTO point VALUES (1126, 496, '61/1', NULL, NULL);
INSERT INTO point VALUES (1127, 326, '6', NULL, NULL);
INSERT INTO point VALUES (1128, 386, '8Б', NULL, NULL);
INSERT INTO point VALUES (1129, 464, '34/2', NULL, NULL);
INSERT INTO point VALUES (1130, 384, '20', NULL, NULL);
INSERT INTO point VALUES (1131, 639, '27', NULL, NULL);
INSERT INTO point VALUES (1132, 467, '4', NULL, NULL);
INSERT INTO point VALUES (1133, 648, '4', NULL, NULL);
INSERT INTO point VALUES (1134, 292, '16', NULL, NULL);
INSERT INTO point VALUES (1135, 696, '25', NULL, NULL);
INSERT INTO point VALUES (1136, 649, '31', NULL, NULL);
INSERT INTO point VALUES (1137, 277, '68', NULL, NULL);
INSERT INTO point VALUES (1138, 67, '56а', NULL, NULL);
INSERT INTO point VALUES (1139, 643, '71', NULL, NULL);
INSERT INTO point VALUES (1140, 496, '65', NULL, NULL);
INSERT INTO point VALUES (1141, 261, '25', NULL, NULL);
INSERT INTO point VALUES (1142, 462, '10', NULL, NULL);
INSERT INTO point VALUES (1143, 373, '77', NULL, NULL);
INSERT INTO point VALUES (1144, 233, '7', NULL, NULL);
INSERT INTO point VALUES (1145, 211, '2', NULL, NULL);
INSERT INTO point VALUES (1146, 460, '12', NULL, NULL);
INSERT INTO point VALUES (1147, 50, '17', NULL, NULL);
INSERT INTO point VALUES (1148, 84, '23Б', NULL, NULL);
INSERT INTO point VALUES (1149, 688, '3', NULL, NULL);
INSERT INTO point VALUES (1150, 325, '9', NULL, NULL);
INSERT INTO point VALUES (1151, 566, '15', NULL, NULL);
INSERT INTO point VALUES (1152, 152, '10', NULL, NULL);
INSERT INTO point VALUES (1153, 142, '9', NULL, NULL);
INSERT INTO point VALUES (1154, 25, '13', NULL, NULL);
INSERT INTO point VALUES (1155, 354, '45', NULL, NULL);
INSERT INTO point VALUES (1156, 27, '16', NULL, NULL);
INSERT INTO point VALUES (1157, 610, '21', NULL, NULL);
INSERT INTO point VALUES (1158, 235, '33', NULL, NULL);
INSERT INTO point VALUES (1159, 232, '14', NULL, NULL);
INSERT INTO point VALUES (1160, 157, '26/6', NULL, NULL);
INSERT INTO point VALUES (1161, 692, '14', NULL, NULL);
INSERT INTO point VALUES (1162, 624, '78', NULL, NULL);
INSERT INTO point VALUES (1163, 203, '17', NULL, NULL);
INSERT INTO point VALUES (1164, 235, '24', NULL, NULL);
INSERT INTO point VALUES (1165, 335, '16', NULL, NULL);
INSERT INTO point VALUES (1166, 257, '4', NULL, NULL);
INSERT INTO point VALUES (1167, 170, '6', NULL, NULL);
INSERT INTO point VALUES (1168, 372, '19Б', NULL, NULL);
INSERT INTO point VALUES (1169, 55, '6', NULL, NULL);
INSERT INTO point VALUES (1170, 601, '62', NULL, NULL);
INSERT INTO point VALUES (1171, 534, '3', NULL, NULL);
INSERT INTO point VALUES (1172, 236, '34', NULL, NULL);
INSERT INTO point VALUES (1173, 285, '20', NULL, NULL);
INSERT INTO point VALUES (1174, 183, '36', NULL, NULL);
INSERT INTO point VALUES (1175, 452, '16', NULL, NULL);
INSERT INTO point VALUES (1176, 653, '29', NULL, NULL);
INSERT INTO point VALUES (1177, 236, '81', NULL, NULL);
INSERT INTO point VALUES (1178, 489, '19', NULL, NULL);
INSERT INTO point VALUES (1179, 572, '4', NULL, NULL);
INSERT INTO point VALUES (1180, 496, '53А', NULL, NULL);
INSERT INTO point VALUES (1181, 261, '7', NULL, NULL);
INSERT INTO point VALUES (1182, 267, '3', NULL, NULL);
INSERT INTO point VALUES (1183, 59, '17', NULL, NULL);
INSERT INTO point VALUES (1184, 464, '44', NULL, NULL);
INSERT INTO point VALUES (1185, 99, '27', NULL, NULL);
INSERT INTO point VALUES (1186, 285, '16', NULL, NULL);
INSERT INTO point VALUES (1187, 271, '8Б', NULL, NULL);
INSERT INTO point VALUES (1188, 653, '61', NULL, NULL);
INSERT INTO point VALUES (1189, 560, '55', NULL, NULL);
INSERT INTO point VALUES (1190, 203, '39', NULL, NULL);
INSERT INTO point VALUES (1191, 46, '7', NULL, NULL);
INSERT INTO point VALUES (1192, 670, '55', NULL, NULL);
INSERT INTO point VALUES (1193, 465, '84', NULL, NULL);
INSERT INTO point VALUES (1194, 21, '5', NULL, NULL);
INSERT INTO point VALUES (1195, 389, '28', NULL, NULL);
INSERT INTO point VALUES (1196, 223, '31', NULL, NULL);
INSERT INTO point VALUES (1197, 393, '12', NULL, NULL);
INSERT INTO point VALUES (1198, 304, '15', NULL, NULL);
INSERT INTO point VALUES (1199, 183, '18', NULL, NULL);
INSERT INTO point VALUES (1200, 37, '1В', NULL, NULL);
INSERT INTO point VALUES (1201, 48, '124', NULL, NULL);
INSERT INTO point VALUES (1202, 635, '6', NULL, NULL);
INSERT INTO point VALUES (1203, 425, '38', NULL, NULL);
INSERT INTO point VALUES (1204, 384, '16', NULL, NULL);
INSERT INTO point VALUES (1205, 489, '1', NULL, NULL);
INSERT INTO point VALUES (1206, 110, '42', NULL, NULL);
INSERT INTO point VALUES (1207, 292, '20', NULL, NULL);
INSERT INTO point VALUES (1208, 458, '9', NULL, NULL);
INSERT INTO point VALUES (1209, 500, '32', NULL, NULL);
INSERT INTO point VALUES (1210, 694, '14', NULL, NULL);
INSERT INTO point VALUES (1211, 473, '15', NULL, NULL);
INSERT INTO point VALUES (1212, 210, '11', NULL, NULL);
INSERT INTO point VALUES (1213, 282, '26', NULL, NULL);
INSERT INTO point VALUES (1214, 548, '18', NULL, NULL);
INSERT INTO point VALUES (1215, 163, '46', NULL, NULL);
INSERT INTO point VALUES (1216, 629, '9', NULL, NULL);
INSERT INTO point VALUES (1217, 248, '17', NULL, NULL);
INSERT INTO point VALUES (1218, 464, '33', NULL, NULL);
INSERT INTO point VALUES (1219, 515, '5', NULL, NULL);
INSERT INTO point VALUES (1220, 110, '35А', NULL, NULL);
INSERT INTO point VALUES (1221, 486, '16', NULL, NULL);
INSERT INTO point VALUES (1222, 554, '106', NULL, NULL);
INSERT INTO point VALUES (1223, 67, '96', NULL, NULL);
INSERT INTO point VALUES (1224, 376, '5', NULL, NULL);
INSERT INTO point VALUES (1225, 687, '10', NULL, NULL);
INSERT INTO point VALUES (1226, 386, '6Г', NULL, NULL);
INSERT INTO point VALUES (1227, 464, '24', NULL, NULL);
INSERT INTO point VALUES (1228, 70, '4', NULL, NULL);
INSERT INTO point VALUES (1229, 626, '9', NULL, NULL);
INSERT INTO point VALUES (1230, 696, '7', NULL, NULL);
INSERT INTO point VALUES (1231, 624, '80', NULL, NULL);
INSERT INTO point VALUES (1232, 487, '24', NULL, NULL);
INSERT INTO point VALUES (1233, 572, '11', NULL, NULL);
INSERT INTO point VALUES (1234, 554, '8', NULL, NULL);
INSERT INTO point VALUES (1235, 172, '10', NULL, NULL);
INSERT INTO point VALUES (1236, 530, '5', NULL, NULL);
INSERT INTO point VALUES (1237, 658, '28', NULL, NULL);
INSERT INTO point VALUES (1238, 110, '21А', NULL, NULL);
INSERT INTO point VALUES (1239, 434, '44', NULL, NULL);
INSERT INTO point VALUES (1240, 264, '9', NULL, NULL);
INSERT INTO point VALUES (1241, 57, '20', NULL, NULL);
INSERT INTO point VALUES (1242, 531, '192', NULL, NULL);
INSERT INTO point VALUES (1243, 278, '21', NULL, NULL);
INSERT INTO point VALUES (1244, 39, '8', NULL, NULL);
INSERT INTO point VALUES (1245, 664, '8А', NULL, NULL);
INSERT INTO point VALUES (1246, 496, '9', NULL, NULL);
INSERT INTO point VALUES (1247, 435, '10/1', NULL, NULL);
INSERT INTO point VALUES (1248, 25, '19', NULL, NULL);
INSERT INTO point VALUES (1249, 531, '134', NULL, NULL);
INSERT INTO point VALUES (1250, 429, '2', NULL, NULL);
INSERT INTO point VALUES (1251, 496, '80', NULL, NULL);
INSERT INTO point VALUES (1252, 108, '5', NULL, NULL);
INSERT INTO point VALUES (1253, 599, '9', NULL, NULL);
INSERT INTO point VALUES (1254, 424, '16', NULL, NULL);
INSERT INTO point VALUES (1255, 184, '21', NULL, NULL);
INSERT INTO point VALUES (1256, 303, '14', NULL, NULL);
INSERT INTO point VALUES (1257, 235, '42', NULL, NULL);
INSERT INTO point VALUES (1258, 465, '20', NULL, NULL);
INSERT INTO point VALUES (1259, 464, '66', NULL, NULL);
INSERT INTO point VALUES (1260, 152, '6', NULL, NULL);
INSERT INTO point VALUES (1261, 455, '10А', NULL, NULL);
INSERT INTO point VALUES (1262, 236, '35', NULL, NULL);
INSERT INTO point VALUES (1263, 447, '49', NULL, NULL);
INSERT INTO point VALUES (1264, 114, '45', NULL, NULL);
INSERT INTO point VALUES (1265, 536, '6', NULL, NULL);
INSERT INTO point VALUES (1266, 299, '17', NULL, NULL);
INSERT INTO point VALUES (1267, 618, '9В', NULL, NULL);
INSERT INTO point VALUES (1268, 600, '48', NULL, NULL);
INSERT INTO point VALUES (1269, 174, '18', NULL, NULL);
INSERT INTO point VALUES (1270, 389, '45', NULL, NULL);
INSERT INTO point VALUES (1271, 435, '48', NULL, NULL);
INSERT INTO point VALUES (1272, 25, '1', NULL, NULL);
INSERT INTO point VALUES (1273, 523, '22', NULL, NULL);
INSERT INTO point VALUES (1274, 617, '13', NULL, NULL);
INSERT INTO point VALUES (1275, 108, '2', NULL, NULL);
INSERT INTO point VALUES (1276, 356, '12', NULL, NULL);
INSERT INTO point VALUES (1277, 111, '36', NULL, NULL);
INSERT INTO point VALUES (1278, 374, '104', NULL, NULL);
INSERT INTO point VALUES (1279, 376, '29', NULL, NULL);
INSERT INTO point VALUES (1280, 468, '14', NULL, NULL);
INSERT INTO point VALUES (1281, 659, '4', NULL, NULL);
INSERT INTO point VALUES (1282, 539, '35', NULL, NULL);
INSERT INTO point VALUES (1283, 601, '141', NULL, NULL);
INSERT INTO point VALUES (1284, 434, '24', NULL, NULL);
INSERT INTO point VALUES (1285, 329, '17', NULL, NULL);
INSERT INTO point VALUES (1286, 376, '61', NULL, NULL);
INSERT INTO point VALUES (1287, 654, '25', NULL, NULL);
INSERT INTO point VALUES (1288, 262, '21А', NULL, NULL);
INSERT INTO point VALUES (1289, 32, '15', NULL, NULL);
INSERT INTO point VALUES (1290, 496, '26', NULL, NULL);
INSERT INTO point VALUES (1291, 374, '10', NULL, NULL);
INSERT INTO point VALUES (1292, 429, '5', NULL, NULL);
INSERT INTO point VALUES (1293, 48, '12', NULL, NULL);
INSERT INTO point VALUES (1294, 67, '174', NULL, NULL);
INSERT INTO point VALUES (1295, 44, '18', NULL, NULL);
INSERT INTO point VALUES (1296, 449, '19', NULL, NULL);
INSERT INTO point VALUES (1297, 189, '14', NULL, NULL);
INSERT INTO point VALUES (1298, 163, '40', NULL, NULL);
INSERT INTO point VALUES (1299, 201, '34', NULL, NULL);
INSERT INTO point VALUES (1300, 170, '10', NULL, NULL);
INSERT INTO point VALUES (1301, 437, '1', NULL, NULL);
INSERT INTO point VALUES (1302, 366, '15', NULL, NULL);
INSERT INTO point VALUES (1303, 201, '81', NULL, NULL);
INSERT INTO point VALUES (1304, 53, '54', NULL, NULL);
INSERT INTO point VALUES (1305, 425, '41', NULL, NULL);
INSERT INTO point VALUES (1306, 451, '2/1', NULL, NULL);
INSERT INTO point VALUES (1307, 389, '3', NULL, NULL);
INSERT INTO point VALUES (1308, 11, '16', NULL, NULL);
INSERT INTO point VALUES (1309, 398, '7', NULL, NULL);
INSERT INTO point VALUES (1310, 280, '139', NULL, NULL);
INSERT INTO point VALUES (1311, 374, '43', NULL, NULL);
INSERT INTO point VALUES (1312, 26, '9', NULL, NULL);
INSERT INTO point VALUES (1313, 572, '50', NULL, NULL);
INSERT INTO point VALUES (1314, 205, '3', NULL, NULL);
INSERT INTO point VALUES (1315, 393, '5А', NULL, NULL);
INSERT INTO point VALUES (1316, 117, '58', NULL, NULL);
INSERT INTO point VALUES (1317, 566, '16Б', NULL, NULL);
INSERT INTO point VALUES (1318, 139, '8', NULL, NULL);
INSERT INTO point VALUES (1319, 170, '43', NULL, NULL);
INSERT INTO point VALUES (1320, 494, '5', NULL, NULL);
INSERT INTO point VALUES (1321, 197, '3', NULL, NULL);
INSERT INTO point VALUES (1322, 110, '24', NULL, NULL);
INSERT INTO point VALUES (1323, 342, '11', NULL, NULL);
INSERT INTO point VALUES (1324, 679, '7', NULL, NULL);
INSERT INTO point VALUES (1325, 111, '18', NULL, NULL);
INSERT INTO point VALUES (1326, 117, '12', NULL, NULL);
INSERT INTO point VALUES (1327, 202, '50А', NULL, NULL);
INSERT INTO point VALUES (1328, 110, '33', NULL, NULL);
INSERT INTO point VALUES (1329, 163, '30', NULL, NULL);
INSERT INTO point VALUES (1330, 496, '64', NULL, NULL);
INSERT INTO point VALUES (1331, 280, '89', NULL, NULL);
INSERT INTO point VALUES (1332, 346, '6', NULL, NULL);
INSERT INTO point VALUES (1333, 496, '78', NULL, NULL);
INSERT INTO point VALUES (1334, 458, '65', NULL, NULL);
INSERT INTO point VALUES (1335, 44, '36', NULL, NULL);
INSERT INTO point VALUES (1336, 467, '11', NULL, NULL);
INSERT INTO point VALUES (1337, 329, '39', NULL, NULL);
INSERT INTO point VALUES (1338, 235, '66', NULL, NULL);
INSERT INTO point VALUES (1339, 464, '42', NULL, NULL);
INSERT INTO point VALUES (1340, 125, '14', NULL, NULL);
INSERT INTO point VALUES (1341, 294, '74', NULL, NULL);
INSERT INTO point VALUES (1342, 664, '6/1', NULL, NULL);
INSERT INTO point VALUES (1343, 37, '10', NULL, NULL);
INSERT INTO point VALUES (1344, 265, '9А', NULL, NULL);
INSERT INTO point VALUES (1345, 26, '26', NULL, NULL);
INSERT INTO point VALUES (1346, 542, '17А', NULL, NULL);
INSERT INTO point VALUES (1347, 635, '10', NULL, NULL);
INSERT INTO point VALUES (1348, 494, '2', NULL, NULL);
INSERT INTO point VALUES (1349, 636, '14', NULL, NULL);
INSERT INTO point VALUES (1350, 600, '21', NULL, NULL);
INSERT INTO point VALUES (1351, 277, '37', NULL, NULL);
INSERT INTO point VALUES (1352, 236, '74', NULL, NULL);
INSERT INTO point VALUES (1353, 455, '58/1', NULL, NULL);
INSERT INTO point VALUES (1354, 374, '94', NULL, NULL);
INSERT INTO point VALUES (1355, 362, '15А', NULL, NULL);
INSERT INTO point VALUES (1356, 96, '7', NULL, NULL);
INSERT INTO point VALUES (1357, 265, '23', NULL, NULL);
INSERT INTO point VALUES (1358, 393, '1А', NULL, NULL);
INSERT INTO point VALUES (1359, 435, '21', NULL, NULL);
INSERT INTO point VALUES (1360, 465, '16', NULL, NULL);
INSERT INTO point VALUES (1361, 604, '15/34', NULL, NULL);
INSERT INTO point VALUES (1362, 531, '123', NULL, NULL);
INSERT INTO point VALUES (1363, 262, '24', NULL, NULL);
INSERT INTO point VALUES (1364, 168, '23', NULL, NULL);
INSERT INTO point VALUES (1365, 110, '44', NULL, NULL);
INSERT INTO point VALUES (1366, 389, '45/1', NULL, NULL);
INSERT INTO point VALUES (1367, 628, '33', NULL, NULL);
INSERT INTO point VALUES (1368, 139, '22/4', NULL, NULL);
INSERT INTO point VALUES (1369, 675, '3', NULL, NULL);
INSERT INTO point VALUES (1370, 419, '14', NULL, NULL);
INSERT INTO point VALUES (1371, 489, '13', NULL, NULL);
INSERT INTO point VALUES (1372, 541, '9', NULL, NULL);
INSERT INTO point VALUES (1373, 12, '62', NULL, NULL);
INSERT INTO point VALUES (1374, 539, '8', NULL, NULL);
INSERT INTO point VALUES (1375, 181, '42', NULL, NULL);
INSERT INTO point VALUES (1376, 329, '32', NULL, NULL);
INSERT INTO point VALUES (1377, 345, '19', NULL, NULL);
INSERT INTO point VALUES (1378, 509, '14', NULL, NULL);
INSERT INTO point VALUES (1379, 53, '30', NULL, NULL);
INSERT INTO point VALUES (1380, 100, '49', NULL, NULL);
INSERT INTO point VALUES (1381, 94, '5', NULL, NULL);
INSERT INTO point VALUES (1382, 242, '8', NULL, NULL);
INSERT INTO point VALUES (1383, 564, '14', NULL, NULL);
INSERT INTO point VALUES (1384, 604, '15', NULL, NULL);
INSERT INTO point VALUES (1385, 166, '9', NULL, NULL);
INSERT INTO point VALUES (1386, 455, '38', NULL, NULL);
INSERT INTO point VALUES (1387, 252, '18', NULL, NULL);
INSERT INTO point VALUES (1388, 615, '1', NULL, NULL);
INSERT INTO point VALUES (1389, 48, '43', NULL, NULL);
INSERT INTO point VALUES (1390, 99, '5', NULL, NULL);
INSERT INTO point VALUES (1391, 542, '48', NULL, NULL);
INSERT INTO point VALUES (1392, 584, '23', NULL, NULL);
INSERT INTO point VALUES (1393, 117, '10', NULL, NULL);
INSERT INTO point VALUES (1394, 545, '21', NULL, NULL);
INSERT INTO point VALUES (1395, 49, '16', NULL, NULL);
INSERT INTO point VALUES (1396, 434, '15', NULL, NULL);
INSERT INTO point VALUES (1397, 389, '1/4', NULL, NULL);
INSERT INTO point VALUES (1398, 390, '5', NULL, NULL);
INSERT INTO point VALUES (1399, 393, '6', NULL, NULL);
INSERT INTO point VALUES (1400, 236, '8', NULL, NULL);
INSERT INTO point VALUES (1401, 120, '4', NULL, NULL);
INSERT INTO point VALUES (1402, 505, '11', NULL, NULL);
INSERT INTO point VALUES (1403, 34, '11', NULL, NULL);
INSERT INTO point VALUES (1404, 388, '9', NULL, NULL);
INSERT INTO point VALUES (1405, 678, '20', NULL, NULL);
INSERT INTO point VALUES (1406, 37, '12', NULL, NULL);
INSERT INTO point VALUES (1407, 166, '26', NULL, NULL);
INSERT INTO point VALUES (1408, 432, '3', NULL, NULL);
INSERT INTO point VALUES (1409, 566, '42', NULL, NULL);
INSERT INTO point VALUES (1410, 465, '51', NULL, NULL);
INSERT INTO point VALUES (1411, 294, '8', NULL, NULL);
INSERT INTO point VALUES (1412, 654, '17', NULL, NULL);
INSERT INTO point VALUES (1413, 635, '12', NULL, NULL);
INSERT INTO point VALUES (1414, 201, '38А', NULL, NULL);
INSERT INTO point VALUES (1415, 325, '18', NULL, NULL);
INSERT INTO point VALUES (1416, 525, '22', NULL, NULL);
INSERT INTO point VALUES (1417, 254, '3', NULL, NULL);
INSERT INTO point VALUES (1418, 625, '3', NULL, NULL);
INSERT INTO point VALUES (1419, 656, '3', NULL, NULL);
INSERT INTO point VALUES (1420, 250, '74', NULL, NULL);
INSERT INTO point VALUES (1421, 329, '25', NULL, NULL);
INSERT INTO point VALUES (1422, 649, '46', NULL, NULL);
INSERT INTO point VALUES (1423, 531, '222', NULL, NULL);
INSERT INTO point VALUES (1424, 117, '30В', NULL, NULL);
INSERT INTO point VALUES (1425, 447, '87', NULL, NULL);
INSERT INTO point VALUES (1426, 2, '11', NULL, NULL);
INSERT INTO point VALUES (1427, 544, '13', NULL, NULL);
INSERT INTO point VALUES (1428, 549, '4', NULL, NULL);
INSERT INTO point VALUES (1429, 349, '7', NULL, NULL);
INSERT INTO point VALUES (1430, 425, '40', NULL, NULL);
INSERT INTO point VALUES (1431, 604, '185', NULL, NULL);
INSERT INTO point VALUES (1432, 310, '4', NULL, NULL);
INSERT INTO point VALUES (1433, 585, '48', NULL, NULL);
INSERT INTO point VALUES (1434, 376, '27', NULL, NULL);
INSERT INTO point VALUES (1435, 340, '3', NULL, NULL);
INSERT INTO point VALUES (1436, 139, '22/7', NULL, NULL);
INSERT INTO point VALUES (1437, 531, '254', NULL, NULL);
INSERT INTO point VALUES (1438, 496, '32Б', NULL, NULL);
INSERT INTO point VALUES (1439, 601, '149', NULL, NULL);
INSERT INTO point VALUES (1440, 582, '11', NULL, NULL);
INSERT INTO point VALUES (1441, 469, '16', NULL, NULL);
INSERT INTO point VALUES (1442, 47, '3А', NULL, NULL);
INSERT INTO point VALUES (1443, 299, '25', NULL, NULL);
INSERT INTO point VALUES (1444, 657, '9', NULL, NULL);
INSERT INTO point VALUES (1445, 390, '2', NULL, NULL);
INSERT INTO point VALUES (1446, 455, '47', NULL, NULL);
INSERT INTO point VALUES (1447, 19, '17', NULL, NULL);
INSERT INTO point VALUES (1448, 398, '17', NULL, NULL);
INSERT INTO point VALUES (1449, 161, '1', NULL, NULL);
INSERT INTO point VALUES (1450, 431, '19', NULL, NULL);
INSERT INTO point VALUES (1451, 447, '70', NULL, NULL);
INSERT INTO point VALUES (1452, 265, '20Б', NULL, NULL);
INSERT INTO point VALUES (1453, 172, '12', NULL, NULL);
INSERT INTO point VALUES (1454, 548, '26', NULL, NULL);
INSERT INTO point VALUES (1455, 594, '50', NULL, NULL);
INSERT INTO point VALUES (1456, 483, '21', NULL, NULL);
INSERT INTO point VALUES (1457, 469, '20', NULL, NULL);
INSERT INTO point VALUES (1458, 425, '30', NULL, NULL);
INSERT INTO point VALUES (1459, 448, '9', NULL, NULL);
INSERT INTO point VALUES (1460, 282, '18', NULL, NULL);
INSERT INTO point VALUES (1461, 601, '60', NULL, NULL);
INSERT INTO point VALUES (1462, 458, '95', NULL, NULL);
INSERT INTO point VALUES (1463, 176, '19', NULL, NULL);
INSERT INTO point VALUES (1464, 415, '65', NULL, NULL);
INSERT INTO point VALUES (1465, 433, '28', NULL, NULL);
INSERT INTO point VALUES (1466, 15, '27', NULL, NULL);
INSERT INTO point VALUES (1467, 496, '103', NULL, NULL);
INSERT INTO point VALUES (1468, 598, '1', NULL, NULL);
INSERT INTO point VALUES (1469, 639, '5', NULL, NULL);
INSERT INTO point VALUES (1470, 678, '16', NULL, NULL);
INSERT INTO point VALUES (1471, 521, '2А', NULL, NULL);
INSERT INTO point VALUES (1472, 447, '68', NULL, NULL);
INSERT INTO point VALUES (1473, 215, '57', NULL, NULL);
INSERT INTO point VALUES (1474, 496, '1/2', NULL, NULL);
INSERT INTO point VALUES (1475, 438, '25', NULL, NULL);
INSERT INTO point VALUES (1476, 304, '42', NULL, NULL);
INSERT INTO point VALUES (1477, 163, '31', NULL, NULL);
INSERT INTO point VALUES (1478, 477, '14', NULL, NULL);
INSERT INTO point VALUES (1479, 262, '15', NULL, NULL);
INSERT INTO point VALUES (1480, 183, '9', NULL, NULL);
INSERT INTO point VALUES (1481, 117, '43', NULL, NULL);
INSERT INTO point VALUES (1482, 465, '53', NULL, NULL);
INSERT INTO point VALUES (1483, 279, '3', NULL, NULL);
INSERT INTO point VALUES (1484, 133, '3', NULL, NULL);
INSERT INTO point VALUES (1485, 374, '58', NULL, NULL);
INSERT INTO point VALUES (1486, 250, '35', NULL, NULL);
INSERT INTO point VALUES (1487, 110, '15', NULL, NULL);
INSERT INTO point VALUES (1488, 225, '8', NULL, NULL);
INSERT INTO point VALUES (1489, 161, '19', NULL, NULL);
INSERT INTO point VALUES (1490, 431, '1', NULL, NULL);
INSERT INTO point VALUES (1491, 492, '3', NULL, NULL);
INSERT INTO point VALUES (1492, 265, '34', NULL, NULL);
INSERT INTO point VALUES (1493, 130, '9', NULL, NULL);
INSERT INTO point VALUES (1494, 458, '18', NULL, NULL);
INSERT INTO point VALUES (1495, 611, '8', NULL, NULL);
INSERT INTO point VALUES (1496, 283, '9', NULL, NULL);
INSERT INTO point VALUES (1497, 329, '30А', NULL, NULL);
INSERT INTO point VALUES (1498, 100, '91', NULL, NULL);
INSERT INTO point VALUES (1499, 548, '9', NULL, NULL);
INSERT INTO point VALUES (1500, 472, '19', NULL, NULL);
INSERT INTO point VALUES (1501, 465, '90', NULL, NULL);
INSERT INTO point VALUES (1502, 356, '10', NULL, NULL);
INSERT INTO point VALUES (1503, 208, '13', NULL, NULL);
INSERT INTO point VALUES (1504, 303, '55', NULL, NULL);
INSERT INTO point VALUES (1505, 531, '21', NULL, NULL);
INSERT INTO point VALUES (1506, 183, '26', NULL, NULL);
INSERT INTO point VALUES (1507, 598, '19', NULL, NULL);
INSERT INTO point VALUES (1508, 105, '8', NULL, NULL);
INSERT INTO point VALUES (1509, 639, '2', NULL, NULL);
INSERT INTO point VALUES (1510, 374, '12', NULL, NULL);
INSERT INTO point VALUES (1511, 48, '10', NULL, NULL);
INSERT INTO point VALUES (1512, 55, '12', NULL, NULL);
INSERT INTO point VALUES (1513, 395, '6', NULL, NULL);
INSERT INTO point VALUES (1514, 144, '9', NULL, NULL);
INSERT INTO point VALUES (1515, 643, '73', NULL, NULL);
INSERT INTO point VALUES (1516, 265, '15Б', NULL, NULL);
INSERT INTO point VALUES (1517, 696, '17', NULL, NULL);
INSERT INTO point VALUES (1518, 294, '23', NULL, NULL);
INSERT INTO point VALUES (1519, 547, '24', NULL, NULL);
INSERT INTO point VALUES (1520, 264, '18', NULL, NULL);
INSERT INTO point VALUES (1521, 12, '60', NULL, NULL);
INSERT INTO point VALUES (1522, 157, '20', NULL, NULL);
INSERT INTO point VALUES (1523, 396, '28', NULL, NULL);
INSERT INTO point VALUES (1524, 589, '66', NULL, NULL);
INSERT INTO point VALUES (1525, 296, '1/2', NULL, NULL);
INSERT INTO point VALUES (1526, 411, '16', NULL, NULL);
INSERT INTO point VALUES (1527, 496, '18', NULL, NULL);
INSERT INTO point VALUES (1528, 228, '4', NULL, NULL);
INSERT INTO point VALUES (1529, 181, '44', NULL, NULL);
INSERT INTO point VALUES (1530, 544, '19', NULL, NULL);
INSERT INTO point VALUES (1531, 37, '1А', NULL, NULL);
INSERT INTO point VALUES (1532, 248, '7', NULL, NULL);
INSERT INTO point VALUES (1533, 44, '26', NULL, NULL);
INSERT INTO point VALUES (1534, 3, '8', NULL, NULL);
INSERT INTO point VALUES (1535, 610, '17А', NULL, NULL);
INSERT INTO point VALUES (1536, 220, '22/6', NULL, NULL);
INSERT INTO point VALUES (1537, 531, '216', NULL, NULL);
INSERT INTO point VALUES (1538, 115, '9', NULL, NULL);
INSERT INTO point VALUES (1539, 235, '15', NULL, NULL);
INSERT INTO point VALUES (1540, 474, '3', NULL, NULL);
INSERT INTO point VALUES (1541, 664, '12А', NULL, NULL);
INSERT INTO point VALUES (1542, 346, '12', NULL, NULL);
INSERT INTO point VALUES (1543, 496, '22/1', NULL, NULL);
INSERT INTO point VALUES (1544, 117, '56', NULL, NULL);
INSERT INTO point VALUES (1545, 607, '21', NULL, NULL);
INSERT INTO point VALUES (1546, 169, '22', NULL, NULL);
INSERT INTO point VALUES (1547, 87, '22', NULL, NULL);
INSERT INTO point VALUES (1548, 476, '8', NULL, NULL);
INSERT INTO point VALUES (1549, 539, '23', NULL, NULL);
INSERT INTO point VALUES (1550, 46, '17', NULL, NULL);
INSERT INTO point VALUES (1551, 181, '24', NULL, NULL);
INSERT INTO point VALUES (1552, 561, '19', NULL, NULL);
INSERT INTO point VALUES (1553, 203, '25', NULL, NULL);
INSERT INTO point VALUES (1554, 447, '37', NULL, NULL);
INSERT INTO point VALUES (1555, 360, '1', NULL, NULL);
INSERT INTO point VALUES (1556, 601, '151', NULL, NULL);
INSERT INTO point VALUES (1557, 643, '55', NULL, NULL);
INSERT INTO point VALUES (1558, 75, '19', NULL, NULL);
INSERT INTO point VALUES (1559, 544, '1', NULL, NULL);
INSERT INTO point VALUES (1560, 566, '44', NULL, NULL);
INSERT INTO point VALUES (1561, 92, '9', NULL, NULL);
INSERT INTO point VALUES (1562, 496, '95', NULL, NULL);
INSERT INTO point VALUES (1563, 345, '13', NULL, NULL);
INSERT INTO point VALUES (1564, 560, '88', NULL, NULL);
INSERT INTO point VALUES (1565, 76, '48', NULL, NULL);
INSERT INTO point VALUES (1566, 219, '15', NULL, NULL);
INSERT INTO point VALUES (1567, 334, '48', NULL, NULL);
INSERT INTO point VALUES (1568, 560, '14', NULL, NULL);
INSERT INTO point VALUES (1569, 598, '52', NULL, NULL);
INSERT INTO point VALUES (1570, 236, '23', NULL, NULL);
INSERT INTO point VALUES (1571, 254, '28', NULL, NULL);
INSERT INTO point VALUES (1572, 261, '17', NULL, NULL);
INSERT INTO point VALUES (1573, 286, '6', NULL, NULL);
INSERT INTO point VALUES (1574, 100, '81А', NULL, NULL);
INSERT INTO point VALUES (1575, 521, '2', NULL, NULL);
INSERT INTO point VALUES (1576, 569, '17', NULL, NULL);
INSERT INTO point VALUES (1577, 663, '19', NULL, NULL);
INSERT INTO point VALUES (1578, 199, '6/2', NULL, NULL);
INSERT INTO point VALUES (1579, 67, '51/2', NULL, NULL);
INSERT INTO point VALUES (1580, 653, '27', NULL, NULL);
INSERT INTO point VALUES (1581, 591, '2', NULL, NULL);
INSERT INTO point VALUES (1582, 665, '11', NULL, NULL);
INSERT INTO point VALUES (1583, 473, '24', NULL, NULL);
INSERT INTO point VALUES (1584, 100, '108', NULL, NULL);
INSERT INTO point VALUES (1585, 26, '18', NULL, NULL);
INSERT INTO point VALUES (1586, 571, '6', NULL, NULL);
INSERT INTO point VALUES (1587, 528, '1', NULL, NULL);
INSERT INTO point VALUES (1588, 598, '13', NULL, NULL);
INSERT INTO point VALUES (1589, 208, '19', NULL, NULL);
INSERT INTO point VALUES (1590, 304, '44', NULL, NULL);
INSERT INTO point VALUES (1591, 472, '13', NULL, NULL);
INSERT INTO point VALUES (1592, 374, '1А', NULL, NULL);
INSERT INTO point VALUES (1593, 99, '29', NULL, NULL);
INSERT INTO point VALUES (1594, 372, '42А', NULL, NULL);
INSERT INTO point VALUES (1595, 294, '106', NULL, NULL);
INSERT INTO point VALUES (1596, 362, '14', NULL, NULL);
INSERT INTO point VALUES (1597, 111, '9', NULL, NULL);
INSERT INTO point VALUES (1598, 231, '22', NULL, NULL);
INSERT INTO point VALUES (1599, 562, '9', NULL, NULL);
INSERT INTO point VALUES (1600, 139, '21/3', NULL, NULL);
INSERT INTO point VALUES (1601, 614, '4', NULL, NULL);
INSERT INTO point VALUES (1602, 197, '6А', NULL, NULL);
INSERT INTO point VALUES (1603, 505, '4', NULL, NULL);
INSERT INTO point VALUES (1604, 696, '18/1', NULL, NULL);
INSERT INTO point VALUES (1605, 161, '13', NULL, NULL);
INSERT INTO point VALUES (1606, 566, '34/4', NULL, NULL);
INSERT INTO point VALUES (1607, 50, '7', NULL, NULL);
INSERT INTO point VALUES (1608, 473, '33', NULL, NULL);
INSERT INTO point VALUES (1609, 548, '65', NULL, NULL);
INSERT INTO point VALUES (1610, 120, '11', NULL, NULL);
INSERT INTO point VALUES (1611, 294, '256', NULL, NULL);
INSERT INTO point VALUES (1612, 445, '20', NULL, NULL);
INSERT INTO point VALUES (1613, 462, '12', NULL, NULL);
INSERT INTO point VALUES (1614, 411, '20', NULL, NULL);
INSERT INTO point VALUES (1615, 460, '10', NULL, NULL);
INSERT INTO point VALUES (1616, 180, '37', NULL, NULL);
INSERT INTO point VALUES (1617, 663, '1', NULL, NULL);
INSERT INTO point VALUES (1618, 465, '88А', NULL, NULL);
INSERT INTO point VALUES (1619, 696, '39', NULL, NULL);
INSERT INTO point VALUES (1620, 152, '12', NULL, NULL);
INSERT INTO point VALUES (1621, 208, '1', NULL, NULL);
INSERT INTO point VALUES (1622, 566, '34/2', NULL, NULL);
INSERT INTO point VALUES (1623, 604, '203', NULL, NULL);
INSERT INTO point VALUES (1624, 236, '106', NULL, NULL);
INSERT INTO point VALUES (1625, 531, '19А', NULL, NULL);
INSERT INTO point VALUES (1626, 304, '33', NULL, NULL);
INSERT INTO point VALUES (1627, 220, '13', NULL, NULL);
INSERT INTO point VALUES (1628, 496, '36', NULL, NULL);
INSERT INTO point VALUES (1629, 582, '4', NULL, NULL);
INSERT INTO point VALUES (1630, 538, '8', NULL, NULL);
INSERT INTO point VALUES (1631, 176, '13', NULL, NULL);
INSERT INTO point VALUES (1632, 304, '24', NULL, NULL);
INSERT INTO point VALUES (1633, 356, '6', NULL, NULL);
INSERT INTO point VALUES (1634, 311, '1', NULL, NULL);
INSERT INTO point VALUES (1635, 334, '32А', NULL, NULL);
INSERT INTO point VALUES (1636, 499, '17', NULL, NULL);
INSERT INTO point VALUES (1637, 163, '38', NULL, NULL);
INSERT INTO point VALUES (1638, 567, '10', NULL, NULL);
INSERT INTO point VALUES (1639, 265, '35', NULL, NULL);
INSERT INTO point VALUES (1640, 111, '26', NULL, NULL);
INSERT INTO point VALUES (1641, 562, '26', NULL, NULL);
INSERT INTO point VALUES (1642, 48, '6', NULL, NULL);
INSERT INTO point VALUES (1643, 157, '16', NULL, NULL);
INSERT INTO point VALUES (1644, 334, '21', NULL, NULL);
INSERT INTO point VALUES (1645, 250, '34', NULL, NULL);
INSERT INTO point VALUES (1646, 415, '9', NULL, NULL);
INSERT INTO point VALUES (1647, 425, '46', NULL, NULL);
INSERT INTO point VALUES (1648, 596, '3', NULL, NULL);
INSERT INTO point VALUES (1649, 376, '63', NULL, NULL);
INSERT INTO point VALUES (1650, 572, '5-717', NULL, NULL);
INSERT INTO point VALUES (1651, 541, '18', NULL, NULL);
INSERT INTO point VALUES (1652, 146, '33', NULL, NULL);
INSERT INTO point VALUES (1653, 359, '12Б', NULL, NULL);
INSERT INTO point VALUES (1654, 548, '29', NULL, NULL);
INSERT INTO point VALUES (1655, 117, '16', NULL, NULL);
INSERT INTO point VALUES (1656, 509, '1', NULL, NULL);
INSERT INTO point VALUES (1657, 49, '10', NULL, NULL);
INSERT INTO point VALUES (1658, 158, '11', NULL, NULL);
INSERT INTO point VALUES (1659, 105, '7', NULL, NULL);
INSERT INTO point VALUES (1660, 618, '15', NULL, NULL);
INSERT INTO point VALUES (1661, 100, '11', NULL, NULL);
INSERT INTO point VALUES (1662, 239, '3', NULL, NULL);
INSERT INTO point VALUES (1663, 111, '40А', NULL, NULL);
INSERT INTO point VALUES (1664, 174, '5', NULL, NULL);
INSERT INTO point VALUES (1665, 554, '17', NULL, NULL);
INSERT INTO point VALUES (1666, 639, '20А', NULL, NULL);
INSERT INTO point VALUES (1667, 548, '61', NULL, NULL);
INSERT INTO point VALUES (1668, 564, '1', NULL, NULL);
INSERT INTO point VALUES (1669, 236, '25', NULL, NULL);
INSERT INTO point VALUES (1670, 44, '5', NULL, NULL);
INSERT INTO point VALUES (1671, 435, '41', NULL, NULL);
INSERT INTO point VALUES (1672, 225, '7', NULL, NULL);
INSERT INTO point VALUES (1673, 429, '18', NULL, NULL);
INSERT INTO point VALUES (1674, 601, '128', NULL, NULL);
INSERT INTO point VALUES (1675, 600, '31', NULL, NULL);
INSERT INTO point VALUES (1676, 144, '29', NULL, NULL);
INSERT INTO point VALUES (1677, 539, '25', NULL, NULL);
INSERT INTO point VALUES (1678, 451, '12/1', NULL, NULL);
INSERT INTO point VALUES (1679, 654, '35', NULL, NULL);
INSERT INTO point VALUES (1680, 585, '30', NULL, NULL);
INSERT INTO point VALUES (1681, 183, '52/3', NULL, NULL);
INSERT INTO point VALUES (1682, 203, '23', NULL, NULL);
INSERT INTO point VALUES (1683, 222, '5', NULL, NULL);
INSERT INTO point VALUES (1684, 262, '22', NULL, NULL);
INSERT INTO point VALUES (1685, 563, '3', NULL, NULL);
INSERT INTO point VALUES (1686, 389, '27/2', NULL, NULL);
INSERT INTO point VALUES (1687, 92, '5', NULL, NULL);
INSERT INTO point VALUES (1688, 74, '1', NULL, NULL);
INSERT INTO point VALUES (1689, 48, '20', NULL, NULL);
INSERT INTO point VALUES (1690, 435, '31', NULL, NULL);
INSERT INTO point VALUES (1691, 26, '27', NULL, NULL);
INSERT INTO point VALUES (1692, 670, '13', NULL, NULL);
INSERT INTO point VALUES (1693, 234, '45', NULL, NULL);
INSERT INTO point VALUES (1694, 374, '53', NULL, NULL);
INSERT INTO point VALUES (1695, 566, '36/3', NULL, NULL);
INSERT INTO point VALUES (1696, 110, '22', NULL, NULL);
INSERT INTO point VALUES (1697, 6, '19', NULL, NULL);
INSERT INTO point VALUES (1698, 509, '19', NULL, NULL);
INSERT INTO point VALUES (1699, 40, '4', NULL, NULL);
INSERT INTO point VALUES (1700, 182, '4', NULL, NULL);
INSERT INTO point VALUES (1701, 236, '32', NULL, NULL);
INSERT INTO point VALUES (1702, 657, '2А', NULL, NULL);
INSERT INTO point VALUES (1703, 277, '4', NULL, NULL);
INSERT INTO point VALUES (1704, 653, '18', NULL, NULL);
INSERT INTO point VALUES (1705, 601, '28', NULL, NULL);
INSERT INTO point VALUES (1706, 539, '32', NULL, NULL);
INSERT INTO point VALUES (1707, 548, '89', NULL, NULL);
INSERT INTO point VALUES (1708, 92, '2', NULL, NULL);
INSERT INTO point VALUES (1709, 445, '56', NULL, NULL);
INSERT INTO point VALUES (1710, 374, '127А', NULL, NULL);
INSERT INTO point VALUES (1711, 183, '29', NULL, NULL);
INSERT INTO point VALUES (1712, 329, '8', NULL, NULL);
INSERT INTO point VALUES (1713, 465, '112', NULL, NULL);
INSERT INTO point VALUES (1714, 250, '39', NULL, NULL);
INSERT INTO point VALUES (1715, 115, '5', NULL, NULL);
INSERT INTO point VALUES (1716, 215, '51', NULL, NULL);
INSERT INTO point VALUES (1717, 294, '25', NULL, NULL);
INSERT INTO point VALUES (1718, 386, '10А', NULL, NULL);
INSERT INTO point VALUES (1719, 295, '3', NULL, NULL);
INSERT INTO point VALUES (1720, 231, '2В', NULL, NULL);
INSERT INTO point VALUES (1721, 76, '46', NULL, NULL);
INSERT INTO point VALUES (1722, 483, '30', NULL, NULL);
INSERT INTO point VALUES (1723, 601, '153', NULL, NULL);
INSERT INTO point VALUES (1724, 294, '204', NULL, NULL);
INSERT INTO point VALUES (1725, 334, '46', NULL, NULL);
INSERT INTO point VALUES (1726, 374, '167', NULL, NULL);
INSERT INTO point VALUES (1727, 226, '4', NULL, NULL);
INSERT INTO point VALUES (1728, 23, '15', NULL, NULL);
INSERT INTO point VALUES (1729, 465, '57', NULL, NULL);
INSERT INTO point VALUES (1730, 531, '166', NULL, NULL);
INSERT INTO point VALUES (1731, 521, '9', NULL, NULL);
INSERT INTO point VALUES (1732, 161, '14', NULL, NULL);
INSERT INTO point VALUES (1733, 294, '186', NULL, NULL);
INSERT INTO point VALUES (1734, 408, '12', NULL, NULL);
INSERT INTO point VALUES (1735, 653, '36', NULL, NULL);
INSERT INTO point VALUES (1736, 458, '63', NULL, NULL);
INSERT INTO point VALUES (1737, 424, '12', NULL, NULL);
INSERT INTO point VALUES (1738, 362, '13', NULL, NULL);
INSERT INTO point VALUES (1739, 657, '29', NULL, NULL);
INSERT INTO point VALUES (1740, 472, '14', NULL, NULL);
INSERT INTO point VALUES (1741, 434, '22', NULL, NULL);
INSERT INTO point VALUES (1742, 600, '54', NULL, NULL);
INSERT INTO point VALUES (1743, 554, '102', NULL, NULL);
INSERT INTO point VALUES (1744, 531, '252', NULL, NULL);
INSERT INTO point VALUES (1745, 206, '2', NULL, NULL);
INSERT INTO point VALUES (1746, 562, '2', NULL, NULL);
INSERT INTO point VALUES (1747, 523, '24', NULL, NULL);
INSERT INTO point VALUES (1748, 435, '54', NULL, NULL);
INSERT INTO point VALUES (1749, 601, '136', NULL, NULL);
INSERT INTO point VALUES (1750, 12, '111', NULL, NULL);
INSERT INTO point VALUES (1751, 374, '97а', NULL, NULL);
INSERT INTO point VALUES (1752, 571, '16', NULL, NULL);
INSERT INTO point VALUES (1753, 349, '8', NULL, NULL);
INSERT INTO point VALUES (1754, 431, '14', NULL, NULL);
INSERT INTO point VALUES (1755, 525, '15', NULL, NULL);
INSERT INTO point VALUES (1756, 494, '18', NULL, NULL);
INSERT INTO point VALUES (1757, 356, '16', NULL, NULL);
INSERT INTO point VALUES (1758, 371, '10', NULL, NULL);
INSERT INTO point VALUES (1759, 496, '92', NULL, NULL);
INSERT INTO point VALUES (1760, 184, '41', NULL, NULL);
INSERT INTO point VALUES (1761, 374, '51', NULL, NULL);
INSERT INTO point VALUES (1762, 378, '1', NULL, NULL);
INSERT INTO point VALUES (1763, 166, '29', NULL, NULL);
INSERT INTO point VALUES (1764, 503, '6', NULL, NULL);
INSERT INTO point VALUES (1765, 84, '9', NULL, NULL);
INSERT INTO point VALUES (1766, 496, '48/1', NULL, NULL);
INSERT INTO point VALUES (1767, 236, '7', NULL, NULL);
INSERT INTO point VALUES (1768, 48, '16', NULL, NULL);
INSERT INTO point VALUES (1769, 176, '14', NULL, NULL);
INSERT INTO point VALUES (1770, 157, '6', NULL, NULL);
INSERT INTO point VALUES (1771, 435, '28А', NULL, NULL);
INSERT INTO point VALUES (1772, 117, '20', NULL, NULL);
INSERT INTO point VALUES (1773, 49, '43', NULL, NULL);
INSERT INTO point VALUES (1774, 388, '29', NULL, NULL);
INSERT INTO point VALUES (1775, 539, '7', NULL, NULL);
INSERT INTO point VALUES (1776, 215, '53', NULL, NULL);
INSERT INTO point VALUES (1777, 415, '2', NULL, NULL);
INSERT INTO point VALUES (1778, 283, '2А', NULL, NULL);
INSERT INTO point VALUES (1779, 304, '30/1', NULL, NULL);
INSERT INTO point VALUES (1780, 227, '15', NULL, NULL);
INSERT INTO point VALUES (1781, 477, '19', NULL, NULL);
INSERT INTO point VALUES (1782, 585, '40', NULL, NULL);
INSERT INTO point VALUES (1783, 425, '48', NULL, NULL);
INSERT INTO point VALUES (1784, 111, '5', NULL, NULL);
INSERT INTO point VALUES (1785, 511, '1', NULL, NULL);
INSERT INTO point VALUES (1786, 562, '5', NULL, NULL);
INSERT INTO point VALUES (1787, 563, '28', NULL, NULL);
INSERT INTO point VALUES (1788, 411, '10', NULL, NULL);
INSERT INTO point VALUES (1789, 338, '40', NULL, NULL);
INSERT INTO point VALUES (1790, 531, '248', NULL, NULL);
INSERT INTO point VALUES (1791, 27, '57', NULL, NULL);
INSERT INTO point VALUES (1792, 76, '30', NULL, NULL);
INSERT INTO point VALUES (1793, 435, '47', NULL, NULL);
INSERT INTO point VALUES (1794, 334, '30', NULL, NULL);
INSERT INTO point VALUES (1795, 213, '33', NULL, NULL);
INSERT INTO point VALUES (1796, 49, '6', NULL, NULL);
INSERT INTO point VALUES (1797, 183, '40А', NULL, NULL);
INSERT INTO point VALUES (1798, 74, '13', NULL, NULL);
INSERT INTO point VALUES (1799, 460, '20', NULL, NULL);
INSERT INTO point VALUES (1800, 531, '130', NULL, NULL);
INSERT INTO point VALUES (1801, 600, '47', NULL, NULL);
INSERT INTO point VALUES (1802, 299, '23', NULL, NULL);
INSERT INTO point VALUES (1803, 20, '3', NULL, NULL);
INSERT INTO point VALUES (1804, 561, '14', NULL, NULL);
INSERT INTO point VALUES (1805, 112, '38', NULL, NULL);
INSERT INTO point VALUES (1806, 572, '37', NULL, NULL);
INSERT INTO point VALUES (1807, 545, '27/1', NULL, NULL);
INSERT INTO point VALUES (1808, 455, '8Б', NULL, NULL);
INSERT INTO point VALUES (1809, 373, '33', NULL, NULL);
INSERT INTO point VALUES (1810, 452, '12', NULL, NULL);
INSERT INTO point VALUES (1811, 657, '5', NULL, NULL);
INSERT INTO point VALUES (1812, 415, '29', NULL, NULL);
INSERT INTO point VALUES (1813, 390, '26', NULL, NULL);
INSERT INTO point VALUES (1814, 316, '8', NULL, NULL);
INSERT INTO point VALUES (1815, 329, '23', NULL, NULL);
INSERT INTO point VALUES (1816, 231, '15', NULL, NULL);
INSERT INTO point VALUES (1817, 564, '13', NULL, NULL);
INSERT INTO point VALUES (1818, 236, '140', NULL, NULL);
INSERT INTO point VALUES (1819, 231, '2Г', NULL, NULL);
INSERT INTO point VALUES (1820, 509, '13', NULL, NULL);
INSERT INTO point VALUES (1821, 388, '2', NULL, NULL);
INSERT INTO point VALUES (1822, 554, '99', NULL, NULL);
INSERT INTO point VALUES (1823, 560, '19', NULL, NULL);
INSERT INTO point VALUES (1824, 285, '12', NULL, NULL);
INSERT INTO point VALUES (1825, 415, '61', NULL, NULL);
INSERT INTO point VALUES (1826, 670, '19', NULL, NULL);
INSERT INTO point VALUES (1827, 213, '24', NULL, NULL);
INSERT INTO point VALUES (1828, 279, '60', NULL, NULL);
INSERT INTO point VALUES (1829, 464, '22', NULL, NULL);
INSERT INTO point VALUES (1830, 469, '6', NULL, NULL);
INSERT INTO point VALUES (1831, 542, '10А', NULL, NULL);
INSERT INTO point VALUES (1832, 277, '50', NULL, NULL);
INSERT INTO point VALUES (1833, 294, '140', NULL, NULL);
INSERT INTO point VALUES (1834, 374, '88А', NULL, NULL);
INSERT INTO point VALUES (1835, 486, '12', NULL, NULL);
INSERT INTO point VALUES (1836, 94, '9', NULL, NULL);
INSERT INTO point VALUES (1837, 67, '62', NULL, NULL);
INSERT INTO point VALUES (1838, 166, '5', NULL, NULL);
INSERT INTO point VALUES (1839, 389, '27/3', NULL, NULL);
INSERT INTO point VALUES (1840, 15, '18', NULL, NULL);
INSERT INTO point VALUES (1841, 496, '31А', NULL, NULL);
INSERT INTO point VALUES (1842, 201, '32', NULL, NULL);
INSERT INTO point VALUES (1843, 112, '5а', NULL, NULL);
INSERT INTO point VALUES (1844, 520, '20', NULL, NULL);
INSERT INTO point VALUES (1845, 223, '21', NULL, NULL);
INSERT INTO point VALUES (1846, 696, '35', NULL, NULL);
INSERT INTO point VALUES (1847, 388, '5', NULL, NULL);
INSERT INTO point VALUES (1848, 215, '113', NULL, NULL);
INSERT INTO point VALUES (1849, 544, '14', NULL, NULL);
INSERT INTO point VALUES (1850, 496, '63', NULL, NULL);
INSERT INTO point VALUES (1851, 496, '78А', NULL, NULL);
INSERT INTO point VALUES (1852, 384, '12', NULL, NULL);
INSERT INTO point VALUES (1853, 447, '72', NULL, NULL);
INSERT INTO point VALUES (1854, 376, '36', NULL, NULL);
INSERT INTO point VALUES (1855, 560, '1', NULL, NULL);
INSERT INTO point VALUES (1856, 390, '9', NULL, NULL);
INSERT INTO point VALUES (1857, 139, '21/1', NULL, NULL);
INSERT INTO point VALUES (1858, 268, '17', NULL, NULL);
INSERT INTO point VALUES (1859, 111, '29', NULL, NULL);
INSERT INTO point VALUES (1860, 562, '29', NULL, NULL);
INSERT INTO point VALUES (1861, 203, '8', NULL, NULL);
INSERT INTO point VALUES (1862, 150, '25', NULL, NULL);
INSERT INTO point VALUES (1863, 158, '4', NULL, NULL);
INSERT INTO point VALUES (1864, 477, '13', NULL, NULL);
INSERT INTO point VALUES (1865, 130, '5', NULL, NULL);
INSERT INTO point VALUES (1866, 265, '17', NULL, NULL);
INSERT INTO point VALUES (1867, 283, '5', NULL, NULL);
INSERT INTO point VALUES (1868, 183, '52/25', NULL, NULL);
INSERT INTO point VALUES (1869, 382, '3', NULL, NULL);
INSERT INTO point VALUES (1870, 496, '4А', NULL, NULL);
INSERT INTO point VALUES (1871, 174, '29', NULL, NULL);
INSERT INTO point VALUES (1872, 554, '97', NULL, NULL);
INSERT INTO point VALUES (1873, 292, '12', NULL, NULL);
INSERT INTO point VALUES (1874, 250, '69', NULL, NULL);
INSERT INTO point VALUES (1875, 59, '8', NULL, NULL);
INSERT INTO point VALUES (1876, 604, '215', NULL, NULL);
INSERT INTO point VALUES (1877, 294, '127', NULL, NULL);
INSERT INTO point VALUES (1878, 554, '105', NULL, NULL);
INSERT INTO point VALUES (1879, 476, '7', NULL, NULL);
INSERT INTO point VALUES (1880, 138, '6', NULL, NULL);
INSERT INTO point VALUES (1881, 496, '23Б', NULL, NULL);
INSERT INTO point VALUES (1882, 374, '175', NULL, NULL);
INSERT INTO point VALUES (1883, 59, '46Б', NULL, NULL);
INSERT INTO point VALUES (1884, 78, '4', NULL, NULL);
INSERT INTO point VALUES (1885, 664, '18/1', NULL, NULL);
INSERT INTO point VALUES (1886, 610, '41', NULL, NULL);
INSERT INTO point VALUES (1887, 610, '31', NULL, NULL);
INSERT INTO point VALUES (1888, 607, '30', NULL, NULL);
INSERT INTO point VALUES (1889, 168, '17', NULL, NULL);
INSERT INTO point VALUES (1890, 235, '22', NULL, NULL);
INSERT INTO point VALUES (1891, 120, '49', NULL, NULL);
INSERT INTO point VALUES (1892, 324, '28', NULL, NULL);
INSERT INTO point VALUES (1893, 663, '14', NULL, NULL);
INSERT INTO point VALUES (1894, 3, '7', NULL, NULL);
INSERT INTO point VALUES (1895, 374, '88Б', NULL, NULL);
INSERT INTO point VALUES (1896, 87, '15', NULL, NULL);
INSERT INTO point VALUES (1897, 280, '36', NULL, NULL);
INSERT INTO point VALUES (1898, 335, '12', NULL, NULL);
INSERT INTO point VALUES (1899, 374, '113', NULL, NULL);
INSERT INTO point VALUES (1900, 169, '15', NULL, NULL);
INSERT INTO point VALUES (1901, 338, '30', NULL, NULL);
INSERT INTO point VALUES (1902, 438, '23', NULL, NULL);
INSERT INTO point VALUES (1903, 649, '21', NULL, NULL);
INSERT INTO point VALUES (1904, 277, '11', NULL, NULL);
INSERT INTO point VALUES (1905, 601, '96', NULL, NULL);
INSERT INTO point VALUES (1906, 207, '8', NULL, NULL);
INSERT INTO point VALUES (1907, 201, '7', NULL, NULL);
INSERT INTO point VALUES (1908, 157, '10', NULL, NULL);
INSERT INTO point VALUES (1909, 76, '40', NULL, NULL);
INSERT INTO point VALUES (1910, 448, '5', NULL, NULL);
INSERT INTO point VALUES (1911, 208, '14', NULL, NULL);
INSERT INTO point VALUES (1912, 130, '2', NULL, NULL);
INSERT INTO point VALUES (1913, 334, '40', NULL, NULL);
INSERT INTO point VALUES (1914, 40, '11', NULL, NULL);
INSERT INTO point VALUES (1915, 182, '11', NULL, NULL);
INSERT INTO point VALUES (1916, 339, '24', NULL, NULL);
INSERT INTO point VALUES (1917, 184, '47', NULL, NULL);
INSERT INTO point VALUES (1918, 362, '19', NULL, NULL);
INSERT INTO point VALUES (1919, 183, '5', NULL, NULL);
INSERT INTO point VALUES (1920, 460, '16', NULL, NULL);
INSERT INTO point VALUES (1921, 552, '30', NULL, NULL);
INSERT INTO point VALUES (1922, 305, '1', NULL, NULL);
INSERT INTO point VALUES (1923, 144, '2', NULL, NULL);
INSERT INTO point VALUES (1924, 137, '3', NULL, NULL);
INSERT INTO point VALUES (1925, 27, '12', NULL, NULL);
INSERT INTO point VALUES (1926, 674, '6', NULL, NULL);
INSERT INTO point VALUES (1927, 166, '17', NULL, NULL);
INSERT INTO point VALUES (1928, 548, '39', NULL, NULL);
INSERT INTO point VALUES (1929, 100, '19', NULL, NULL);
INSERT INTO point VALUES (1930, 496, '25', NULL, NULL);
INSERT INTO point VALUES (1931, 250, '72/3', NULL, NULL);
INSERT INTO point VALUES (1932, 250, '89', NULL, NULL);
INSERT INTO point VALUES (1933, 654, '26', NULL, NULL);
INSERT INTO point VALUES (1934, 248, '36', NULL, NULL);
INSERT INTO point VALUES (1935, 175, '4', NULL, NULL);
INSERT INTO point VALUES (1936, 604, '15/207', NULL, NULL);
INSERT INTO point VALUES (1937, 183, '52/6', NULL, NULL);
INSERT INTO point VALUES (1938, 435, '45А', NULL, NULL);
INSERT INTO point VALUES (1939, 139, '22/3', NULL, NULL);
INSERT INTO point VALUES (1940, 98, '6', NULL, NULL);
INSERT INTO point VALUES (1941, 496, '72/2', NULL, NULL);
INSERT INTO point VALUES (1942, 617, '37', NULL, NULL);
INSERT INTO point VALUES (1943, 158, '19', NULL, NULL);
INSERT INTO point VALUES (1944, 541, '7', NULL, NULL);
INSERT INTO point VALUES (1945, 125, '3/1', NULL, NULL);
INSERT INTO point VALUES (1946, 598, '24А', NULL, NULL);
INSERT INTO point VALUES (1947, 305, '4', NULL, NULL);
INSERT INTO point VALUES (1948, 374, '58/1', NULL, NULL);
INSERT INTO point VALUES (1949, 687, '30', NULL, NULL);
INSERT INTO point VALUES (1950, 16, '55', NULL, NULL);
INSERT INTO point VALUES (1951, 292, '21', NULL, NULL);
INSERT INTO point VALUES (1952, 388, '17', NULL, NULL);
INSERT INTO point VALUES (1953, 12, '98', NULL, NULL);
INSERT INTO point VALUES (1954, 245, '35А', NULL, NULL);
INSERT INTO point VALUES (1955, 268, '5', NULL, NULL);
INSERT INTO point VALUES (1956, 369, '51', NULL, NULL);
INSERT INTO point VALUES (1957, 83, '22', NULL, NULL);
INSERT INTO point VALUES (1958, 78, '19', NULL, NULL);
INSERT INTO point VALUES (1959, 531, '27А', NULL, NULL);
INSERT INTO point VALUES (1960, 23, '4/2', NULL, NULL);
INSERT INTO point VALUES (1961, 634, '3', NULL, NULL);
INSERT INTO point VALUES (1962, 157, '26А', NULL, NULL);
INSERT INTO point VALUES (1963, 496, '1/3', NULL, NULL);
INSERT INTO point VALUES (1964, 239, '14Б', NULL, NULL);
INSERT INTO point VALUES (1965, 304, '62', NULL, NULL);
INSERT INTO point VALUES (1966, 582, '14', NULL, NULL);
INSERT INTO point VALUES (1967, 390, '34', NULL, NULL);
INSERT INTO point VALUES (1968, 496, '32', NULL, NULL);
INSERT INTO point VALUES (1969, 531, '196', NULL, NULL);
INSERT INTO point VALUES (1970, 362, '23А', NULL, NULL);
INSERT INTO point VALUES (1971, 670, '57А', NULL, NULL);
INSERT INTO point VALUES (1972, 27, '21', NULL, NULL);
INSERT INTO point VALUES (1973, 564, '11', NULL, NULL);
INSERT INTO point VALUES (1974, 516, '11', NULL, NULL);
INSERT INTO point VALUES (1975, 638, '1', NULL, NULL);
INSERT INTO point VALUES (1976, 15, '8', NULL, NULL);
INSERT INTO point VALUES (1977, 100, '1', NULL, NULL);
INSERT INTO point VALUES (1978, 405, '15', NULL, NULL);
INSERT INTO point VALUES (1979, 384, '48', NULL, NULL);
INSERT INTO point VALUES (1980, 88, '33', NULL, NULL);
INSERT INTO point VALUES (1981, 372, '42', NULL, NULL);
INSERT INTO point VALUES (1982, 277, '52', NULL, NULL);
INSERT INTO point VALUES (1983, 6, '11', NULL, NULL);
INSERT INTO point VALUES (1984, 59, '36', NULL, NULL);
INSERT INTO point VALUES (1985, 509, '11', NULL, NULL);
INSERT INTO point VALUES (1986, 169, '3', NULL, NULL);
INSERT INTO point VALUES (1987, 87, '3', NULL, NULL);
INSERT INTO point VALUES (1988, 695, '16', NULL, NULL);
INSERT INTO point VALUES (1989, 174, '69', NULL, NULL);
INSERT INTO point VALUES (1990, 525, '28', NULL, NULL);
INSERT INTO point VALUES (1991, 183, '39', NULL, NULL);
INSERT INTO point VALUES (1992, 74, '11', NULL, NULL);
INSERT INTO point VALUES (1993, 398, '9', NULL, NULL);
INSERT INTO point VALUES (1994, 649, '12', NULL, NULL);
INSERT INTO point VALUES (1995, 505, '14', NULL, NULL);
INSERT INTO point VALUES (1996, 657, '17', NULL, NULL);
INSERT INTO point VALUES (1997, 518, '14А', NULL, NULL);
INSERT INTO point VALUES (1998, 250, '61', NULL, NULL);
INSERT INTO point VALUES (1999, 26, '7', NULL, NULL);
INSERT INTO point VALUES (2000, 699, '4', NULL, NULL);
INSERT INTO point VALUES (2001, 78, '1', NULL, NULL);
INSERT INTO point VALUES (2002, 260, '12', NULL, NULL);
INSERT INTO point VALUES (2003, 376, '63А', NULL, NULL);
INSERT INTO point VALUES (2004, 20, '15', NULL, NULL);
INSERT INTO point VALUES (2005, 176, '49', NULL, NULL);
INSERT INTO point VALUES (2006, 139, '23/1', NULL, NULL);
INSERT INTO point VALUES (2007, 548, '67', NULL, NULL);
INSERT INTO point VALUES (2008, 497, '21', NULL, NULL);
INSERT INTO point VALUES (2009, 431, '49', NULL, NULL);
INSERT INTO point VALUES (2010, 294, '27', NULL, NULL);
INSERT INTO point VALUES (2011, 670, '23А', NULL, NULL);
INSERT INTO point VALUES (2012, 59, '18', NULL, NULL);
INSERT INTO point VALUES (2013, 448, '17', NULL, NULL);
INSERT INTO point VALUES (2014, 455, '10', NULL, NULL);
INSERT INTO point VALUES (2015, 604, '15/188', NULL, NULL);
INSERT INTO point VALUES (2016, 554, '139', NULL, NULL);
INSERT INTO point VALUES (2017, 346, '40', NULL, NULL);
INSERT INTO point VALUES (2018, 168, '2', NULL, NULL);
INSERT INTO point VALUES (2019, 183, '17', NULL, NULL);
INSERT INTO point VALUES (2020, 425, '1А', NULL, NULL);
INSERT INTO point VALUES (2021, 294, '92', NULL, NULL);
INSERT INTO point VALUES (2022, 117, '38', NULL, NULL);
INSERT INTO point VALUES (2023, 40, '13', NULL, NULL);
INSERT INTO point VALUES (2024, 182, '13', NULL, NULL);
INSERT INTO point VALUES (2025, 433, '22', NULL, NULL);
INSERT INTO point VALUES (2026, 695, '20', NULL, NULL);
INSERT INTO point VALUES (2027, 277, '13', NULL, NULL);
INSERT INTO point VALUES (2028, 172, '46', NULL, NULL);
INSERT INTO point VALUES (2029, 231, '3', NULL, NULL);
INSERT INTO point VALUES (2030, 554, '89', NULL, NULL);
INSERT INTO point VALUES (2031, 283, '17', NULL, NULL);
INSERT INTO point VALUES (2032, 117, '47', NULL, NULL);
INSERT INTO point VALUES (2033, 496, '7', NULL, NULL);
INSERT INTO point VALUES (2034, 265, '5', NULL, NULL);
INSERT INTO point VALUES (2035, 374, '46', NULL, NULL);
INSERT INTO point VALUES (2036, 166, '39', NULL, NULL);
INSERT INTO point VALUES (2037, 548, '17', NULL, NULL);
INSERT INTO point VALUES (2038, 539, '27', NULL, NULL);
INSERT INTO point VALUES (2039, 270, '10', NULL, NULL);
INSERT INTO point VALUES (2040, 236, '27', NULL, NULL);
INSERT INTO point VALUES (2041, 251, '7', NULL, NULL);
INSERT INTO point VALUES (2042, 191, '14', NULL, NULL);
INSERT INTO point VALUES (2043, 425, '5А', NULL, NULL);
INSERT INTO point VALUES (2044, 504, '6', NULL, NULL);
INSERT INTO point VALUES (2045, 264, '7', NULL, NULL);
INSERT INTO point VALUES (2046, 223, '12', NULL, NULL);
INSERT INTO point VALUES (2047, 151, '10', NULL, NULL);
INSERT INTO point VALUES (2048, 477, '11', NULL, NULL);
INSERT INTO point VALUES (2049, 183, '52/2', NULL, NULL);
INSERT INTO point VALUES (2050, 26, '32', NULL, NULL);
INSERT INTO point VALUES (2051, 397, '21', NULL, NULL);
INSERT INTO point VALUES (2052, 67, '110А', NULL, NULL);
INSERT INTO point VALUES (2053, 687, '40', NULL, NULL);
INSERT INTO point VALUES (2054, 228, '14', NULL, NULL);
INSERT INTO point VALUES (2055, 243, '6А', NULL, NULL);
INSERT INTO point VALUES (2056, 643, '72', NULL, NULL);
INSERT INTO point VALUES (2057, 210, '15А', NULL, NULL);
INSERT INTO point VALUES (2058, 294, '74А', NULL, NULL);
INSERT INTO point VALUES (2059, 15, '23', NULL, NULL);
INSERT INTO point VALUES (2060, 174, '67', NULL, NULL);
INSERT INTO point VALUES (2061, 234, '15', NULL, NULL);
INSERT INTO point VALUES (2062, 372, '24', NULL, NULL);
INSERT INTO point VALUES (2063, 682, '24', NULL, NULL);
INSERT INTO point VALUES (2064, 554, '2', NULL, NULL);
INSERT INTO point VALUES (2065, 294, '63', NULL, NULL);
INSERT INTO point VALUES (2066, 674, '10', NULL, NULL);
INSERT INTO point VALUES (2067, 626, '7', NULL, NULL);
INSERT INTO point VALUES (2068, 696, '9', NULL, NULL);
INSERT INTO point VALUES (2069, 315, '15', NULL, NULL);
INSERT INTO point VALUES (2070, 389, '25Б', NULL, NULL);
INSERT INTO point VALUES (2071, 39, '2', NULL, NULL);
INSERT INTO point VALUES (2072, 98, '10', NULL, NULL);
INSERT INTO point VALUES (2073, 589, '62', NULL, NULL);
INSERT INTO point VALUES (2074, 601, '86', NULL, NULL);
INSERT INTO point VALUES (2075, 429, '8', NULL, NULL);
INSERT INTO point VALUES (2076, 542, '51', NULL, NULL);
INSERT INTO point VALUES (2077, 572, '15А', NULL, NULL);
INSERT INTO point VALUES (2078, 408, '21', NULL, NULL);
INSERT INTO point VALUES (2079, 560, '11', NULL, NULL);
INSERT INTO point VALUES (2080, 427, '16', NULL, NULL);
INSERT INTO point VALUES (2081, 670, '11', NULL, NULL);
INSERT INTO point VALUES (2082, 458, '7', NULL, NULL);
INSERT INTO point VALUES (2083, 48, '41', NULL, NULL);
INSERT INTO point VALUES (2084, 531, '202', NULL, NULL);
INSERT INTO point VALUES (2085, 372, '33', NULL, NULL);
INSERT INTO point VALUES (2086, 396, '22', NULL, NULL);
INSERT INTO point VALUES (2087, 682, '33', NULL, NULL);
INSERT INTO point VALUES (2088, 629, '7', NULL, NULL);
INSERT INTO point VALUES (2089, 303, '72', NULL, NULL);
INSERT INTO point VALUES (2090, 561, '49', NULL, NULL);
INSERT INTO point VALUES (2091, 265, '29', NULL, NULL);
INSERT INTO point VALUES (2092, 46, '9', NULL, NULL);
INSERT INTO point VALUES (2093, 78, '13', NULL, NULL);
INSERT INTO point VALUES (2094, 75, '49', NULL, NULL);
INSERT INTO point VALUES (2095, 67, '76', NULL, NULL);
INSERT INTO point VALUES (2096, 571, '31', NULL, NULL);
INSERT INTO point VALUES (2097, 530, '8', NULL, NULL);
INSERT INTO point VALUES (2098, 525, '3', NULL, NULL);
INSERT INTO point VALUES (2099, 294, '76В', NULL, NULL);
INSERT INTO point VALUES (2100, 664, '12Д', NULL, NULL);
INSERT INTO point VALUES (2101, 563, '14А', NULL, NULL);
INSERT INTO point VALUES (2102, 53, '12', NULL, NULL);
INSERT INTO point VALUES (2103, 299, '18', NULL, NULL);
INSERT INTO point VALUES (2104, 235, '60', NULL, NULL);
INSERT INTO point VALUES (2105, 602, '39/1', NULL, NULL);
INSERT INTO point VALUES (2106, 158, '13', NULL, NULL);
INSERT INTO point VALUES (2107, 55, '40', NULL, NULL);
INSERT INTO point VALUES (2108, 477, '4', NULL, NULL);
INSERT INTO point VALUES (2109, 261, '9', NULL, NULL);
INSERT INTO point VALUES (2110, 108, '8', NULL, NULL);
INSERT INTO point VALUES (2111, 374, '40', NULL, NULL);
INSERT INTO point VALUES (2112, 531, '51', NULL, NULL);
INSERT INTO point VALUES (2113, 87, '28', NULL, NULL);
INSERT INTO point VALUES (2114, 44, '17', NULL, NULL);
INSERT INTO point VALUES (2115, 53, '58', NULL, NULL);
INSERT INTO point VALUES (2116, 256, '16', NULL, NULL);
INSERT INTO point VALUES (2117, 168, '29', NULL, NULL);
INSERT INTO point VALUES (2118, 239, '14А', NULL, NULL);
INSERT INTO point VALUES (2119, 100, '13', NULL, NULL);
INSERT INTO point VALUES (2120, 150, '27', NULL, NULL);
INSERT INTO point VALUES (2121, 372, '44', NULL, NULL);
INSERT INTO point VALUES (2122, 562, '39', NULL, NULL);
INSERT INTO point VALUES (2123, 236, '63', NULL, NULL);
INSERT INTO point VALUES (2124, 340, '22', NULL, NULL);
INSERT INTO point VALUES (2125, 117, '54', NULL, NULL);
INSERT INTO point VALUES (2126, 310, '14', NULL, NULL);
INSERT INTO point VALUES (2127, 525, '45', NULL, NULL);
INSERT INTO point VALUES (2128, 451, '10Б', NULL, NULL);
INSERT INTO point VALUES (2129, 646, '22', NULL, NULL);
INSERT INTO point VALUES (2130, 277, '1', NULL, NULL);
INSERT INTO point VALUES (2131, 231, '28', NULL, NULL);
INSERT INTO point VALUES (2132, 455, '6', NULL, NULL);
INSERT INTO point VALUES (2133, 323, '24', NULL, NULL);
INSERT INTO point VALUES (2134, 174, '39', NULL, NULL);
INSERT INTO point VALUES (2135, 569, '9', NULL, NULL);
INSERT INTO point VALUES (2136, 438, '18', NULL, NULL);
INSERT INTO point VALUES (2137, 542, '53', NULL, NULL);
INSERT INTO point VALUES (2138, 563, '15', NULL, NULL);
INSERT INTO point VALUES (2139, 389, '15/1', NULL, NULL);
INSERT INTO point VALUES (2140, 233, '9', NULL, NULL);
INSERT INTO point VALUES (2141, 329, '36', NULL, NULL);
INSERT INTO point VALUES (2142, 601, '98', NULL, NULL);
INSERT INTO point VALUES (2143, 361, '1', NULL, NULL);
INSERT INTO point VALUES (2144, 604, '211', NULL, NULL);
INSERT INTO point VALUES (2145, 325, '7', NULL, NULL);
INSERT INTO point VALUES (2146, 415, '67', NULL, NULL);
INSERT INTO point VALUES (2147, 112, '16', NULL, NULL);
INSERT INTO point VALUES (2148, 562, '17', NULL, NULL);
INSERT INTO point VALUES (2149, 55, '30', NULL, NULL);
INSERT INTO point VALUES (2150, 458, '32', NULL, NULL);
INSERT INTO point VALUES (2151, 539, '4А', NULL, NULL);
INSERT INTO point VALUES (2152, 142, '7', NULL, NULL);
INSERT INTO point VALUES (2153, 374, '30', NULL, NULL);
INSERT INTO point VALUES (2154, 584, '27', NULL, NULL);
INSERT INTO point VALUES (2155, 250, '2', NULL, NULL);
INSERT INTO point VALUES (2156, 602, '25 к3', NULL, NULL);
INSERT INTO point VALUES (2157, 139, '5', NULL, NULL);
INSERT INTO point VALUES (2158, 531, '127А', NULL, NULL);
INSERT INTO point VALUES (2159, 277, '19', NULL, NULL);
INSERT INTO point VALUES (2160, 427, '20', NULL, NULL);
INSERT INTO point VALUES (2161, 294, '127/5', NULL, NULL);
INSERT INTO point VALUES (2162, 40, '19', NULL, NULL);
INSERT INTO point VALUES (2163, 531, '90', NULL, NULL);
INSERT INTO point VALUES (2164, 564, '4', NULL, NULL);
INSERT INTO point VALUES (2165, 600, '16', NULL, NULL);
INSERT INTO point VALUES (2166, 375, '28', NULL, NULL);
INSERT INTO point VALUES (2167, 279, '22', NULL, NULL);
INSERT INTO point VALUES (2168, 531, '167', NULL, NULL);
INSERT INTO point VALUES (2169, 15, '25А', NULL, NULL);
INSERT INTO point VALUES (2170, 151, '6', NULL, NULL);
INSERT INTO point VALUES (2171, 263, '5А', NULL, NULL);
INSERT INTO point VALUES (2172, 504, '10', NULL, NULL);
INSERT INTO point VALUES (2173, 120, '14', NULL, NULL);
INSERT INTO point VALUES (2174, 451, '45', NULL, NULL);
INSERT INTO point VALUES (2175, 270, '6', NULL, NULL);
INSERT INTO point VALUES (2176, 304, '59', NULL, NULL);
INSERT INTO point VALUES (2177, 57, '21', NULL, NULL);
INSERT INTO point VALUES (2178, 117, '41', NULL, NULL);
INSERT INTO point VALUES (2179, 531, '53', NULL, NULL);
INSERT INTO point VALUES (2180, 74, '4', NULL, NULL);
INSERT INTO point VALUES (2181, 425, '58', NULL, NULL);
INSERT INTO point VALUES (2182, 294, '4А', NULL, NULL);
INSERT INTO point VALUES (2183, 515, '23', NULL, NULL);
INSERT INTO point VALUES (2184, 548, '69', NULL, NULL);
INSERT INTO point VALUES (2185, 117, '31', NULL, NULL);
INSERT INTO point VALUES (2186, 67, '180', NULL, NULL);
INSERT INTO point VALUES (2187, 604, '191', NULL, NULL);
INSERT INTO point VALUES (2188, 600, '16-14', NULL, NULL);
INSERT INTO point VALUES (2189, 362, '11', NULL, NULL);
INSERT INTO point VALUES (2190, 496, '127', NULL, NULL);
INSERT INTO point VALUES (2191, 668, '17', NULL, NULL);
INSERT INTO point VALUES (2192, 455, '56', NULL, NULL);
INSERT INTO point VALUES (2193, 499, '9', NULL, NULL);
INSERT INTO point VALUES (2194, 252, '7', NULL, NULL);
INSERT INTO point VALUES (2195, 421, '22', NULL, NULL);
INSERT INTO point VALUES (2196, 458, '25', NULL, NULL);
INSERT INTO point VALUES (2197, 376, '23', NULL, NULL);
INSERT INTO point VALUES (2198, 157, '31', NULL, NULL);
INSERT INTO point VALUES (2199, 427, '6', NULL, NULL);
INSERT INTO point VALUES (2200, 208, '4', NULL, NULL);
INSERT INTO point VALUES (2201, 157, '26/2', NULL, NULL);
INSERT INTO point VALUES (2202, 21, '7', NULL, NULL);
INSERT INTO point VALUES (2203, 264, '8', NULL, NULL);
INSERT INTO point VALUES (2204, 20, '22', NULL, NULL);
INSERT INTO point VALUES (2205, 24, '6', NULL, NULL);
INSERT INTO point VALUES (2206, 389, '42', NULL, NULL);
INSERT INTO point VALUES (2207, 345, '11', NULL, NULL);
INSERT INTO point VALUES (2208, 598, '31 ка', NULL, NULL);
INSERT INTO point VALUES (2209, 262, '28', NULL, NULL);
INSERT INTO point VALUES (2210, 46, '5', NULL, NULL);
INSERT INTO point VALUES (2211, 39, '9', NULL, NULL);
INSERT INTO point VALUES (2212, 506, '12', NULL, NULL);
INSERT INTO point VALUES (2213, 663, '4', NULL, NULL);
INSERT INTO point VALUES (2214, 294, '200', NULL, NULL);
INSERT INTO point VALUES (2215, 496, '8', NULL, NULL);
INSERT INTO point VALUES (2216, 250, '78', NULL, NULL);
INSERT INTO point VALUES (2217, 250, '64', NULL, NULL);
INSERT INTO point VALUES (2218, 386, '12', NULL, NULL);
INSERT INTO point VALUES (2219, 34, '19', NULL, NULL);
INSERT INTO point VALUES (2220, 3, '18', NULL, NULL);
INSERT INTO point VALUES (2221, 261, '5', NULL, NULL);
INSERT INTO point VALUES (2222, 582, '1', NULL, NULL);
INSERT INTO point VALUES (2223, 44, '34', NULL, NULL);
INSERT INTO point VALUES (2224, 294, '140А', NULL, NULL);
INSERT INTO point VALUES (2225, 433, '15', NULL, NULL);
INSERT INTO point VALUES (2226, 311, '4', NULL, NULL);
INSERT INTO point VALUES (2227, 531, '1А', NULL, NULL);
INSERT INTO point VALUES (2228, 528, '4', NULL, NULL);
INSERT INTO point VALUES (2229, 354, '24', NULL, NULL);
INSERT INTO point VALUES (2230, 415, '81', NULL, NULL);
INSERT INTO point VALUES (2231, 76, '12', NULL, NULL);
INSERT INTO point VALUES (2232, 406, '12', NULL, NULL);
INSERT INTO point VALUES (2233, 438, '27', NULL, NULL);
INSERT INTO point VALUES (2234, 46, '2', NULL, NULL);
INSERT INTO point VALUES (2235, 388, '35', NULL, NULL);
INSERT INTO point VALUES (2236, 202, '37', NULL, NULL);
INSERT INTO point VALUES (2237, 376, '7', NULL, NULL);
INSERT INTO point VALUES (2238, 445, '54', NULL, NULL);
INSERT INTO point VALUES (2239, 256, '6', NULL, NULL);
INSERT INTO point VALUES (2240, 261, '2', NULL, NULL);
INSERT INTO point VALUES (2241, 610, '10', NULL, NULL);
INSERT INTO point VALUES (2242, 166, '35', NULL, NULL);
INSERT INTO point VALUES (2243, 501, '24', NULL, NULL);
INSERT INTO point VALUES (2244, 110, '28', NULL, NULL);
INSERT INTO point VALUES (2245, 351, '3', NULL, NULL);
INSERT INTO point VALUES (2246, 374, '96А', NULL, NULL);
INSERT INTO point VALUES (2247, 280, '32', NULL, NULL);
INSERT INTO point VALUES (2248, 393, '17А', NULL, NULL);
INSERT INTO point VALUES (2249, 598, '50', NULL, NULL);
INSERT INTO point VALUES (2250, 152, '21', NULL, NULL);
INSERT INTO point VALUES (2251, 78, '14', NULL, NULL);
INSERT INTO point VALUES (2252, 536, '21', NULL, NULL);
INSERT INTO point VALUES (2253, 285, '30', NULL, NULL);
INSERT INTO point VALUES (2254, 100, '110', NULL, NULL);
INSERT INTO point VALUES (2255, 76, '58', NULL, NULL);
INSERT INTO point VALUES (2256, 582, '19', NULL, NULL);
INSERT INTO point VALUES (2257, 265, '20А', NULL, NULL);
INSERT INTO point VALUES (2258, 695, '10', NULL, NULL);
INSERT INTO point VALUES (2259, 599, '11А', NULL, NULL);
INSERT INTO point VALUES (2260, 531, '232', NULL, NULL);
INSERT INTO point VALUES (2261, 654, '29', NULL, NULL);
INSERT INTO point VALUES (2262, 303, '68', NULL, NULL);
INSERT INTO point VALUES (2263, 435, '22А', NULL, NULL);
INSERT INTO point VALUES (2264, 610, '43', NULL, NULL);
INSERT INTO point VALUES (2265, 434, '28', NULL, NULL);
INSERT INTO point VALUES (2266, 359, '8', NULL, NULL);
INSERT INTO point VALUES (2267, 435, '56', NULL, NULL);
INSERT INTO point VALUES (2268, 299, '27', NULL, NULL);
INSERT INTO point VALUES (2269, 49, '38', NULL, NULL);
INSERT INTO point VALUES (2270, 176, '11', NULL, NULL);
INSERT INTO point VALUES (2271, 360, '4', NULL, NULL);
INSERT INTO point VALUES (2272, 447, '73', NULL, NULL);
INSERT INTO point VALUES (2273, 431, '11', NULL, NULL);
INSERT INTO point VALUES (2274, 67, '24', NULL, NULL);
INSERT INTO point VALUES (2275, 458, '23', NULL, NULL);
INSERT INTO point VALUES (2276, 139, '9', NULL, NULL);
INSERT INTO point VALUES (2277, 376, '25', NULL, NULL);
INSERT INTO point VALUES (2278, 496, '11А', NULL, NULL);
INSERT INTO point VALUES (2279, 569, '2', NULL, NULL);
INSERT INTO point VALUES (2280, 338, '12', NULL, NULL);
INSERT INTO point VALUES (2281, 192, '12', NULL, NULL);
INSERT INTO point VALUES (2282, 235, '3', NULL, NULL);
INSERT INTO point VALUES (2283, 395, '17А', NULL, NULL);
INSERT INTO point VALUES (2284, 499, '5', NULL, NULL);
INSERT INTO point VALUES (2285, 95, '42', NULL, NULL);
INSERT INTO point VALUES (2286, 191, '19', NULL, NULL);
INSERT INTO point VALUES (2287, 303, '70', NULL, NULL);
INSERT INTO point VALUES (2288, 338, '58', NULL, NULL);
INSERT INTO point VALUES (2289, 548, '35', NULL, NULL);
INSERT INTO point VALUES (2290, 220, '11', NULL, NULL);
INSERT INTO point VALUES (2291, 59, '52А', NULL, NULL);
INSERT INTO point VALUES (2292, 604, '28', NULL, NULL);
INSERT INTO point VALUES (2293, 27, '30', NULL, NULL);
INSERT INTO point VALUES (2294, 329, '27', NULL, NULL);
INSERT INTO point VALUES (2295, 544, '4', NULL, NULL);
INSERT INTO point VALUES (2296, 626, '23', NULL, NULL);
INSERT INTO point VALUES (2297, 250, '80', NULL, NULL);
INSERT INTO point VALUES (2298, 500, '2', NULL, NULL);
INSERT INTO point VALUES (2299, 270, '16', NULL, NULL);
INSERT INTO point VALUES (2300, 75, '4', NULL, NULL);
INSERT INTO point VALUES (2301, 447, '55', NULL, NULL);
INSERT INTO point VALUES (2302, 451, '60', NULL, NULL);
INSERT INTO point VALUES (2303, 183, '35', NULL, NULL);
INSERT INTO point VALUES (2304, 569, '5', NULL, NULL);
INSERT INTO point VALUES (2305, 643, '37', NULL, NULL);
INSERT INTO point VALUES (2306, 29, '12', NULL, NULL);
INSERT INTO point VALUES (2307, 120, '13', NULL, NULL);
INSERT INTO point VALUES (2308, 411, '31', NULL, NULL);
INSERT INTO point VALUES (2309, 84, '17', NULL, NULL);
INSERT INTO point VALUES (2310, 161, '11', NULL, NULL);
INSERT INTO point VALUES (2311, 294, '145', NULL, NULL);
INSERT INTO point VALUES (2312, 250, '26', NULL, NULL);
INSERT INTO point VALUES (2313, 538, '18', NULL, NULL);
INSERT INTO point VALUES (2314, 665, '13', NULL, NULL);
INSERT INTO point VALUES (2315, 219, '3', NULL, NULL);
INSERT INTO point VALUES (2316, 531, '124', NULL, NULL);
INSERT INTO point VALUES (2317, 111, '34', NULL, NULL);
INSERT INTO point VALUES (2318, 464, '26В', NULL, NULL);
INSERT INTO point VALUES (2319, 137, '22', NULL, NULL);
INSERT INTO point VALUES (2320, 384, '40', NULL, NULL);
INSERT INTO point VALUES (2321, 601, '77', NULL, NULL);
INSERT INTO point VALUES (2322, 499, '2', NULL, NULL);
INSERT INTO point VALUES (2323, 472, '11', NULL, NULL);
INSERT INTO point VALUES (2324, 604, '182', NULL, NULL);
INSERT INTO point VALUES (2325, 233, '5', NULL, NULL);
INSERT INTO point VALUES (2326, 100, '71', NULL, NULL);
INSERT INTO point VALUES (2327, 598, '11', NULL, NULL);
INSERT INTO point VALUES (2328, 541, '8', NULL, NULL);
INSERT INTO point VALUES (2329, 582, '13', NULL, NULL);
INSERT INTO point VALUES (2330, 24, '10', NULL, NULL);
INSERT INTO point VALUES (2331, 539, '18', NULL, NULL);
INSERT INTO point VALUES (2332, 176, '4', NULL, NULL);
INSERT INTO point VALUES (2333, 435, '43', NULL, NULL);
INSERT INTO point VALUES (2334, 487, '45', NULL, NULL);
INSERT INTO point VALUES (2335, 643, '70', NULL, NULL);
INSERT INTO point VALUES (2336, 326, '21', NULL, NULL);
INSERT INTO point VALUES (2337, 542, '12', NULL, NULL);
INSERT INTO point VALUES (2338, 548, '1/1', NULL, NULL);
INSERT INTO point VALUES (2339, 252, '8', NULL, NULL);
INSERT INTO point VALUES (2340, 431, '4', NULL, NULL);
INSERT INTO point VALUES (2341, 679, '5', NULL, NULL);
INSERT INTO point VALUES (2342, 494, '7', NULL, NULL);
INSERT INTO point VALUES (2343, 468, '37', NULL, NULL);
INSERT INTO point VALUES (2344, 262, '3', NULL, NULL);
INSERT INTO point VALUES (2345, 542, '58', NULL, NULL);
INSERT INTO point VALUES (2346, 563, '22', NULL, NULL);
INSERT INTO point VALUES (2347, 674, '16', NULL, NULL);
INSERT INTO point VALUES (2348, 560, '49', NULL, NULL);
INSERT INTO point VALUES (2349, 670, '49', NULL, NULL);
INSERT INTO point VALUES (2350, 451, '41А', NULL, NULL);
INSERT INTO point VALUES (2351, 236, '59Б', NULL, NULL);
INSERT INTO point VALUES (2352, 496, '8А', NULL, NULL);
INSERT INTO point VALUES (2353, 398, '5', NULL, NULL);
INSERT INTO point VALUES (2354, 483, '12', NULL, NULL);
INSERT INTO point VALUES (2355, 465, '30', NULL, NULL);
INSERT INTO point VALUES (2356, 236, '18', NULL, NULL);
INSERT INTO point VALUES (2357, 8, '12', NULL, NULL);
INSERT INTO point VALUES (2358, 220, '4', NULL, NULL);
INSERT INTO point VALUES (2359, 653, '32', NULL, NULL);
INSERT INTO point VALUES (2360, 98, '16', NULL, NULL);
INSERT INTO point VALUES (2361, 258, '5', NULL, NULL);
INSERT INTO point VALUES (2362, 643, '68', NULL, NULL);
INSERT INTO point VALUES (2363, 96, '2', NULL, NULL);
INSERT INTO point VALUES (2364, 389, '44', NULL, NULL);
INSERT INTO point VALUES (2365, 544, '11', NULL, NULL);
INSERT INTO point VALUES (2366, 170, '21', NULL, NULL);
INSERT INTO point VALUES (2367, 389, '24', NULL, NULL);
INSERT INTO point VALUES (2368, 561, '11', NULL, NULL);
INSERT INTO point VALUES (2369, 614, '13', NULL, NULL);
INSERT INTO point VALUES (2370, 325, '8', NULL, NULL);
INSERT INTO point VALUES (2371, 531, '112', NULL, NULL);
INSERT INTO point VALUES (2372, 569, '29', NULL, NULL);
INSERT INTO point VALUES (2373, 384, '46', NULL, NULL);
INSERT INTO point VALUES (2374, 505, '13', NULL, NULL);
INSERT INTO point VALUES (2375, 34, '13', NULL, NULL);
INSERT INTO point VALUES (2376, 256, '10', NULL, NULL);
INSERT INTO point VALUES (2377, 542, '49А', NULL, NULL);
INSERT INTO point VALUES (2378, 4, '18', NULL, NULL);
INSERT INTO point VALUES (2379, 133, '15', NULL, NULL);
INSERT INTO point VALUES (2380, 161, '4', NULL, NULL);
INSERT INTO point VALUES (2381, 531, '12', NULL, NULL);
INSERT INTO point VALUES (2382, 110, '3', NULL, NULL);
INSERT INTO point VALUES (2383, 664, '26', NULL, NULL);
INSERT INTO point VALUES (2384, 425, '90', NULL, NULL);
INSERT INTO point VALUES (2385, 166, '34', NULL, NULL);
INSERT INTO point VALUES (2386, 94, '17', NULL, NULL);
INSERT INTO point VALUES (2387, 585, '12', NULL, NULL);
INSERT INTO point VALUES (2388, 601, '139Б', NULL, NULL);
INSERT INTO point VALUES (2389, 531, '58', NULL, NULL);
INSERT INTO point VALUES (2390, 114, '33', NULL, NULL);
INSERT INTO point VALUES (2391, 390, '17', NULL, NULL);
INSERT INTO point VALUES (2392, 30, '12', NULL, NULL);
INSERT INTO point VALUES (2393, 268, '9', NULL, NULL);
INSERT INTO point VALUES (2394, 496, '23', NULL, NULL);
INSERT INTO point VALUES (2395, 258, '2', NULL, NULL);
INSERT INTO point VALUES (2396, 96, '5', NULL, NULL);
INSERT INTO point VALUES (2397, 389, '33', NULL, NULL);
INSERT INTO point VALUES (2398, 303, '37', NULL, NULL);
INSERT INTO point VALUES (2399, 598, '4', NULL, NULL);
INSERT INTO point VALUES (2400, 236, '95', NULL, NULL);
INSERT INTO point VALUES (2401, 472, '4', NULL, NULL);
INSERT INTO point VALUES (2402, 27, '27/1', NULL, NULL);
INSERT INTO point VALUES (2403, 531, '138', NULL, NULL);
INSERT INTO point VALUES (2404, 277, '14', NULL, NULL);
INSERT INTO point VALUES (2405, 234, '22', NULL, NULL);
INSERT INTO point VALUES (2406, 445, '38', NULL, NULL);
INSERT INTO point VALUES (2407, 411, '38', NULL, NULL);
INSERT INTO point VALUES (2408, 208, '11', NULL, NULL);
INSERT INTO point VALUES (2409, 282, '8', NULL, NULL);
INSERT INTO point VALUES (2410, 277, '88', NULL, NULL);
INSERT INTO point VALUES (2411, 50, '27', NULL, NULL);
INSERT INTO point VALUES (2412, 40, '14', NULL, NULL);
INSERT INTO point VALUES (2413, 108, '7', NULL, NULL);
INSERT INTO point VALUES (2414, 147, '1/1', NULL, NULL);
INSERT INTO point VALUES (2415, 548, '34', NULL, NULL);
INSERT INTO point VALUES (2416, 345, '4', NULL, NULL);
INSERT INTO point VALUES (2417, 112, '10', NULL, NULL);
INSERT INTO point VALUES (2418, 235, '28', NULL, NULL);
INSERT INTO point VALUES (2419, 315, '22', NULL, NULL);
INSERT INTO point VALUES (2420, 594, '52', NULL, NULL);
INSERT INTO point VALUES (2421, 265, '9', NULL, NULL);
INSERT INTO point VALUES (2422, 665, '19', NULL, NULL);
INSERT INTO point VALUES (2423, 480, '37', NULL, NULL);
INSERT INTO point VALUES (2424, 294, '132', NULL, NULL);
INSERT INTO point VALUES (2425, 306, '4', NULL, NULL);
INSERT INTO point VALUES (2426, 120, '19', NULL, NULL);
INSERT INTO point VALUES (2427, 168, '9', NULL, NULL);
INSERT INTO point VALUES (2428, 203, '27', NULL, NULL);
INSERT INTO point VALUES (2429, 261, '29', NULL, NULL);
INSERT INTO point VALUES (2430, 170, '10/1', NULL, NULL);
INSERT INTO point VALUES (2431, 530, '7', NULL, NULL);
INSERT INTO point VALUES (2432, 572, '2а', NULL, NULL);
INSERT INTO point VALUES (2433, 434, '3', NULL, NULL);
INSERT INTO point VALUES (2434, 643, '87', NULL, NULL);
INSERT INTO point VALUES (2435, 426, '14', NULL, NULL);
INSERT INTO point VALUES (2436, 225, '18', NULL, NULL);
INSERT INTO point VALUES (2437, 429, '7', NULL, NULL);
INSERT INTO point VALUES (2438, 615, '4', NULL, NULL);
INSERT INTO point VALUES (2439, 374, '48', NULL, NULL);
INSERT INTO point VALUES (2440, 265, '26', NULL, NULL);
INSERT INTO point VALUES (2441, 52, '10', NULL, NULL);
INSERT INTO point VALUES (2442, 49, '41', NULL, NULL);
INSERT INTO point VALUES (2443, 250, '65', NULL, NULL);
INSERT INTO point VALUES (2444, 458, '8', NULL, NULL);
INSERT INTO point VALUES (2445, 562, '35', NULL, NULL);
INSERT INTO point VALUES (2446, 236, '132', NULL, NULL);
INSERT INTO point VALUES (2447, 98, '20', NULL, NULL);
INSERT INTO point VALUES (2448, 191, '13', NULL, NULL);
INSERT INTO point VALUES (2449, 625, '15', NULL, NULL);
INSERT INTO point VALUES (2450, 656, '15', NULL, NULL);
INSERT INTO point VALUES (2451, 629, '8', NULL, NULL);
INSERT INTO point VALUES (2452, 26, '23', NULL, NULL);
INSERT INTO point VALUES (2453, 71, '8', NULL, NULL);
INSERT INTO point VALUES (2454, 435, '10', NULL, NULL);
INSERT INTO point VALUES (2455, 324, '22', NULL, NULL);
INSERT INTO point VALUES (2456, 639, '17', NULL, NULL);
INSERT INTO point VALUES (2457, 624, '8', NULL, NULL);
INSERT INTO point VALUES (2458, 183, '34', NULL, NULL);
INSERT INTO point VALUES (2459, 95, '24', NULL, NULL);
INSERT INTO point VALUES (2460, 236, '36', NULL, NULL);
INSERT INTO point VALUES (2461, 464, '28Д', NULL, NULL);
INSERT INTO point VALUES (2462, 276, '4', NULL, NULL);
INSERT INTO point VALUES (2463, 166, '37/1', NULL, NULL);
INSERT INTO point VALUES (2464, 113, '49', NULL, NULL);
INSERT INTO point VALUES (2465, 205, '15', NULL, NULL);
INSERT INTO point VALUES (2466, 451, '56А', NULL, NULL);
INSERT INTO point VALUES (2467, 624, '74', NULL, NULL);
INSERT INTO point VALUES (2468, 117, '32А', NULL, NULL);
INSERT INTO point VALUES (2469, 617, '11', NULL, NULL);
INSERT INTO point VALUES (2470, 132, '2А', NULL, NULL);
INSERT INTO point VALUES (2471, 133, '24', NULL, NULL);
INSERT INTO point VALUES (2472, 114, '15', NULL, NULL);
INSERT INTO point VALUES (2473, 303, '48А', NULL, NULL);
INSERT INTO point VALUES (2474, 338, '6', NULL, NULL);
INSERT INTO point VALUES (2475, 112, '12', NULL, NULL);
INSERT INTO point VALUES (2476, 390, '32', NULL, NULL);
INSERT INTO point VALUES (2477, 366, '3', NULL, NULL);
INSERT INTO point VALUES (2478, 271, '6', NULL, NULL);
INSERT INTO point VALUES (2479, 342, '52', NULL, NULL);
INSERT INTO point VALUES (2480, 53, '20', NULL, NULL);
INSERT INTO point VALUES (2481, 389, '15', NULL, NULL);
INSERT INTO point VALUES (2482, 49, '40', NULL, NULL);
INSERT INTO point VALUES (2483, 304, '28', NULL, NULL);
INSERT INTO point VALUES (2484, 639, '7', NULL, NULL);
INSERT INTO point VALUES (2485, 643, '91', NULL, NULL);
INSERT INTO point VALUES (2486, 182, '3А', NULL, NULL);
INSERT INTO point VALUES (2487, 142, '35', NULL, NULL);
INSERT INTO point VALUES (2488, 657, '9А', NULL, NULL);
INSERT INTO point VALUES (2489, 294, '65', NULL, NULL);
INSERT INTO point VALUES (2490, 696, '18/2', NULL, NULL);
INSERT INTO point VALUES (2491, 277, '3А', NULL, NULL);
INSERT INTO point VALUES (2492, 192, '6', NULL, NULL);
INSERT INTO point VALUES (2493, 3, '9', NULL, NULL);
INSERT INTO point VALUES (2494, 421, '24', NULL, NULL);
INSERT INTO point VALUES (2495, 531, '43', NULL, NULL);
INSERT INTO point VALUES (2496, 429, '17', NULL, NULL);
INSERT INTO point VALUES (2497, 657, '23', NULL, NULL);
INSERT INTO point VALUES (2498, 433, '42', NULL, NULL);
INSERT INTO point VALUES (2499, 280, '99', NULL, NULL);
INSERT INTO point VALUES (2500, 584, '26', NULL, NULL);
INSERT INTO point VALUES (2501, 393, '19А', NULL, NULL);
INSERT INTO point VALUES (2502, 323, '22', NULL, NULL);
INSERT INTO point VALUES (2503, 509, '37', NULL, NULL);
INSERT INTO point VALUES (2504, 174, '8', NULL, NULL);
INSERT INTO point VALUES (2505, 554, '95', NULL, NULL);
INSERT INTO point VALUES (2506, 483, '43', NULL, NULL);
INSERT INTO point VALUES (2507, 437, '4', NULL, NULL);
INSERT INTO point VALUES (2508, 294, '164', NULL, NULL);
INSERT INTO point VALUES (2509, 236, '65', NULL, NULL);
INSERT INTO point VALUES (2510, 29, '6', NULL, NULL);
INSERT INTO point VALUES (2511, 435, '58', NULL, NULL);
INSERT INTO point VALUES (2512, 166, '23', NULL, NULL);
INSERT INTO point VALUES (2513, 67, '17/1', NULL, NULL);
INSERT INTO point VALUES (2514, 675, '15', NULL, NULL);
INSERT INTO point VALUES (2515, 384, '38', NULL, NULL);
INSERT INTO point VALUES (2516, 572, '13', NULL, NULL);
INSERT INTO point VALUES (2517, 99, '25', NULL, NULL);
INSERT INTO point VALUES (2518, 92, '8', NULL, NULL);
INSERT INTO point VALUES (2519, 496, '34', NULL, NULL);
INSERT INTO point VALUES (2520, 388, '23', NULL, NULL);
INSERT INTO point VALUES (2521, 531, '94', NULL, NULL);
INSERT INTO point VALUES (2522, 607, '6', NULL, NULL);
INSERT INTO point VALUES (2523, 473, '28', NULL, NULL);
INSERT INTO point VALUES (2524, 250, '36', NULL, NULL);
INSERT INTO point VALUES (2525, 44, '8', NULL, NULL);
INSERT INTO point VALUES (2526, 294, '214', NULL, NULL);
INSERT INTO point VALUES (2527, 338, '56', NULL, NULL);
INSERT INTO point VALUES (2528, 374, '123', NULL, NULL);
INSERT INTO point VALUES (2529, 42, '14', NULL, NULL);
INSERT INTO point VALUES (2530, 502, '14', NULL, NULL);
INSERT INTO point VALUES (2531, 601, '76', NULL, NULL);
INSERT INTO point VALUES (2532, 24, '12', NULL, NULL);
INSERT INTO point VALUES (2533, 139, '22/1', NULL, NULL);
INSERT INTO point VALUES (2534, 572, '52', NULL, NULL);
INSERT INTO point VALUES (2535, 653, '39', NULL, NULL);
INSERT INTO point VALUES (2536, 50, '29', NULL, NULL);
INSERT INTO point VALUES (2537, 512, '2Б', NULL, NULL);
INSERT INTO point VALUES (2538, 283, '9А', NULL, NULL);
INSERT INTO point VALUES (2539, 427, '12', NULL, NULL);
INSERT INTO point VALUES (2540, 600, '57', NULL, NULL);
INSERT INTO point VALUES (2541, 489, '11', NULL, NULL);
INSERT INTO point VALUES (2542, 506, '6', NULL, NULL);
INSERT INTO point VALUES (2543, 202, '24А', NULL, NULL);
INSERT INTO point VALUES (2544, 435, '57', NULL, NULL);
INSERT INTO point VALUES (2545, 390, '7', NULL, NULL);
INSERT INTO point VALUES (2546, 496, '81', NULL, NULL);
INSERT INTO point VALUES (2547, 139, '18', NULL, NULL);
INSERT INTO point VALUES (2548, 542, '10', NULL, NULL);
INSERT INTO point VALUES (2549, 675, '14А', NULL, NULL);
INSERT INTO point VALUES (2550, 283, '23', NULL, NULL);
INSERT INTO point VALUES (2551, 67, '98', NULL, NULL);
INSERT INTO point VALUES (2552, 376, '69', NULL, NULL);
INSERT INTO point VALUES (2553, 99, '7', NULL, NULL);
INSERT INTO point VALUES (2554, 386, '6', NULL, NULL);
INSERT INTO point VALUES (2555, 111, '8', NULL, NULL);
INSERT INTO point VALUES (2556, 562, '8', NULL, NULL);
INSERT INTO point VALUES (2557, 352, '14', NULL, NULL);
INSERT INTO point VALUES (2558, 340, '24', NULL, NULL);
INSERT INTO point VALUES (2559, 150, '9', NULL, NULL);
INSERT INTO point VALUES (2560, 94, '7', NULL, NULL);
INSERT INTO point VALUES (2561, 181, '28', NULL, NULL);
INSERT INTO point VALUES (2562, 76, '56', NULL, NULL);
INSERT INTO point VALUES (2563, 604, '193А', NULL, NULL);
INSERT INTO point VALUES (2564, 25, '4', NULL, NULL);
INSERT INTO point VALUES (2565, 483, '10', NULL, NULL);
INSERT INTO point VALUES (2566, 250, '18', NULL, NULL);
INSERT INTO point VALUES (2567, 538, '26', NULL, NULL);
INSERT INTO point VALUES (2568, 433, '66', NULL, NULL);
INSERT INTO point VALUES (2569, 8, '10', NULL, NULL);
INSERT INTO point VALUES (2570, 659, '1', NULL, NULL);
INSERT INTO point VALUES (2571, 445, '46', NULL, NULL);
INSERT INTO point VALUES (2572, 411, '46', NULL, NULL);
INSERT INTO point VALUES (2573, 560, '68', NULL, NULL);
INSERT INTO point VALUES (2574, 696, '27', NULL, NULL);
INSERT INTO point VALUES (2575, 76, '6', NULL, NULL);
INSERT INTO point VALUES (2576, 531, '104', NULL, NULL);
INSERT INTO point VALUES (2577, 334, '6', NULL, NULL);
INSERT INTO point VALUES (2578, 416, '3', NULL, NULL);
INSERT INTO point VALUES (2579, 210, '19', NULL, NULL);
INSERT INTO point VALUES (2580, 373, '75', NULL, NULL);
INSERT INTO point VALUES (2581, 467, '13', NULL, NULL);
INSERT INTO point VALUES (2582, 256, '12', NULL, NULL);
INSERT INTO point VALUES (2583, 639, '25', NULL, NULL);
INSERT INTO point VALUES (2584, 531, '10', NULL, NULL);
INSERT INTO point VALUES (2585, 658, '29Б', NULL, NULL);
INSERT INTO point VALUES (2586, 372, '22', NULL, NULL);
INSERT INTO point VALUES (2587, 494, '17', NULL, NULL);
INSERT INTO point VALUES (2588, 585, '10', NULL, NULL);
INSERT INTO point VALUES (2589, 32, '3', NULL, NULL);
INSERT INTO point VALUES (2590, 349, '5', NULL, NULL);
INSERT INTO point VALUES (2591, 496, '1/1', NULL, NULL);
INSERT INTO point VALUES (2592, 30, '10', NULL, NULL);
INSERT INTO point VALUES (2593, 396, '24', NULL, NULL);
INSERT INTO point VALUES (2594, 566, '28', NULL, NULL);
INSERT INTO point VALUES (2595, 560, '70', NULL, NULL);
INSERT INTO point VALUES (2596, 183, '23', NULL, NULL);
INSERT INTO point VALUES (2597, 342, '13', NULL, NULL);
INSERT INTO point VALUES (2598, 254, '44', NULL, NULL);
INSERT INTO point VALUES (2599, 601, '145А', NULL, NULL);
INSERT INTO point VALUES (2600, 542, '14/1', NULL, NULL);
INSERT INTO point VALUES (2601, 150, '26', NULL, NULL);
INSERT INTO point VALUES (2602, 464, '82', NULL, NULL);
INSERT INTO point VALUES (2603, 364, '19', NULL, NULL);
INSERT INTO point VALUES (2604, 50, '5', NULL, NULL);
INSERT INTO point VALUES (2605, 425, '84', NULL, NULL);
INSERT INTO point VALUES (2606, 488, '7', NULL, NULL);
INSERT INTO point VALUES (2607, 664, '18', NULL, NULL);
INSERT INTO point VALUES (2608, 166, '8', NULL, NULL);
INSERT INTO point VALUES (2609, 572, '19', NULL, NULL);
INSERT INTO point VALUES (2610, 447, '88', NULL, NULL);
INSERT INTO point VALUES (2611, 433, '44', NULL, NULL);
INSERT INTO point VALUES (2612, 489, '4', NULL, NULL);
INSERT INTO point VALUES (2613, 445, '40', NULL, NULL);
INSERT INTO point VALUES (2614, 411, '40', NULL, NULL);
INSERT INTO point VALUES (2615, 338, '10', NULL, NULL);
INSERT INTO point VALUES (2616, 192, '10', NULL, NULL);
INSERT INTO point VALUES (2617, 334, '43', NULL, NULL);
INSERT INTO point VALUES (2618, 203, '5', NULL, NULL);
INSERT INTO point VALUES (2619, 649, '20', NULL, NULL);
INSERT INTO point VALUES (2620, 531, '208', NULL, NULL);
INSERT INTO point VALUES (2621, 670, '37', NULL, NULL);
INSERT INTO point VALUES (2622, 560, '37', NULL, NULL);
INSERT INTO point VALUES (2623, 308, '16', NULL, NULL);
INSERT INTO point VALUES (2624, 236, '9', NULL, NULL);
INSERT INTO point VALUES (2625, 25, '11', NULL, NULL);
INSERT INTO point VALUES (2626, 388, '8', NULL, NULL);
INSERT INTO point VALUES (2627, 236, '80', NULL, NULL);
INSERT INTO point VALUES (2628, 435, '5А', NULL, NULL);
INSERT INTO point VALUES (2629, 430, '5', NULL, NULL);
INSERT INTO point VALUES (2630, 473, '3', NULL, NULL);
INSERT INTO point VALUES (2631, 294, '9', NULL, NULL);
INSERT INTO point VALUES (2632, 438, '29', NULL, NULL);
INSERT INTO point VALUES (2633, 644, '4', NULL, NULL);
INSERT INTO point VALUES (2634, 296, '1/1', NULL, NULL);
INSERT INTO point VALUES (2635, 27, '28А', NULL, NULL);
INSERT INTO point VALUES (2636, 496, '35', NULL, NULL);
INSERT INTO point VALUES (2637, 29, '10', NULL, NULL);
INSERT INTO point VALUES (2638, 294, '238А', NULL, NULL);
INSERT INTO point VALUES (2639, 572, '1', NULL, NULL);
INSERT INTO point VALUES (2640, 458, '81', NULL, NULL);
INSERT INTO point VALUES (2641, 131, '14А/3', NULL, NULL);
INSERT INTO point VALUES (2642, 166, '31а', NULL, NULL);
INSERT INTO point VALUES (2643, 236, '26', NULL, NULL);
INSERT INTO point VALUES (2644, 433, '24', NULL, NULL);
INSERT INTO point VALUES (2645, 303, '49', NULL, NULL);
INSERT INTO point VALUES (2646, 369, '43', NULL, NULL);
INSERT INTO point VALUES (2647, 521, '7', NULL, NULL);
INSERT INTO point VALUES (2648, 376, '39', NULL, NULL);
INSERT INTO point VALUES (2649, 449, '11', NULL, NULL);
INSERT INTO point VALUES (2650, 465, '38', NULL, NULL);
INSERT INTO point VALUES (2651, 81, '15', NULL, NULL);
INSERT INTO point VALUES (2652, 203, '2', NULL, NULL);
INSERT INTO point VALUES (2653, 180, '14', NULL, NULL);
INSERT INTO point VALUES (2654, 554, '103', NULL, NULL);
INSERT INTO point VALUES (2655, 451, '38Б', NULL, NULL);
INSERT INTO point VALUES (2656, 299, '29', NULL, NULL);
INSERT INTO point VALUES (2657, 531, '147', NULL, NULL);
INSERT INTO point VALUES (2658, 342, '19', NULL, NULL);
INSERT INTO point VALUES (2659, 666, '46', NULL, NULL);
INSERT INTO point VALUES (2660, 81, '14А', NULL, NULL);
INSERT INTO point VALUES (2661, 207, '5', NULL, NULL);
INSERT INTO point VALUES (2662, 53, '84', NULL, NULL);
INSERT INTO point VALUES (2663, 59, '2', NULL, NULL);
INSERT INTO point VALUES (2664, 248, '5', NULL, NULL);
INSERT INTO point VALUES (2665, 277, '21Б', NULL, NULL);
INSERT INTO point VALUES (2666, 531, '244', NULL, NULL);
INSERT INTO point VALUES (2667, 83, '44', NULL, NULL);
INSERT INTO point VALUES (2668, 100, '55', NULL, NULL);
INSERT INTO point VALUES (2669, 265, '18', NULL, NULL);
INSERT INTO point VALUES (2670, 506, '10', NULL, NULL);
INSERT INTO point VALUES (2671, 473, '45', NULL, NULL);
INSERT INTO point VALUES (2672, 236, '64', NULL, NULL);
INSERT INTO point VALUES (2673, 236, '78', NULL, NULL);
INSERT INTO point VALUES (2674, 515, '17', NULL, NULL);
INSERT INTO point VALUES (2675, 658, '15', NULL, NULL);
INSERT INTO point VALUES (2676, 386, '10', NULL, NULL);
INSERT INTO point VALUES (2677, 467, '19', NULL, NULL);
INSERT INTO point VALUES (2678, 27, '31', NULL, NULL);
INSERT INTO point VALUES (2679, 168, '18', NULL, NULL);
INSERT INTO point VALUES (2680, 415, '23', NULL, NULL);
INSERT INTO point VALUES (2681, 210, '13', NULL, NULL);
INSERT INTO point VALUES (2682, 389, '17/1', NULL, NULL);
INSERT INTO point VALUES (2683, 483, '6', NULL, NULL);
INSERT INTO point VALUES (2684, 531, '22А', NULL, NULL);
INSERT INTO point VALUES (2685, 76, '34А', NULL, NULL);
INSERT INTO point VALUES (2686, 8, '6', NULL, NULL);
INSERT INTO point VALUES (2687, 183, '8', NULL, NULL);
INSERT INTO point VALUES (2688, 480, '49', NULL, NULL);
INSERT INTO point VALUES (2689, 342, '1', NULL, NULL);
INSERT INTO point VALUES (2690, 100, '73', NULL, NULL);
INSERT INTO point VALUES (2691, 547, '3', NULL, NULL);
INSERT INTO point VALUES (2692, 12, '207', NULL, NULL);
INSERT INTO point VALUES (2693, 225, '9', NULL, NULL);
INSERT INTO point VALUES (2694, 395, '21', NULL, NULL);
INSERT INTO point VALUES (2695, 578, '3', NULL, NULL);
INSERT INTO point VALUES (2696, 76, '10', NULL, NULL);
INSERT INTO point VALUES (2697, 406, '10', NULL, NULL);
INSERT INTO point VALUES (2698, 649, '16', NULL, NULL);
INSERT INTO point VALUES (2699, 67, '15', NULL, NULL);
INSERT INTO point VALUES (2700, 411, '30', NULL, NULL);
INSERT INTO point VALUES (2701, 130, '8', NULL, NULL);
INSERT INTO point VALUES (2702, 95, '29Б', NULL, NULL);
INSERT INTO point VALUES (2703, 308, '20', NULL, NULL);
INSERT INTO point VALUES (2704, 148, '1', NULL, NULL);
INSERT INTO point VALUES (2705, 254, '42', NULL, NULL);
INSERT INTO point VALUES (2706, 283, '8', NULL, NULL);
INSERT INTO point VALUES (2707, 294, '78', NULL, NULL);
INSERT INTO point VALUES (2708, 294, '64', NULL, NULL);
INSERT INTO point VALUES (2709, 693, '14', NULL, NULL);
INSERT INTO point VALUES (2710, 531, '6', NULL, NULL);
INSERT INTO point VALUES (2711, 552, '43', NULL, NULL);
INSERT INTO point VALUES (2712, 111, '38А', NULL, NULL);
INSERT INTO point VALUES (2713, 566, '3', NULL, NULL);
INSERT INTO point VALUES (2714, 548, '8', NULL, NULL);
INSERT INTO point VALUES (2715, 26, '35', NULL, NULL);
INSERT INTO point VALUES (2716, 610, '12', NULL, NULL);
INSERT INTO point VALUES (2717, 30, '6', NULL, NULL);
INSERT INTO point VALUES (2718, 467, '1', NULL, NULL);
INSERT INTO point VALUES (2719, 362, '37', NULL, NULL);
INSERT INTO point VALUES (2720, 105, '9', NULL, NULL);
INSERT INTO point VALUES (2721, 15, '18/1', NULL, NULL);
INSERT INTO point VALUES (2722, 374, '129', NULL, NULL);
INSERT INTO point VALUES (2723, 585, '6', NULL, NULL);
INSERT INTO point VALUES (2724, 451, '59', NULL, NULL);
INSERT INTO point VALUES (2725, 277, '15А', NULL, NULL);
INSERT INTO point VALUES (2726, 16, '1', NULL, NULL);
INSERT INTO point VALUES (2727, 452, '54', NULL, NULL);
INSERT INTO point VALUES (2728, 144, '8', NULL, NULL);
INSERT INTO point VALUES (2729, 542, '56', NULL, NULL);
INSERT INTO point VALUES (2730, 386, '12В', NULL, NULL);
INSERT INTO point VALUES (2731, 376, '67', NULL, NULL);
INSERT INTO point VALUES (2732, 294, '141А', NULL, NULL);
INSERT INTO point VALUES (2733, 695, '12', NULL, NULL);
INSERT INTO point VALUES (2734, 445, '19А', NULL, NULL);
INSERT INTO point VALUES (2735, 260, '6', NULL, NULL);
INSERT INTO point VALUES (2736, 496, '69', NULL, NULL);
INSERT INTO point VALUES (2737, 245, '15', NULL, NULL);
INSERT INTO point VALUES (2738, 252, '17', NULL, NULL);
INSERT INTO point VALUES (2739, 496, '15/2', NULL, NULL);
INSERT INTO point VALUES (2740, 531, '20', NULL, NULL);
INSERT INTO point VALUES (2741, 531, '143', NULL, NULL);
INSERT INTO point VALUES (2742, 180, '39А', NULL, NULL);
INSERT INTO point VALUES (2743, 415, '7', NULL, NULL);
INSERT INTO point VALUES (2744, 44, '32', NULL, NULL);
INSERT INTO point VALUES (2745, 318, '8', NULL, NULL);
INSERT INTO point VALUES (2746, 250, '78а', NULL, NULL);
INSERT INTO point VALUES (2747, 455, '46А', NULL, NULL);
INSERT INTO point VALUES (2748, 595, '4', NULL, NULL);
INSERT INTO point VALUES (2749, 12, '24', NULL, NULL);
INSERT INTO point VALUES (2750, 95, '22', NULL, NULL);
INSERT INTO point VALUES (2751, 585, '20', NULL, NULL);
INSERT INTO point VALUES (2752, 304, '75', NULL, NULL);
INSERT INTO point VALUES (2753, 653, '35', NULL, NULL);
INSERT INTO point VALUES (2754, 203, '26', NULL, NULL);
INSERT INTO point VALUES (2755, 419, '4', NULL, NULL);
INSERT INTO point VALUES (2756, 290, '10', NULL, NULL);
INSERT INTO point VALUES (2757, 374, '54', NULL, NULL);
INSERT INTO point VALUES (2758, 30, '20', NULL, NULL);
INSERT INTO point VALUES (2759, 394, '1', NULL, NULL);
INSERT INTO point VALUES (2760, 120, '55', NULL, NULL);
INSERT INTO point VALUES (2761, 48, '30', NULL, NULL);
INSERT INTO point VALUES (2762, 96, '18', NULL, NULL);
INSERT INTO point VALUES (2763, 373, '61А', NULL, NULL);
INSERT INTO point VALUES (2764, 480, '4', NULL, NULL);
INSERT INTO point VALUES (2765, 418, '1', NULL, NULL);
INSERT INTO point VALUES (2766, 199, '15', NULL, NULL);
INSERT INTO point VALUES (2767, 117, '40', NULL, NULL);
INSERT INTO point VALUES (2768, 49, '21', NULL, NULL);
INSERT INTO point VALUES (2769, 324, '24', NULL, NULL);
INSERT INTO point VALUES (2770, 188, '6', NULL, NULL);
INSERT INTO point VALUES (2771, 236, '2', NULL, NULL);
INSERT INTO point VALUES (2772, 111, '7', NULL, NULL);
INSERT INTO point VALUES (2773, 562, '7', NULL, NULL);
INSERT INTO point VALUES (2774, 374, '95/1', NULL, NULL);
INSERT INTO point VALUES (2775, 280, '34', NULL, NULL);
INSERT INTO point VALUES (2776, 464, '42А', NULL, NULL);
INSERT INTO point VALUES (2777, 242, '5', NULL, NULL);
INSERT INTO point VALUES (2778, 526, '3', NULL, NULL);
INSERT INTO point VALUES (2779, 600, '51', NULL, NULL);
INSERT INTO point VALUES (2780, 9, '83', NULL, NULL);
INSERT INTO point VALUES (2781, 294, '2', NULL, NULL);
INSERT INTO point VALUES (2782, 265, '27', NULL, NULL);
INSERT INTO point VALUES (2783, 682, '15', NULL, NULL);
INSERT INTO point VALUES (2784, 571, '30', NULL, NULL);
INSERT INTO point VALUES (2785, 435, '51', NULL, NULL);
INSERT INTO point VALUES (2786, 539, '5', NULL, NULL);
INSERT INTO point VALUES (2787, 234, '24', NULL, NULL);
INSERT INTO point VALUES (2788, 12, '44', NULL, NULL);
INSERT INTO point VALUES (2789, 325, '17', NULL, NULL);
INSERT INTO point VALUES (2790, 178, '3', NULL, NULL);
INSERT INTO point VALUES (2791, 654, '18', NULL, NULL);
INSERT INTO point VALUES (2792, 50, '9', NULL, NULL);
INSERT INTO point VALUES (2793, 687, '38', NULL, NULL);
INSERT INTO point VALUES (2794, 223, '6', NULL, NULL);
INSERT INTO point VALUES (2795, 272, '6', NULL, NULL);
INSERT INTO point VALUES (2796, 125, '4', NULL, NULL);
INSERT INTO point VALUES (2797, 174, '25', NULL, NULL);
INSERT INTO point VALUES (2798, 394, '19', NULL, NULL);
INSERT INTO point VALUES (2799, 235, '59', NULL, NULL);
INSERT INTO point VALUES (2800, 19, '18', NULL, NULL);
INSERT INTO point VALUES (2801, 565, '11', NULL, NULL);
INSERT INTO point VALUES (2802, 236, '5', NULL, NULL);
INSERT INTO point VALUES (2803, 652, '11', NULL, NULL);
INSERT INTO point VALUES (2804, 150, '29', NULL, NULL);
INSERT INTO point VALUES (2805, 390, '8', NULL, NULL);
INSERT INTO point VALUES (2806, 601, '66', NULL, NULL);
INSERT INTO point VALUES (2807, 42, '1', NULL, NULL);
INSERT INTO point VALUES (2808, 535, '11', NULL, NULL);
INSERT INTO point VALUES (2809, 502, '1', NULL, NULL);
INSERT INTO point VALUES (2810, 203, '9', NULL, NULL);
INSERT INTO point VALUES (2811, 209, '28', NULL, NULL);
INSERT INTO point VALUES (2812, 610, '27А', NULL, NULL);
INSERT INTO point VALUES (2813, 694, '11', NULL, NULL);
INSERT INTO point VALUES (2814, 84, '23', NULL, NULL);
INSERT INTO point VALUES (2815, 672, '12', NULL, NULL);
INSERT INTO point VALUES (2816, 664, '12Б', NULL, NULL);
INSERT INTO point VALUES (2817, 513, '1', NULL, NULL);
INSERT INTO point VALUES (2818, 92, '7', NULL, NULL);
INSERT INTO point VALUES (2819, 431, '37', NULL, NULL);
INSERT INTO point VALUES (2820, 674, '12', NULL, NULL);
INSERT INTO point VALUES (2821, 210, '14', NULL, NULL);
INSERT INTO point VALUES (2822, 111, '25', NULL, NULL);
INSERT INTO point VALUES (2823, 222, '7', NULL, NULL);
INSERT INTO point VALUES (2824, 562, '25', NULL, NULL);
INSERT INTO point VALUES (2825, 142, '39', NULL, NULL);
INSERT INTO point VALUES (2826, 176, '37', NULL, NULL);
INSERT INTO point VALUES (2827, 389, '22', NULL, NULL);
INSERT INTO point VALUES (2828, 464, '38Б', NULL, NULL);
INSERT INTO point VALUES (2829, 483, '16', NULL, NULL);
INSERT INTO point VALUES (2830, 8, '16', NULL, NULL);
INSERT INTO point VALUES (2831, 458, '67', NULL, NULL);
INSERT INTO point VALUES (2832, 531, '190', NULL, NULL);
INSERT INTO point VALUES (2833, 425, '46/1', NULL, NULL);
INSERT INTO point VALUES (2834, 98, '12', NULL, NULL);
INSERT INTO point VALUES (2835, 248, '26', NULL, NULL);
INSERT INTO point VALUES (2836, 225, '5', NULL, NULL);
INSERT INTO point VALUES (2837, 189, '4', NULL, NULL);
INSERT INTO point VALUES (2838, 425, '43', NULL, NULL);
INSERT INTO point VALUES (2839, 170, '31', NULL, NULL);
INSERT INTO point VALUES (2840, 174, '7', NULL, NULL);
INSERT INTO point VALUES (2841, 294, '212', NULL, NULL);
INSERT INTO point VALUES (2842, 468, '4', NULL, NULL);
INSERT INTO point VALUES (2843, 660, '1', NULL, NULL);
INSERT INTO point VALUES (2844, 50, '33А', NULL, NULL);
INSERT INTO point VALUES (2845, 105, '5', NULL, NULL);
INSERT INTO point VALUES (2846, 496, '97', NULL, NULL);
INSERT INTO point VALUES (2847, 554, '4А', NULL, NULL);
INSERT INTO point VALUES (2848, 170, '41', NULL, NULL);
INSERT INTO point VALUES (2849, 678, '21', NULL, NULL);
INSERT INTO point VALUES (2850, 496, '105', NULL, NULL);
INSERT INTO point VALUES (2851, 433, '76', NULL, NULL);
INSERT INTO point VALUES (2852, 374, '41', NULL, NULL);
INSERT INTO point VALUES (2853, 585, '16', NULL, NULL);
INSERT INTO point VALUES (2854, 458, '17', NULL, NULL);
INSERT INTO point VALUES (2855, 447, '52', NULL, NULL);
INSERT INTO point VALUES (2856, 111, '32', NULL, NULL);
INSERT INTO point VALUES (2857, 30, '16', NULL, NULL);
INSERT INTO point VALUES (2858, 629, '17', NULL, NULL);
INSERT INTO point VALUES (2859, 248, '9', NULL, NULL);
INSERT INTO point VALUES (2860, 225, '2', NULL, NULL);
INSERT INTO point VALUES (2861, 529, '19', NULL, NULL);
INSERT INTO point VALUES (2862, 172, '31', NULL, NULL);
INSERT INTO point VALUES (2863, 643, '11', NULL, NULL);
INSERT INTO point VALUES (2864, 435, '53', NULL, NULL);
INSERT INTO point VALUES (2865, 304, '60', NULL, NULL);
INSERT INTO point VALUES (2866, 115, '7', NULL, NULL);
INSERT INTO point VALUES (2867, 531, '194', NULL, NULL);
INSERT INTO point VALUES (2868, 53, '10', NULL, NULL);
INSERT INTO point VALUES (2869, 202, '50', NULL, NULL);
INSERT INTO point VALUES (2870, 598, '37', NULL, NULL);
INSERT INTO point VALUES (2871, 105, '2', NULL, NULL);
INSERT INTO point VALUES (2872, 626, '17', NULL, NULL);
INSERT INTO point VALUES (2873, 131, '12/5', NULL, NULL);
INSERT INTO point VALUES (2874, 48, '40', NULL, NULL);
INSERT INTO point VALUES (2875, 693, '13', NULL, NULL);
INSERT INTO point VALUES (2876, 425, '94', NULL, NULL);
INSERT INTO point VALUES (2877, 686, '3', NULL, NULL);
INSERT INTO point VALUES (2878, 117, '30', NULL, NULL);
INSERT INTO point VALUES (2879, 370, '13', NULL, NULL);
INSERT INTO point VALUES (2880, 201, '29', NULL, NULL);
INSERT INTO point VALUES (2881, 203, '64', NULL, NULL);
INSERT INTO point VALUES (2882, 183, '52/9', NULL, NULL);
INSERT INTO point VALUES (2883, 531, '16', NULL, NULL);
INSERT INTO point VALUES (2884, 421, '24Б', NULL, NULL);
INSERT INTO point VALUES (2885, 601, '42', NULL, NULL);
INSERT INTO point VALUES (2886, 146, '3', NULL, NULL);
INSERT INTO point VALUES (2887, 250, '63', NULL, NULL);
INSERT INTO point VALUES (2888, 250, '78А', NULL, NULL);
INSERT INTO point VALUES (2889, 563, '24', NULL, NULL);
INSERT INTO point VALUES (2890, 565, '50', NULL, NULL);
INSERT INTO point VALUES (2891, 639, '8', NULL, NULL);
INSERT INTO point VALUES (2892, 347, '15', NULL, NULL);
INSERT INTO point VALUES (2893, 376, '34', NULL, NULL);
INSERT INTO point VALUES (2894, 334, '20', NULL, NULL);
INSERT INTO point VALUES (2895, 260, '10', NULL, NULL);
INSERT INTO point VALUES (2896, 192, '16', NULL, NULL);
INSERT INTO point VALUES (2897, 94, '23', NULL, NULL);
INSERT INTO point VALUES (2898, 451, '6А', NULL, NULL);
INSERT INTO point VALUES (2899, 560, '72', NULL, NULL);
INSERT INTO point VALUES (2900, 694, '4', NULL, NULL);
INSERT INTO point VALUES (2901, 318, '8А', NULL, NULL);
INSERT INTO point VALUES (2902, 299, '26', NULL, NULL);
INSERT INTO point VALUES (2903, 76, '20', NULL, NULL);
INSERT INTO point VALUES (2904, 250, '74А', NULL, NULL);
INSERT INTO point VALUES (2905, 137, '33', NULL, NULL);
INSERT INTO point VALUES (2906, 696, '18', NULL, NULL);
INSERT INTO point VALUES (2907, 374, '133А', NULL, NULL);
INSERT INTO point VALUES (2908, 339, '3', NULL, NULL);
INSERT INTO point VALUES (2909, 653, '34', NULL, NULL);
INSERT INTO point VALUES (2910, 388, '25', NULL, NULL);
INSERT INTO point VALUES (2911, 264, '17', NULL, NULL);
INSERT INTO point VALUES (2912, 496, '48Г', NULL, NULL);
INSERT INTO point VALUES (2913, 394, '13', NULL, NULL);
INSERT INTO point VALUES (2914, 14, '5', NULL, NULL);
INSERT INTO point VALUES (2915, 144, '7', NULL, NULL);
INSERT INTO point VALUES (2916, 476, '5', NULL, NULL);
INSERT INTO point VALUES (2917, 544, '37', NULL, NULL);
INSERT INTO point VALUES (2918, 37, '47', NULL, NULL);
INSERT INTO point VALUES (2919, 658, '22', NULL, NULL);
INSERT INTO point VALUES (2920, 425, '56', NULL, NULL);
INSERT INTO point VALUES (2921, 3, '2', NULL, NULL);
INSERT INTO point VALUES (2922, 290, '6', NULL, NULL);
INSERT INTO point VALUES (2923, 189, '11', NULL, NULL);
INSERT INTO point VALUES (2924, 213, '45', NULL, NULL);
INSERT INTO point VALUES (2925, 141, '13', NULL, NULL);
INSERT INTO point VALUES (2926, 236, '146', NULL, NULL);
INSERT INTO point VALUES (2927, 455, '58', NULL, NULL);
INSERT INTO point VALUES (2928, 70, '14', NULL, NULL);
INSERT INTO point VALUES (2929, 480, '50', NULL, NULL);
INSERT INTO point VALUES (2930, 329, '26', NULL, NULL);
INSERT INTO point VALUES (2931, 283, '7', NULL, NULL);
INSERT INTO point VALUES (2932, 464, '62', NULL, NULL);
INSERT INTO point VALUES (2933, 604, '197', NULL, NULL);
INSERT INTO point VALUES (2934, 496, '17', NULL, NULL);
INSERT INTO point VALUES (2935, 130, '7', NULL, NULL);
INSERT INTO point VALUES (2936, 188, '10', NULL, NULL);
INSERT INTO point VALUES (2937, 548, '7', NULL, NULL);
INSERT INTO point VALUES (2938, 119, '3', NULL, NULL);
INSERT INTO point VALUES (2939, 687, '31', NULL, NULL);
INSERT INTO point VALUES (2940, 166, '25', NULL, NULL);
INSERT INTO point VALUES (2941, 445, '21', NULL, NULL);
INSERT INTO point VALUES (2942, 338, '16', NULL, NULL);
INSERT INTO point VALUES (2943, 88, '15', NULL, NULL);
INSERT INTO point VALUES (2944, 411, '21', NULL, NULL);
INSERT INTO point VALUES (2945, 502, '13', NULL, NULL);
INSERT INTO point VALUES (2946, 46, '18', NULL, NULL);
INSERT INTO point VALUES (2947, 67, '22', NULL, NULL);
INSERT INTO point VALUES (2948, 14, '2', NULL, NULL);
INSERT INTO point VALUES (2949, 523, '28', NULL, NULL);
INSERT INTO point VALUES (2950, 209, '3', NULL, NULL);
INSERT INTO point VALUES (2951, 26, '39', NULL, NULL);
INSERT INTO point VALUES (2952, 51, '52', NULL, NULL);
INSERT INTO point VALUES (2953, 657, '25', NULL, NULL);
INSERT INTO point VALUES (2954, 447, '19', NULL, NULL);
INSERT INTO point VALUES (2955, 572, '14', NULL, NULL);
INSERT INTO point VALUES (2956, 75, '37', NULL, NULL);
INSERT INTO point VALUES (2957, 607, '16', NULL, NULL);
INSERT INTO point VALUES (2958, 183, '7', NULL, NULL);
INSERT INTO point VALUES (2959, 270, '12', NULL, NULL);
INSERT INTO point VALUES (2960, 250, '27', NULL, NULL);
INSERT INTO point VALUES (2961, 223, '10', NULL, NULL);
INSERT INTO point VALUES (2962, 151, '12', NULL, NULL);
INSERT INTO point VALUES (2963, 496, '67', NULL, NULL);
INSERT INTO point VALUES (2964, 12, '42', NULL, NULL);
INSERT INTO point VALUES (2965, 500, '36', NULL, NULL);
INSERT INTO point VALUES (2966, 166, '32', NULL, NULL);
INSERT INTO point VALUES (2967, 3, '5', NULL, NULL);
INSERT INTO point VALUES (2968, 558, '22', NULL, NULL);
INSERT INTO point VALUES (2969, 269, '25а', NULL, NULL);
INSERT INTO point VALUES (2970, 660, '13', NULL, NULL);
INSERT INTO point VALUES (2971, 170, '41/1', NULL, NULL);
INSERT INTO point VALUES (2972, 26, '17', NULL, NULL);
INSERT INTO point VALUES (2973, 180, '1', NULL, NULL);
INSERT INTO point VALUES (2974, 580, '3/1', NULL, NULL);
INSERT INTO point VALUES (2975, 236, '89', NULL, NULL);
INSERT INTO point VALUES (2976, 521, '8', NULL, NULL);
INSERT INTO point VALUES (2977, 374, '41/1', NULL, NULL);
INSERT INTO point VALUES (2978, 47, '11', NULL, NULL);
INSERT INTO point VALUES (2979, 183, '25', NULL, NULL);
INSERT INTO point VALUES (2980, 354, '22', NULL, NULL);
INSERT INTO point VALUES (2981, 601, '33', NULL, NULL);
INSERT INTO point VALUES (2982, 374, '47', NULL, NULL);
INSERT INTO point VALUES (2983, 693, '19', NULL, NULL);
INSERT INTO point VALUES (2984, 374, '161', NULL, NULL);
INSERT INTO point VALUES (2985, 9, '79', NULL, NULL);
INSERT INTO point VALUES (2986, 657, '7', NULL, NULL);
INSERT INTO point VALUES (2987, 536, '31', NULL, NULL);
INSERT INTO point VALUES (2988, 636, '11', NULL, NULL);
INSERT INTO point VALUES (2989, 419, '11', NULL, NULL);
INSERT INTO point VALUES (2990, 150, '2', NULL, NULL);
INSERT INTO point VALUES (2991, 67, '106А', NULL, NULL);
INSERT INTO point VALUES (2992, 235, '62', NULL, NULL);
INSERT INTO point VALUES (2993, 501, '22', NULL, NULL);
INSERT INTO point VALUES (2994, 538, '5', NULL, NULL);
INSERT INTO point VALUES (2995, 607, '20', NULL, NULL);
INSERT INTO point VALUES (2996, 445, '48', NULL, NULL);
INSERT INTO point VALUES (2997, 506, '16', NULL, NULL);
INSERT INTO point VALUES (2998, 433, '24Б', NULL, NULL);
INSERT INTO point VALUES (2999, 548, '32', NULL, NULL);
INSERT INTO point VALUES (3000, 411, '48', NULL, NULL);
INSERT INTO point VALUES (3001, 376, '35', NULL, NULL);
INSERT INTO point VALUES (3002, 67, '77', NULL, NULL);
INSERT INTO point VALUES (3003, 61, '15', NULL, NULL);
INSERT INTO point VALUES (3004, 202, '4', NULL, NULL);
INSERT INTO point VALUES (3005, 342, '14', NULL, NULL);
INSERT INTO point VALUES (3006, 658, '37а', NULL, NULL);
INSERT INTO point VALUES (3007, 53, '6', NULL, NULL);
INSERT INTO point VALUES (3008, 157, '5Б', NULL, NULL);
INSERT INTO point VALUES (3009, 373, '3', NULL, NULL);
INSERT INTO point VALUES (3010, 291, '15', NULL, NULL);
INSERT INTO point VALUES (3011, 388, '7', NULL, NULL);
INSERT INTO point VALUES (3012, 539, '29', NULL, NULL);
INSERT INTO point VALUES (3013, 601, '44', NULL, NULL);
INSERT INTO point VALUES (3014, 294, '139', NULL, NULL);
INSERT INTO point VALUES (3015, 20, '24', NULL, NULL);
INSERT INTO point VALUES (3016, 183, '32', NULL, NULL);
INSERT INTO point VALUES (3017, 370, '1', NULL, NULL);
INSERT INTO point VALUES (3018, 334, '16', NULL, NULL);
INSERT INTO point VALUES (3019, 76, '16', NULL, NULL);
INSERT INTO point VALUES (3020, 541, '17', NULL, NULL);
INSERT INTO point VALUES (3021, 554, '92', NULL, NULL);
INSERT INTO point VALUES (3022, 649, '10', NULL, NULL);
INSERT INTO point VALUES (3023, 467, '14', NULL, NULL);
INSERT INTO point VALUES (3024, 236, '29', NULL, NULL);
INSERT INTO point VALUES (3025, 589, '60', NULL, NULL);
INSERT INTO point VALUES (3026, 150, '5', NULL, NULL);
INSERT INTO point VALUES (3027, 67, '162', NULL, NULL);
INSERT INTO point VALUES (3028, 236, '61', NULL, NULL);
INSERT INTO point VALUES (3029, 374, '107', NULL, NULL);
INSERT INTO point VALUES (3030, 166, '7', NULL, NULL);
INSERT INTO point VALUES (3031, 55, '38', NULL, NULL);
INSERT INTO point VALUES (3032, 213, '3', NULL, NULL);
INSERT INTO point VALUES (3033, 329, '64', NULL, NULL);
INSERT INTO point VALUES (3034, 652, '4', NULL, NULL);
INSERT INTO point VALUES (3035, 458, '69', NULL, NULL);
INSERT INTO point VALUES (3036, 303, '50', NULL, NULL);
INSERT INTO point VALUES (3037, 499, '18', NULL, NULL);
INSERT INTO point VALUES (3038, 283, '25', NULL, NULL);
INSERT INTO point VALUES (3039, 496, '39', NULL, NULL);
INSERT INTO point VALUES (3040, 119, '5', NULL, NULL);
INSERT INTO point VALUES (3041, 601, '151В', NULL, NULL);
INSERT INTO point VALUES (3042, 25, '21', NULL, NULL);
INSERT INTO point VALUES (3043, 235, '36', NULL, NULL);
INSERT INTO point VALUES (3044, 256, '1', NULL, NULL);
INSERT INTO point VALUES (3045, 382, '7', NULL, NULL);
INSERT INTO point VALUES (3046, 548, '44', NULL, NULL);
INSERT INTO point VALUES (3047, 396, '23', NULL, NULL);
INSERT INTO point VALUES (3048, 541, '15', NULL, NULL);
INSERT INTO point VALUES (3049, 184, '19', NULL, NULL);
INSERT INTO point VALUES (3050, 88, '39', NULL, NULL);
INSERT INTO point VALUES (3051, 277, '20', NULL, NULL);
INSERT INTO point VALUES (3052, 95, '34', NULL, NULL);
INSERT INTO point VALUES (3053, 362, '47', NULL, NULL);
INSERT INTO point VALUES (3054, 598, '26А', NULL, NULL);
INSERT INTO point VALUES (3055, 374, '100', NULL, NULL);
INSERT INTO point VALUES (3056, 183, '24', NULL, NULL);
INSERT INTO point VALUES (3057, 40, '20', NULL, NULL);
INSERT INTO point VALUES (3058, 236, '128', NULL, NULL);
INSERT INTO point VALUES (3059, 274, '8', NULL, NULL);
INSERT INTO point VALUES (3060, 476, '3', NULL, NULL);
INSERT INTO point VALUES (3061, 183, '33', NULL, NULL);
INSERT INTO point VALUES (3062, 601, '25', NULL, NULL);
INSERT INTO point VALUES (3063, 61, '17', NULL, NULL);
INSERT INTO point VALUES (3064, 614, '6', NULL, NULL);
INSERT INTO point VALUES (3065, 548, '67/1', NULL, NULL);
INSERT INTO point VALUES (3066, 339, '5', NULL, NULL);
INSERT INTO point VALUES (3067, 402, '69', NULL, NULL);
INSERT INTO point VALUES (3068, 389, '1/1', NULL, NULL);
INSERT INTO point VALUES (3069, 304, '65', NULL, NULL);
INSERT INTO point VALUES (3070, 505, '6', NULL, NULL);
INSERT INTO point VALUES (3071, 34, '6', NULL, NULL);
INSERT INTO point VALUES (3072, 294, '153', NULL, NULL);
INSERT INTO point VALUES (3073, 278, '19', NULL, NULL);
INSERT INTO point VALUES (3074, 15, '22', NULL, NULL);
INSERT INTO point VALUES (3075, 393, '11', NULL, NULL);
INSERT INTO point VALUES (3076, 658, '29А', NULL, NULL);
INSERT INTO point VALUES (3077, 477, '31', NULL, NULL);
INSERT INTO point VALUES (3078, 146, '29', NULL, NULL);
INSERT INTO point VALUES (3079, 604, '201', NULL, NULL);
INSERT INTO point VALUES (3080, 548, '33', NULL, NULL);
INSERT INTO point VALUES (3081, 464, '18', NULL, NULL);
INSERT INTO point VALUES (3082, 98, '14', NULL, NULL);
INSERT INTO point VALUES (3083, 67, '35', NULL, NULL);
INSERT INTO point VALUES (3084, 3, '3', NULL, NULL);
INSERT INTO point VALUES (3085, 223, '15А', NULL, NULL);
INSERT INTO point VALUES (3086, 119, '2', NULL, NULL);
INSERT INTO point VALUES (3087, 426, '20', NULL, NULL);
INSERT INTO point VALUES (3088, 554, '6А', NULL, NULL);
INSERT INTO point VALUES (3089, 24, '1', NULL, NULL);
INSERT INTO point VALUES (3090, 374, '72', NULL, NULL);
INSERT INTO point VALUES (3091, 674, '14', NULL, NULL);
INSERT INTO point VALUES (3092, 120, '43', NULL, NULL);
INSERT INTO point VALUES (3093, 210, '12', NULL, NULL);
INSERT INTO point VALUES (3094, 111, '42', NULL, NULL);
INSERT INTO point VALUES (3095, 26, '15', NULL, NULL);
INSERT INTO point VALUES (3096, 582, '6', NULL, NULL);
INSERT INTO point VALUES (3097, 176, '26А', NULL, NULL);
INSERT INTO point VALUES (3098, 236, '28', NULL, NULL);
INSERT INTO point VALUES (3099, 356, '4', NULL, NULL);
INSERT INTO point VALUES (3100, 183, '44', NULL, NULL);
INSERT INTO point VALUES (3101, 618, '12Б', NULL, NULL);
INSERT INTO point VALUES (3102, 550, '68', NULL, NULL);
INSERT INTO point VALUES (3103, 126, '41', NULL, NULL);
INSERT INTO point VALUES (3104, 601, '98/1', NULL, NULL);
INSERT INTO point VALUES (3105, 303, '40', NULL, NULL);
INSERT INTO point VALUES (3106, 137, '7', NULL, NULL);
INSERT INTO point VALUES (3107, 366, '9', NULL, NULL);
INSERT INTO point VALUES (3108, 48, '4', NULL, NULL);
INSERT INTO point VALUES (3109, 548, '24', NULL, NULL);
INSERT INTO point VALUES (3110, 480, '30', NULL, NULL);
INSERT INTO point VALUES (3111, 455, '50А', NULL, NULL);
INSERT INTO point VALUES (3112, 339, '2', NULL, NULL);
INSERT INTO point VALUES (3113, 518, '7', NULL, NULL);
INSERT INTO point VALUES (3114, 538, '3', NULL, NULL);
INSERT INTO point VALUES (3115, 451, '27', NULL, NULL);
INSERT INTO point VALUES (3116, 299, '19Б', NULL, NULL);
INSERT INTO point VALUES (3117, 32, '9', NULL, NULL);
INSERT INTO point VALUES (3118, 219, '18', NULL, NULL);
INSERT INTO point VALUES (3119, 509, '31', NULL, NULL);
INSERT INTO point VALUES (3120, 166, '33', NULL, NULL);
INSERT INTO point VALUES (3121, 236, '136', NULL, NULL);
INSERT INTO point VALUES (3122, 20, '7', NULL, NULL);
INSERT INTO point VALUES (3123, 213, '2', NULL, NULL);
INSERT INTO point VALUES (3124, 303, '30', NULL, NULL);
INSERT INTO point VALUES (3125, 389, '34', NULL, NULL);
INSERT INTO point VALUES (3126, 388, '33', NULL, NULL);
INSERT INTO point VALUES (3127, 480, '40', NULL, NULL);
INSERT INTO point VALUES (3128, 564, '7/1', NULL, NULL);
INSERT INTO point VALUES (3129, 600, '1', NULL, NULL);
INSERT INTO point VALUES (3130, 426, '16', NULL, NULL);
INSERT INTO point VALUES (3131, 415, '83А', NULL, NULL);
INSERT INTO point VALUES (3132, 279, '8А', NULL, NULL);
INSERT INTO point VALUES (3133, 120, '10', NULL, NULL);
INSERT INTO point VALUES (3134, 166, '24', NULL, NULL);
INSERT INTO point VALUES (3135, 235, '18', NULL, NULL);
INSERT INTO point VALUES (3136, 67, '74', NULL, NULL);
INSERT INTO point VALUES (3137, 449, '13А', NULL, NULL);
INSERT INTO point VALUES (3138, 560, '47', NULL, NULL);
INSERT INTO point VALUES (3139, 670, '47', NULL, NULL);
INSERT INTO point VALUES (3140, 376, '22', NULL, NULL);
INSERT INTO point VALUES (3141, 150, '3', NULL, NULL);
INSERT INTO point VALUES (3142, 112, '1', NULL, NULL);
INSERT INTO point VALUES (3143, 496, '15', NULL, NULL);
INSERT INTO point VALUES (3144, 245, '69', NULL, NULL);
INSERT INTO point VALUES (3145, 67, '170', NULL, NULL);
INSERT INTO point VALUES (3146, 310, '10', NULL, NULL);
INSERT INTO point VALUES (3147, 565, '46', NULL, NULL);
INSERT INTO point VALUES (3148, 549, '10', NULL, NULL);
INSERT INTO point VALUES (3149, 82, '5', NULL, NULL);
INSERT INTO point VALUES (3150, 52, '19', NULL, NULL);
INSERT INTO point VALUES (3151, 88, '17', NULL, NULL);
INSERT INTO point VALUES (3152, 657, '33', NULL, NULL);
INSERT INTO point VALUES (3153, 525, '27', NULL, NULL);
INSERT INTO point VALUES (3154, 600, '19', NULL, NULL);
INSERT INTO point VALUES (3155, 373, '5', NULL, NULL);
INSERT INTO point VALUES (3156, 531, '114', NULL, NULL);
INSERT INTO point VALUES (3157, 283, '21А', NULL, NULL);
INSERT INTO point VALUES (3158, 61, '39', NULL, NULL);
INSERT INTO point VALUES (3159, 468, '30', NULL, NULL);
INSERT INTO point VALUES (3160, 280, '77', NULL, NULL);
INSERT INTO point VALUES (3161, 395, '11', NULL, NULL);
INSERT INTO point VALUES (3162, 202, '46', NULL, NULL);
INSERT INTO point VALUES (3163, 277, '16', NULL, NULL);
INSERT INTO point VALUES (3164, 589, '64', NULL, NULL);
INSERT INTO point VALUES (3165, 435, '19', NULL, NULL);
INSERT INTO point VALUES (3166, 632, '4', NULL, NULL);
INSERT INTO point VALUES (3167, 604, '191А', NULL, NULL);
INSERT INTO point VALUES (3168, 40, '16', NULL, NULL);
INSERT INTO point VALUES (3169, 329, '60', NULL, NULL);
INSERT INTO point VALUES (3170, 340, '8', NULL, NULL);
INSERT INTO point VALUES (3171, 59, '60', NULL, NULL);
INSERT INTO point VALUES (3172, 626, '15', NULL, NULL);
INSERT INTO point VALUES (3173, 111, '24', NULL, NULL);
INSERT INTO point VALUES (3174, 562, '24', NULL, NULL);
INSERT INTO point VALUES (3175, 523, '2', NULL, NULL);
INSERT INTO point VALUES (3176, 465, '68', NULL, NULL);
INSERT INTO point VALUES (3177, 434, '36', NULL, NULL);
INSERT INTO point VALUES (3178, 342, '12', NULL, NULL);
INSERT INTO point VALUES (3179, 347, '17', NULL, NULL);
INSERT INTO point VALUES (3180, 304, '26', NULL, NULL);
INSERT INTO point VALUES (3181, 520, '4', NULL, NULL);
INSERT INTO point VALUES (3182, 118, '27', NULL, NULL);
INSERT INTO point VALUES (3183, 531, '11Б', NULL, NULL);
INSERT INTO point VALUES (3184, 604, '36', NULL, NULL);
INSERT INTO point VALUES (3185, 614, '10', NULL, NULL);
INSERT INTO point VALUES (3186, 519, '8', NULL, NULL);
INSERT INTO point VALUES (3187, 362, '31', NULL, NULL);
INSERT INTO point VALUES (3188, 458, '15', NULL, NULL);
INSERT INTO point VALUES (3189, 548, '42', NULL, NULL);
INSERT INTO point VALUES (3190, 695, '1', NULL, NULL);
INSERT INTO point VALUES (3191, 158, '16', NULL, NULL);
INSERT INTO point VALUES (3192, 342, '58', NULL, NULL);
INSERT INTO point VALUES (3193, 374, '163', NULL, NULL);
INSERT INTO point VALUES (3194, 625, '8', NULL, NULL);
INSERT INTO point VALUES (3195, 629, '15', NULL, NULL);
INSERT INTO point VALUES (3196, 95, '35', NULL, NULL);
INSERT INTO point VALUES (3197, 617, '21', NULL, NULL);
INSERT INTO point VALUES (3198, 496, '86', NULL, NULL);
INSERT INTO point VALUES (3199, 563, '32', NULL, NULL);
INSERT INTO point VALUES (3200, 110, '18', NULL, NULL);
INSERT INTO point VALUES (3201, 600, '39А', NULL, NULL);
INSERT INTO point VALUES (3202, 505, '10', NULL, NULL);
INSERT INTO point VALUES (3203, 467, '12', NULL, NULL);
INSERT INTO point VALUES (3204, 562, '33', NULL, NULL);
INSERT INTO point VALUES (3205, 465, '70', NULL, NULL);
INSERT INTO point VALUES (3206, 325, '14А', NULL, NULL);
INSERT INTO point VALUES (3207, 183, '42', NULL, NULL);
INSERT INTO point VALUES (3208, 554, '82', NULL, NULL);
INSERT INTO point VALUES (3209, 213, '29', NULL, NULL);
INSERT INTO point VALUES (3210, 555, '6', NULL, NULL);
INSERT INTO point VALUES (3211, 278, '13', NULL, NULL);
INSERT INTO point VALUES (3212, 304, '9', NULL, NULL);
INSERT INTO point VALUES (3213, 202, '40', NULL, NULL);
INSERT INTO point VALUES (3214, 664, '6А', NULL, NULL);
INSERT INTO point VALUES (3215, 386, '6Б', NULL, NULL);
INSERT INTO point VALUES (3216, 539, '3', NULL, NULL);
INSERT INTO point VALUES (3217, 178, '5', NULL, NULL);
INSERT INTO point VALUES (3218, 184, '13', NULL, NULL);
INSERT INTO point VALUES (3219, 582, '10', NULL, NULL);
INSERT INTO point VALUES (3220, 242, '3', NULL, NULL);
INSERT INTO point VALUES (3221, 526, '5', NULL, NULL);
INSERT INTO point VALUES (3222, 600, '52', NULL, NULL);
INSERT INTO point VALUES (3223, 111, '44', NULL, NULL);
INSERT INTO point VALUES (3224, 565, '40', NULL, NULL);
INSERT INTO point VALUES (3225, 636, '20/1', NULL, NULL);
INSERT INTO point VALUES (3226, 447, '53', NULL, NULL);
INSERT INTO point VALUES (3227, 496, '17/1', NULL, NULL);
INSERT INTO point VALUES (3228, 202, '30', NULL, NULL);
INSERT INTO point VALUES (3229, 496, '98', NULL, NULL);
INSERT INTO point VALUES (3230, 333, '9', NULL, NULL);
INSERT INTO point VALUES (3231, 572, '12', NULL, NULL);
INSERT INTO point VALUES (3232, 105, '3', NULL, NULL);
INSERT INTO point VALUES (3233, 67, '81', NULL, NULL);
INSERT INTO point VALUES (3234, 114, '35', NULL, NULL);
INSERT INTO point VALUES (3235, 373, '2А', NULL, NULL);
INSERT INTO point VALUES (3236, 425, '44Б', NULL, NULL);
INSERT INTO point VALUES (3237, 277, '84', NULL, NULL);
INSERT INTO point VALUES (3238, 389, '35', NULL, NULL);
INSERT INTO point VALUES (3239, 294, '96', NULL, NULL);
INSERT INTO point VALUES (3240, 600, '13', NULL, NULL);
INSERT INTO point VALUES (3241, 565, '30', NULL, NULL);
INSERT INTO point VALUES (3242, 547, '9', NULL, NULL);
INSERT INTO point VALUES (3243, 225, '3', NULL, NULL);
INSERT INTO point VALUES (3244, 279, '8', NULL, NULL);
INSERT INTO point VALUES (3245, 228, '10', NULL, NULL);
INSERT INTO point VALUES (3246, 395, '7А', NULL, NULL);
INSERT INTO point VALUES (3247, 181, '26', NULL, NULL);
INSERT INTO point VALUES (3248, 578, '9', NULL, NULL);
INSERT INTO point VALUES (3249, 489, '21', NULL, NULL);
INSERT INTO point VALUES (3250, 193, '2', NULL, NULL);
INSERT INTO point VALUES (3251, 131, '21', NULL, NULL);
INSERT INTO point VALUES (3252, 393, '4', NULL, NULL);
INSERT INTO point VALUES (3253, 270, '14', NULL, NULL);
INSERT INTO point VALUES (3254, 117, '50', NULL, NULL);
INSERT INTO point VALUES (3255, 245, '67', NULL, NULL);
INSERT INTO point VALUES (3256, 538, '28', NULL, NULL);
INSERT INTO point VALUES (3257, 120, '6', NULL, NULL);
INSERT INTO point VALUES (3258, 455, '64А', NULL, NULL);
INSERT INTO point VALUES (3259, 682, '17', NULL, NULL);
INSERT INTO point VALUES (3260, 17, '15', NULL, NULL);
INSERT INTO point VALUES (3261, 372, '17', NULL, NULL);
INSERT INTO point VALUES (3262, 566, '9', NULL, NULL);
INSERT INTO point VALUES (3263, 617, '10/1', NULL, NULL);
INSERT INTO point VALUES (3264, 146, '5', NULL, NULL);
INSERT INTO point VALUES (3265, 23, '4А', NULL, NULL);
INSERT INTO point VALUES (3266, 455, '14', NULL, NULL);
INSERT INTO point VALUES (3267, 347, '39', NULL, NULL);
INSERT INTO point VALUES (3268, 44, '24', NULL, NULL);
INSERT INTO point VALUES (3269, 686, '5', NULL, NULL);
INSERT INTO point VALUES (3270, 549, '6', NULL, NULL);
INSERT INTO point VALUES (3271, 434, '18', NULL, NULL);
INSERT INTO point VALUES (3272, 234, '25', NULL, NULL);
INSERT INTO point VALUES (3273, 199, '17', NULL, NULL);
INSERT INTO point VALUES (3274, 310, '6', NULL, NULL);
INSERT INTO point VALUES (3275, 389, '12А', NULL, NULL);
INSERT INTO point VALUES (3276, 337, '1', NULL, NULL);
INSERT INTO point VALUES (3277, 560, '41', NULL, NULL);
INSERT INTO point VALUES (3278, 670, '41', NULL, NULL);
INSERT INTO point VALUES (3279, 78, '20', NULL, NULL);
INSERT INTO point VALUES (3280, 451, '4А', NULL, NULL);
INSERT INTO point VALUES (3281, 12, '32', NULL, NULL);
INSERT INTO point VALUES (3282, 245, '17', NULL, NULL);
INSERT INTO point VALUES (3283, 566, '26', NULL, NULL);
INSERT INTO point VALUES (3284, 451, '60 (З)', NULL, NULL);
INSERT INTO point VALUES (3285, 252, '15', NULL, NULL);
INSERT INTO point VALUES (3286, 271, '6Б', NULL, NULL);
INSERT INTO point VALUES (3287, 76, '42/1', NULL, NULL);
INSERT INTO point VALUES (3288, 236, '96', NULL, NULL);
INSERT INTO point VALUES (3289, 169, '27', NULL, NULL);
INSERT INTO point VALUES (3290, 250, '82', NULL, NULL);
INSERT INTO point VALUES (3291, 693, '2/4', NULL, NULL);
INSERT INTO point VALUES (3292, 110, '36', NULL, NULL);
INSERT INTO point VALUES (3293, 150, '28', NULL, NULL);
INSERT INTO point VALUES (3294, 447, '51', NULL, NULL);
INSERT INTO point VALUES (3295, 48, '11', NULL, NULL);
INSERT INTO point VALUES (3296, 670, '31', NULL, NULL);
INSERT INTO point VALUES (3297, 70, '12', NULL, NULL);
INSERT INTO point VALUES (3298, 256, '14', NULL, NULL);
INSERT INTO point VALUES (3299, 208, '38', NULL, NULL);
INSERT INTO point VALUES (3300, 435, '71', NULL, NULL);
INSERT INTO point VALUES (3301, 445, '11', NULL, NULL);
INSERT INTO point VALUES (3302, 158, '6', NULL, NULL);
INSERT INTO point VALUES (3303, 480, '48', NULL, NULL);
INSERT INTO point VALUES (3304, 367, '23/1', NULL, NULL);
INSERT INTO point VALUES (3305, 434, '27', NULL, NULL);
INSERT INTO point VALUES (3306, 464, '63', NULL, NULL);
INSERT INTO point VALUES (3307, 226, '10', NULL, NULL);
INSERT INTO point VALUES (3308, 299, '28', NULL, NULL);
INSERT INTO point VALUES (3309, 161, '31', NULL, NULL);
INSERT INTO point VALUES (3310, 283, '2/1', NULL, NULL);
INSERT INTO point VALUES (3311, 601, '8', NULL, NULL);
INSERT INTO point VALUES (3312, 542, '55', NULL, NULL);
INSERT INTO point VALUES (3313, 310, '20', NULL, NULL);
INSERT INTO point VALUES (3314, 674, '19', NULL, NULL);
INSERT INTO point VALUES (3315, 172, '37', NULL, NULL);
INSERT INTO point VALUES (3316, 455, '52', NULL, NULL);
INSERT INTO point VALUES (3317, 203, '3', NULL, NULL);
INSERT INTO point VALUES (3318, 294, '149', NULL, NULL);
INSERT INTO point VALUES (3319, 138, '4', NULL, NULL);
INSERT INTO point VALUES (3320, 496, '93', NULL, NULL);
INSERT INTO point VALUES (3321, 67, '17', NULL, NULL);
INSERT INTO point VALUES (3322, 78, '6', NULL, NULL);
INSERT INTO point VALUES (3323, 433, '7', NULL, NULL);
INSERT INTO point VALUES (3324, 473, '2', NULL, NULL);
INSERT INTO point VALUES (3325, 598, '31', NULL, NULL);
INSERT INTO point VALUES (3326, 277, '43', NULL, NULL);
INSERT INTO point VALUES (3327, 598, '41', NULL, NULL);
INSERT INTO point VALUES (3328, 374, '129А', NULL, NULL);
INSERT INTO point VALUES (3329, 329, '28', NULL, NULL);
INSERT INTO point VALUES (3330, 169, '18', NULL, NULL);
INSERT INTO point VALUES (3331, 87, '18', NULL, NULL);
INSERT INTO point VALUES (3332, 178, '9', NULL, NULL);
INSERT INTO point VALUES (3333, 50, '3', NULL, NULL);
INSERT INTO point VALUES (3334, 176, '41', NULL, NULL);
INSERT INTO point VALUES (3335, 98, '1', NULL, NULL);
INSERT INTO point VALUES (3336, 375, '36', NULL, NULL);
INSERT INTO point VALUES (3337, 665, '20', NULL, NULL);
INSERT INTO point VALUES (3338, 523, '26', NULL, NULL);
INSERT INTO point VALUES (3339, 515, '15', NULL, NULL);
INSERT INTO point VALUES (3340, 76, '36А', NULL, NULL);
INSERT INTO point VALUES (3341, 303, '21', NULL, NULL);
INSERT INTO point VALUES (3342, 447, '85', NULL, NULL);
INSERT INTO point VALUES (3343, 674, '1', NULL, NULL);
INSERT INTO point VALUES (3344, 431, '41', NULL, NULL);
INSERT INTO point VALUES (3345, 496, '22', NULL, NULL);
INSERT INTO point VALUES (3346, 176, '31', NULL, NULL);
INSERT INTO point VALUES (3347, 531, '55', NULL, NULL);
INSERT INTO point VALUES (3348, 186, '19', NULL, NULL);
INSERT INTO point VALUES (3349, 236, '75', NULL, NULL);
INSERT INTO point VALUES (3350, 51, '58', NULL, NULL);
INSERT INTO point VALUES (3351, 123, '2', NULL, NULL);
INSERT INTO point VALUES (3352, 170, '37', NULL, NULL);
INSERT INTO point VALUES (3353, 518, '8', NULL, NULL);
INSERT INTO point VALUES (3354, 682, '1/1', NULL, NULL);
INSERT INTO point VALUES (3355, 660, '12', NULL, NULL);
INSERT INTO point VALUES (3356, 374, '37', NULL, NULL);
INSERT INTO point VALUES (3357, 464, '52А', NULL, NULL);
INSERT INTO point VALUES (3358, 200, '4', NULL, NULL);
INSERT INTO point VALUES (3359, 277, '94', NULL, NULL);
INSERT INTO point VALUES (3360, 163, '19', NULL, NULL);
INSERT INTO point VALUES (3361, 67, '67', NULL, NULL);
INSERT INTO point VALUES (3362, 20, '8', NULL, NULL);
INSERT INTO point VALUES (3363, 323, '34', NULL, NULL);
INSERT INTO point VALUES (3364, 120, '20', NULL, NULL);
INSERT INTO point VALUES (3365, 554, '141', NULL, NULL);
INSERT INTO point VALUES (3366, 131, '20/1', NULL, NULL);
INSERT INTO point VALUES (3367, 601, '153А', NULL, NULL);
INSERT INTO point VALUES (3368, 541, '22', NULL, NULL);
INSERT INTO point VALUES (3369, 480, '21', NULL, NULL);
INSERT INTO point VALUES (3370, 637, '2А', NULL, NULL);
INSERT INTO point VALUES (3371, 235, '63', NULL, NULL);
INSERT INTO point VALUES (3372, 390, '42', NULL, NULL);
INSERT INTO point VALUES (3373, 49, '4', NULL, NULL);
INSERT INTO point VALUES (3374, 212, '31', NULL, NULL);
INSERT INTO point VALUES (3375, 270, '13', NULL, NULL);
INSERT INTO point VALUES (3376, 333, '2', NULL, NULL);
INSERT INTO point VALUES (3377, 323, '81', NULL, NULL);
INSERT INTO point VALUES (3378, 445, '50', NULL, NULL);
INSERT INTO point VALUES (3379, 411, '50', NULL, NULL);
INSERT INTO point VALUES (3380, 137, '8', NULL, NULL);
INSERT INTO point VALUES (3381, 67, '102', NULL, NULL);
INSERT INTO point VALUES (3382, 146, '9', NULL, NULL);
INSERT INTO point VALUES (3383, 465, '100', NULL, NULL);
INSERT INTO point VALUES (3384, 67, '18/1', NULL, NULL);
INSERT INTO point VALUES (3385, 643, '83', NULL, NULL);
INSERT INTO point VALUES (3386, 265, '13Б', NULL, NULL);
INSERT INTO point VALUES (3387, 405, '8', NULL, NULL);
INSERT INTO point VALUES (3388, 598, '54', NULL, NULL);
INSERT INTO point VALUES (3389, 600, '14', NULL, NULL);
INSERT INTO point VALUES (3390, 561, '47', NULL, NULL);
INSERT INTO point VALUES (3391, 636, '21', NULL, NULL);
INSERT INTO point VALUES (3392, 248, '3', NULL, NULL);
INSERT INTO point VALUES (3393, 366, '29', NULL, NULL);
INSERT INTO point VALUES (3394, 451, '12/2', NULL, NULL);
INSERT INTO point VALUES (3395, 433, '32', NULL, NULL);
INSERT INTO point VALUES (3396, 236, '60', NULL, NULL);
INSERT INTO point VALUES (3397, 42, '12', NULL, NULL);
INSERT INTO point VALUES (3398, 502, '12', NULL, NULL);
INSERT INTO point VALUES (3399, 602, '36', NULL, NULL);
INSERT INTO point VALUES (3400, 566, '2', NULL, NULL);
INSERT INTO point VALUES (3401, 512, '4/5', NULL, NULL);
INSERT INTO point VALUES (3402, 504, '1', NULL, NULL);
INSERT INTO point VALUES (3403, 234, '23', NULL, NULL);
INSERT INTO point VALUES (3404, 88, '35', NULL, NULL);
INSERT INTO point VALUES (3405, 469, '4', NULL, NULL);
INSERT INTO point VALUES (3406, 435, '64А', NULL, NULL);
INSERT INTO point VALUES (3407, 112, '14', NULL, NULL);
INSERT INTO point VALUES (3408, 203, '45', NULL, NULL);
INSERT INTO point VALUES (3409, 503, '11', NULL, NULL);
INSERT INTO point VALUES (3410, 215, '37', NULL, NULL);
INSERT INTO point VALUES (3411, 277, '104', NULL, NULL);
INSERT INTO point VALUES (3412, 601, '151Б', NULL, NULL);
INSERT INTO point VALUES (3413, 125, '21', NULL, NULL);
INSERT INTO point VALUES (3414, 303, '48', NULL, NULL);
INSERT INTO point VALUES (3415, 157, '11', NULL, NULL);
INSERT INTO point VALUES (3416, 465, '72', NULL, NULL);
INSERT INTO point VALUES (3417, 617, '10А', NULL, NULL);
INSERT INTO point VALUES (3418, 277, '10', NULL, NULL);
INSERT INTO point VALUES (3419, 389, '15/2', NULL, NULL);
INSERT INTO point VALUES (3420, 496, '77', NULL, NULL);
INSERT INTO point VALUES (3421, 333, '5', NULL, NULL);
INSERT INTO point VALUES (3422, 374, '23/10', NULL, NULL);
INSERT INTO point VALUES (3423, 40, '10', NULL, NULL);
INSERT INTO point VALUES (3424, 182, '10', NULL, NULL);
INSERT INTO point VALUES (3425, 294, '60', NULL, NULL);
INSERT INTO point VALUES (3426, 451, '68а', NULL, NULL);
INSERT INTO point VALUES (3427, 566, '5', NULL, NULL);
INSERT INTO point VALUES (3428, 277, '66А', NULL, NULL);
INSERT INTO point VALUES (3429, 26, '22', NULL, NULL);
INSERT INTO point VALUES (3430, 682, '34', NULL, NULL);
INSERT INTO point VALUES (3431, 578, '5', NULL, NULL);
INSERT INTO point VALUES (3432, 310, '16', NULL, NULL);
INSERT INTO point VALUES (3433, 25, '30', NULL, NULL);
INSERT INTO point VALUES (3434, 87, '36', NULL, NULL);
INSERT INTO point VALUES (3435, 169, '36', NULL, NULL);
INSERT INTO point VALUES (3436, 226, '6', NULL, NULL);
INSERT INTO point VALUES (3437, 253, '26', NULL, NULL);
INSERT INTO point VALUES (3438, 660, '1А', NULL, NULL);
INSERT INTO point VALUES (3439, 49, '11', NULL, NULL);
INSERT INTO point VALUES (3440, 693, '12', NULL, NULL);
INSERT INTO point VALUES (3441, 158, '10', NULL, NULL);
INSERT INTO point VALUES (3442, 163, '13', NULL, NULL);
INSERT INTO point VALUES (3443, 295, '8', NULL, NULL);
INSERT INTO point VALUES (3444, 531, '133', NULL, NULL);
INSERT INTO point VALUES (3445, 67, '69', NULL, NULL);
INSERT INTO point VALUES (3446, 294, '151', NULL, NULL);
INSERT INTO point VALUES (3447, 235, '27', NULL, NULL);
INSERT INTO point VALUES (3448, 117, '30Б', NULL, NULL);
INSERT INTO point VALUES (3449, 431, '38', NULL, NULL);
INSERT INTO point VALUES (3450, 67, '116', NULL, NULL);
INSERT INTO point VALUES (3451, 505, '16', NULL, NULL);
INSERT INTO point VALUES (3452, 339, '26', NULL, NULL);
INSERT INTO point VALUES (3453, 186, '13', NULL, NULL);
INSERT INTO point VALUES (3454, 114, '39', NULL, NULL);
INSERT INTO point VALUES (3455, 117, '49', NULL, NULL);
INSERT INTO point VALUES (3456, 396, '32', NULL, NULL);
INSERT INTO point VALUES (3457, 78, '10', NULL, NULL);
INSERT INTO point VALUES (3458, 518, '23', NULL, NULL);
INSERT INTO point VALUES (3459, 458, '77', NULL, NULL);
INSERT INTO point VALUES (3460, 366, '5', NULL, NULL);
INSERT INTO point VALUES (3461, 180, '39Б', NULL, NULL);
INSERT INTO point VALUES (3462, 548, '91В', NULL, NULL);
INSERT INTO point VALUES (3463, 203, '28', NULL, NULL);
INSERT INTO point VALUES (3464, 695, '14', NULL, NULL);
INSERT INTO point VALUES (3465, 525, '18', NULL, NULL);
INSERT INTO point VALUES (3466, 389, '39', NULL, NULL);
INSERT INTO point VALUES (3467, 215, '109А', NULL, NULL);
INSERT INTO point VALUES (3468, 447, '57', NULL, NULL);
INSERT INTO point VALUES (3469, 208, '41', NULL, NULL);
INSERT INTO point VALUES (3470, 469, '11', NULL, NULL);
INSERT INTO point VALUES (3471, 254, '32', NULL, NULL);
INSERT INTO point VALUES (3472, 231, '1/2', NULL, NULL);
INSERT INTO point VALUES (3473, 582, '16', NULL, NULL);
INSERT INTO point VALUES (3474, 503, '4', NULL, NULL);
INSERT INTO point VALUES (3475, 180, '12', NULL, NULL);
INSERT INTO point VALUES (3476, 451, '18', NULL, NULL);
INSERT INTO point VALUES (3477, 563, '8', NULL, NULL);
INSERT INTO point VALUES (3478, 548, '91Б', NULL, NULL);
INSERT INTO point VALUES (3479, 302, '3А', NULL, NULL);
INSERT INTO point VALUES (3480, 315, '11А', NULL, NULL);
INSERT INTO point VALUES (3481, 201, '75', NULL, NULL);
INSERT INTO point VALUES (3482, 119, '9', NULL, NULL);
INSERT INTO point VALUES (3483, 236, '92/2', NULL, NULL);
INSERT INTO point VALUES (3484, 674, '13', NULL, NULL);
INSERT INTO point VALUES (3485, 421, '7', NULL, NULL);
INSERT INTO point VALUES (3486, 589, '2', NULL, NULL);
INSERT INTO point VALUES (3487, 202, '32А', NULL, NULL);
INSERT INTO point VALUES (3488, 396, '25', NULL, NULL);
INSERT INTO point VALUES (3489, 365, '6', NULL, NULL);
INSERT INTO point VALUES (3490, 98, '13', NULL, NULL);
INSERT INTO point VALUES (3491, 431, '47', NULL, NULL);
INSERT INTO point VALUES (3492, 598, '38', NULL, NULL);
INSERT INTO point VALUES (3493, 339, '9', NULL, NULL);
INSERT INTO point VALUES (3494, 496, '53 ка', NULL, NULL);
INSERT INTO point VALUES (3495, 374, '96/1', NULL, NULL);
INSERT INTO point VALUES (3496, 209, '26', NULL, NULL);
INSERT INTO point VALUES (3497, 472, '38', NULL, NULL);
INSERT INTO point VALUES (3498, 366, '2', NULL, NULL);
INSERT INTO point VALUES (3499, 347, '35', NULL, NULL);
INSERT INTO point VALUES (3500, 294, '220', NULL, NULL);
INSERT INTO point VALUES (3501, 675, '17', NULL, NULL);
INSERT INTO point VALUES (3502, 42, '5А', NULL, NULL);
INSERT INTO point VALUES (3503, 32, '2', NULL, NULL);
INSERT INTO point VALUES (3504, 245, '35', NULL, NULL);
INSERT INTO point VALUES (3505, 561, '41', NULL, NULL);
INSERT INTO point VALUES (3506, 2, '20', NULL, NULL);
INSERT INTO point VALUES (3507, 464, '27', NULL, NULL);
INSERT INTO point VALUES (3508, 304, '29', NULL, NULL);
INSERT INTO point VALUES (3509, 191, '16', NULL, NULL);
INSERT INTO point VALUES (3510, 75, '31', NULL, NULL);
INSERT INTO point VALUES (3511, 394, '1А', NULL, NULL);
INSERT INTO point VALUES (3512, 374, '68', NULL, NULL);
INSERT INTO point VALUES (3513, 390, '44', NULL, NULL);
INSERT INTO point VALUES (3514, 550, '72', NULL, NULL);
INSERT INTO point VALUES (3515, 582, '20', NULL, NULL);
INSERT INTO point VALUES (3516, 496, '71А', NULL, NULL);
INSERT INTO point VALUES (3517, 374, '70', NULL, NULL);
INSERT INTO point VALUES (3518, 182, '22А', NULL, NULL);
INSERT INTO point VALUES (3519, 377, '2', NULL, NULL);
INSERT INTO point VALUES (3520, 277, '56', NULL, NULL);
INSERT INTO point VALUES (3521, 270, '1', NULL, NULL);
INSERT INTO point VALUES (3522, 432, '7', NULL, NULL);
INSERT INTO point VALUES (3523, 133, '32', NULL, NULL);
INSERT INTO point VALUES (3524, 254, '7', NULL, NULL);
INSERT INTO point VALUES (3525, 625, '7', NULL, NULL);
INSERT INTO point VALUES (3526, 656, '7', NULL, NULL);
INSERT INTO point VALUES (3527, 429, '15', NULL, NULL);
INSERT INTO point VALUES (3528, 389, '48Г', NULL, NULL);
INSERT INTO point VALUES (3529, 565, '48', NULL, NULL);
INSERT INTO point VALUES (3530, 495, '18', NULL, NULL);
INSERT INTO point VALUES (3531, 40, '6', NULL, NULL);
INSERT INTO point VALUES (3532, 182, '6', NULL, NULL);
INSERT INTO point VALUES (3533, 458, '93', NULL, NULL);
INSERT INTO point VALUES (3534, 221, '21', NULL, NULL);
INSERT INTO point VALUES (3535, 390, '24', NULL, NULL);
INSERT INTO point VALUES (3536, 277, '6', NULL, NULL);
INSERT INTO point VALUES (3537, 372, '35', NULL, NULL);
INSERT INTO point VALUES (3538, 32, '5', NULL, NULL);
INSERT INTO point VALUES (3539, 349, '3', NULL, NULL);
INSERT INTO point VALUES (3540, 329, '45', NULL, NULL);
INSERT INTO point VALUES (3541, 338, '3А', NULL, NULL);
INSERT INTO point VALUES (3542, 614, '20', NULL, NULL);
INSERT INTO point VALUES (3543, 315, '8', NULL, NULL);
INSERT INTO point VALUES (3544, 205, '17', NULL, NULL);
INSERT INTO point VALUES (3545, 340, '7', NULL, NULL);
INSERT INTO point VALUES (3546, 421, '32', NULL, NULL);
INSERT INTO point VALUES (3547, 601, '106', NULL, NULL);
INSERT INTO point VALUES (3548, 114, '17', NULL, NULL);
INSERT INTO point VALUES (3549, 643, '21', NULL, NULL);
INSERT INTO point VALUES (3550, 544, '31', NULL, NULL);
INSERT INTO point VALUES (3551, 604, '189', NULL, NULL);
INSERT INTO point VALUES (3552, 270, '19', NULL, NULL);
INSERT INTO point VALUES (3553, 100, '43', NULL, NULL);
INSERT INTO point VALUES (3554, 447, '58', NULL, NULL);
INSERT INTO point VALUES (3555, 531, '15А', NULL, NULL);
INSERT INTO point VALUES (3556, 202, '48', NULL, NULL);
INSERT INTO point VALUES (3557, 416, '5', NULL, NULL);
INSERT INTO point VALUES (3558, 389, '17', NULL, NULL);
INSERT INTO point VALUES (3559, 44, '22', NULL, NULL);
INSERT INTO point VALUES (3560, 235, '61', NULL, NULL);
INSERT INTO point VALUES (3561, 29, '14', NULL, NULL);
INSERT INTO point VALUES (3562, 182, '22Б', NULL, NULL);
INSERT INTO point VALUES (3563, 604, '212', NULL, NULL);
INSERT INTO point VALUES (3564, 639, '15', NULL, NULL);
INSERT INTO point VALUES (3565, 398, '3', NULL, NULL);
INSERT INTO point VALUES (3566, 389, '7', NULL, NULL);
INSERT INTO point VALUES (3567, 260, '19', NULL, NULL);
INSERT INTO point VALUES (3568, 205, '7', NULL, NULL);
INSERT INTO point VALUES (3569, 303, '55А', NULL, NULL);
INSERT INTO point VALUES (3570, 262, '5', NULL, NULL);
INSERT INTO point VALUES (3571, 340, '17', NULL, NULL);
INSERT INTO point VALUES (3572, 670, '21', NULL, NULL);
INSERT INTO point VALUES (3573, 560, '21', NULL, NULL);
INSERT INTO point VALUES (3574, 523, '18', NULL, NULL);
INSERT INTO point VALUES (3575, 682, '11А', NULL, NULL);
INSERT INTO point VALUES (3576, 42, '6', NULL, NULL);
INSERT INTO point VALUES (3577, 502, '6', NULL, NULL);
INSERT INTO point VALUES (3578, 679, '3', NULL, NULL);
INSERT INTO point VALUES (3579, 572, '16', NULL, NULL);
INSERT INTO point VALUES (3580, 607, '14', NULL, NULL);
INSERT INTO point VALUES (3581, 106, '4', NULL, NULL);
INSERT INTO point VALUES (3582, 294, '62', NULL, NULL);
INSERT INTO point VALUES (3583, 180, '43', NULL, NULL);
INSERT INTO point VALUES (3584, 272, '1', NULL, NULL);
INSERT INTO point VALUES (3585, 174, '22', NULL, NULL);
INSERT INTO point VALUES (3586, 625, '17', NULL, NULL);
INSERT INTO point VALUES (3587, 261, '28', NULL, NULL);
INSERT INTO point VALUES (3588, 201, '42А', NULL, NULL);
INSERT INTO point VALUES (3589, 169, '9', NULL, NULL);
INSERT INTO point VALUES (3590, 87, '9', NULL, NULL);
INSERT INTO point VALUES (3591, 178, '18', NULL, NULL);
INSERT INTO point VALUES (3592, 489, '31', NULL, NULL);
INSERT INTO point VALUES (3593, 236, '62', NULL, NULL);
INSERT INTO point VALUES (3594, 208, '30', NULL, NULL);
INSERT INTO point VALUES (3595, 290, '13', NULL, NULL);
INSERT INTO point VALUES (3596, 598, '46', NULL, NULL);
INSERT INTO point VALUES (3597, 374, '84Д', NULL, NULL);
INSERT INTO point VALUES (3598, 486, '4', NULL, NULL);
INSERT INTO point VALUES (3599, 338, '14', NULL, NULL);
INSERT INTO point VALUES (3600, 374, '115', NULL, NULL);
INSERT INTO point VALUES (3601, 308, '1', NULL, NULL);
INSERT INTO point VALUES (3602, 620, '4', NULL, NULL);
INSERT INTO point VALUES (3603, 96, '3', NULL, NULL);
INSERT INTO point VALUES (3604, 396, '17', NULL, NULL);
INSERT INTO point VALUES (3605, 260, '1', NULL, NULL);
INSERT INTO point VALUES (3606, 634, '9', NULL, NULL);
INSERT INTO point VALUES (3607, 361, '5А', NULL, NULL);
INSERT INTO point VALUES (3608, 53, '52', NULL, NULL);
INSERT INTO point VALUES (3609, 70, '16', NULL, NULL);
INSERT INTO point VALUES (3610, 214, '4', NULL, NULL);
INSERT INTO point VALUES (3611, 362, '13А', NULL, NULL);
INSERT INTO point VALUES (3612, 384, '4', NULL, NULL);
INSERT INTO point VALUES (3613, 100, '57', NULL, NULL);
INSERT INTO point VALUES (3614, 169, '26', NULL, NULL);
INSERT INTO point VALUES (3615, 87, '26', NULL, NULL);
INSERT INTO point VALUES (3616, 188, '1', NULL, NULL);
INSERT INTO point VALUES (3617, 110, '5', NULL, NULL);
INSERT INTO point VALUES (3618, 12, '74', NULL, NULL);
INSERT INTO point VALUES (3619, 192, '14', NULL, NULL);
INSERT INTO point VALUES (3620, 374, '49', NULL, NULL);
INSERT INTO point VALUES (3621, 675, '7', NULL, NULL);
INSERT INTO point VALUES (3622, 279, '39', NULL, NULL);
INSERT INTO point VALUES (3623, 223, '19', NULL, NULL);
INSERT INTO point VALUES (3624, 61, '23', NULL, NULL);
INSERT INTO point VALUES (3625, 88, '23', NULL, NULL);
INSERT INTO point VALUES (3626, 390, '15', NULL, NULL);
INSERT INTO point VALUES (3627, 693, '10', NULL, NULL);
INSERT INTO point VALUES (3628, 231, '26', NULL, NULL);
INSERT INTO point VALUES (3629, 375, '9', NULL, NULL);
INSERT INTO point VALUES (3630, 389, '32', NULL, NULL);
INSERT INTO point VALUES (3631, 277, '3 кб', NULL, NULL);
INSERT INTO point VALUES (3632, 76, '14', NULL, NULL);
INSERT INTO point VALUES (3633, 406, '14', NULL, NULL);
INSERT INTO point VALUES (3634, 467, '16', NULL, NULL);
INSERT INTO point VALUES (3635, 304, '27', NULL, NULL);
INSERT INTO point VALUES (3636, 464, '29', NULL, NULL);
INSERT INTO point VALUES (3637, 487, '2', NULL, NULL);
INSERT INTO point VALUES (3638, 682, '8', NULL, NULL);
INSERT INTO point VALUES (3639, 403, '3', NULL, NULL);
INSERT INTO point VALUES (3640, 193, '18', NULL, NULL);
INSERT INTO point VALUES (3641, 447, '43', NULL, NULL);
INSERT INTO point VALUES (3642, 372, '8', NULL, NULL);
INSERT INTO point VALUES (3643, 172, '29/2', NULL, NULL);
INSERT INTO point VALUES (3644, 174, '77', NULL, NULL);
INSERT INTO point VALUES (3645, 25, '38', NULL, NULL);
INSERT INTO point VALUES (3646, 279, '17', NULL, NULL);
INSERT INTO point VALUES (3647, 51, '56', NULL, NULL);
INSERT INTO point VALUES (3648, 99, '15', NULL, NULL);
INSERT INTO point VALUES (3649, 268, '2/2', NULL, NULL);
INSERT INTO point VALUES (3650, 70, '20', NULL, NULL);
INSERT INTO point VALUES (3651, 94, '15', NULL, NULL);
INSERT INTO point VALUES (3652, 374, '91', NULL, NULL);
INSERT INTO point VALUES (3653, 280, '109', NULL, NULL);
INSERT INTO point VALUES (3654, 572, '20', NULL, NULL);
INSERT INTO point VALUES (3655, 335, '4', NULL, NULL);
INSERT INTO point VALUES (3656, 389, '25', NULL, NULL);
INSERT INTO point VALUES (3657, 653, '33', NULL, NULL);
INSERT INTO point VALUES (3658, 37, '49', NULL, NULL);
INSERT INTO point VALUES (3659, 199, '8', NULL, NULL);
INSERT INTO point VALUES (3660, 506, '14', NULL, NULL);
INSERT INTO point VALUES (3661, 628, '40А', NULL, NULL);
INSERT INTO point VALUES (3662, 586, '6', NULL, NULL);
INSERT INTO point VALUES (3663, 364, '20', NULL, NULL);
INSERT INTO point VALUES (3664, 215, '49', NULL, NULL);
INSERT INTO point VALUES (3665, 114, '25', NULL, NULL);
INSERT INTO point VALUES (3666, 617, '31', NULL, NULL);
INSERT INTO point VALUES (3667, 111, '22', NULL, NULL);
INSERT INTO point VALUES (3668, 231, '9', NULL, NULL);
INSERT INTO point VALUES (3669, 562, '22', NULL, NULL);
INSERT INTO point VALUES (3670, 375, '26', NULL, NULL);
INSERT INTO point VALUES (3671, 205, '25', NULL, NULL);
INSERT INTO point VALUES (3672, 224, '6', NULL, NULL);
INSERT INTO point VALUES (3673, 660, '6', NULL, NULL);
INSERT INTO point VALUES (3674, 654, '45', NULL, NULL);
INSERT INTO point VALUES (3675, 215, '115', NULL, NULL);
INSERT INTO point VALUES (3676, 604, '2', NULL, NULL);
INSERT INTO point VALUES (3677, 389, '1/3', NULL, NULL);
INSERT INTO point VALUES (3678, 653, '24', NULL, NULL);
INSERT INTO point VALUES (3679, 27, '4', NULL, NULL);
INSERT INTO point VALUES (3680, 280, '42', NULL, NULL);
INSERT INTO point VALUES (3681, 294, '246', NULL, NULL);
INSERT INTO point VALUES (3682, 352, '6', NULL, NULL);
INSERT INTO point VALUES (3683, 473, '27', NULL, NULL);
INSERT INTO point VALUES (3684, 544, '30', NULL, NULL);
INSERT INTO point VALUES (3685, 386, '14', NULL, NULL);
INSERT INTO point VALUES (3686, 649, '19', NULL, NULL);
INSERT INTO point VALUES (3687, 246, '7', NULL, NULL);
INSERT INTO point VALUES (3688, 223, '13', NULL, NULL);
INSERT INTO point VALUES (3689, 434, '29', NULL, NULL);
INSERT INTO point VALUES (3690, 120, '51', NULL, NULL);
INSERT INTO point VALUES (3691, 451, '26', NULL, NULL);
INSERT INTO point VALUES (3692, 100, '85', NULL, NULL);
INSERT INTO point VALUES (3693, 227, '9', NULL, NULL);
INSERT INTO point VALUES (3694, 261, '3', NULL, NULL);
INSERT INTO point VALUES (3695, 374, '48А', NULL, NULL);
INSERT INTO point VALUES (3696, 267, '7', NULL, NULL);
INSERT INTO point VALUES (3697, 654, '28', NULL, NULL);
INSERT INTO point VALUES (3698, 259, '8', NULL, NULL);
INSERT INTO point VALUES (3699, 426, '12', NULL, NULL);
INSERT INTO point VALUES (3700, 292, '11', NULL, NULL);
INSERT INTO point VALUES (3701, 161, '30', NULL, NULL);
INSERT INTO point VALUES (3702, 425, '1', NULL, NULL);
INSERT INTO point VALUES (3703, 210, '20', NULL, NULL);
INSERT INTO point VALUES (3704, 131, '38', NULL, NULL);
INSERT INTO point VALUES (3705, 508, '4', NULL, NULL);
INSERT INTO point VALUES (3706, 563, '34', NULL, NULL);
INSERT INTO point VALUES (3707, 46, '3', NULL, NULL);
INSERT INTO point VALUES (3708, 447, '56', NULL, NULL);
INSERT INTO point VALUES (3709, 23, '26', NULL, NULL);
INSERT INTO point VALUES (3710, 291, '8', NULL, NULL);
INSERT INTO point VALUES (3711, 569, '45', NULL, NULL);
INSERT INTO point VALUES (3712, 525, '9', NULL, NULL);
INSERT INTO point VALUES (3713, 598, '30', NULL, NULL);
INSERT INTO point VALUES (3714, 658, '32', NULL, NULL);
INSERT INTO point VALUES (3715, 294, '141', NULL, NULL);
INSERT INTO point VALUES (3716, 604, '29', NULL, NULL);
INSERT INTO point VALUES (3717, 472, '30', NULL, NULL);
INSERT INTO point VALUES (3718, 84, '15', NULL, NULL);
INSERT INTO point VALUES (3719, 269, '25', NULL, NULL);
INSERT INTO point VALUES (3720, 12, '81', NULL, NULL);
INSERT INTO point VALUES (3721, 435, '73', NULL, NULL);
INSERT INTO point VALUES (3722, 117, '37', NULL, NULL);
INSERT INTO point VALUES (3723, 347, '23', NULL, NULL);
INSERT INTO point VALUES (3724, 621, '7', NULL, NULL);
INSERT INTO point VALUES (3725, 335, '11', NULL, NULL);
INSERT INTO point VALUES (3726, 569, '10Б', NULL, NULL);
INSERT INTO point VALUES (3727, 451, '9', NULL, NULL);
INSERT INTO point VALUES (3728, 277, '12', NULL, NULL);
INSERT INTO point VALUES (3729, 119, '18', NULL, NULL);
INSERT INTO point VALUES (3730, 601, '151А', NULL, NULL);
INSERT INTO point VALUES (3731, 431, '30', NULL, NULL);
INSERT INTO point VALUES (3732, 351, '5', NULL, NULL);
INSERT INTO point VALUES (3733, 40, '12', NULL, NULL);
INSERT INTO point VALUES (3734, 57, '4', NULL, NULL);
INSERT INTO point VALUES (3735, 182, '12', NULL, NULL);
INSERT INTO point VALUES (3736, 374, '121', NULL, NULL);
INSERT INTO point VALUES (3737, 435, '55', NULL, NULL);
INSERT INTO point VALUES (3738, 509, '21', NULL, NULL);
INSERT INTO point VALUES (3739, 81, '7', NULL, NULL);
INSERT INTO point VALUES (3740, 277, '58', NULL, NULL);
INSERT INTO point VALUES (3741, 525, '26', NULL, NULL);
INSERT INTO point VALUES (3742, 496, '15/1', NULL, NULL);
INSERT INTO point VALUES (3743, 260, '13', NULL, NULL);
INSERT INTO point VALUES (3744, 512, '4', NULL, NULL);
INSERT INTO point VALUES (3745, 415, '71А', NULL, NULL);
INSERT INTO point VALUES (3746, 696, '3', NULL, NULL);
INSERT INTO point VALUES (3747, 487, '29', NULL, NULL);
INSERT INTO point VALUES (3748, 658, '25', NULL, NULL);
INSERT INTO point VALUES (3749, 290, '1', NULL, NULL);
INSERT INTO point VALUES (3750, 339, '18', NULL, NULL);
INSERT INTO point VALUES (3751, 465, '4', NULL, NULL);
INSERT INTO point VALUES (3752, 394, '10', NULL, NULL);
INSERT INTO point VALUES (3753, 521, '15', NULL, NULL);
INSERT INTO point VALUES (3754, 601, '155', NULL, NULL);
INSERT INTO point VALUES (3755, 601, '35', NULL, NULL);
INSERT INTO point VALUES (3756, 120, '53', NULL, NULL);
INSERT INTO point VALUES (3757, 624, '76', NULL, NULL);
INSERT INTO point VALUES (3758, 571, '37', NULL, NULL);
INSERT INTO point VALUES (3759, 131, '12/7', NULL, NULL);
INSERT INTO point VALUES (3760, 273, '2', NULL, NULL);
INSERT INTO point VALUES (3761, 57, '7А', NULL, NULL);
INSERT INTO point VALUES (3762, 531, '14', NULL, NULL);
INSERT INTO point VALUES (3763, 370, '6', NULL, NULL);
INSERT INTO point VALUES (3764, 431, '40', NULL, NULL);
INSERT INTO point VALUES (3765, 424, '4', NULL, NULL);
INSERT INTO point VALUES (3766, 213, '18', NULL, NULL);
INSERT INTO point VALUES (3767, 236, '59', NULL, NULL);
INSERT INTO point VALUES (3768, 465, '57А', NULL, NULL);
INSERT INTO point VALUES (3769, 499, '3', NULL, NULL);
INSERT INTO point VALUES (3770, 461, '3', NULL, NULL);
INSERT INTO point VALUES (3771, 373, '59Б', NULL, NULL);
INSERT INTO point VALUES (3772, 548, '22', NULL, NULL);
INSERT INTO point VALUES (3773, 366, '27', NULL, NULL);
INSERT INTO point VALUES (3774, 628, '29', NULL, NULL);
INSERT INTO point VALUES (3775, 497, '11', NULL, NULL);
INSERT INTO point VALUES (3776, 569, '111', NULL, NULL);
INSERT INTO point VALUES (3777, 585, '14', NULL, NULL);
INSERT INTO point VALUES (3778, 30, '14', NULL, NULL);
INSERT INTO point VALUES (3779, 531, '110', NULL, NULL);
INSERT INTO point VALUES (3780, 667, '31', NULL, NULL);
INSERT INTO point VALUES (3781, 285, '11', NULL, NULL);
INSERT INTO point VALUES (3782, 658, '7', NULL, NULL);
INSERT INTO point VALUES (3783, 451, '78', NULL, NULL);
INSERT INTO point VALUES (3784, 451, '64', NULL, NULL);
INSERT INTO point VALUES (3785, 233, '3', NULL, NULL);
INSERT INTO point VALUES (3786, 12, '34', NULL, NULL);
INSERT INTO point VALUES (3787, 374, '135А', NULL, NULL);
INSERT INTO point VALUES (3788, 215, '121', NULL, NULL);
INSERT INTO point VALUES (3789, 183, '22', NULL, NULL);
INSERT INTO point VALUES (3790, 542, '14', NULL, NULL);
INSERT INTO point VALUES (3791, 375, '54/1', NULL, NULL);
INSERT INTO point VALUES (3792, 397, '11', NULL, NULL);
INSERT INTO point VALUES (3793, 235, '2', NULL, NULL);
INSERT INTO point VALUES (3794, 688, '7', NULL, NULL);
INSERT INTO point VALUES (3795, 273, '5', NULL, NULL);
INSERT INTO point VALUES (3796, 495, '9', NULL, NULL);
INSERT INTO point VALUES (3797, 477, '21', NULL, NULL);
INSERT INTO point VALUES (3798, 180, '6', NULL, NULL);
INSERT INTO point VALUES (3799, 620, '11', NULL, NULL);
INSERT INTO point VALUES (3800, 219, '5', NULL, NULL);
INSERT INTO point VALUES (3801, 372, '23', NULL, NULL);
INSERT INTO point VALUES (3802, 483, '14', NULL, NULL);
INSERT INTO point VALUES (3803, 558, '7', NULL, NULL);
INSERT INTO point VALUES (3804, 15, '24', NULL, NULL);
INSERT INTO point VALUES (3805, 598, '40', NULL, NULL);
INSERT INTO point VALUES (3806, 294, '59', NULL, NULL);
INSERT INTO point VALUES (3807, 8, '14', NULL, NULL);
INSERT INTO point VALUES (3808, 660, '10', NULL, NULL);
INSERT INTO point VALUES (3809, 110, '29', NULL, NULL);
INSERT INTO point VALUES (3810, 682, '23', NULL, NULL);
INSERT INTO point VALUES (3811, 25, '31', NULL, NULL);
INSERT INTO point VALUES (3812, 374, '108', NULL, NULL);
INSERT INTO point VALUES (3813, 569, '3', NULL, NULL);
INSERT INTO point VALUES (3814, 601, '74', NULL, NULL);
INSERT INTO point VALUES (3815, 352, '10', NULL, NULL);
INSERT INTO point VALUES (3816, 682, '9А', NULL, NULL);
INSERT INTO point VALUES (3817, 210, '16', NULL, NULL);
INSERT INTO point VALUES (3818, 534, '7', NULL, NULL);
INSERT INTO point VALUES (3819, 455, '70А', NULL, NULL);
INSERT INTO point VALUES (3820, 220, '22/5', NULL, NULL);
INSERT INTO point VALUES (3821, 458, '44', NULL, NULL);
INSERT INTO point VALUES (3822, 544, '21', NULL, NULL);
INSERT INTO point VALUES (3823, 572, '10', NULL, NULL);
INSERT INTO point VALUES (3824, 390, '22', NULL, NULL);
INSERT INTO point VALUES (3825, 415, '15', NULL, NULL);
INSERT INTO point VALUES (3826, 250, '45', NULL, NULL);
INSERT INTO point VALUES (3827, 323, '25', NULL, NULL);
INSERT INTO point VALUES (3828, 329, '62', NULL, NULL);
INSERT INTO point VALUES (3829, 364, '10', NULL, NULL);
INSERT INTO point VALUES (3830, 478, '44', NULL, NULL);
INSERT INTO point VALUES (3831, 658, '23', NULL, NULL);
INSERT INTO point VALUES (3832, 489, '8Б', NULL, NULL);
INSERT INTO point VALUES (3833, 243, '4А', NULL, NULL);
INSERT INTO point VALUES (3834, 542, '52', NULL, NULL);
INSERT INTO point VALUES (3835, 643, '41', NULL, NULL);
INSERT INTO point VALUES (3836, 607, '1', NULL, NULL);
INSERT INTO point VALUES (3837, 12, '102', NULL, NULL);
INSERT INTO point VALUES (3838, 7, '29', NULL, NULL);
INSERT INTO point VALUES (3839, 347, '25', NULL, NULL);
INSERT INTO point VALUES (3840, 601, '116', NULL, NULL);
INSERT INTO point VALUES (3841, 100, '53', NULL, NULL);
INSERT INTO point VALUES (3842, 326, '11', NULL, NULL);
INSERT INTO point VALUES (3843, 346, '4', NULL, NULL);
INSERT INTO point VALUES (3844, 480, '38', NULL, NULL);
INSERT INTO point VALUES (3845, 560, '40', NULL, NULL);
INSERT INTO point VALUES (3846, 525, '2', NULL, NULL);
INSERT INTO point VALUES (3847, 362, '30', NULL, NULL);
INSERT INTO point VALUES (3848, 213, '27', NULL, NULL);
INSERT INTO point VALUES (3849, 682, '7', NULL, NULL);
INSERT INTO point VALUES (3850, 338, '1', NULL, NULL);
INSERT INTO point VALUES (3851, 372, '7', NULL, NULL);
INSERT INTO point VALUES (3852, 111, '15', NULL, NULL);
INSERT INTO point VALUES (3853, 235, '64', NULL, NULL);
INSERT INTO point VALUES (3854, 562, '15', NULL, NULL);
INSERT INTO point VALUES (3855, 269, '23', NULL, NULL);
INSERT INTO point VALUES (3856, 451, '2', NULL, NULL);
INSERT INTO point VALUES (3857, 323, '32', NULL, NULL);
INSERT INTO point VALUES (3858, 480, '47', NULL, NULL);
INSERT INTO point VALUES (3859, 294, '135', NULL, NULL);
INSERT INTO point VALUES (3860, 664, '28', NULL, NULL);
INSERT INTO point VALUES (3861, 554, '3', NULL, NULL);
INSERT INTO point VALUES (3862, 447, '16', NULL, NULL);
INSERT INTO point VALUES (3863, 566, '36/4', NULL, NULL);
INSERT INTO point VALUES (3864, 67, '98А', NULL, NULL);
INSERT INTO point VALUES (3865, 394, '32/1', NULL, NULL);
INSERT INTO point VALUES (3866, 687, '4', NULL, NULL);
INSERT INTO point VALUES (3867, 531, '152', NULL, NULL);
INSERT INTO point VALUES (3868, 277, '23/2', NULL, NULL);
INSERT INTO point VALUES (3869, 525, '5', NULL, NULL);
INSERT INTO point VALUES (3870, 607, '19', NULL, NULL);
INSERT INTO point VALUES (3871, 589, '18', NULL, NULL);
INSERT INTO point VALUES (3872, 374, '94А', NULL, NULL);
INSERT INTO point VALUES (3873, 67, '23', NULL, NULL);
INSERT INTO point VALUES (3874, 236, '82', NULL, NULL);
INSERT INTO point VALUES (3875, 183, '52/17', NULL, NULL);
INSERT INTO point VALUES (3876, 192, '1', NULL, NULL);
INSERT INTO point VALUES (3877, 23, '2', NULL, NULL);
INSERT INTO point VALUES (3878, 170, '11', NULL, NULL);
INSERT INTO point VALUES (3879, 458, '24', NULL, NULL);
INSERT INTO point VALUES (3880, 280, '76', NULL, NULL);
INSERT INTO point VALUES (3881, 39, '3', NULL, NULL);
INSERT INTO point VALUES (3882, 202, '28А', NULL, NULL);
INSERT INTO point VALUES (3883, 280, '117', NULL, NULL);
INSERT INTO point VALUES (3884, 202, '41', NULL, NULL);
INSERT INTO point VALUES (3885, 639, '22', NULL, NULL);
INSERT INTO point VALUES (3886, 75, '10/1', NULL, NULL);
INSERT INTO point VALUES (3887, 433, '34', NULL, NULL);
INSERT INTO point VALUES (3888, 604, '209', NULL, NULL);
INSERT INTO point VALUES (3889, 32, '18', NULL, NULL);
INSERT INTO point VALUES (3890, 30, '13', NULL, NULL);
INSERT INTO point VALUES (3891, 269, '25А', NULL, NULL);
INSERT INTO point VALUES (3892, 447, '20', NULL, NULL);
INSERT INTO point VALUES (3893, 372, '25', NULL, NULL);
INSERT INTO point VALUES (3894, 219, '9', NULL, NULL);
INSERT INTO point VALUES (3895, 44, '15', NULL, NULL);
INSERT INTO point VALUES (3896, 273, '9', NULL, NULL);
INSERT INTO point VALUES (3897, 294, '258', NULL, NULL);
INSERT INTO point VALUES (3898, 682, '25', NULL, NULL);
INSERT INTO point VALUES (3899, 303, '47', NULL, NULL);
INSERT INTO point VALUES (3900, 643, '54', NULL, NULL);
INSERT INTO point VALUES (3901, 235, '26', NULL, NULL);
INSERT INTO point VALUES (3902, 76, '1', NULL, NULL);
INSERT INTO point VALUES (3903, 406, '1', NULL, NULL);
INSERT INTO point VALUES (3904, 222, '15', NULL, NULL);
INSERT INTO point VALUES (3905, 342, '10', NULL, NULL);
INSERT INTO point VALUES (3906, 92, '15', NULL, NULL);
INSERT INTO point VALUES (3907, 334, '1', NULL, NULL);
INSERT INTO point VALUES (3908, 614, '12', NULL, NULL);
INSERT INTO point VALUES (3909, 693, '16', NULL, NULL);
INSERT INTO point VALUES (3910, 100, '51', NULL, NULL);
INSERT INTO point VALUES (3911, 663, '21', NULL, NULL);
INSERT INTO point VALUES (3912, 602, '29', NULL, NULL);
INSERT INTO point VALUES (3913, 294, '160', NULL, NULL);
INSERT INTO point VALUES (3914, 220, '19А', NULL, NULL);
INSERT INTO point VALUES (3915, 208, '21', NULL, NULL);
INSERT INTO point VALUES (3916, 531, '13', NULL, NULL);
INSERT INTO point VALUES (3917, 183, '52/11', NULL, NULL);
INSERT INTO point VALUES (3918, 505, '12', NULL, NULL);
INSERT INTO point VALUES (3919, 467, '10', NULL, NULL);
INSERT INTO point VALUES (3920, 115, '15', NULL, NULL);
INSERT INTO point VALUES (3921, 152, '4', NULL, NULL);
INSERT INTO point VALUES (3922, 682, '32', NULL, NULL);
INSERT INTO point VALUES (3923, 235, '9', NULL, NULL);
INSERT INTO point VALUES (3924, 37, '11', NULL, NULL);
INSERT INTO point VALUES (3925, 475, '4', NULL, NULL);
INSERT INTO point VALUES (3926, 536, '4', NULL, NULL);
INSERT INTO point VALUES (3927, 462, '4', NULL, NULL);
INSERT INTO point VALUES (3928, 142, '33', NULL, NULL);
INSERT INTO point VALUES (3929, 372, '32', NULL, NULL);
INSERT INTO point VALUES (3930, 265, '28', NULL, NULL);
INSERT INTO point VALUES (3931, 409, '8', NULL, NULL);
INSERT INTO point VALUES (3932, 210, '6', NULL, NULL);
INSERT INTO point VALUES (3933, 250, '3', NULL, NULL);
INSERT INTO point VALUES (3934, 334, '19', NULL, NULL);
INSERT INTO point VALUES (3935, 146, '63', NULL, NULL);
INSERT INTO point VALUES (3936, 483, '13', NULL, NULL);
INSERT INTO point VALUES (3937, 496, '42', NULL, NULL);
INSERT INTO point VALUES (3938, 67, '106', NULL, NULL);
INSERT INTO point VALUES (3939, 604, '214', NULL, NULL);
INSERT INTO point VALUES (3940, 473, '3а', NULL, NULL);
INSERT INTO point VALUES (3941, 257, '10', NULL, NULL);
INSERT INTO point VALUES (3942, 303, '38', NULL, NULL);
INSERT INTO point VALUES (3943, 169, '29', NULL, NULL);
INSERT INTO point VALUES (3944, 87, '29', NULL, NULL);
INSERT INTO point VALUES (3945, 389, '8', NULL, NULL);
INSERT INTO point VALUES (3946, 582, '12', NULL, NULL);
INSERT INTO point VALUES (3947, 542, '13', NULL, NULL);
INSERT INTO point VALUES (3948, 205, '8', NULL, NULL);
INSERT INTO point VALUES (3949, 139, '3', NULL, NULL);
INSERT INTO point VALUES (3950, 197, '8', NULL, NULL);
INSERT INTO point VALUES (3951, 231, '2А', NULL, NULL);
INSERT INTO point VALUES (3952, 168, '28', NULL, NULL);
INSERT INTO point VALUES (3953, 624, '42', NULL, NULL);
INSERT INTO point VALUES (3954, 545, '19', NULL, NULL);
INSERT INTO point VALUES (3955, 268, '3', NULL, NULL);
INSERT INTO point VALUES (3956, 26, '33', NULL, NULL);
INSERT INTO point VALUES (3957, 396, '34', NULL, NULL);
INSERT INTO point VALUES (3958, 447, '84', NULL, NULL);
INSERT INTO point VALUES (3959, 42, '16', NULL, NULL);
INSERT INTO point VALUES (3960, 502, '16', NULL, NULL);
INSERT INTO point VALUES (3961, 95, '23', NULL, NULL);
INSERT INTO point VALUES (3962, 269, '8', NULL, NULL);
INSERT INTO point VALUES (3963, 114, '106', NULL, NULL);
INSERT INTO point VALUES (3964, 425, '88', NULL, NULL);
INSERT INTO point VALUES (3965, 601, '17', NULL, NULL);
INSERT INTO point VALUES (3966, 262, '26', NULL, NULL);
INSERT INTO point VALUES (3967, 49, '37', NULL, NULL);
INSERT INTO point VALUES (3968, 386, '6В', NULL, NULL);
INSERT INTO point VALUES (3969, 283, '15', NULL, NULL);
INSERT INTO point VALUES (3970, 473, '18', NULL, NULL);
INSERT INTO point VALUES (3971, 477, '30', NULL, NULL);
INSERT INTO point VALUES (3972, 374, '7А', NULL, NULL);
INSERT INTO point VALUES (3973, 213, '4А', NULL, NULL);
INSERT INTO point VALUES (3974, 688, '8', NULL, NULL);
INSERT INTO point VALUES (3975, 88, '7', NULL, NULL);
INSERT INTO point VALUES (3976, 666, '37', NULL, NULL);
INSERT INTO point VALUES (3977, 531, '242', NULL, NULL);
INSERT INTO point VALUES (3978, 458, '42', NULL, NULL);
INSERT INTO point VALUES (3979, 170, '7А', NULL, NULL);
INSERT INTO point VALUES (3980, 548, '15', NULL, NULL);
INSERT INTO point VALUES (3981, 433, '74', NULL, NULL);
INSERT INTO point VALUES (3982, 303, '54', NULL, NULL);
INSERT INTO point VALUES (3983, 110, '9', NULL, NULL);
INSERT INTO point VALUES (3984, 643, '47', NULL, NULL);
INSERT INTO point VALUES (3985, 169, '2', NULL, NULL);
INSERT INTO point VALUES (3986, 117, '43А', NULL, NULL);
INSERT INTO point VALUES (3987, 120, '12', NULL, NULL);
INSERT INTO point VALUES (3988, 26, '24', NULL, NULL);
INSERT INTO point VALUES (3989, 478, '42', NULL, NULL);
INSERT INTO point VALUES (3990, 67, '8', NULL, NULL);
INSERT INTO point VALUES (3991, 181, '36', NULL, NULL);
INSERT INTO point VALUES (3992, 15, '24Б', NULL, NULL);
INSERT INTO point VALUES (3993, 352, '20', NULL, NULL);
INSERT INTO point VALUES (3994, 598, '48', NULL, NULL);
INSERT INTO point VALUES (3995, 635, '4', NULL, NULL);
INSERT INTO point VALUES (3996, 262, '9', NULL, NULL);
INSERT INTO point VALUES (3997, 152, '11', NULL, NULL);
INSERT INTO point VALUES (3998, 183, '15', NULL, NULL);
INSERT INTO point VALUES (3999, 304, '18', NULL, NULL);
INSERT INTO point VALUES (4000, 536, '11', NULL, NULL);
INSERT INTO point VALUES (4001, 634, '2', NULL, NULL);
INSERT INTO point VALUES (4002, 61, '32', NULL, NULL);
INSERT INTO point VALUES (4003, 549, '12', NULL, NULL);
INSERT INTO point VALUES (4004, 394, '16', NULL, NULL);
INSERT INTO point VALUES (4005, 110, '26', NULL, NULL);
INSERT INTO point VALUES (4006, 254, '34', NULL, NULL);
INSERT INTO point VALUES (4007, 20, '17', NULL, NULL);
INSERT INTO point VALUES (4008, 458, '109', NULL, NULL);
INSERT INTO point VALUES (4009, 87, '5', NULL, NULL);
INSERT INTO point VALUES (4010, 604, '15/219', NULL, NULL);
INSERT INTO point VALUES (4011, 169, '5', NULL, NULL);
INSERT INTO point VALUES (4012, 480, '31', NULL, NULL);
INSERT INTO point VALUES (4013, 451, '2А', NULL, NULL);
INSERT INTO point VALUES (4014, 389, '25А', NULL, NULL);
INSERT INTO point VALUES (4015, 448, '15', NULL, NULL);
INSERT INTO point VALUES (4016, 137, '17', NULL, NULL);
INSERT INTO point VALUES (4017, 375, '2', NULL, NULL);
INSERT INTO point VALUES (4018, 231, '5', NULL, NULL);
INSERT INTO point VALUES (4019, 451, '29', NULL, NULL);
INSERT INTO point VALUES (4020, 542, '19', NULL, NULL);
INSERT INTO point VALUES (4021, 657, '15', NULL, NULL);
INSERT INTO point VALUES (4022, 496, '24', NULL, NULL);
INSERT INTO point VALUES (4023, 220, '21', NULL, NULL);
INSERT INTO point VALUES (4024, 531, '1', NULL, NULL);
INSERT INTO point VALUES (4025, 53, '14', NULL, NULL);
INSERT INTO point VALUES (4026, 304, '36', NULL, NULL);
INSERT INTO point VALUES (4027, 434, '26', NULL, NULL);
INSERT INTO point VALUES (4028, 451, '38 ка', NULL, NULL);
INSERT INTO point VALUES (4029, 488, '22', NULL, NULL);
INSERT INTO point VALUES (4030, 294, '76А', NULL, NULL);
INSERT INTO point VALUES (4031, 560, '46', NULL, NULL);
INSERT INTO point VALUES (4032, 342, '6', NULL, NULL);
INSERT INTO point VALUES (4033, 451, '61', NULL, NULL);
INSERT INTO point VALUES (4034, 317, '7А', NULL, NULL);
INSERT INTO point VALUES (4035, 338, '52', NULL, NULL);
INSERT INTO point VALUES (4036, 483, '19', NULL, NULL);
INSERT INTO point VALUES (4037, 389, '23', NULL, NULL);
INSERT INTO point VALUES (4038, 235, '65', NULL, NULL);
INSERT INTO point VALUES (4039, 601, '102', NULL, NULL);
INSERT INTO point VALUES (4040, 621, '8', NULL, NULL);
INSERT INTO point VALUES (4041, 303, '41', NULL, NULL);
INSERT INTO point VALUES (4042, 326, '4', NULL, NULL);
INSERT INTO point VALUES (4043, 395, '11В', NULL, NULL);
INSERT INTO point VALUES (4044, 139, '23/3', NULL, NULL);
INSERT INTO point VALUES (4045, 334, '13', NULL, NULL);
INSERT INTO point VALUES (4046, 30, '1', NULL, NULL);
INSERT INTO point VALUES (4047, 394, '20', NULL, NULL);
INSERT INTO point VALUES (4048, 467, '6', NULL, NULL);
INSERT INTO point VALUES (4049, 114, '23', NULL, NULL);
INSERT INTO point VALUES (4050, 176, '21', NULL, NULL);
INSERT INTO point VALUES (4051, 405, '17', NULL, NULL);
INSERT INTO point VALUES (4052, 236, '126', NULL, NULL);
INSERT INTO point VALUES (4053, 205, '23', NULL, NULL);
INSERT INTO point VALUES (4054, 303, '31', NULL, NULL);
INSERT INTO point VALUES (4055, 346, '11', NULL, NULL);
INSERT INTO point VALUES (4056, 496, '33', NULL, NULL);
INSERT INTO point VALUES (4057, 279, '20Б', NULL, NULL);
INSERT INTO point VALUES (4058, 433, '35', NULL, NULL);
INSERT INTO point VALUES (4059, 202, '38', NULL, NULL);
INSERT INTO point VALUES (4060, 531, '19', NULL, NULL);
INSERT INTO point VALUES (4061, 598, '21', NULL, NULL);
INSERT INTO point VALUES (4062, 120, '57', NULL, NULL);
INSERT INTO point VALUES (4063, 294, '126', NULL, NULL);
INSERT INTO point VALUES (4064, 523, '27', NULL, NULL);
INSERT INTO point VALUES (4065, 568, '6', NULL, NULL);
INSERT INTO point VALUES (4066, 277, '90', NULL, NULL);
INSERT INTO point VALUES (4067, 472, '21', NULL, NULL);
INSERT INTO point VALUES (4068, 168, '3', NULL, NULL);
INSERT INTO point VALUES (4069, 601, '39', NULL, NULL);
INSERT INTO point VALUES (4070, 231, '2', NULL, NULL);
INSERT INTO point VALUES (4071, 352, '16', NULL, NULL);
INSERT INTO point VALUES (4072, 110, '33А', NULL, NULL);
INSERT INTO point VALUES (4073, 531, '137', NULL, NULL);
INSERT INTO point VALUES (4074, 604, '9', NULL, NULL);
INSERT INTO point VALUES (4075, 480, '54', NULL, NULL);
INSERT INTO point VALUES (4076, 166, '15', NULL, NULL);
INSERT INTO point VALUES (4077, 565, '38', NULL, NULL);
INSERT INTO point VALUES (4078, 161, '21', NULL, NULL);
INSERT INTO point VALUES (4079, 88, '25', NULL, NULL);
INSERT INTO point VALUES (4080, 250, '28', NULL, NULL);
INSERT INTO point VALUES (4081, 246, '8', NULL, NULL);
INSERT INTO point VALUES (4082, 445, '68', NULL, NULL);
INSERT INTO point VALUES (4083, 42, '20', NULL, NULL);
INSERT INTO point VALUES (4084, 502, '20', NULL, NULL);
INSERT INTO point VALUES (4085, 468, '31', NULL, NULL);
INSERT INTO point VALUES (4086, 525, '29', NULL, NULL);
INSERT INTO point VALUES (4087, 687, '11', NULL, NULL);
INSERT INTO point VALUES (4088, 257, '6', NULL, NULL);
INSERT INTO point VALUES (4089, 573, '7', NULL, NULL);
INSERT INTO point VALUES (4090, 496, '44', NULL, NULL);
INSERT INTO point VALUES (4091, 259, '7', NULL, NULL);
INSERT INTO point VALUES (4092, 373, '63', NULL, NULL);
INSERT INTO point VALUES (4093, 30, '19', NULL, NULL);
INSERT INTO point VALUES (4094, 265, '3', NULL, NULL);
INSERT INTO point VALUES (4095, 342, '56', NULL, NULL);
INSERT INTO point VALUES (4096, 388, '12', NULL, NULL);
INSERT INTO point VALUES (4097, 600, '23', NULL, NULL);
INSERT INTO point VALUES (4098, 67, '110 ка', NULL, NULL);
INSERT INTO point VALUES (4099, 161, '3', NULL, NULL);
INSERT INTO point VALUES (4100, 279, '19', NULL, NULL);
INSERT INTO point VALUES (4101, 334, '35', NULL, NULL);
INSERT INTO point VALUES (4102, 203, '41', NULL, NULL);
INSERT INTO point VALUES (4103, 133, '19', NULL, NULL);
INSERT INTO point VALUES (4104, 384, '5', NULL, NULL);
INSERT INTO point VALUES (4105, 458, '56', NULL, NULL);
INSERT INTO point VALUES (4106, 560, '60', NULL, NULL);
INSERT INTO point VALUES (4107, 323, '55', NULL, NULL);
INSERT INTO point VALUES (4108, 373, '87', NULL, NULL);
INSERT INTO point VALUES (4109, 585, '34', NULL, NULL);
INSERT INTO point VALUES (4110, 464, '50В', NULL, NULL);
INSERT INTO point VALUES (4111, 277, '22', NULL, NULL);
INSERT INTO point VALUES (4112, 203, '31', NULL, NULL);
INSERT INTO point VALUES (4113, 478, '56', NULL, NULL);
INSERT INTO point VALUES (4114, 40, '22', NULL, NULL);
INSERT INTO point VALUES (4115, 182, '22', NULL, NULL);
INSERT INTO point VALUES (4116, 548, '57', NULL, NULL);
INSERT INTO point VALUES (4117, 234, '14', NULL, NULL);
INSERT INTO point VALUES (4118, 433, '13', NULL, NULL);
INSERT INTO point VALUES (4119, 265, '21', NULL, NULL);
INSERT INTO point VALUES (4120, 386, '12А', NULL, NULL);
INSERT INTO point VALUES (4121, 598, '3', NULL, NULL);
INSERT INTO point VALUES (4122, 397, '5', NULL, NULL);
INSERT INTO point VALUES (4123, 37, '26', NULL, NULL);
INSERT INTO point VALUES (4124, 421, '19', NULL, NULL);
INSERT INTO point VALUES (4125, 166, '12', NULL, NULL);
INSERT INTO point VALUES (4126, 520, '18', NULL, NULL);
INSERT INTO point VALUES (4127, 472, '3', NULL, NULL);
INSERT INTO point VALUES (4128, 376, '16', NULL, NULL);
INSERT INTO point VALUES (4129, 26, '10', NULL, NULL);
INSERT INTO point VALUES (4130, 374, '169', NULL, NULL);
INSERT INTO point VALUES (4131, 569, '40', NULL, NULL);
INSERT INTO point VALUES (4132, 531, '27Б', NULL, NULL);
INSERT INTO point VALUES (4133, 15, '20', NULL, NULL);
INSERT INTO point VALUES (4134, 50, '31', NULL, NULL);
INSERT INTO point VALUES (4135, 359, '10', NULL, NULL);
INSERT INTO point VALUES (4136, 496, '94', NULL, NULL);
INSERT INTO point VALUES (4137, 282, '6', NULL, NULL);
INSERT INTO point VALUES (4138, 146, '37', NULL, NULL);
INSERT INTO point VALUES (4139, 620, '5', NULL, NULL);
INSERT INTO point VALUES (4140, 219, '11', NULL, NULL);
INSERT INTO point VALUES (4141, 279, '1', NULL, NULL);
INSERT INTO point VALUES (4142, 280, '101', NULL, NULL);
INSERT INTO point VALUES (4143, 572, '42', NULL, NULL);
INSERT INTO point VALUES (4144, 541, '10', NULL, NULL);
INSERT INTO point VALUES (4145, 624, '6', NULL, NULL);
INSERT INTO point VALUES (4146, 483, '34', NULL, NULL);
INSERT INTO point VALUES (4147, 649, '17', NULL, NULL);
INSERT INTO point VALUES (4148, 262, '23А', NULL, NULL);
INSERT INTO point VALUES (4149, 497, '5', NULL, NULL);
INSERT INTO point VALUES (4150, 431, '3', NULL, NULL);
INSERT INTO point VALUES (4151, 415, '85', NULL, NULL);
INSERT INTO point VALUES (4152, 323, '73', NULL, NULL);
INSERT INTO point VALUES (4153, 329, '38', NULL, NULL);
INSERT INTO point VALUES (4154, 71, '6', NULL, NULL);
INSERT INTO point VALUES (4155, 338, '74', NULL, NULL);
INSERT INTO point VALUES (4156, 374, '64', NULL, NULL);
INSERT INTO point VALUES (4157, 384, '2', NULL, NULL);
INSERT INTO point VALUES (4158, 646, '19', NULL, NULL);
INSERT INTO point VALUES (4159, 210, '21А', NULL, NULL);
INSERT INTO point VALUES (4160, 208, '28', NULL, NULL);
INSERT INTO point VALUES (4161, 220, '3', NULL, NULL);
INSERT INTO point VALUES (4162, 49, '27', NULL, NULL);
INSERT INTO point VALUES (4163, 577, '5', NULL, NULL);
INSERT INTO point VALUES (4164, 572, '35А', NULL, NULL);
INSERT INTO point VALUES (4165, 620, '2', NULL, NULL);
INSERT INTO point VALUES (4166, 464, '50', NULL, NULL);
INSERT INTO point VALUES (4167, 486, '2', NULL, NULL);
INSERT INTO point VALUES (4168, 317, '9', NULL, NULL);
INSERT INTO point VALUES (4169, 280, '143', NULL, NULL);
INSERT INTO point VALUES (4170, 460, '18', NULL, NULL);
INSERT INTO point VALUES (4171, 635, '9', NULL, NULL);
INSERT INTO point VALUES (4172, 270, '25', NULL, NULL);
INSERT INTO point VALUES (4173, 496, '43', NULL, NULL);
INSERT INTO point VALUES (4174, 235, '11', NULL, NULL);
INSERT INTO point VALUES (4175, 512, '2А', NULL, NULL);
INSERT INTO point VALUES (4176, 37, '9', NULL, NULL);
INSERT INTO point VALUES (4177, 183, '57', NULL, NULL);
INSERT INTO point VALUES (4178, 59, '54', NULL, NULL);
INSERT INTO point VALUES (4179, 625, '19', NULL, NULL);
INSERT INTO point VALUES (4180, 496, '104', NULL, NULL);
INSERT INTO point VALUES (4181, 183, '12', NULL, NULL);
INSERT INTO point VALUES (4182, 465, '61', NULL, NULL);
INSERT INTO point VALUES (4183, 451, '81А', NULL, NULL);
INSERT INTO point VALUES (4184, 548, '91А', NULL, NULL);
INSERT INTO point VALUES (4185, 447, '76', NULL, NULL);
INSERT INTO point VALUES (4186, 265, '13А', NULL, NULL);
INSERT INTO point VALUES (4187, 604, '217', NULL, NULL);
INSERT INTO point VALUES (4188, 139, '22/5', NULL, NULL);
INSERT INTO point VALUES (4189, 326, '9', NULL, NULL);
INSERT INTO point VALUES (4190, 431, '45', NULL, NULL);
INSERT INTO point VALUES (4191, 615, '3', NULL, NULL);
INSERT INTO point VALUES (4192, 487, '4', NULL, NULL);
INSERT INTO point VALUES (4193, 496, '10', NULL, NULL);
INSERT INTO point VALUES (4194, 374, '26', NULL, NULL);
INSERT INTO point VALUES (4195, 27, '5', NULL, NULL);
INSERT INTO point VALUES (4196, 265, '48', NULL, NULL);
INSERT INTO point VALUES (4197, 303, '62', NULL, NULL);
INSERT INTO point VALUES (4198, 252, '6', NULL, NULL);
INSERT INTO point VALUES (4199, 415, '1А', NULL, NULL);
INSERT INTO point VALUES (4200, 260, '17', NULL, NULL);
INSERT INTO point VALUES (4201, 335, '5', NULL, NULL);
INSERT INTO point VALUES (4202, 340, '19', NULL, NULL);
INSERT INTO point VALUES (4203, 264, '10', NULL, NULL);
INSERT INTO point VALUES (4204, 57, '29', NULL, NULL);
INSERT INTO point VALUES (4205, 270, '7', NULL, NULL);
INSERT INTO point VALUES (4206, 202, '6/2', NULL, NULL);
INSERT INTO point VALUES (4207, 554, '19А', NULL, NULL);
INSERT INTO point VALUES (4208, 563, '14', NULL, NULL);
INSERT INTO point VALUES (4209, 665, '15', NULL, NULL);
INSERT INTO point VALUES (4210, 170, '9', NULL, NULL);
INSERT INTO point VALUES (4211, 223, '17', NULL, NULL);
INSERT INTO point VALUES (4212, 261, '40', NULL, NULL);
INSERT INTO point VALUES (4213, 459, '13', NULL, NULL);
INSERT INTO point VALUES (4214, 254, '1', NULL, NULL);
INSERT INTO point VALUES (4215, 656, '1', NULL, NULL);
INSERT INTO point VALUES (4216, 210, '24', NULL, NULL);
INSERT INTO point VALUES (4217, 374, '9', NULL, NULL);
INSERT INTO point VALUES (4218, 26, '43', NULL, NULL);
INSERT INTO point VALUES (4219, 643, '59', NULL, NULL);
INSERT INTO point VALUES (4220, 670, '61Б', NULL, NULL);
INSERT INTO point VALUES (4221, 278, '23', NULL, NULL);
INSERT INTO point VALUES (4222, 15, '16', NULL, NULL);
INSERT INTO point VALUES (4223, 117, '32Б', NULL, NULL);
INSERT INTO point VALUES (4224, 544, '28', NULL, NULL);
INSERT INTO point VALUES (4225, 342, '42', NULL, NULL);
INSERT INTO point VALUES (4226, 610, '8', NULL, NULL);
INSERT INTO point VALUES (4227, 157, '4А', NULL, NULL);
INSERT INTO point VALUES (4228, 548, '12', NULL, NULL);
INSERT INTO point VALUES (4229, 268, '21', NULL, NULL);
INSERT INTO point VALUES (4230, 283, '12', NULL, NULL);
INSERT INTO point VALUES (4231, 434, '4', NULL, NULL);
INSERT INTO point VALUES (4232, 396, '19', NULL, NULL);
INSERT INTO point VALUES (4233, 235, '50', NULL, NULL);
INSERT INTO point VALUES (4234, 130, '12', NULL, NULL);
INSERT INTO point VALUES (4235, 139, '21/2', NULL, NULL);
INSERT INTO point VALUES (4236, 37, '64', NULL, NULL);
INSERT INTO point VALUES (4237, 9, '63', NULL, NULL);
INSERT INTO point VALUES (4238, 184, '23', NULL, NULL);
INSERT INTO point VALUES (4239, 292, '5', NULL, NULL);
INSERT INTO point VALUES (4240, 554, '83', NULL, NULL);
INSERT INTO point VALUES (4241, 120, '15', NULL, NULL);
INSERT INTO point VALUES (4242, 306, '3', NULL, NULL);
INSERT INTO point VALUES (4243, 335, '2', NULL, NULL);
INSERT INTO point VALUES (4244, 325, '6', NULL, NULL);
INSERT INTO point VALUES (4245, 295, '14', NULL, NULL);
INSERT INTO point VALUES (4246, 364, '24', NULL, NULL);
INSERT INTO point VALUES (4247, 346, '9', NULL, NULL);
INSERT INTO point VALUES (4248, 382, '14', NULL, NULL);
INSERT INTO point VALUES (4249, 294, '134', NULL, NULL);
INSERT INTO point VALUES (4250, 542, '12А', NULL, NULL);
INSERT INTO point VALUES (4251, 554, '13А', NULL, NULL);
INSERT INTO point VALUES (4252, 528, '3', NULL, NULL);
INSERT INTO point VALUES (4253, 572, '24', NULL, NULL);
INSERT INTO point VALUES (4254, 186, '7', NULL, NULL);
INSERT INTO point VALUES (4255, 598, '28', NULL, NULL);
INSERT INTO point VALUES (4256, 531, '35', NULL, NULL);
INSERT INTO point VALUES (4257, 643, '62', NULL, NULL);
INSERT INTO point VALUES (4258, 472, '28', NULL, NULL);
INSERT INTO point VALUES (4259, 425, '39', NULL, NULL);
INSERT INTO point VALUES (4260, 653, '20', NULL, NULL);
INSERT INTO point VALUES (4261, 203, '47', NULL, NULL);
INSERT INTO point VALUES (4262, 26, '6', NULL, NULL);
INSERT INTO point VALUES (4263, 572, '33', NULL, NULL);
INSERT INTO point VALUES (4264, 582, '15', NULL, NULL);
INSERT INTO point VALUES (4265, 374, '20А', NULL, NULL);
INSERT INTO point VALUES (4266, 112, '8', NULL, NULL);
INSERT INTO point VALUES (4267, 282, '10', NULL, NULL);
INSERT INTO point VALUES (4268, 389, '17/2', NULL, NULL);
INSERT INTO point VALUES (4269, 261, '13/1', NULL, NULL);
INSERT INTO point VALUES (4270, 299, '31', NULL, NULL);
INSERT INTO point VALUES (4271, 57, '5', NULL, NULL);
INSERT INTO point VALUES (4272, 213, '37', NULL, NULL);
INSERT INTO point VALUES (4273, 294, '192', NULL, NULL);
INSERT INTO point VALUES (4274, 334, '34', NULL, NULL);
INSERT INTO point VALUES (4275, 161, '28', NULL, NULL);
INSERT INTO point VALUES (4276, 250, '21', NULL, NULL);
INSERT INTO point VALUES (4277, 351, '4', NULL, NULL);
INSERT INTO point VALUES (4278, 76, '34', NULL, NULL);
INSERT INTO point VALUES (4279, 415, '57', NULL, NULL);
INSERT INTO point VALUES (4280, 26, '22А', NULL, NULL);
INSERT INTO point VALUES (4281, 561, '45', NULL, NULL);
INSERT INTO point VALUES (4282, 48, '18', NULL, NULL);
INSERT INTO point VALUES (4283, 469, '4А', NULL, NULL);
INSERT INTO point VALUES (4284, 44, '12', NULL, NULL);
INSERT INTO point VALUES (4285, 375, '48А', NULL, NULL);
INSERT INTO point VALUES (4286, 600, '8', NULL, NULL);
INSERT INTO point VALUES (4287, 465, '2', NULL, NULL);
INSERT INTO point VALUES (4288, 541, '6', NULL, NULL);
INSERT INTO point VALUES (4289, 405, '14', NULL, NULL);
INSERT INTO point VALUES (4290, 663, '3', NULL, NULL);
INSERT INTO point VALUES (4291, 92, '12', NULL, NULL);
INSERT INTO point VALUES (4292, 674, '7', NULL, NULL);
INSERT INTO point VALUES (4293, 208, '3', NULL, NULL);
INSERT INTO point VALUES (4294, 512, '2', NULL, NULL);
INSERT INTO point VALUES (4295, 421, '13', NULL, NULL);
INSERT INTO point VALUES (4296, 687, '9', NULL, NULL);
INSERT INTO point VALUES (4297, 435, '8', NULL, NULL);
INSERT INTO point VALUES (4298, 100, '77', NULL, NULL);
INSERT INTO point VALUES (4299, 222, '12', NULL, NULL);
INSERT INTO point VALUES (4300, 429, '20', NULL, NULL);
INSERT INTO point VALUES (4301, 71, '10', NULL, NULL);
INSERT INTO point VALUES (4302, 356, '18', NULL, NULL);
INSERT INTO point VALUES (4303, 604, '11', NULL, NULL);
INSERT INTO point VALUES (4304, 548, '50/2', NULL, NULL);
INSERT INTO point VALUES (4305, 117, '36', NULL, NULL);
INSERT INTO point VALUES (4306, 494, '16', NULL, NULL);
INSERT INTO point VALUES (4307, 531, '12А', NULL, NULL);
INSERT INTO point VALUES (4308, 604, '15/205', NULL, NULL);
INSERT INTO point VALUES (4309, 434, '11', NULL, NULL);
INSERT INTO point VALUES (4310, 629, '10', NULL, NULL);
INSERT INTO point VALUES (4311, 458, '10', NULL, NULL);
INSERT INTO point VALUES (4312, 311, '3', NULL, NULL);
INSERT INTO point VALUES (4313, 572, '44', NULL, NULL);
INSERT INTO point VALUES (4314, 411, '27', NULL, NULL);
INSERT INTO point VALUES (4315, 303, '59', NULL, NULL);
INSERT INTO point VALUES (4316, 508, '5', NULL, NULL);
INSERT INTO point VALUES (4317, 34, '15', NULL, NULL);
INSERT INTO point VALUES (4318, 133, '13', NULL, NULL);
INSERT INTO point VALUES (4319, 236, '134', NULL, NULL);
INSERT INTO point VALUES (4320, 389, '37А', NULL, NULL);
INSERT INTO point VALUES (4321, 483, '35', NULL, NULL);
INSERT INTO point VALUES (4322, 137, '14', NULL, NULL);
INSERT INTO point VALUES (4323, 290, '17', NULL, NULL);
INSERT INTO point VALUES (4324, 329, '54', NULL, NULL);
INSERT INTO point VALUES (4325, 518, '14', NULL, NULL);
INSERT INTO point VALUES (4326, 607, '34', NULL, NULL);
INSERT INTO point VALUES (4327, 110, '11', NULL, NULL);
INSERT INTO point VALUES (4328, 342, '24', NULL, NULL);
INSERT INTO point VALUES (4329, 208, '45', NULL, NULL);
INSERT INTO point VALUES (4330, 496, '6', NULL, NULL);
INSERT INTO point VALUES (4331, 531, '74', NULL, NULL);
INSERT INTO point VALUES (4332, 610, '23', NULL, NULL);
INSERT INTO point VALUES (4333, 111, '12', NULL, NULL);
INSERT INTO point VALUES (4334, 20, '14', NULL, NULL);
INSERT INTO point VALUES (4335, 478, '43', NULL, NULL);
INSERT INTO point VALUES (4336, 562, '12', NULL, NULL);
INSERT INTO point VALUES (4337, 117, '18', NULL, NULL);
INSERT INTO point VALUES (4338, 561, '3', NULL, NULL);
INSERT INTO point VALUES (4339, 451, '36/2', NULL, NULL);
INSERT INTO point VALUES (4340, 252, '10', NULL, NULL);
INSERT INTO point VALUES (4341, 424, '2', NULL, NULL);
INSERT INTO point VALUES (4342, 100, '93', NULL, NULL);
INSERT INTO point VALUES (4343, 374, '65', NULL, NULL);
INSERT INTO point VALUES (4344, 59, '38', NULL, NULL);
INSERT INTO point VALUES (4345, 67, '114', NULL, NULL);
INSERT INTO point VALUES (4346, 427, '8', NULL, NULL);
INSERT INTO point VALUES (4347, 277, '2-74а', NULL, NULL);
INSERT INTO point VALUES (4348, 273, '4', NULL, NULL);
INSERT INTO point VALUES (4349, 494, '20', NULL, NULL);
INSERT INTO point VALUES (4350, 504, '7', NULL, NULL);
INSERT INTO point VALUES (4351, 429, '16', NULL, NULL);
INSERT INTO point VALUES (4352, 163, '32', NULL, NULL);
INSERT INTO point VALUES (4353, 24, '8', NULL, NULL);
INSERT INTO point VALUES (4354, 131, '8/1', NULL, NULL);
INSERT INTO point VALUES (4355, 552, '34', NULL, NULL);
INSERT INTO point VALUES (4356, 610, '8А', NULL, NULL);
INSERT INTO point VALUES (4357, 340, '13', NULL, NULL);
INSERT INTO point VALUES (4358, 353, '52', NULL, NULL);
INSERT INTO point VALUES (4359, 601, '110', NULL, NULL);
INSERT INTO point VALUES (4360, 360, '3', NULL, NULL);
INSERT INTO point VALUES (4361, 571, '36', NULL, NULL);
INSERT INTO point VALUES (4362, 81, '18/4', NULL, NULL);
INSERT INTO point VALUES (4363, 544, '3', NULL, NULL);
INSERT INTO point VALUES (4364, 451, '49', NULL, NULL);
INSERT INTO point VALUES (4365, 376, '45А', NULL, NULL);
INSERT INTO point VALUES (4366, 601, '88', NULL, NULL);
INSERT INTO point VALUES (4367, 586, '117', NULL, NULL);
INSERT INTO point VALUES (4368, 693, '2/1', NULL, NULL);
INSERT INTO point VALUES (4369, 338, '34', NULL, NULL);
INSERT INTO point VALUES (4370, 256, '8', NULL, NULL);
INSERT INTO point VALUES (4371, 342, '44', NULL, NULL);
INSERT INTO point VALUES (4372, 569, '10А', NULL, NULL);
INSERT INTO point VALUES (4373, 262, '11', NULL, NULL);
INSERT INTO point VALUES (4374, 152, '9', NULL, NULL);
INSERT INTO point VALUES (4375, 294, '123', NULL, NULL);
INSERT INTO point VALUES (4376, 432, '13', NULL, NULL);
INSERT INTO point VALUES (4377, 235, '4', NULL, NULL);
INSERT INTO point VALUES (4378, 475, '9', NULL, NULL);
INSERT INTO point VALUES (4379, 325, '10', NULL, NULL);
INSERT INTO point VALUES (4380, 163, '25', NULL, NULL);
INSERT INTO point VALUES (4381, 536, '9', NULL, NULL);
INSERT INTO point VALUES (4382, 191, '15', NULL, NULL);
INSERT INTO point VALUES (4383, 462, '9', NULL, NULL);
INSERT INTO point VALUES (4384, 625, '13', NULL, NULL);
INSERT INTO point VALUES (4385, 656, '13', NULL, NULL);
INSERT INTO point VALUES (4386, 236, '38', NULL, NULL);
INSERT INTO point VALUES (4387, 525, '4', NULL, NULL);
INSERT INTO point VALUES (4388, 243, '4Б', NULL, NULL);
INSERT INTO point VALUES (4389, 687, '5', NULL, NULL);
INSERT INTO point VALUES (4390, 100, '98', NULL, NULL);
INSERT INTO point VALUES (4391, 455, '46Б', NULL, NULL);
INSERT INTO point VALUES (4392, 465, '26', NULL, NULL);
INSERT INTO point VALUES (4393, 310, '22', NULL, NULL);
INSERT INTO point VALUES (4394, 670, '61А', NULL, NULL);
INSERT INTO point VALUES (4395, 294, '47', NULL, NULL);
INSERT INTO point VALUES (4396, 111, '40/1', NULL, NULL);
INSERT INTO point VALUES (4397, 170, '29', NULL, NULL);
INSERT INTO point VALUES (4398, 362, '28', NULL, NULL);
INSERT INTO point VALUES (4399, 94, '1А', NULL, NULL);
INSERT INTO point VALUES (4400, 455, '8', NULL, NULL);
INSERT INTO point VALUES (4401, 695, '7', NULL, NULL);
INSERT INTO point VALUES (4402, 53, '34', NULL, NULL);
INSERT INTO point VALUES (4403, 601, '52', NULL, NULL);
INSERT INTO point VALUES (4404, 375, '11', NULL, NULL);
INSERT INTO point VALUES (4405, 393, '4А', NULL, NULL);
INSERT INTO point VALUES (4406, 269, '4/1', NULL, NULL);
INSERT INTO point VALUES (4407, 477, '3', NULL, NULL);
INSERT INTO point VALUES (4408, 183, '53', NULL, NULL);
INSERT INTO point VALUES (4409, 610, '7', NULL, NULL);
INSERT INTO point VALUES (4410, 502, '24', NULL, NULL);
INSERT INTO point VALUES (4411, 57, '26', NULL, NULL);
INSERT INTO point VALUES (4412, 265, '40', NULL, NULL);
INSERT INTO point VALUES (4413, 91, '21', NULL, NULL);
INSERT INTO point VALUES (4414, 23, '4', NULL, NULL);
INSERT INTO point VALUES (4415, 465, '9', NULL, NULL);
INSERT INTO point VALUES (4416, 531, '69', NULL, NULL);
INSERT INTO point VALUES (4417, 183, '54А', NULL, NULL);
INSERT INTO point VALUES (4418, 137, '13', NULL, NULL);
INSERT INTO point VALUES (4419, 133, '14', NULL, NULL);
INSERT INTO point VALUES (4420, 665, '22', NULL, NULL);
INSERT INTO point VALUES (4421, 117, '27', NULL, NULL);
INSERT INTO point VALUES (4422, 465, '80', NULL, NULL);
INSERT INTO point VALUES (4423, 378, '3', NULL, NULL);
INSERT INTO point VALUES (4424, 151, '8', NULL, NULL);
INSERT INTO point VALUES (4425, 531, '220А', NULL, NULL);
INSERT INTO point VALUES (4426, 374, '139', NULL, NULL);
INSERT INTO point VALUES (4427, 280, '43', NULL, NULL);
INSERT INTO point VALUES (4428, 496, '20', NULL, NULL);
INSERT INTO point VALUES (4429, 201, '31', NULL, NULL);
INSERT INTO point VALUES (4430, 177, '19', NULL, NULL);
INSERT INTO point VALUES (4431, 548, '53', NULL, NULL);
INSERT INTO point VALUES (4432, 270, '8', NULL, NULL);
INSERT INTO point VALUES (4433, 451, '4', NULL, NULL);
INSERT INTO point VALUES (4434, 541, '16', NULL, NULL);
INSERT INTO point VALUES (4435, 172, '29', NULL, NULL);
INSERT INTO point VALUES (4436, 231, '11', NULL, NULL);
INSERT INTO point VALUES (4437, 157, '18', NULL, NULL);
INSERT INTO point VALUES (4438, 236, '47', NULL, NULL);
INSERT INTO point VALUES (4439, 334, '17', NULL, NULL);
INSERT INTO point VALUES (4440, 496, '101', NULL, NULL);
INSERT INTO point VALUES (4441, 57, '9', NULL, NULL);
INSERT INTO point VALUES (4442, 494, '6', NULL, NULL);
INSERT INTO point VALUES (4443, 405, '13', NULL, NULL);
INSERT INTO point VALUES (4444, 264, '20', NULL, NULL);
INSERT INTO point VALUES (4445, 511, '3', NULL, NULL);
INSERT INTO point VALUES (4446, 235, '49', NULL, NULL);
INSERT INTO point VALUES (4447, 445, '36', NULL, NULL);
INSERT INTO point VALUES (4448, 120, '22', NULL, NULL);
INSERT INTO point VALUES (4449, 509, '3', NULL, NULL);
INSERT INTO point VALUES (4450, 169, '11', NULL, NULL);
INSERT INTO point VALUES (4451, 87, '11', NULL, NULL);
INSERT INTO point VALUES (4452, 447, '66', NULL, NULL);
INSERT INTO point VALUES (4453, 541, '20', NULL, NULL);
INSERT INTO point VALUES (4454, 192, '17', NULL, NULL);
INSERT INTO point VALUES (4455, 40, '15', NULL, NULL);
INSERT INTO point VALUES (4456, 163, '23', NULL, NULL);
INSERT INTO point VALUES (4457, 429, '6', NULL, NULL);
INSERT INTO point VALUES (4458, 696, '21', NULL, NULL);
INSERT INTO point VALUES (4459, 15, '14/1', NULL, NULL);
INSERT INTO point VALUES (4460, 325, '18А', NULL, NULL);
INSERT INTO point VALUES (4461, 352, '44', NULL, NULL);
INSERT INTO point VALUES (4462, 180, '42', NULL, NULL);
INSERT INTO point VALUES (4463, 239, '1', NULL, NULL);
INSERT INTO point VALUES (4464, 277, '15', NULL, NULL);
INSERT INTO point VALUES (4465, 580, '3', NULL, NULL);
INSERT INTO point VALUES (4466, 564, '3', NULL, NULL);
INSERT INTO point VALUES (4467, 520, '4А', NULL, NULL);
INSERT INTO point VALUES (4468, 462, '5', NULL, NULL);
INSERT INTO point VALUES (4469, 202, '6А', NULL, NULL);
INSERT INTO point VALUES (4470, 375, '50', NULL, NULL);
INSERT INTO point VALUES (4471, 20, '13', NULL, NULL);
INSERT INTO point VALUES (4472, 334, '39', NULL, NULL);
INSERT INTO point VALUES (4473, 152, '5', NULL, NULL);
INSERT INTO point VALUES (4474, 475, '5', NULL, NULL);
INSERT INTO point VALUES (4475, 536, '5', NULL, NULL);
INSERT INTO point VALUES (4476, 425, '34', NULL, NULL);
INSERT INTO point VALUES (4477, 98, '8А', NULL, NULL);
INSERT INTO point VALUES (4478, 223, '29А', NULL, NULL);
INSERT INTO point VALUES (4479, 479, '1', NULL, NULL);
INSERT INTO point VALUES (4480, 521, '12', NULL, NULL);
INSERT INTO point VALUES (4481, 250, '46', NULL, NULL);
INSERT INTO point VALUES (4482, 67, '120', NULL, NULL);
INSERT INTO point VALUES (4483, 51, '44', NULL, NULL);
INSERT INTO point VALUES (4484, 180, '35А', NULL, NULL);
INSERT INTO point VALUES (4485, 411, '18', NULL, NULL);
INSERT INTO point VALUES (4486, 496, '16', NULL, NULL);
INSERT INTO point VALUES (4487, 74, '3', NULL, NULL);
INSERT INTO point VALUES (4488, 464, '30Б', NULL, NULL);
INSERT INTO point VALUES (4489, 488, '12', NULL, NULL);
INSERT INTO point VALUES (4490, 465, '78', NULL, NULL);
INSERT INTO point VALUES (4491, 449, '13Б', NULL, NULL);
INSERT INTO point VALUES (4492, 465, '64', NULL, NULL);
INSERT INTO point VALUES (4493, 389, '55', NULL, NULL);
INSERT INTO point VALUES (4494, 548, '51', NULL, NULL);
INSERT INTO point VALUES (4495, 530, '6', NULL, NULL);
INSERT INTO point VALUES (4496, 376, '43', NULL, NULL);
INSERT INTO point VALUES (4497, 352, '24', NULL, NULL);
INSERT INTO point VALUES (4498, 265, '30', NULL, NULL);
INSERT INTO point VALUES (4499, 340, '14', NULL, NULL);
INSERT INTO point VALUES (4500, 369, '39', NULL, NULL);
INSERT INTO point VALUES (4501, 462, '2', NULL, NULL);
INSERT INTO point VALUES (4502, 15, '10', NULL, NULL);
INSERT INTO point VALUES (4503, 571, '27', NULL, NULL);
INSERT INTO point VALUES (4504, 110, '48А', NULL, NULL);
INSERT INTO point VALUES (4505, 152, '2', NULL, NULL);
INSERT INTO point VALUES (4506, 536, '2', NULL, NULL);
INSERT INTO point VALUES (4507, 653, '43', NULL, NULL);
INSERT INTO point VALUES (4508, 477, '28', NULL, NULL);
INSERT INTO point VALUES (4509, 201, '38', NULL, NULL);
INSERT INTO point VALUES (4510, 285, '9', NULL, NULL);
INSERT INTO point VALUES (4511, 425, '74', NULL, NULL);
INSERT INTO point VALUES (4512, 256, '7', NULL, NULL);
INSERT INTO point VALUES (4513, 67, '55', NULL, NULL);
INSERT INTO point VALUES (4514, 169, '4', NULL, NULL);
INSERT INTO point VALUES (4515, 87, '4', NULL, NULL);
INSERT INTO point VALUES (4516, 405, '19', NULL, NULL);
INSERT INTO point VALUES (4517, 497, '9', NULL, NULL);
INSERT INTO point VALUES (4518, 589, '70', NULL, NULL);
INSERT INTO point VALUES (4519, 487, '49', NULL, NULL);
INSERT INTO point VALUES (4520, 270, '23', NULL, NULL);
INSERT INTO point VALUES (4521, 696, '18/3', NULL, NULL);
INSERT INTO point VALUES (4522, 282, '16', NULL, NULL);
INSERT INTO point VALUES (4523, 496, '121А', NULL, NULL);
INSERT INTO point VALUES (4524, 649, '34', NULL, NULL);
INSERT INTO point VALUES (4525, 8, '17', NULL, NULL);
INSERT INTO point VALUES (4526, 483, '17', NULL, NULL);
INSERT INTO point VALUES (4527, 433, '14', NULL, NULL);
INSERT INTO point VALUES (4528, 531, '67', NULL, NULL);
INSERT INTO point VALUES (4529, 600, '32', NULL, NULL);
INSERT INTO point VALUES (4530, 670, '45', NULL, NULL);
INSERT INTO point VALUES (4531, 643, '82', NULL, NULL);
INSERT INTO point VALUES (4532, 560, '45', NULL, NULL);
INSERT INTO point VALUES (4533, 536, '29', NULL, NULL);
INSERT INTO point VALUES (4534, 542, '17', NULL, NULL);
INSERT INTO point VALUES (4535, 315, '13', NULL, NULL);
INSERT INTO point VALUES (4536, 325, '20', NULL, NULL);
INSERT INTO point VALUES (4537, 389, '17/3', NULL, NULL);
INSERT INTO point VALUES (4538, 455, '8А', NULL, NULL);
INSERT INTO point VALUES (4539, 81, '18/6', NULL, NULL);
INSERT INTO point VALUES (4540, 329, '26А', NULL, NULL);
INSERT INTO point VALUES (4541, 678, '18', NULL, NULL);
INSERT INTO point VALUES (4542, 137, '19', NULL, NULL);
INSERT INTO point VALUES (4543, 589, '68', NULL, NULL);
INSERT INTO point VALUES (4544, 30, '17', NULL, NULL);
INSERT INTO point VALUES (4545, 629, '16', NULL, NULL);
INSERT INTO point VALUES (4546, 158, '15', NULL, NULL);
INSERT INTO point VALUES (4547, 458, '16', NULL, NULL);
INSERT INTO point VALUES (4548, 443, '7', NULL, NULL);
INSERT INTO point VALUES (4549, 560, '96', NULL, NULL);
INSERT INTO point VALUES (4550, 390, '12', NULL, NULL);
INSERT INTO point VALUES (4551, 285, '26', NULL, NULL);
INSERT INTO point VALUES (4552, 447, '24', NULL, NULL);
INSERT INTO point VALUES (4553, 184, '7', NULL, NULL);
INSERT INTO point VALUES (4554, 24, '7', NULL, NULL);
INSERT INTO point VALUES (4555, 62, '12', NULL, NULL);
INSERT INTO point VALUES (4556, 618, '11', NULL, NULL);
INSERT INTO point VALUES (4557, 504, '8', NULL, NULL);
INSERT INTO point VALUES (4558, 100, '15', NULL, NULL);
INSERT INTO point VALUES (4559, 175, '3', NULL, NULL);
INSERT INTO point VALUES (4560, 376, '22А', NULL, NULL);
INSERT INTO point VALUES (4561, 620, '9', NULL, NULL);
INSERT INTO point VALUES (4562, 539, '31', NULL, NULL);
INSERT INTO point VALUES (4563, 634, '4', NULL, NULL);
INSERT INTO point VALUES (4564, 495, '11', NULL, NULL);
INSERT INTO point VALUES (4565, 376, '56', NULL, NULL);
INSERT INTO point VALUES (4566, 78, '15', NULL, NULL);
INSERT INTO point VALUES (4567, 305, '3', NULL, NULL);
INSERT INTO point VALUES (4568, 183, '52/13', NULL, NULL);
INSERT INTO point VALUES (4569, 397, '9', NULL, NULL);
INSERT INTO point VALUES (4570, 191, '22', NULL, NULL);
INSERT INTO point VALUES (4571, 137, '1', NULL, NULL);
INSERT INTO point VALUES (4572, 37, '2', NULL, NULL);
INSERT INTO point VALUES (4573, 389, '15А', NULL, NULL);
INSERT INTO point VALUES (4574, 496, '45А', NULL, NULL);
INSERT INTO point VALUES (4575, 277, '86', NULL, NULL);
INSERT INTO point VALUES (4576, 451, '50', NULL, NULL);
INSERT INTO point VALUES (4577, 49, '36', NULL, NULL);
INSERT INTO point VALUES (4578, 278, '7', NULL, NULL);
INSERT INTO point VALUES (4579, 531, '17', NULL, NULL);
INSERT INTO point VALUES (4580, 473, '37', NULL, NULL);
INSERT INTO point VALUES (4581, 252, '16', NULL, NULL);
INSERT INTO point VALUES (4582, 303, '6А', NULL, NULL);
INSERT INTO point VALUES (4583, 525, '11', NULL, NULL);
INSERT INTO point VALUES (4584, 687, '29', NULL, NULL);
INSERT INTO point VALUES (4585, 425, '35', NULL, NULL);
INSERT INTO point VALUES (4586, 374, '5', NULL, NULL);
INSERT INTO point VALUES (4587, 20, '1', NULL, NULL);
INSERT INTO point VALUES (4588, 27, '26', NULL, NULL);
INSERT INTO point VALUES (4589, 52, '7', NULL, NULL);
INSERT INTO point VALUES (4590, 51, '42', NULL, NULL);
INSERT INTO point VALUES (4591, 184, '25', NULL, NULL);
INSERT INTO point VALUES (4592, 2, '22', NULL, NULL);
INSERT INTO point VALUES (4593, 53, '74', NULL, NULL);
INSERT INTO point VALUES (4594, 521, '5А', NULL, NULL);
INSERT INTO point VALUES (4595, 693, '24', NULL, NULL);
INSERT INTO point VALUES (4596, 265, '46', NULL, NULL);
INSERT INTO point VALUES (4597, 429, '10', NULL, NULL);
INSERT INTO point VALUES (4598, 326, '2', NULL, NULL);
INSERT INTO point VALUES (4599, 170, '10/2', NULL, NULL);
INSERT INTO point VALUES (4600, 144, '27А', NULL, NULL);
INSERT INTO point VALUES (4601, 98, '8', NULL, NULL);
INSERT INTO point VALUES (4602, 582, '22', NULL, NULL);
INSERT INTO point VALUES (4603, 600, '7', NULL, NULL);
INSERT INTO point VALUES (4604, 292, '9', NULL, NULL);
INSERT INTO point VALUES (4605, 674, '8', NULL, NULL);
INSERT INTO point VALUES (4606, 389, '48/2', NULL, NULL);
INSERT INTO point VALUES (4607, 172, '2', NULL, NULL);
INSERT INTO point VALUES (4608, 531, '39', NULL, NULL);
INSERT INTO point VALUES (4609, 278, '25', NULL, NULL);
INSERT INTO point VALUES (4610, 601, '137', NULL, NULL);
INSERT INTO point VALUES (4611, 375, '4', NULL, NULL);
INSERT INTO point VALUES (4612, 180, '44', NULL, NULL);
INSERT INTO point VALUES (4613, 49, '18', NULL, NULL);
INSERT INTO point VALUES (4614, 227, '11', NULL, NULL);
INSERT INTO point VALUES (4615, 171, '11', NULL, NULL);
INSERT INTO point VALUES (4616, 352, '42', NULL, NULL);
INSERT INTO point VALUES (4617, 531, '102', NULL, NULL);
INSERT INTO point VALUES (4618, 295, '13', NULL, NULL);
INSERT INTO point VALUES (4619, 250, '30', NULL, NULL);
INSERT INTO point VALUES (4620, 27, '9', NULL, NULL);
INSERT INTO point VALUES (4621, 639, '12', NULL, NULL);
INSERT INTO point VALUES (4622, 23, '11', NULL, NULL);
INSERT INTO point VALUES (4623, 170, '2', NULL, NULL);
INSERT INTO point VALUES (4624, 604, '198', NULL, NULL);
INSERT INTO point VALUES (4625, 274, '14', NULL, NULL);
INSERT INTO point VALUES (4626, 277, '98', NULL, NULL);
INSERT INTO point VALUES (4627, 389, '36А', NULL, NULL);
INSERT INTO point VALUES (4628, 236, '54', NULL, NULL);
INSERT INTO point VALUES (4629, 496, '84', NULL, NULL);
INSERT INTO point VALUES (4630, 427, '32', NULL, NULL);
INSERT INTO point VALUES (4631, 483, '39', NULL, NULL);
INSERT INTO point VALUES (4632, 496, '48Б', NULL, NULL);
INSERT INTO point VALUES (4633, 108, '10', NULL, NULL);
INSERT INTO point VALUES (4634, 325, '16', NULL, NULL);
INSERT INTO point VALUES (4635, 654, '21', NULL, NULL);
INSERT INTO point VALUES (4636, 294, '236', NULL, NULL);
INSERT INTO point VALUES (4637, 425, '78/1', NULL, NULL);
INSERT INTO point VALUES (4638, 304, '37', NULL, NULL);
INSERT INTO point VALUES (4639, 19, '21', NULL, NULL);
INSERT INTO point VALUES (4640, 231, '4', NULL, NULL);
INSERT INTO point VALUES (4641, 530, '10', NULL, NULL);
INSERT INTO point VALUES (4642, 280, '147', NULL, NULL);
INSERT INTO point VALUES (4643, 469, '18', NULL, NULL);
INSERT INTO point VALUES (4644, 335, '9', NULL, NULL);
INSERT INTO point VALUES (4645, 459, '14', NULL, NULL);
INSERT INTO point VALUES (4646, 282, '20', NULL, NULL);
INSERT INTO point VALUES (4647, 180, '33', NULL, NULL);
INSERT INTO point VALUES (4648, 670, '3', NULL, NULL);
INSERT INTO point VALUES (4649, 545, '27/5', NULL, NULL);
INSERT INTO point VALUES (4650, 542, '39', NULL, NULL);
INSERT INTO point VALUES (4651, 415, '51', NULL, NULL);
INSERT INTO point VALUES (4652, 15, '6', NULL, NULL);
INSERT INTO point VALUES (4653, 44, '20', NULL, NULL);
INSERT INTO point VALUES (4654, 354, '14', NULL, NULL);
INSERT INTO point VALUES (4655, 548, '18А', NULL, NULL);
INSERT INTO point VALUES (4656, 531, '32', NULL, NULL);
INSERT INTO point VALUES (4657, 496, '69А', NULL, NULL);
INSERT INTO point VALUES (4658, 183, '32/1', NULL, NULL);
INSERT INTO point VALUES (4659, 469, '20А', NULL, NULL);
INSERT INTO point VALUES (4660, 548, '67/2', NULL, NULL);
INSERT INTO point VALUES (4661, 277, '66', NULL, NULL);
INSERT INTO point VALUES (4662, 435, '67', NULL, NULL);
INSERT INTO point VALUES (4663, 438, '21', NULL, NULL);
INSERT INTO point VALUES (4664, 209, '4', NULL, NULL);
INSERT INTO point VALUES (4665, 193, '11', NULL, NULL);
INSERT INTO point VALUES (4666, 429, '12', NULL, NULL);
INSERT INTO point VALUES (4667, 48, '5', NULL, NULL);
INSERT INTO point VALUES (4668, 146, '11', NULL, NULL);
INSERT INTO point VALUES (4669, 501, '14', NULL, NULL);
INSERT INTO point VALUES (4670, 483, '25', NULL, NULL);
INSERT INTO point VALUES (4671, 215, '63', NULL, NULL);
INSERT INTO point VALUES (4672, 431, '42А', NULL, NULL);
INSERT INTO point VALUES (4673, 183, '16А', NULL, NULL);
INSERT INTO point VALUES (4674, 536, '27', NULL, NULL);
INSERT INTO point VALUES (4675, 88, '1', NULL, NULL);
INSERT INTO point VALUES (4676, 245, '13', NULL, NULL);
INSERT INTO point VALUES (4677, 100, '33', NULL, NULL);
INSERT INTO point VALUES (4678, 201, '46', NULL, NULL);
INSERT INTO point VALUES (4679, 174, '20', NULL, NULL);
INSERT INTO point VALUES (4680, 521, '6', NULL, NULL);
INSERT INTO point VALUES (4681, 111, '16', NULL, NULL);
INSERT INTO point VALUES (4682, 562, '16', NULL, NULL);
INSERT INTO point VALUES (4683, 585, '32', NULL, NULL);
INSERT INTO point VALUES (4684, 157, '26', NULL, NULL);
INSERT INTO point VALUES (4685, 531, '25', NULL, NULL);
INSERT INTO point VALUES (4686, 435, '17', NULL, NULL);
INSERT INTO point VALUES (4687, 139, '25/1', NULL, NULL);
INSERT INTO point VALUES (4688, 339, '4', NULL, NULL);
INSERT INTO point VALUES (4689, 465, '18', NULL, NULL);
INSERT INTO point VALUES (4690, 639, '10', NULL, NULL);
INSERT INTO point VALUES (4691, 478, '53', NULL, NULL);
INSERT INTO point VALUES (4692, 236, '30', NULL, NULL);
INSERT INTO point VALUES (4693, 48, '2', NULL, NULL);
INSERT INTO point VALUES (4694, 356, '2', NULL, NULL);
INSERT INTO point VALUES (4695, 250, '54', NULL, NULL);
INSERT INTO point VALUES (4696, 531, '204', NULL, NULL);
INSERT INTO point VALUES (4697, 373, '7А', NULL, NULL);
INSERT INTO point VALUES (4698, 480, '28', NULL, NULL);
INSERT INTO point VALUES (4699, 108, '12', NULL, NULL);
INSERT INTO point VALUES (4700, 600, '17', NULL, NULL);
INSERT INTO point VALUES (4701, 694, '3', NULL, NULL);
INSERT INTO point VALUES (4702, 415, '16', NULL, NULL);
INSERT INTO point VALUES (4703, 184, '39', NULL, NULL);
INSERT INTO point VALUES (4704, 52, '17', NULL, NULL);
INSERT INTO point VALUES (4705, 88, '19', NULL, NULL);
INSERT INTO point VALUES (4706, 235, '37', NULL, NULL);
INSERT INTO point VALUES (4707, 483, '32', NULL, NULL);
INSERT INTO point VALUES (4708, 119, '4', NULL, NULL);
INSERT INTO point VALUES (4709, 157, '9', NULL, NULL);
INSERT INTO point VALUES (4710, 81, '14', NULL, NULL);
INSERT INTO point VALUES (4711, 455, '34', NULL, NULL);
INSERT INTO point VALUES (4712, 57, '18', NULL, NULL);
INSERT INTO point VALUES (4713, 636, '28', NULL, NULL);
INSERT INTO point VALUES (4714, 100, '44', NULL, NULL);
INSERT INTO point VALUES (4715, 503, '9', NULL, NULL);
INSERT INTO point VALUES (4716, 303, '28', NULL, NULL);
INSERT INTO point VALUES (4717, 294, '252', NULL, NULL);
INSERT INTO point VALUES (4718, 374, '63', NULL, NULL);
INSERT INTO point VALUES (4719, 178, '11', NULL, NULL);
INSERT INTO point VALUES (4720, 465, '36', NULL, NULL);
INSERT INTO point VALUES (4721, 278, '17', NULL, NULL);
INSERT INTO point VALUES (4722, 435, '39', NULL, NULL);
INSERT INTO point VALUES (4723, 183, '52/4', NULL, NULL);
INSERT INTO point VALUES (4724, 531, '7', NULL, NULL);
INSERT INTO point VALUES (4725, 632, '5', NULL, NULL);
INSERT INTO point VALUES (4726, 277, '42', NULL, NULL);
INSERT INTO point VALUES (4727, 600, '39', NULL, NULL);
INSERT INTO point VALUES (4728, 290, '8', NULL, NULL);
INSERT INTO point VALUES (4729, 236, '40', NULL, NULL);
INSERT INTO point VALUES (4730, 653, '57', NULL, NULL);
INSERT INTO point VALUES (4731, 223, '23', NULL, NULL);
INSERT INTO point VALUES (4732, 61, '19', NULL, NULL);
INSERT INTO point VALUES (4733, 180, '15', NULL, NULL);
INSERT INTO point VALUES (4734, 250, '72А', NULL, NULL);
INSERT INTO point VALUES (4735, 546, '17', NULL, NULL);
INSERT INTO point VALUES (4736, 280, '85', NULL, NULL);
INSERT INTO point VALUES (4737, 213, '4', NULL, NULL);
INSERT INTO point VALUES (4738, 318, '10', NULL, NULL);
INSERT INTO point VALUES (4739, 531, '186', NULL, NULL);
INSERT INTO point VALUES (4740, 652, '3', NULL, NULL);
INSERT INTO point VALUES (4741, 184, '17', NULL, NULL);
INSERT INTO point VALUES (4742, 294, '166', NULL, NULL);
INSERT INTO point VALUES (4743, 265, '38', NULL, NULL);
INSERT INTO point VALUES (4744, 408, '18', NULL, NULL);
INSERT INTO point VALUES (4745, 535, '3', NULL, NULL);
INSERT INTO point VALUES (4746, 30, '7', NULL, NULL);
INSERT INTO point VALUES (4747, 565, '3', NULL, NULL);
INSERT INTO point VALUES (4748, 658, '14', NULL, NULL);
INSERT INTO point VALUES (4749, 658, '29В', NULL, NULL);
INSERT INTO point VALUES (4750, 445, '9', NULL, NULL);
INSERT INTO point VALUES (4751, 384, '1/2', NULL, NULL);
INSERT INTO point VALUES (4752, 250, '41', NULL, NULL);
INSERT INTO point VALUES (4753, 542, '7', NULL, NULL);
INSERT INTO point VALUES (4754, 478, '51', NULL, NULL);
INSERT INTO point VALUES (4755, 572, '22', NULL, NULL);
INSERT INTO point VALUES (4756, 688, '14', NULL, NULL);
INSERT INTO point VALUES (4757, 693, '15', NULL, NULL);
INSERT INTO point VALUES (4758, 370, '15', NULL, NULL);
INSERT INTO point VALUES (4759, 26, '27А', NULL, NULL);
INSERT INTO point VALUES (4760, 390, '10', NULL, NULL);
INSERT INTO point VALUES (4761, 291, '1', NULL, NULL);
INSERT INTO point VALUES (4762, 364, '22', NULL, NULL);
INSERT INTO point VALUES (4763, 560, '82', NULL, NULL);
INSERT INTO point VALUES (4764, 468, '28', NULL, NULL);
INSERT INTO point VALUES (4765, 692, '3', NULL, NULL);
INSERT INTO point VALUES (4766, 183, '52/18', NULL, NULL);
INSERT INTO point VALUES (4767, 347, '13', NULL, NULL);
INSERT INTO point VALUES (4768, 299, '21', NULL, NULL);
INSERT INTO point VALUES (4769, 111, '20', NULL, NULL);
INSERT INTO point VALUES (4770, 562, '20', NULL, NULL);
INSERT INTO point VALUES (4771, 464, '37', NULL, NULL);
INSERT INTO point VALUES (4772, 604, '181', NULL, NULL);
INSERT INTO point VALUES (4773, 67, '116А', NULL, NULL);
INSERT INTO point VALUES (4774, 112, '17а', NULL, NULL);
INSERT INTO point VALUES (4775, 44, '16', NULL, NULL);
INSERT INTO point VALUES (4776, 329, '21', NULL, NULL);
INSERT INTO point VALUES (4777, 308, '23', NULL, NULL);
INSERT INTO point VALUES (4778, 323, '13', NULL, NULL);
INSERT INTO point VALUES (4779, 483, '7', NULL, NULL);
INSERT INTO point VALUES (4780, 558, '14', NULL, NULL);
INSERT INTO point VALUES (4781, 358, '3', NULL, NULL);
INSERT INTO point VALUES (4782, 67, '110', NULL, NULL);
INSERT INTO point VALUES (4783, 92, '16', NULL, NULL);
INSERT INTO point VALUES (4784, 573, '1', NULL, NULL);
INSERT INTO point VALUES (4785, 259, '1', NULL, NULL);
INSERT INTO point VALUES (4786, 222, '16', NULL, NULL);
INSERT INTO point VALUES (4787, 269, '14', NULL, NULL);
INSERT INTO point VALUES (4788, 131, '14А/2', NULL, NULL);
INSERT INTO point VALUES (4789, 67, '118', NULL, NULL);
INSERT INTO point VALUES (4790, 494, '12', NULL, NULL);
INSERT INTO point VALUES (4791, 610, '39', NULL, NULL);
INSERT INTO point VALUES (4792, 372, '19', NULL, NULL);
INSERT INTO point VALUES (4793, 389, '14', NULL, NULL);
INSERT INTO point VALUES (4794, 285, '18', NULL, NULL);
INSERT INTO point VALUES (4795, 374, '119', NULL, NULL);
INSERT INTO point VALUES (4796, 141, '15', NULL, NULL);
INSERT INTO point VALUES (4797, 29, '7', NULL, NULL);
INSERT INTO point VALUES (4798, 682, '19', NULL, NULL);
INSERT INTO point VALUES (4799, 178, '4', NULL, NULL);
INSERT INTO point VALUES (4800, 170, '27', NULL, NULL);
INSERT INTO point VALUES (4801, 395, '5', NULL, NULL);
INSERT INTO point VALUES (4802, 464, '68', NULL, NULL);
INSERT INTO point VALUES (4803, 76, '32', NULL, NULL);
INSERT INTO point VALUES (4804, 334, '32', NULL, NULL);
INSERT INTO point VALUES (4805, 205, '14', NULL, NULL);
INSERT INTO point VALUES (4806, 210, '22', NULL, NULL);
INSERT INTO point VALUES (4807, 245, '1', NULL, NULL);
INSERT INTO point VALUES (4808, 88, '13', NULL, NULL);
INSERT INTO point VALUES (4809, 496, '51', NULL, NULL);
INSERT INTO point VALUES (4810, 374, '92', NULL, NULL);
INSERT INTO point VALUES (4811, 183, '16', NULL, NULL);
INSERT INTO point VALUES (4812, 45, '1', NULL, NULL);
INSERT INTO point VALUES (4813, 523, '4', NULL, NULL);
INSERT INTO point VALUES (4814, 213, '11', NULL, NULL);
INSERT INTO point VALUES (4815, 464, '32/3', NULL, NULL);
INSERT INTO point VALUES (4816, 418, '15', NULL, NULL);
INSERT INTO point VALUES (4817, 460, '5', NULL, NULL);
INSERT INTO point VALUES (4818, 294, '248', NULL, NULL);
INSERT INTO point VALUES (4819, 125, '3', NULL, NULL);
INSERT INTO point VALUES (4820, 521, '10', NULL, NULL);
INSERT INTO point VALUES (4821, 236, '46', NULL, NULL);
INSERT INTO point VALUES (4822, 394, '15', NULL, NULL);
INSERT INTO point VALUES (4823, 554, '107', NULL, NULL);
INSERT INTO point VALUES (4824, 643, '28', NULL, NULL);
INSERT INTO point VALUES (4825, 294, '130', NULL, NULL);
INSERT INTO point VALUES (4826, 111, '16А', NULL, NULL);
INSERT INTO point VALUES (4827, 548, '16', NULL, NULL);
INSERT INTO point VALUES (4828, 117, '29', NULL, NULL);
INSERT INTO point VALUES (4829, 682, '1', NULL, NULL);
INSERT INTO point VALUES (4830, 338, '7', NULL, NULL);
INSERT INTO point VALUES (4831, 604, '37', NULL, NULL);
INSERT INTO point VALUES (4832, 639, '6', NULL, NULL);
INSERT INTO point VALUES (4833, 47, '3', NULL, NULL);
INSERT INTO point VALUES (4834, 566, '36/2', NULL, NULL);
INSERT INTO point VALUES (4835, 595, '3', NULL, NULL);
INSERT INTO point VALUES (4836, 236, '130', NULL, NULL);
INSERT INTO point VALUES (4837, 334, '25', NULL, NULL);
INSERT INTO point VALUES (4838, 384, '18', NULL, NULL);
INSERT INTO point VALUES (4839, 649, '8', NULL, NULL);
INSERT INTO point VALUES (4840, 100, '42', NULL, NULL);
INSERT INTO point VALUES (4841, 245, '19', NULL, NULL);
INSERT INTO point VALUES (4842, 277, '21А', NULL, NULL);
INSERT INTO point VALUES (4843, 664, '26/2', NULL, NULL);
INSERT INTO point VALUES (4844, 144, '16', NULL, NULL);
INSERT INTO point VALUES (4845, 48, '2А', NULL, NULL);
INSERT INTO point VALUES (4846, 552, '7', NULL, NULL);
INSERT INTO point VALUES (4847, 172, '27', NULL, NULL);
INSERT INTO point VALUES (4848, 303, '45', NULL, NULL);
INSERT INTO point VALUES (4849, 531, '140', NULL, NULL);
INSERT INTO point VALUES (4850, 376, '57', NULL, NULL);
INSERT INTO point VALUES (4851, 15, '12', NULL, NULL);
INSERT INTO point VALUES (4852, 192, '7', NULL, NULL);
INSERT INTO point VALUES (4853, 419, '3', NULL, NULL);
INSERT INTO point VALUES (4854, 435, '69', NULL, NULL);
INSERT INTO point VALUES (4855, 675, '14', NULL, NULL);
INSERT INTO point VALUES (4856, 460, '2', NULL, NULL);
INSERT INTO point VALUES (4857, 565, '28', NULL, NULL);
INSERT INTO point VALUES (4858, 250, '38', NULL, NULL);
INSERT INTO point VALUES (4859, 496, '90', NULL, NULL);
INSERT INTO point VALUES (4860, 188, '8', NULL, NULL);
INSERT INTO point VALUES (4861, 393, '2', NULL, NULL);
INSERT INTO point VALUES (4862, 606, '11', NULL, NULL);
INSERT INTO point VALUES (4863, 441, '2', NULL, NULL);
INSERT INTO point VALUES (4864, 166, '16', NULL, NULL);
INSERT INTO point VALUES (4865, 451, '100', NULL, NULL);
INSERT INTO point VALUES (4866, 376, '12', NULL, NULL);
INSERT INTO point VALUES (4867, 279, '55', NULL, NULL);
INSERT INTO point VALUES (4868, 235, '68', NULL, NULL);
INSERT INTO point VALUES (4869, 201, '40', NULL, NULL);
INSERT INTO point VALUES (4870, 384, '36', NULL, NULL);
INSERT INTO point VALUES (4871, 76, '7', NULL, NULL);
INSERT INTO point VALUES (4872, 406, '7', NULL, NULL);
INSERT INTO point VALUES (4873, 67, '178', NULL, NULL);
INSERT INTO point VALUES (4874, 193, '4', NULL, NULL);
INSERT INTO point VALUES (4875, 59, '48', NULL, NULL);
INSERT INTO point VALUES (4876, 48, '29', NULL, NULL);
INSERT INTO point VALUES (4877, 473, '49', NULL, NULL);
INSERT INTO point VALUES (4878, 334, '7', NULL, NULL);
INSERT INTO point VALUES (4879, 347, '19', NULL, NULL);
INSERT INTO point VALUES (4880, 607, '32', NULL, NULL);
INSERT INTO point VALUES (4881, 496, '53', NULL, NULL);
INSERT INTO point VALUES (4882, 12, '88/1', NULL, NULL);
INSERT INTO point VALUES (4883, 660, '15', NULL, NULL);
INSERT INTO point VALUES (4884, 202, '28', NULL, NULL);
INSERT INTO point VALUES (4885, 548, '20', NULL, NULL);
INSERT INTO point VALUES (4886, 552, '25', NULL, NULL);
INSERT INTO point VALUES (4887, 292, '18', NULL, NULL);
INSERT INTO point VALUES (4888, 261, '13/2', NULL, NULL);
INSERT INTO point VALUES (4889, 215, '119', NULL, NULL);
INSERT INTO point VALUES (4890, 531, '127', NULL, NULL);
INSERT INTO point VALUES (4891, 303, '3', NULL, NULL);
INSERT INTO point VALUES (4892, 183, '52/5', NULL, NULL);
INSERT INTO point VALUES (4893, 546, '15/2', NULL, NULL);
INSERT INTO point VALUES (4894, 49, '9', NULL, NULL);
INSERT INTO point VALUES (4895, 277, '44', NULL, NULL);
INSERT INTO point VALUES (4896, 480, '45', NULL, NULL);
INSERT INTO point VALUES (4897, 260, '8', NULL, NULL);
INSERT INTO point VALUES (4898, 215, '27', NULL, NULL);
INSERT INTO point VALUES (4899, 376, '58', NULL, NULL);
INSERT INTO point VALUES (4900, 338, '32', NULL, NULL);
INSERT INTO point VALUES (4901, 390, '6', NULL, NULL);
INSERT INTO point VALUES (4902, 277, '24', NULL, NULL);
INSERT INTO point VALUES (4903, 183, '20', NULL, NULL);
INSERT INTO point VALUES (4904, 27, '18', NULL, NULL);
INSERT INTO point VALUES (4905, 168, '31', NULL, NULL);
INSERT INTO point VALUES (4906, 610, '17', NULL, NULL);
INSERT INTO point VALUES (4907, 570, '12', NULL, NULL);
INSERT INTO point VALUES (4908, 339, '11', NULL, NULL);
INSERT INTO point VALUES (4909, 280, '57', NULL, NULL);
INSERT INTO point VALUES (4910, 272, '8', NULL, NULL);
INSERT INTO point VALUES (4911, 353, '55', NULL, NULL);
INSERT INTO point VALUES (4912, 223, '8', NULL, NULL);
INSERT INTO point VALUES (4913, 100, '104/2', NULL, NULL);
INSERT INTO point VALUES (4914, 62, '6', NULL, NULL);
INSERT INTO point VALUES (4915, 441, '5', NULL, NULL);
INSERT INTO point VALUES (4916, 628, '37', NULL, NULL);
INSERT INTO point VALUES (4917, 393, '5', NULL, NULL);
INSERT INTO point VALUES (4918, 150, '30', NULL, NULL);
INSERT INTO point VALUES (4919, 50, '21', NULL, NULL);
INSERT INTO point VALUES (4920, 9, '65', NULL, NULL);
INSERT INTO point VALUES (4921, 100, '83А', NULL, NULL);
INSERT INTO point VALUES (4922, 61, '13', NULL, NULL);
INSERT INTO point VALUES (4923, 692, '28', NULL, NULL);
INSERT INTO point VALUES (4924, 119, '11', NULL, NULL);
INSERT INTO point VALUES (4925, 552, '32', NULL, NULL);
INSERT INTO point VALUES (4926, 575, '3', NULL, NULL);
INSERT INTO point VALUES (4927, 250, '47', NULL, NULL);
INSERT INTO point VALUES (4928, 607, '25', NULL, NULL);
INSERT INTO point VALUES (4929, 447, '86', NULL, NULL);
INSERT INTO point VALUES (4930, 189, '3', NULL, NULL);
INSERT INTO point VALUES (4931, 469, '9', NULL, NULL);
INSERT INTO point VALUES (4932, 335, '18', NULL, NULL);
INSERT INTO point VALUES (4933, 386, '7', NULL, NULL);
INSERT INTO point VALUES (4934, 304, '49', NULL, NULL);
INSERT INTO point VALUES (4935, 571, '29', NULL, NULL);
INSERT INTO point VALUES (4936, 203, '21', NULL, NULL);
INSERT INTO point VALUES (4937, 447, '77', NULL, NULL);
INSERT INTO point VALUES (4938, 478, '57', NULL, NULL);
INSERT INTO point VALUES (4939, 53, '32', NULL, NULL);
INSERT INTO point VALUES (4940, 386, '8А', NULL, NULL);
INSERT INTO point VALUES (4941, 451, '68', NULL, NULL);
INSERT INTO point VALUES (4942, 250, '84/1', NULL, NULL);
INSERT INTO point VALUES (4943, 55, '36', NULL, NULL);
INSERT INTO point VALUES (4944, 267, '1', NULL, NULL);
INSERT INTO point VALUES (4945, 594, '24', NULL, NULL);
INSERT INTO point VALUES (4946, 8, '8', NULL, NULL);
INSERT INTO point VALUES (4947, 483, '8', NULL, NULL);
INSERT INTO point VALUES (4948, 280, '113', NULL, NULL);
INSERT INTO point VALUES (4949, 465, '63', NULL, NULL);
INSERT INTO point VALUES (4950, 390, '20', NULL, NULL);
INSERT INTO point VALUES (4951, 183, '6', NULL, NULL);
INSERT INTO point VALUES (4952, 374, '113А', NULL, NULL);
INSERT INTO point VALUES (4953, 15, '27А', NULL, NULL);
INSERT INTO point VALUES (4954, 236, '79', NULL, NULL);
INSERT INTO point VALUES (4955, 473, '4', NULL, NULL);
INSERT INTO point VALUES (4956, 329, '30', NULL, NULL);
INSERT INTO point VALUES (4957, 27, '27', NULL, NULL);
INSERT INTO point VALUES (4958, 425, '7', NULL, NULL);
INSERT INTO point VALUES (4959, 111, '10', NULL, NULL);
INSERT INTO point VALUES (4960, 277, '76', NULL, NULL);
INSERT INTO point VALUES (4961, 562, '10', NULL, NULL);
INSERT INTO point VALUES (4962, 75, '8/1', NULL, NULL);
INSERT INTO point VALUES (4963, 644, '3', NULL, NULL);
INSERT INTO point VALUES (4964, 349, '40', NULL, NULL);
INSERT INTO point VALUES (4965, 542, '8', NULL, NULL);
INSERT INTO point VALUES (4966, 205, '13', NULL, NULL);
INSERT INTO point VALUES (4967, 252, '12', NULL, NULL);
INSERT INTO point VALUES (4968, 435, '35', NULL, NULL);
INSERT INTO point VALUES (4969, 654, '41', NULL, NULL);
INSERT INTO point VALUES (4970, 375, '37', NULL, NULL);
INSERT INTO point VALUES (4971, 114, '13', NULL, NULL);
INSERT INTO point VALUES (4972, 299, '30', NULL, NULL);
INSERT INTO point VALUES (4973, 496, '45Б', NULL, NULL);
INSERT INTO point VALUES (4974, 654, '31', NULL, NULL);
INSERT INTO point VALUES (4975, 236, '48', NULL, NULL);
INSERT INTO point VALUES (4976, 389, '13', NULL, NULL);
INSERT INTO point VALUES (4977, 601, '55', NULL, NULL);
INSERT INTO point VALUES (4978, 675, '13', NULL, NULL);
INSERT INTO point VALUES (4979, 2, '24', NULL, NULL);
INSERT INTO point VALUES (4980, 303, '60', NULL, NULL);
INSERT INTO point VALUES (4981, 572, '15', NULL, NULL);
INSERT INTO point VALUES (4982, 489, '3', NULL, NULL);
INSERT INTO point VALUES (4983, 294, '254', NULL, NULL);
INSERT INTO point VALUES (4984, 138, '5', NULL, NULL);
INSERT INTO point VALUES (4985, 693, '22', NULL, NULL);
INSERT INTO point VALUES (4986, 30, '8', NULL, NULL);
INSERT INTO point VALUES (4987, 200, '2', NULL, NULL);
INSERT INTO point VALUES (4988, 653, '51', NULL, NULL);
INSERT INTO point VALUES (4989, 364, '15', NULL, NULL);
INSERT INTO point VALUES (4990, 112, '35', NULL, NULL);
INSERT INTO point VALUES (4991, 585, '8', NULL, NULL);
INSERT INTO point VALUES (4992, 546, '15/204а', NULL, NULL);
INSERT INTO point VALUES (4993, 130, '6', NULL, NULL);
INSERT INTO point VALUES (4994, 639, '16', NULL, NULL);
INSERT INTO point VALUES (4995, 411, '29', NULL, NULL);
INSERT INTO point VALUES (4996, 283, '6', NULL, NULL);
INSERT INTO point VALUES (4997, 601, '73', NULL, NULL);
INSERT INTO point VALUES (4998, 460, '9', NULL, NULL);
INSERT INTO point VALUES (4999, 635, '18', NULL, NULL);
INSERT INTO point VALUES (5000, 325, '12', NULL, NULL);
INSERT INTO point VALUES (5001, 594, '44', NULL, NULL);
INSERT INTO point VALUES (5002, 9, '61', NULL, NULL);
INSERT INTO point VALUES (5003, 431, '6А', NULL, NULL);
INSERT INTO point VALUES (5004, 582, '24', NULL, NULL);
INSERT INTO point VALUES (5005, 183, '52/8', NULL, NULL);
INSERT INTO point VALUES (5006, 294, '222', NULL, NULL);
INSERT INTO point VALUES (5007, 37, '18', NULL, NULL);
INSERT INTO point VALUES (5008, 374, '94/2', NULL, NULL);
INSERT INTO point VALUES (5009, 539, '21', NULL, NULL);
INSERT INTO point VALUES (5010, 393, '9', NULL, NULL);
INSERT INTO point VALUES (5011, 131, '20/3', NULL, NULL);
INSERT INTO point VALUES (5012, 384, '27', NULL, NULL);
INSERT INTO point VALUES (5013, 639, '20', NULL, NULL);
INSERT INTO point VALUES (5014, 374, '95', NULL, NULL);
INSERT INTO point VALUES (5015, 607, '23', NULL, NULL);
INSERT INTO point VALUES (5016, 388, '6', NULL, NULL);
INSERT INTO point VALUES (5017, 496, '85', NULL, NULL);
INSERT INTO point VALUES (5018, 566, '4', NULL, NULL);
INSERT INTO point VALUES (5019, 191, '33', NULL, NULL);
INSERT INTO point VALUES (5020, 552, '37/1', NULL, NULL);
INSERT INTO point VALUES (5021, 87, '37', NULL, NULL);
INSERT INTO point VALUES (5022, 59, '46', NULL, NULL);
INSERT INTO point VALUES (5023, 578, '4', NULL, NULL);
INSERT INTO point VALUES (5024, 169, '37', NULL, NULL);
INSERT INTO point VALUES (5025, 100, '83Б', NULL, NULL);
INSERT INTO point VALUES (5026, 425, '32', NULL, NULL);
INSERT INTO point VALUES (5027, 131, '22-1', NULL, NULL);
INSERT INTO point VALUES (5028, 191, '24', NULL, NULL);
INSERT INTO point VALUES (5029, 415, '43', NULL, NULL);
INSERT INTO point VALUES (5030, 386, '6/1', NULL, NULL);
INSERT INTO point VALUES (5031, 674, '17', NULL, NULL);
INSERT INTO point VALUES (5032, 166, '6', NULL, NULL);
INSERT INTO point VALUES (5033, 282, '12', NULL, NULL);
INSERT INTO point VALUES (5034, 49, '2', NULL, NULL);
INSERT INTO point VALUES (5035, 236, '21', NULL, NULL);
INSERT INTO point VALUES (5036, 333, '4', NULL, NULL);
INSERT INTO point VALUES (5037, 271, '8А', NULL, NULL);
INSERT INTO point VALUES (5038, 98, '17', NULL, NULL);
INSERT INTO point VALUES (5039, 172, '18', NULL, NULL);
INSERT INTO point VALUES (5040, 512, '4/6', NULL, NULL);
INSERT INTO point VALUES (5041, 201, '83', NULL, NULL);
INSERT INTO point VALUES (5042, 497, '27', NULL, NULL);
INSERT INTO point VALUES (5043, 170, '18', NULL, NULL);
INSERT INTO point VALUES (5044, 26, '1А', NULL, NULL);
INSERT INTO point VALUES (5045, 329, '40', NULL, NULL);
INSERT INTO point VALUES (5046, 44, '10', NULL, NULL);
INSERT INTO point VALUES (5047, 294, '21', NULL, NULL);
INSERT INTO point VALUES (5048, 291, '14', NULL, NULL);
INSERT INTO point VALUES (5049, 366, '11', NULL, NULL);
INSERT INTO point VALUES (5050, 688, '1', NULL, NULL);
INSERT INTO point VALUES (5051, 184, '35', NULL, NULL);
INSERT INTO point VALUES (5052, 92, '10', NULL, NULL);
INSERT INTO point VALUES (5053, 617, '3', NULL, NULL);
INSERT INTO point VALUES (5054, 496, '72Б', NULL, NULL);
INSERT INTO point VALUES (5055, 464, '72', NULL, NULL);
INSERT INTO point VALUES (5056, 458, '58', NULL, NULL);
INSERT INTO point VALUES (5057, 67, '1', NULL, NULL);
INSERT INTO point VALUES (5058, 191, '44', NULL, NULL);
INSERT INTO point VALUES (5059, 653, '53', NULL, NULL);
INSERT INTO point VALUES (5060, 560, '62', NULL, NULL);
INSERT INTO point VALUES (5061, 49, '5', NULL, NULL);
INSERT INTO point VALUES (5062, 629, '12', NULL, NULL);
INSERT INTO point VALUES (5063, 186, '17', NULL, NULL);
INSERT INTO point VALUES (5064, 458, '12', NULL, NULL);
INSERT INTO point VALUES (5065, 390, '16', NULL, NULL);
INSERT INTO point VALUES (5066, 269, '1', NULL, NULL);
INSERT INTO point VALUES (5067, 467, '15', NULL, NULL);
INSERT INTO point VALUES (5068, 658, '19', NULL, NULL);
INSERT INTO point VALUES (5069, 435, '22Г', NULL, NULL);
INSERT INTO point VALUES (5070, 469, '2', NULL, NULL);
INSERT INTO point VALUES (5071, 120, '42', NULL, NULL);
INSERT INTO point VALUES (5072, 451, '58А', NULL, NULL);
INSERT INTO point VALUES (5073, 534, '1', NULL, NULL);
INSERT INTO point VALUES (5074, 437, '3', NULL, NULL);
INSERT INTO point VALUES (5075, 548, '14/1', NULL, NULL);
INSERT INTO point VALUES (5076, 643, '75', NULL, NULL);
INSERT INTO point VALUES (5077, 183, '10', NULL, NULL);
INSERT INTO point VALUES (5078, 654, '47', NULL, NULL);
INSERT INTO point VALUES (5079, 67, '52', NULL, NULL);
INSERT INTO point VALUES (5080, 566, '11', NULL, NULL);
INSERT INTO point VALUES (5081, 67, '176', NULL, NULL);
INSERT INTO point VALUES (5082, 283, '14/1', NULL, NULL);
INSERT INTO point VALUES (5083, 389, '1', NULL, NULL);
INSERT INTO point VALUES (5084, 280, '51', NULL, NULL);
INSERT INTO point VALUES (5085, 203, '30', NULL, NULL);
INSERT INTO point VALUES (5086, 48, '26', NULL, NULL);
INSERT INTO point VALUES (5087, 615, '8/1', NULL, NULL);
INSERT INTO point VALUES (5088, 521, '16', NULL, NULL);
INSERT INTO point VALUES (5089, 386, '8', NULL, NULL);
INSERT INTO point VALUES (5090, 111, '6', NULL, NULL);
INSERT INTO point VALUES (5091, 562, '6', NULL, NULL);
INSERT INTO point VALUES (5092, 201, '79', NULL, NULL);
INSERT INTO point VALUES (5093, 325, '1А', NULL, NULL);
INSERT INTO point VALUES (5094, 496, '12', NULL, NULL);
INSERT INTO point VALUES (5095, 294, '216', NULL, NULL);
INSERT INTO point VALUES (5096, 506, '8', NULL, NULL);
INSERT INTO point VALUES (5097, 396, '24/1', NULL, NULL);
INSERT INTO point VALUES (5098, 531, '23', NULL, NULL);
INSERT INTO point VALUES (5099, 503, '5', NULL, NULL);
INSERT INTO point VALUES (5100, 582, '42', NULL, NULL);
INSERT INTO point VALUES (5101, 213, '49', NULL, NULL);
INSERT INTO point VALUES (5102, 157, '5', NULL, NULL);
INSERT INTO point VALUES (5103, 67, '152', NULL, NULL);
INSERT INTO point VALUES (5104, 264, '12', NULL, NULL);
INSERT INTO point VALUES (5105, 376, '53', NULL, NULL);
INSERT INTO point VALUES (5106, 223, '7', NULL, NULL);
INSERT INTO point VALUES (5107, 560, '59', NULL, NULL);
INSERT INTO point VALUES (5108, 59, '40', NULL, NULL);
INSERT INTO point VALUES (5109, 267, '13', NULL, NULL);
INSERT INTO point VALUES (5110, 352, '22', NULL, NULL);
INSERT INTO point VALUES (5111, 170, '12/2', NULL, NULL);
INSERT INTO point VALUES (5112, 366, '4', NULL, NULL);
INSERT INTO point VALUES (5113, 483, '23', NULL, NULL);
INSERT INTO point VALUES (5114, 48, '9', NULL, NULL);
INSERT INTO point VALUES (5115, 374, '103', NULL, NULL);
INSERT INTO point VALUES (5116, 270, '17', NULL, NULL);
INSERT INTO point VALUES (5117, 166, '43', NULL, NULL);
INSERT INTO point VALUES (5118, 114, '19', NULL, NULL);
INSERT INTO point VALUES (5119, 687, '18', NULL, NULL);
INSERT INTO point VALUES (5120, 496, '49А', NULL, NULL);
INSERT INTO point VALUES (5121, 260, '7', NULL, NULL);
INSERT INTO point VALUES (5122, 205, '19', NULL, NULL);
INSERT INTO point VALUES (5123, 594, '42', NULL, NULL);
INSERT INTO point VALUES (5124, 548, '10', NULL, NULL);
INSERT INTO point VALUES (5125, 157, '2', NULL, NULL);
INSERT INTO point VALUES (5126, 112, '34', NULL, NULL);
INSERT INTO point VALUES (5127, 696, '41', NULL, NULL);
INSERT INTO point VALUES (5128, 304, '50', NULL, NULL);
INSERT INTO point VALUES (5129, 283, '10', NULL, NULL);
INSERT INTO point VALUES (5130, 130, '10', NULL, NULL);
INSERT INTO point VALUES (5131, 188, '7', NULL, NULL);
INSERT INTO point VALUES (5132, 488, '16', NULL, NULL);
INSERT INTO point VALUES (5133, 76, '8', NULL, NULL);
INSERT INTO point VALUES (5134, 406, '8', NULL, NULL);
INSERT INTO point VALUES (5135, 496, '91А', NULL, NULL);
INSERT INTO point VALUES (5136, 696, '31', NULL, NULL);
INSERT INTO point VALUES (5137, 388, '10', NULL, NULL);
INSERT INTO point VALUES (5138, 601, '120', NULL, NULL);
INSERT INTO point VALUES (5139, 377, '4', NULL, NULL);
INSERT INTO point VALUES (5140, 531, '106', NULL, NULL);
INSERT INTO point VALUES (5141, 210, '15', NULL, NULL);
INSERT INTO point VALUES (5142, 664, '12Г', NULL, NULL);
INSERT INTO point VALUES (5143, 525, '37', NULL, NULL);
INSERT INTO point VALUES (5144, 473, '11', NULL, NULL);
INSERT INTO point VALUES (5145, 416, '4', NULL, NULL);
INSERT INTO point VALUES (5146, 120, '33', NULL, NULL);
INSERT INTO point VALUES (5147, 192, '8', NULL, NULL);
INSERT INTO point VALUES (5148, 338, '8', NULL, NULL);
INSERT INTO point VALUES (5149, 624, '1А', NULL, NULL);
INSERT INTO point VALUES (5150, 271, '8', NULL, NULL);
INSERT INTO point VALUES (5151, 245, '71', NULL, NULL);
INSERT INTO point VALUES (5152, 166, '10', NULL, NULL);
INSERT INTO point VALUES (5153, 26, '12', NULL, NULL);
INSERT INTO point VALUES (5154, 465, '92', NULL, NULL);
INSERT INTO point VALUES (5155, 376, '51', NULL, NULL);
INSERT INTO point VALUES (5156, 32, '4', NULL, NULL);
INSERT INTO point VALUES (5157, 359, '12', NULL, NULL);
INSERT INTO point VALUES (5158, 449, '3', NULL, NULL);
INSERT INTO point VALUES (5159, 541, '12', NULL, NULL);
INSERT INTO point VALUES (5160, 269, '13', NULL, NULL);
INSERT INTO point VALUES (5161, 607, '8', NULL, NULL);
INSERT INTO point VALUES (5162, 236, '83', NULL, NULL);
INSERT INTO point VALUES (5163, 310, '24', NULL, NULL);
INSERT INTO point VALUES (5164, 44, '6', NULL, NULL);
INSERT INTO point VALUES (5165, 117, '26', NULL, NULL);
INSERT INTO point VALUES (5166, 120, '44', NULL, NULL);
INSERT INTO point VALUES (5167, 181, '50', NULL, NULL);
INSERT INTO point VALUES (5168, 323, '14', NULL, NULL);
INSERT INTO point VALUES (5169, 92, '6', NULL, NULL);
INSERT INTO point VALUES (5170, 569, '41', NULL, NULL);
INSERT INTO point VALUES (5171, 496, '57', NULL, NULL);
INSERT INTO point VALUES (5172, 25, '3', NULL, NULL);
INSERT INTO point VALUES (5173, 236, '59Г', NULL, NULL);
INSERT INTO point VALUES (5174, 183, '43', NULL, NULL);
INSERT INTO point VALUES (5175, 531, '256', NULL, NULL);
INSERT INTO point VALUES (5176, 502, '22', NULL, NULL);
INSERT INTO point VALUES (5177, 67, '13', NULL, NULL);
INSERT INTO point VALUES (5178, 152, '18', NULL, NULL);
INSERT INTO point VALUES (5179, 643, '60', NULL, NULL);
INSERT INTO point VALUES (5180, 451, '37', NULL, NULL);
INSERT INTO point VALUES (5181, 304, '11', NULL, NULL);
INSERT INTO point VALUES (5182, 294, '19А', NULL, NULL);
INSERT INTO point VALUES (5183, 223, '25', NULL, NULL);
INSERT INTO point VALUES (5184, 425, '42', NULL, NULL);
INSERT INTO point VALUES (5185, 157, '3', NULL, NULL);
INSERT INTO point VALUES (5186, 310, '32', NULL, NULL);
INSERT INTO point VALUES (5187, 213, '21', NULL, NULL);
INSERT INTO point VALUES (5188, 250, '37', NULL, NULL);
INSERT INTO point VALUES (5189, 236, '108', NULL, NULL);
INSERT INTO point VALUES (5190, 601, '94', NULL, NULL);
INSERT INTO point VALUES (5191, 531, '76', NULL, NULL);
INSERT INTO point VALUES (5192, 566, '40', NULL, NULL);
INSERT INTO point VALUES (5193, 405, '10', NULL, NULL);
INSERT INTO point VALUES (5194, 180, '34', NULL, NULL);
INSERT INTO point VALUES (5195, 235, '54', NULL, NULL);
INSERT INTO point VALUES (5196, 570, '13', NULL, NULL);
INSERT INTO point VALUES (5197, 494, '1', NULL, NULL);
INSERT INTO point VALUES (5198, 561, '27', NULL, NULL);
INSERT INTO point VALUES (5199, 137, '10', NULL, NULL);
INSERT INTO point VALUES (5200, 120, '25', NULL, NULL);
INSERT INTO point VALUES (5201, 425, '35А', NULL, NULL);
INSERT INTO point VALUES (5202, 464, '31', NULL, NULL);
INSERT INTO point VALUES (5203, 259, '12', NULL, NULL);
INSERT INTO point VALUES (5204, 629, '14', NULL, NULL);
INSERT INTO point VALUES (5205, 464, '41', NULL, NULL);
INSERT INTO point VALUES (5206, 598, '31А', NULL, NULL);
INSERT INTO point VALUES (5207, 294, '210', NULL, NULL);
INSERT INTO point VALUES (5208, 458, '14', NULL, NULL);
INSERT INTO point VALUES (5209, 276, '2', NULL, NULL);
INSERT INTO point VALUES (5210, 694, '9', NULL, NULL);
INSERT INTO point VALUES (5211, 209, '13А', NULL, NULL);
INSERT INTO point VALUES (5212, 304, '30', NULL, NULL);
INSERT INTO point VALUES (5213, 512, '4/4', NULL, NULL);
INSERT INTO point VALUES (5214, 223, '33', NULL, NULL);
INSERT INTO point VALUES (5215, 447, '81', NULL, NULL);
INSERT INTO point VALUES (5216, 100, '106', NULL, NULL);
INSERT INTO point VALUES (5217, 315, '6', NULL, NULL);
INSERT INTO point VALUES (5218, 433, '16', NULL, NULL);
INSERT INTO point VALUES (5219, 245, '85', NULL, NULL);
INSERT INTO point VALUES (5220, 473, '30', NULL, NULL);
INSERT INTO point VALUES (5221, 329, '4', NULL, NULL);
INSERT INTO point VALUES (5222, 477, '18', NULL, NULL);
INSERT INTO point VALUES (5223, 181, '40', NULL, NULL);
INSERT INTO point VALUES (5224, 40, '8', NULL, NULL);
INSERT INTO point VALUES (5225, 182, '8', NULL, NULL);
INSERT INTO point VALUES (5226, 294, '108', NULL, NULL);
INSERT INTO point VALUES (5227, 643, '80', NULL, NULL);
INSERT INTO point VALUES (5228, 282, '14', NULL, NULL);
INSERT INTO point VALUES (5229, 120, '32', NULL, NULL);
INSERT INTO point VALUES (5230, 496, '89А', NULL, NULL);
INSERT INTO point VALUES (5231, 437, '2', NULL, NULL);
INSERT INTO point VALUES (5232, 277, '8', NULL, NULL);
INSERT INTO point VALUES (5233, 110, '47', NULL, NULL);
INSERT INTO point VALUES (5234, 643, '9', NULL, NULL);
INSERT INTO point VALUES (5235, 617, '29', NULL, NULL);
INSERT INTO point VALUES (5236, 515, '13', NULL, NULL);
INSERT INTO point VALUES (5237, 248, '11', NULL, NULL);
INSERT INTO point VALUES (5238, 210, '17', NULL, NULL);
INSERT INTO point VALUES (5239, 176, '63', NULL, NULL);
INSERT INTO point VALUES (5240, 496, '50А', NULL, NULL);
INSERT INTO point VALUES (5241, 563, '22А', NULL, NULL);
INSERT INTO point VALUES (5242, 458, '71', NULL, NULL);
INSERT INTO point VALUES (5243, 601, '66А', NULL, NULL);
INSERT INTO point VALUES (5244, 425, '66', NULL, NULL);
INSERT INTO point VALUES (5245, 649, '44', NULL, NULL);
INSERT INTO point VALUES (5246, 181, '30', NULL, NULL);
INSERT INTO point VALUES (5247, 429, '19', NULL, NULL);
INSERT INTO point VALUES (5248, 349, '4', NULL, NULL);
INSERT INTO point VALUES (5249, 376, '52', NULL, NULL);
INSERT INTO point VALUES (5250, 451, '60Г', NULL, NULL);
INSERT INTO point VALUES (5251, 477, '36', NULL, NULL);
INSERT INTO point VALUES (5252, 415, '73', NULL, NULL);
INSERT INTO point VALUES (5253, 323, '85', NULL, NULL);
INSERT INTO point VALUES (5254, 67, '90', NULL, NULL);
INSERT INTO point VALUES (5255, 373, '79', NULL, NULL);
INSERT INTO point VALUES (5256, 316, '11', NULL, NULL);
INSERT INTO point VALUES (5257, 15, '13', NULL, NULL);
INSERT INTO point VALUES (5258, 202, '26', NULL, NULL);
INSERT INTO point VALUES (5259, 464, '54', NULL, NULL);
INSERT INTO point VALUES (5260, 295, '6', NULL, NULL);
INSERT INTO point VALUES (5261, 236, '92А', NULL, NULL);
INSERT INTO point VALUES (5262, 523, '19А', NULL, NULL);
INSERT INTO point VALUES (5263, 325, '14', NULL, NULL);
INSERT INTO point VALUES (5264, 601, '104', NULL, NULL);
INSERT INTO point VALUES (5265, 235, '31', NULL, NULL);
INSERT INTO point VALUES (5266, 374, '23/6', NULL, NULL);
INSERT INTO point VALUES (5267, 59, '50', NULL, NULL);
INSERT INTO point VALUES (5268, 226, '8', NULL, NULL);
INSERT INTO point VALUES (5269, 692, '9', NULL, NULL);
INSERT INTO point VALUES (5270, 433, '20', NULL, NULL);
INSERT INTO point VALUES (5271, 464, '34/1', NULL, NULL);
INSERT INTO point VALUES (5272, 13, '8', NULL, NULL);
INSERT INTO point VALUES (5273, 67, '53', NULL, NULL);
INSERT INTO point VALUES (5274, 695, '22', NULL, NULL);
INSERT INTO point VALUES (5275, 220, '4А', NULL, NULL);
INSERT INTO point VALUES (5276, 415, '3А', NULL, NULL);
INSERT INTO point VALUES (5277, 374, '125', NULL, NULL);
INSERT INTO point VALUES (5278, 429, '1', NULL, NULL);
INSERT INTO point VALUES (5279, 415, '55', NULL, NULL);
INSERT INTO point VALUES (5280, 464, '28А', NULL, NULL);
INSERT INTO point VALUES (5281, 566, '30', NULL, NULL);
INSERT INTO point VALUES (5282, 535, '9', NULL, NULL);
INSERT INTO point VALUES (5283, 100, '38А', NULL, NULL);
INSERT INTO point VALUES (5284, 565, '9', NULL, NULL);
INSERT INTO point VALUES (5285, 78, '23', NULL, NULL);
INSERT INTO point VALUES (5286, 665, '7', NULL, NULL);
INSERT INTO point VALUES (5287, 183, '43Б', NULL, NULL);
INSERT INTO point VALUES (5288, 518, '10', NULL, NULL);
INSERT INTO point VALUES (5289, 556, '30', NULL, NULL);
INSERT INTO point VALUES (5290, 25, '5', NULL, NULL);
INSERT INTO point VALUES (5291, 120, '7', NULL, NULL);
INSERT INTO point VALUES (5292, 563, '6', NULL, NULL);
INSERT INTO point VALUES (5293, 509, '18', NULL, NULL);
INSERT INTO point VALUES (5294, 100, '23', NULL, NULL);
INSERT INTO point VALUES (5295, 232, '26', NULL, NULL);
INSERT INTO point VALUES (5296, 50, '11', NULL, NULL);
INSERT INTO point VALUES (5297, 692, '26', NULL, NULL);
INSERT INTO point VALUES (5298, 434, '38', NULL, NULL);
INSERT INTO point VALUES (5299, 304, '40', NULL, NULL);
INSERT INTO point VALUES (5300, 489, '29', NULL, NULL);
INSERT INTO point VALUES (5301, 496, '73А', NULL, NULL);
INSERT INTO point VALUES (5302, 252, '14', NULL, NULL);
INSERT INTO point VALUES (5303, 339, '21', NULL, NULL);
INSERT INTO point VALUES (5304, 643, '78', NULL, NULL);
INSERT INTO point VALUES (5305, 643, '64', NULL, NULL);
INSERT INTO point VALUES (5306, 663, '27', NULL, NULL);
INSERT INTO point VALUES (5307, 465, '82', NULL, NULL);
INSERT INTO point VALUES (5308, 49, '45', NULL, NULL);
INSERT INTO point VALUES (5309, 186, '15', NULL, NULL);
INSERT INTO point VALUES (5310, 447, '74', NULL, NULL);
INSERT INTO point VALUES (5311, 323, '12', NULL, NULL);
INSERT INTO point VALUES (5312, 352, '34', NULL, NULL);
INSERT INTO point VALUES (5313, 643, '65', NULL, NULL);
INSERT INTO point VALUES (5314, 2, '7', NULL, NULL);
INSERT INTO point VALUES (5315, 180, '29А', NULL, NULL);
INSERT INTO point VALUES (5316, 494, '13', NULL, NULL);
INSERT INTO point VALUES (5317, 541, '14', NULL, NULL);
INSERT INTO point VALUES (5318, 276, '2А', NULL, NULL);
INSERT INTO point VALUES (5319, 515, '19', NULL, NULL);
INSERT INTO point VALUES (5320, 405, '6', NULL, NULL);
INSERT INTO point VALUES (5321, 628, '31', NULL, NULL);
INSERT INTO point VALUES (5322, 316, '4', NULL, NULL);
INSERT INTO point VALUES (5323, 539, '37-70', NULL, NULL);
INSERT INTO point VALUES (5324, 467, '17', NULL, NULL);
INSERT INTO point VALUES (5325, 371, '3', NULL, NULL);
INSERT INTO point VALUES (5326, 419, '9', NULL, NULL);
INSERT INTO point VALUES (5327, 146, '21', NULL, NULL);
INSERT INTO point VALUES (5328, 180, '35', NULL, NULL);
INSERT INTO point VALUES (5329, 51, '34', NULL, NULL);
INSERT INTO point VALUES (5330, 191, '25', NULL, NULL);
INSERT INTO point VALUES (5331, 489, '2', NULL, NULL);
INSERT INTO point VALUES (5332, 618, '13/2', NULL, NULL);
INSERT INTO point VALUES (5333, 636, '9', NULL, NULL);
INSERT INTO point VALUES (5334, 277, '23', NULL, NULL);
INSERT INTO point VALUES (5335, 137, '6', NULL, NULL);
INSERT INTO point VALUES (5336, 425, '44', NULL, NULL);
INSERT INTO point VALUES (5337, 12, '104', NULL, NULL);
INSERT INTO point VALUES (5338, 47, '9', NULL, NULL);
INSERT INTO point VALUES (5339, 435, '22', NULL, NULL);
INSERT INTO point VALUES (5340, 40, '23', NULL, NULL);
INSERT INTO point VALUES (5341, 582, '7', NULL, NULL);
INSERT INTO point VALUES (5342, 277, '9А', NULL, NULL);
INSERT INTO point VALUES (5343, 277, '98А', NULL, NULL);
INSERT INTO point VALUES (5344, 133, '16', NULL, NULL);
INSERT INTO point VALUES (5345, 396, '20', NULL, NULL);
INSERT INTO point VALUES (5346, 200, '3', NULL, NULL);
INSERT INTO point VALUES (5347, 303, '64', NULL, NULL);
INSERT INTO point VALUES (5348, 236, '91', NULL, NULL);
INSERT INTO point VALUES (5349, 373, '83', NULL, NULL);
INSERT INTO point VALUES (5350, 672, '15', NULL, NULL);
INSERT INTO point VALUES (5351, 203, '4', NULL, NULL);
INSERT INTO point VALUES (5352, 304, '46', NULL, NULL);
INSERT INTO point VALUES (5353, 98, '15', NULL, NULL);
INSERT INTO point VALUES (5354, 692, '20А', NULL, NULL);
INSERT INTO point VALUES (5355, 480, '26', NULL, NULL);
INSERT INTO point VALUES (5356, 376, '1', NULL, NULL);
INSERT INTO point VALUES (5357, 180, '12А', NULL, NULL);
INSERT INTO point VALUES (5358, 515, '1', NULL, NULL);
INSERT INTO point VALUES (5359, 25, '29', NULL, NULL);
INSERT INTO point VALUES (5360, 315, '10', NULL, NULL);
INSERT INTO point VALUES (5361, 382, '6', NULL, NULL);
INSERT INTO point VALUES (5362, 110, '31', NULL, NULL);
INSERT INTO point VALUES (5363, 531, '206', NULL, NULL);
INSERT INTO point VALUES (5364, 425, '33', NULL, NULL);
INSERT INTO point VALUES (5365, 572, '39', NULL, NULL);
INSERT INTO point VALUES (5366, 191, '32', NULL, NULL);
INSERT INTO point VALUES (5367, 451, '8Б', NULL, NULL);
INSERT INTO point VALUES (5368, 389, '53', NULL, NULL);
INSERT INTO point VALUES (5369, 294, '198', NULL, NULL);
INSERT INTO point VALUES (5370, 182, '8А', NULL, NULL);
INSERT INTO point VALUES (5371, 464, '38', NULL, NULL);
INSERT INTO point VALUES (5372, 138, '3', NULL, NULL);
INSERT INTO point VALUES (5373, 489, '5', NULL, NULL);
INSERT INTO point VALUES (5374, 496, '71', NULL, NULL);
INSERT INTO point VALUES (5375, 340, '20', NULL, NULL);
INSERT INTO point VALUES (5376, 294, '238', NULL, NULL);
INSERT INTO point VALUES (5377, 614, '7', NULL, NULL);
INSERT INTO point VALUES (5378, 373, '7 ка', NULL, NULL);
INSERT INTO point VALUES (5379, 26, '14', NULL, NULL);
INSERT INTO point VALUES (5380, 530, '13', NULL, NULL);
INSERT INTO point VALUES (5381, 394, '34', NULL, NULL);
INSERT INTO point VALUES (5382, 183, '55', NULL, NULL);
INSERT INTO point VALUES (5383, 594, '25', NULL, NULL);
INSERT INTO point VALUES (5384, 362, '36', NULL, NULL);
INSERT INTO point VALUES (5385, 277, '106', NULL, NULL);
INSERT INTO point VALUES (5386, 189, '9', NULL, NULL);
INSERT INTO point VALUES (5387, 469, '3', NULL, NULL);
INSERT INTO point VALUES (5388, 372, '12', NULL, NULL);
INSERT INTO point VALUES (5389, 560, '18', NULL, NULL);
INSERT INTO point VALUES (5390, 235, '47', NULL, NULL);
INSERT INTO point VALUES (5391, 523, '21', NULL, NULL);
INSERT INTO point VALUES (5392, 78, '8', NULL, NULL);
INSERT INTO point VALUES (5393, 340, '16', NULL, NULL);
INSERT INTO point VALUES (5394, 472, '27', NULL, NULL);
INSERT INTO point VALUES (5395, 59, '4', NULL, NULL);
INSERT INTO point VALUES (5396, 234, '43', NULL, NULL);
INSERT INTO point VALUES (5397, 554, '87', NULL, NULL);
INSERT INTO point VALUES (5398, 219, '14/2', NULL, NULL);
INSERT INTO point VALUES (5399, 649, '42', NULL, NULL);
INSERT INTO point VALUES (5400, 15, '1', NULL, NULL);
INSERT INTO point VALUES (5401, 572, '17', NULL, NULL);
INSERT INTO point VALUES (5402, 295, '10', NULL, NULL);
INSERT INTO point VALUES (5403, 434, '31', NULL, NULL);
INSERT INTO point VALUES (5404, 582, '32', NULL, NULL);
INSERT INTO point VALUES (5405, 161, '27', NULL, NULL);
INSERT INTO point VALUES (5406, 53, '44', NULL, NULL);
INSERT INTO point VALUES (5407, 191, '30А', NULL, NULL);
INSERT INTO point VALUES (5408, 548, '73', NULL, NULL);
INSERT INTO point VALUES (5409, 158, '8', NULL, NULL);
INSERT INTO point VALUES (5410, 617, '2', NULL, NULL);
INSERT INTO point VALUES (5411, 601, '6', NULL, NULL);
INSERT INTO point VALUES (5412, 566, '46', NULL, NULL);
INSERT INTO point VALUES (5413, 364, '17', NULL, NULL);
INSERT INTO point VALUES (5414, 594, '32', NULL, NULL);
INSERT INTO point VALUES (5415, 496, '88', NULL, NULL);
INSERT INTO point VALUES (5416, 20, '6', NULL, NULL);
INSERT INTO point VALUES (5417, 447, '12А', NULL, NULL);
INSERT INTO point VALUES (5418, 427, '22', NULL, NULL);
INSERT INTO point VALUES (5419, 496, '14', NULL, NULL);
INSERT INTO point VALUES (5420, 468, '26', NULL, NULL);
INSERT INTO point VALUES (5421, 518, '6', NULL, NULL);
INSERT INTO point VALUES (5422, 601, '56', NULL, NULL);
INSERT INTO point VALUES (5423, 269, '11/1', NULL, NULL);
INSERT INTO point VALUES (5424, 49, '3', NULL, NULL);
INSERT INTO point VALUES (5425, 133, '20', NULL, NULL);
INSERT INTO point VALUES (5426, 279, '20', NULL, NULL);
INSERT INTO point VALUES (5427, 110, '2Б', NULL, NULL);
INSERT INTO point VALUES (5428, 264, '14', NULL, NULL);
INSERT INTO point VALUES (5429, 15, '19', NULL, NULL);
INSERT INTO point VALUES (5430, 176, '27', NULL, NULL);
INSERT INTO point VALUES (5431, 299, '11', NULL, NULL);
INSERT INTO point VALUES (5432, 207, '4', NULL, NULL);
INSERT INTO point VALUES (5433, 617, '5', NULL, NULL);
INSERT INTO point VALUES (5434, 548, '55', NULL, NULL);
INSERT INTO point VALUES (5435, 389, '51', NULL, NULL);
INSERT INTO point VALUES (5436, 601, '147', NULL, NULL);
INSERT INTO point VALUES (5437, 563, '10', NULL, NULL);
INSERT INTO point VALUES (5438, 411, '28', NULL, NULL);
INSERT INTO point VALUES (5439, 262, '3Б', NULL, NULL);
INSERT INTO point VALUES (5440, 429, '13', NULL, NULL);
INSERT INTO point VALUES (5441, 235, '38', NULL, NULL);
INSERT INTO point VALUES (5442, 199, '12', NULL, NULL);
INSERT INTO point VALUES (5443, 181, '46', NULL, NULL);
INSERT INTO point VALUES (5444, 294, '49', NULL, NULL);
INSERT INTO point VALUES (5445, 431, '27', NULL, NULL);
INSERT INTO point VALUES (5446, 421, '20', NULL, NULL);
INSERT INTO point VALUES (5447, 602, '41', NULL, NULL);
INSERT INTO point VALUES (5448, 67, '12', NULL, NULL);
INSERT INTO point VALUES (5449, 120, '8', NULL, NULL);
INSERT INTO point VALUES (5450, 631, '43', NULL, NULL);
INSERT INTO point VALUES (5451, 236, '4', NULL, NULL);
INSERT INTO point VALUES (5452, 277, '32', NULL, NULL);
INSERT INTO point VALUES (5453, 231, '2Б', NULL, NULL);
INSERT INTO point VALUES (5454, 338, '24', NULL, NULL);
INSERT INTO point VALUES (5455, 137, '16', NULL, NULL);
INSERT INTO point VALUES (5456, 451, '47', NULL, NULL);
INSERT INTO point VALUES (5457, 20, '20', NULL, NULL);
INSERT INTO point VALUES (5458, 372, '40/1', NULL, NULL);
INSERT INTO point VALUES (5459, 419, '2', NULL, NULL);
INSERT INTO point VALUES (5460, 53, '76', NULL, NULL);
INSERT INTO point VALUES (5461, 150, '11', NULL, NULL);
INSERT INTO point VALUES (5462, 460, '3', NULL, NULL);
INSERT INTO point VALUES (5463, 220, '22/1', NULL, NULL);
INSERT INTO point VALUES (5464, 464, '26А', NULL, NULL);
INSERT INTO point VALUES (5465, 688, '12', NULL, NULL);
INSERT INTO point VALUES (5466, 48, '28', NULL, NULL);
INSERT INTO point VALUES (5467, 67, '112', NULL, NULL);
INSERT INTO point VALUES (5468, 496, '52', NULL, NULL);
INSERT INTO point VALUES (5469, 242, '4', NULL, NULL);
INSERT INTO point VALUES (5470, 212, '36', NULL, NULL);
INSERT INTO point VALUES (5471, 595, '2', NULL, NULL);
INSERT INTO point VALUES (5472, 552, '24', NULL, NULL);
INSERT INTO point VALUES (5473, 373, '75-16', NULL, NULL);
INSERT INTO point VALUES (5474, 489, '9', NULL, NULL);
INSERT INTO point VALUES (5475, 395, '3', NULL, NULL);
INSERT INTO point VALUES (5476, 496, '152', NULL, NULL);
INSERT INTO point VALUES (5477, 610, '15', NULL, NULL);
INSERT INTO point VALUES (5478, 494, '14', NULL, NULL);
INSERT INTO point VALUES (5479, 541, '13', NULL, NULL);
INSERT INTO point VALUES (5480, 560, '74А', NULL, NULL);
INSERT INTO point VALUES (5481, 458, '1', NULL, NULL);
INSERT INTO point VALUES (5482, 539, '4', NULL, NULL);
INSERT INTO point VALUES (5483, 567, '3', NULL, NULL);
INSERT INTO point VALUES (5484, 421, '6', NULL, NULL);
INSERT INTO point VALUES (5485, 176, '18', NULL, NULL);
INSERT INTO point VALUES (5486, 629, '1', NULL, NULL);
INSERT INTO point VALUES (5487, 558, '12', NULL, NULL);
INSERT INTO point VALUES (5488, 405, '16', NULL, NULL);
INSERT INTO point VALUES (5489, 277, '25', NULL, NULL);
INSERT INTO point VALUES (5490, 548, '45/5', NULL, NULL);
INSERT INTO point VALUES (5491, 660, '17', NULL, NULL);
INSERT INTO point VALUES (5492, 26, '13', NULL, NULL);
INSERT INTO point VALUES (5493, 419, '5', NULL, NULL);
INSERT INTO point VALUES (5494, 670, '27', NULL, NULL);
INSERT INTO point VALUES (5495, 191, '23', NULL, NULL);
INSERT INTO point VALUES (5496, 598, '18', NULL, NULL);
INSERT INTO point VALUES (5497, 40, '25', NULL, NULL);
INSERT INTO point VALUES (5498, 87, '41', NULL, NULL);
INSERT INTO point VALUES (5499, 472, '18', NULL, NULL);
INSERT INTO point VALUES (5500, 226, '7', NULL, NULL);
INSERT INTO point VALUES (5501, 87, '31', NULL, NULL);
INSERT INTO point VALUES (5502, 169, '31', NULL, NULL);
INSERT INTO point VALUES (5503, 626, '19', NULL, NULL);
INSERT INTO point VALUES (5504, 125, '2', NULL, NULL);
INSERT INTO point VALUES (5505, 464, '28В', NULL, NULL);
INSERT INTO point VALUES (5506, 607, '33', NULL, NULL);
INSERT INTO point VALUES (5507, 13, '7', NULL, NULL);
INSERT INTO point VALUES (5508, 458, '137', NULL, NULL);
INSERT INTO point VALUES (5509, 387, '24', NULL, NULL);
INSERT INTO point VALUES (5510, 161, '18', NULL, NULL);
INSERT INTO point VALUES (5511, 183, '52/12', NULL, NULL);
INSERT INTO point VALUES (5512, 374, '121/1', NULL, NULL);
INSERT INTO point VALUES (5513, 658, '12', NULL, NULL);
INSERT INTO point VALUES (5514, 549, '8', NULL, NULL);
INSERT INTO point VALUES (5515, 310, '8', NULL, NULL);
INSERT INTO point VALUES (5516, 382, '16', NULL, NULL);
INSERT INTO point VALUES (5517, 595, '5', NULL, NULL);
INSERT INTO point VALUES (5518, 294, '4', NULL, NULL);
INSERT INTO point VALUES (5519, 47, '5', NULL, NULL);
INSERT INTO point VALUES (5520, 601, '143', NULL, NULL);
INSERT INTO point VALUES (5521, 458, '19', NULL, NULL);
INSERT INTO point VALUES (5522, 560, '92', NULL, NULL);
INSERT INTO point VALUES (5523, 502, '17', NULL, NULL);
INSERT INTO point VALUES (5524, 598, '36', NULL, NULL);
INSERT INTO point VALUES (5525, 40, '7', NULL, NULL);
INSERT INTO point VALUES (5526, 468, '2', NULL, NULL);
INSERT INTO point VALUES (5527, 170, '8/3', NULL, NULL);
INSERT INTO point VALUES (5528, 303, '5', NULL, NULL);
INSERT INTO point VALUES (5529, 602, '6а', NULL, NULL);
INSERT INTO point VALUES (5530, 425, '76', NULL, NULL);
INSERT INTO point VALUES (5531, 575, '2', NULL, NULL);
INSERT INTO point VALUES (5532, 472, '36', NULL, NULL);
INSERT INTO point VALUES (5533, 277, '7', NULL, NULL);
INSERT INTO point VALUES (5534, 502, '14 к1', NULL, NULL);
INSERT INTO point VALUES (5535, 3, '11', NULL, NULL);
INSERT INTO point VALUES (5536, 189, '2', NULL, NULL);
INSERT INTO point VALUES (5537, 362, '27', NULL, NULL);
INSERT INTO point VALUES (5538, 274, '10', NULL, NULL);
INSERT INTO point VALUES (5539, 76, '44', NULL, NULL);
INSERT INTO point VALUES (5540, 345, '18', NULL, NULL);
INSERT INTO point VALUES (5541, 473, '21', NULL, NULL);
INSERT INTO point VALUES (5542, 585, '42', NULL, NULL);
INSERT INTO point VALUES (5543, 361, '7', NULL, NULL);
INSERT INTO point VALUES (5544, 334, '44', NULL, NULL);
INSERT INTO point VALUES (5545, 325, '1', NULL, NULL);
INSERT INTO point VALUES (5546, 643, '61', NULL, NULL);
INSERT INTO point VALUES (5547, 643, '29', NULL, NULL);
INSERT INTO point VALUES (5548, 617, '9', NULL, NULL);
INSERT INTO point VALUES (5549, 340, '6', NULL, NULL);
INSERT INTO point VALUES (5550, 473, '32А', NULL, NULL);
INSERT INTO point VALUES (5551, 252, '19', NULL, NULL);
INSERT INTO point VALUES (5552, 142, '1', NULL, NULL);
INSERT INTO point VALUES (5553, 81, '12', NULL, NULL);
INSERT INTO point VALUES (5554, 326, '6А', NULL, NULL);
INSERT INTO point VALUES (5555, 203, '49', NULL, NULL);
INSERT INTO point VALUES (5556, 604, '184', NULL, NULL);
INSERT INTO point VALUES (5557, 189, '5', NULL, NULL);
INSERT INTO point VALUES (5558, 117, '28', NULL, NULL);
INSERT INTO point VALUES (5559, 304, '21', NULL, NULL);
INSERT INTO point VALUES (5560, 429, '14', NULL, NULL);
INSERT INTO point VALUES (5561, 447, '69', NULL, NULL);
INSERT INTO point VALUES (5562, 643, '89', NULL, NULL);
INSERT INTO point VALUES (5563, 531, '109', NULL, NULL);
INSERT INTO point VALUES (5564, 531, '142', NULL, NULL);
INSERT INTO point VALUES (5565, 105, '4', NULL, NULL);
INSERT INTO point VALUES (5566, 468, '5', NULL, NULL);
INSERT INTO point VALUES (5567, 394, '17', NULL, NULL);
INSERT INTO point VALUES (5568, 264, '13', NULL, NULL);
INSERT INTO point VALUES (5569, 76, '24', NULL, NULL);
INSERT INTO point VALUES (5570, 393, '3', NULL, NULL);
INSERT INTO point VALUES (5571, 334, '33', NULL, NULL);
INSERT INTO point VALUES (5572, 441, '3', NULL, NULL);
INSERT INTO point VALUES (5573, 465, '59', NULL, NULL);
INSERT INTO point VALUES (5574, 20, '16', NULL, NULL);
INSERT INTO point VALUES (5575, 425, '3-101', NULL, NULL);
INSERT INTO point VALUES (5576, 594, '23', NULL, NULL);
INSERT INTO point VALUES (5577, 137, '20', NULL, NULL);
INSERT INTO point VALUES (5578, 431, '36', NULL, NULL);
INSERT INTO point VALUES (5579, 501, '12', NULL, NULL);
INSERT INTO point VALUES (5580, 496, '13', NULL, NULL);
INSERT INTO point VALUES (5581, 225, '4', NULL, NULL);
INSERT INTO point VALUES (5582, 572, '34', NULL, NULL);
INSERT INTO point VALUES (5583, 518, '16', NULL, NULL);
INSERT INTO point VALUES (5584, 389, '45Б', NULL, NULL);
INSERT INTO point VALUES (5585, 252, '1', NULL, NULL);
INSERT INTO point VALUES (5586, 181, '48', NULL, NULL);
INSERT INTO point VALUES (5587, 269, '5А', NULL, NULL);
INSERT INTO point VALUES (5588, 458, '13', NULL, NULL);
INSERT INTO point VALUES (5589, 32, '21', NULL, NULL);
INSERT INTO point VALUES (5590, 87, '38', NULL, NULL);
INSERT INTO point VALUES (5591, 303, '29', NULL, NULL);
INSERT INTO point VALUES (5592, 169, '38', NULL, NULL);
INSERT INTO point VALUES (5593, 311, '18', NULL, NULL);
INSERT INTO point VALUES (5594, 629, '13', NULL, NULL);
INSERT INTO point VALUES (5595, 303, '61', NULL, NULL);
INSERT INTO point VALUES (5596, 433, '56', NULL, NULL);
INSERT INTO point VALUES (5597, 279, '10', NULL, NULL);
INSERT INTO point VALUES (5598, 228, '8', NULL, NULL);
INSERT INTO point VALUES (5599, 570, '14', NULL, NULL);
INSERT INTO point VALUES (5600, 541, '1', NULL, NULL);
INSERT INTO point VALUES (5601, 133, '10', NULL, NULL);
INSERT INTO point VALUES (5602, 262, '26А', NULL, NULL);
INSERT INTO point VALUES (5603, 3, '4', NULL, NULL);
INSERT INTO point VALUES (5604, 236, '50', NULL, NULL);
INSERT INTO point VALUES (5605, 447, '39', NULL, NULL);
INSERT INTO point VALUES (5606, 693, '17', NULL, NULL);
INSERT INTO point VALUES (5607, 117, '45', NULL, NULL);
INSERT INTO point VALUES (5608, 626, '13', NULL, NULL);
INSERT INTO point VALUES (5609, 48, '3', NULL, NULL);
INSERT INTO point VALUES (5610, 451, '41', NULL, NULL);
INSERT INTO point VALUES (5611, 445, '60', NULL, NULL);
INSERT INTO point VALUES (5612, 170, '8/1', NULL, NULL);
INSERT INTO point VALUES (5613, 563, '20', NULL, NULL);
INSERT INTO point VALUES (5614, 602, '47', NULL, NULL);
INSERT INTO point VALUES (5615, 663, '18', NULL, NULL);
INSERT INTO point VALUES (5616, 509, '27', NULL, NULL);
INSERT INTO point VALUES (5617, 465, '62', NULL, NULL);
INSERT INTO point VALUES (5618, 694, '2', NULL, NULL);
INSERT INTO point VALUES (5619, 643, '5', NULL, NULL);
INSERT INTO point VALUES (5620, 208, '18', NULL, NULL);
INSERT INTO point VALUES (5621, 323, '51', NULL, NULL);
INSERT INTO point VALUES (5622, 451, '31', NULL, NULL);
INSERT INTO point VALUES (5623, 26, '19', NULL, NULL);
INSERT INTO point VALUES (5624, 525, '41', NULL, NULL);
INSERT INTO point VALUES (5625, 638, '7', NULL, NULL);
INSERT INTO point VALUES (5626, 120, '23', NULL, NULL);
INSERT INTO point VALUES (5627, 534, '1А', NULL, NULL);
INSERT INTO point VALUES (5628, 100, '7', NULL, NULL);
INSERT INTO point VALUES (5629, 184, '15', NULL, NULL);
INSERT INTO point VALUES (5630, 552, '35А', NULL, NULL);
INSERT INTO point VALUES (5631, 158, '7', NULL, NULL);
INSERT INTO point VALUES (5632, 105, '11', NULL, NULL);
INSERT INTO point VALUES (5633, 236, '59А', NULL, NULL);
INSERT INTO point VALUES (5634, 280, '71', NULL, NULL);
INSERT INTO point VALUES (5635, 525, '31', NULL, NULL);
INSERT INTO point VALUES (5636, 376, '14', NULL, NULL);
INSERT INTO point VALUES (5637, 694, '5', NULL, NULL);
INSERT INTO point VALUES (5638, 87, '47', NULL, NULL);
INSERT INTO point VALUES (5639, 295, '20', NULL, NULL);
INSERT INTO point VALUES (5640, 177, '16', NULL, NULL);
INSERT INTO point VALUES (5641, 278, '15', NULL, NULL);
INSERT INTO point VALUES (5642, 234, '16', NULL, NULL);
INSERT INTO point VALUES (5643, 14, '4', NULL, NULL);
INSERT INTO point VALUES (5644, 125, '2А', NULL, NULL);
INSERT INTO point VALUES (5645, 476, '4', NULL, NULL);
INSERT INTO point VALUES (5646, 26, '1', NULL, NULL);
INSERT INTO point VALUES (5647, 546, '15', NULL, NULL);
INSERT INTO point VALUES (5648, 315, '16', NULL, NULL);
INSERT INTO point VALUES (5649, 78, '7', NULL, NULL);
INSERT INTO point VALUES (5650, 225, '11', NULL, NULL);
INSERT INTO point VALUES (5651, 665, '23', NULL, NULL);
INSERT INTO point VALUES (5652, 334, '42', NULL, NULL);
INSERT INTO point VALUES (5653, 100, '25', NULL, NULL);
INSERT INTO point VALUES (5654, 76, '38/1', NULL, NULL);
INSERT INTO point VALUES (5655, 142, '13', NULL, NULL);
INSERT INTO point VALUES (5656, 25, '9', NULL, NULL);
INSERT INTO point VALUES (5657, 477, '27', NULL, NULL);
INSERT INTO point VALUES (5658, 451, '2Б', NULL, NULL);
INSERT INTO point VALUES (5659, 544, '18', NULL, NULL);
INSERT INTO point VALUES (5660, 565, '5', NULL, NULL);
INSERT INTO point VALUES (5661, 585, '44', NULL, NULL);
INSERT INTO point VALUES (5662, 234, '20', NULL, NULL);
INSERT INTO point VALUES (5663, 572, '12А', NULL, NULL);
INSERT INTO point VALUES (5664, 76, '42', NULL, NULL);
INSERT INTO point VALUES (5665, 496, '19', NULL, NULL);
INSERT INTO point VALUES (5666, 295, '16', NULL, NULL);
INSERT INTO point VALUES (5667, 483, '33', NULL, NULL);
INSERT INTO point VALUES (5668, 274, '6', NULL, NULL);
INSERT INTO point VALUES (5669, 604, '192', NULL, NULL);
INSERT INTO point VALUES (5670, 625, '10', NULL, NULL);
INSERT INTO point VALUES (5671, 652, '5', NULL, NULL);
INSERT INTO point VALUES (5672, 81, '5А', NULL, NULL);
INSERT INTO point VALUES (5673, 67, '85', NULL, NULL);
INSERT INTO point VALUES (5674, 641, '3', NULL, NULL);
INSERT INTO point VALUES (5675, 535, '5', NULL, NULL);
INSERT INTO point VALUES (5676, 614, '8', NULL, NULL);
INSERT INTO point VALUES (5677, 315, '20', NULL, NULL);
INSERT INTO point VALUES (5678, 325, '13', NULL, NULL);
INSERT INTO point VALUES (5679, 150, '4', NULL, NULL);
INSERT INTO point VALUES (5680, 374, '157', NULL, NULL);
INSERT INTO point VALUES (5681, 483, '24', NULL, NULL);
INSERT INTO point VALUES (5682, 15, '14', NULL, NULL);
INSERT INTO point VALUES (5683, 163, '22', NULL, NULL);
INSERT INTO point VALUES (5684, 286, '3', NULL, NULL);
INSERT INTO point VALUES (5685, 180, '39', NULL, NULL);
INSERT INTO point VALUES (5686, 447, '67', NULL, NULL);
INSERT INTO point VALUES (5687, 78, '25', NULL, NULL);
INSERT INTO point VALUES (5688, 696, '37', NULL, NULL);
INSERT INTO point VALUES (5689, 451, '54', NULL, NULL);
INSERT INTO point VALUES (5690, 604, '213', NULL, NULL);
INSERT INTO point VALUES (5691, 600, '15', NULL, NULL);
INSERT INTO point VALUES (5692, 323, '53', NULL, NULL);
INSERT INTO point VALUES (5693, 340, '10', NULL, NULL);
INSERT INTO point VALUES (5694, 374, '131', NULL, NULL);
INSERT INTO point VALUES (5695, 531, '24', NULL, NULL);
INSERT INTO point VALUES (5696, 601, '122', NULL, NULL);
INSERT INTO point VALUES (5697, 386, '8В', NULL, NULL);
INSERT INTO point VALUES (5698, 496, '1', NULL, NULL);
INSERT INTO point VALUES (5699, 205, '12', NULL, NULL);
INSERT INTO point VALUES (5700, 511, '27', NULL, NULL);
INSERT INTO point VALUES (5701, 572, '35', NULL, NULL);
INSERT INTO point VALUES (5702, 252, '13', NULL, NULL);
INSERT INTO point VALUES (5703, 521, '3А', NULL, NULL);
INSERT INTO point VALUES (5704, 170, '8/2', NULL, NULL);
INSERT INTO point VALUES (5705, 563, '16', NULL, NULL);
INSERT INTO point VALUES (5706, 374, '135', NULL, NULL);
INSERT INTO point VALUES (5707, 582, '8', NULL, NULL);
INSERT INTO point VALUES (5708, 170, '12/3', NULL, NULL);
INSERT INTO point VALUES (5709, 389, '12', NULL, NULL);
INSERT INTO point VALUES (5710, 9, '75', NULL, NULL);
INSERT INTO point VALUES (5711, 670, '63', NULL, NULL);
INSERT INTO point VALUES (5712, 98, '22', NULL, NULL);
INSERT INTO point VALUES (5713, 338, '66', NULL, NULL);
INSERT INTO point VALUES (5714, 329, '49', NULL, NULL);
INSERT INTO point VALUES (5715, 480, '29', NULL, NULL);
INSERT INTO point VALUES (5716, 376, '71', NULL, NULL);
INSERT INTO point VALUES (5717, 329, '30Б', NULL, NULL);
INSERT INTO point VALUES (5718, 251, '1', NULL, NULL);
INSERT INTO point VALUES (5719, 324, '20', NULL, NULL);
INSERT INTO point VALUES (5720, 531, '33', NULL, NULL);
INSERT INTO point VALUES (5721, 585, '24', NULL, NULL);
INSERT INTO point VALUES (5722, 366, '21', NULL, NULL);
INSERT INTO point VALUES (5723, 531, '158', NULL, NULL);
INSERT INTO point VALUES (5724, 208, '36', NULL, NULL);
INSERT INTO point VALUES (5725, 94, '1Б', NULL, NULL);
INSERT INTO point VALUES (5726, 601, '48Б', NULL, NULL);
INSERT INTO point VALUES (5727, 561, '18', NULL, NULL);
INSERT INTO point VALUES (5728, 478, '52', NULL, NULL);
INSERT INTO point VALUES (5729, 601, '84', NULL, NULL);
INSERT INTO point VALUES (5730, 294, '11', NULL, NULL);
INSERT INTO point VALUES (5731, 183, '52/7', NULL, NULL);
INSERT INTO point VALUES (5732, 172, '45', NULL, NULL);
INSERT INTO point VALUES (5733, 100, '102', NULL, NULL);
INSERT INTO point VALUES (5734, 23, '30', NULL, NULL);
INSERT INTO point VALUES (5735, 467, '8', NULL, NULL);
INSERT INTO point VALUES (5736, 687, '28', NULL, NULL);
INSERT INTO point VALUES (5737, 488, '14', NULL, NULL);
INSERT INTO point VALUES (5738, 294, '172', NULL, NULL);
INSERT INTO point VALUES (5739, 220, '9', NULL, NULL);
INSERT INTO point VALUES (5740, 250, '11', NULL, NULL);
INSERT INTO point VALUES (5741, 180, '32', NULL, NULL);
INSERT INTO point VALUES (5742, 374, '96', NULL, NULL);
INSERT INTO point VALUES (5743, 183, '19', NULL, NULL);
INSERT INTO point VALUES (5744, 598, '26', NULL, NULL);
INSERT INTO point VALUES (5745, 362, '5', NULL, NULL);
INSERT INTO point VALUES (5746, 635, '3', NULL, NULL);
INSERT INTO point VALUES (5747, 621, '6', NULL, NULL);
INSERT INTO point VALUES (5748, 472, '26', NULL, NULL);
INSERT INTO point VALUES (5749, 53, '22', NULL, NULL);
INSERT INTO point VALUES (5750, 9, '59', NULL, NULL);
INSERT INTO point VALUES (5751, 693, '25', NULL, NULL);
INSERT INTO point VALUES (5752, 139, '11', NULL, NULL);
INSERT INTO point VALUES (5753, 531, '240', NULL, NULL);
INSERT INTO point VALUES (5754, 448, '19', NULL, NULL);
INSERT INTO point VALUES (5755, 310, '34', NULL, NULL);
INSERT INTO point VALUES (5756, 342, '8', NULL, NULL);
INSERT INTO point VALUES (5757, 643, '63', NULL, NULL);
INSERT INTO point VALUES (5758, 449, '12/2', NULL, NULL);
INSERT INTO point VALUES (5759, 675, '10', NULL, NULL);
INSERT INTO point VALUES (5760, 415, '13', NULL, NULL);
INSERT INTO point VALUES (5761, 131, '18', NULL, NULL);
INSERT INTO point VALUES (5762, 531, '218', NULL, NULL);
INSERT INTO point VALUES (5763, 431, '9', NULL, NULL);
INSERT INTO point VALUES (5764, 161, '26', NULL, NULL);
INSERT INTO point VALUES (5765, 372, '16', NULL, NULL);
INSERT INTO point VALUES (5766, 39, '50', NULL, NULL);
INSERT INTO point VALUES (5767, 176, '9', NULL, NULL);
INSERT INTO point VALUES (5768, 130, '1', NULL, NULL);
INSERT INTO point VALUES (5769, 548, '1', NULL, NULL);
INSERT INTO point VALUES (5770, 511, '2А', NULL, NULL);
INSERT INTO point VALUES (5771, 280, '55', NULL, NULL);
INSERT INTO point VALUES (5772, 509, '29', NULL, NULL);
INSERT INTO point VALUES (5773, 682, '16', NULL, NULL);
INSERT INTO point VALUES (5774, 340, '12', NULL, NULL);
INSERT INTO point VALUES (5775, 699, '2', NULL, NULL);
INSERT INTO point VALUES (5776, 323, '20', NULL, NULL);
INSERT INTO point VALUES (5777, 202, '4А', NULL, NULL);
INSERT INTO point VALUES (5778, 436, '1', NULL, NULL);
INSERT INTO point VALUES (5779, 525, '30', NULL, NULL);
INSERT INTO point VALUES (5780, 598, '9', NULL, NULL);
INSERT INTO point VALUES (5781, 205, '10', NULL, NULL);
INSERT INTO point VALUES (5782, 120, '34', NULL, NULL);
INSERT INTO point VALUES (5783, 305, '5', NULL, NULL);
INSERT INTO point VALUES (5784, 472, '9', NULL, NULL);
INSERT INTO point VALUES (5785, 215, '111', NULL, NULL);
INSERT INTO point VALUES (5786, 389, '10', NULL, NULL);
INSERT INTO point VALUES (5787, 246, '6', NULL, NULL);
INSERT INTO point VALUES (5788, 434, '21', NULL, NULL);
INSERT INTO point VALUES (5789, 268, '4', NULL, NULL);
INSERT INTO point VALUES (5790, 257, '8', NULL, NULL);
INSERT INTO point VALUES (5791, 175, '5', NULL, NULL);
INSERT INTO point VALUES (5792, 176, '26', NULL, NULL);
INSERT INTO point VALUES (5793, 521, '14', NULL, NULL);
INSERT INTO point VALUES (5794, 161, '9', NULL, NULL);
INSERT INTO point VALUES (5795, 280, '73', NULL, NULL);
INSERT INTO point VALUES (5796, 448, '1', NULL, NULL);
INSERT INTO point VALUES (5797, 109, '18', NULL, NULL);
INSERT INTO point VALUES (5798, 409, '10', NULL, NULL);
INSERT INTO point VALUES (5799, 374, '45', NULL, NULL);
INSERT INTO point VALUES (5800, 111, '13', NULL, NULL);
INSERT INTO point VALUES (5801, 100, '39', NULL, NULL);
INSERT INTO point VALUES (5802, 562, '13', NULL, NULL);
INSERT INTO point VALUES (5803, 170, '45', NULL, NULL);
INSERT INTO point VALUES (5804, 283, '19', NULL, NULL);
INSERT INTO point VALUES (5805, 294, '230', NULL, NULL);
INSERT INTO point VALUES (5806, 501, '6', NULL, NULL);
INSERT INTO point VALUES (5807, 568, '8', NULL, NULL);
INSERT INTO point VALUES (5808, 180, '7', NULL, NULL);
INSERT INTO point VALUES (5809, 375, '46', NULL, NULL);
INSERT INTO point VALUES (5810, 384, '2/2', NULL, NULL);
INSERT INTO point VALUES (5811, 477, '29', NULL, NULL);
INSERT INTO point VALUES (5812, 277, '21/1', NULL, NULL);
INSERT INTO point VALUES (5813, 78, '17', NULL, NULL);
INSERT INTO point VALUES (5814, 388, '19', NULL, NULL);
INSERT INTO point VALUES (5815, 265, '23А', NULL, NULL);
INSERT INTO point VALUES (5816, 600, '44', NULL, NULL);
INSERT INTO point VALUES (5817, 531, '15', NULL, NULL);
INSERT INTO point VALUES (5818, 250, '50', NULL, NULL);
INSERT INTO point VALUES (5819, 168, '4', NULL, NULL);
INSERT INTO point VALUES (5820, 345, '9', NULL, NULL);
INSERT INTO point VALUES (5821, 170, '3', NULL, NULL);
INSERT INTO point VALUES (5822, 269, '6', NULL, NULL);
INSERT INTO point VALUES (5823, 39, '11', NULL, NULL);
INSERT INTO point VALUES (5824, 114, '43', NULL, NULL);
INSERT INTO point VALUES (5825, 294, '234', NULL, NULL);
INSERT INTO point VALUES (5826, 30, '15', NULL, NULL);
INSERT INTO point VALUES (5827, 323, '16', NULL, NULL);
INSERT INTO point VALUES (5828, 374, '3', NULL, NULL);
INSERT INTO point VALUES (5829, 534, '6', NULL, NULL);
INSERT INTO point VALUES (5830, 558, '6', NULL, NULL);
INSERT INTO point VALUES (5831, 389, '43', NULL, NULL);
INSERT INTO point VALUES (5832, 110, '21', NULL, NULL);
INSERT INTO point VALUES (5833, 166, '19', NULL, NULL);
INSERT INTO point VALUES (5834, 222, '13', NULL, NULL);
INSERT INTO point VALUES (5835, 92, '13', NULL, NULL);
INSERT INTO point VALUES (5836, 100, '17', NULL, NULL);
INSERT INTO point VALUES (5837, 37, '45', NULL, NULL);
INSERT INTO point VALUES (5838, 262, '21', NULL, NULL);
INSERT INTO point VALUES (5839, 670, '5', NULL, NULL);
INSERT INTO point VALUES (5840, 435, '33', NULL, NULL);
INSERT INTO point VALUES (5841, 213, '47', NULL, NULL);
INSERT INTO point VALUES (5842, 693, '7', NULL, NULL);
INSERT INTO point VALUES (5843, 542, '15', NULL, NULL);
INSERT INTO point VALUES (5844, 657, '19', NULL, NULL);
INSERT INTO point VALUES (5845, 447, '25', NULL, NULL);
INSERT INTO point VALUES (5846, 393, '6А', NULL, NULL);
INSERT INTO point VALUES (5847, 372, '20', NULL, NULL);
INSERT INTO point VALUES (5848, 600, '33', NULL, NULL);
INSERT INTO point VALUES (5849, 376, '73', NULL, NULL);
INSERT INTO point VALUES (5850, 285, '2/2', NULL, NULL);
INSERT INTO point VALUES (5851, 172, '3', NULL, NULL);
INSERT INTO point VALUES (5852, 203, '37', NULL, NULL);
INSERT INTO point VALUES (5853, 682, '20', NULL, NULL);
INSERT INTO point VALUES (5854, 370, '7', NULL, NULL);
INSERT INTO point VALUES (5855, 564, '2А', NULL, NULL);
INSERT INTO point VALUES (5856, 115, '13', NULL, NULL);
INSERT INTO point VALUES (5857, 654, '49', NULL, NULL);
INSERT INTO point VALUES (5858, 67, '56', NULL, NULL);
INSERT INTO point VALUES (5859, 658, '6', NULL, NULL);
INSERT INTO point VALUES (5860, 455, '52Б', NULL, NULL);
INSERT INTO point VALUES (5861, 376, '3А', NULL, NULL);
INSERT INTO point VALUES (5862, 146, '31', NULL, NULL);
INSERT INTO point VALUES (5863, 345, '26', NULL, NULL);
INSERT INTO point VALUES (5864, 374, '111', NULL, NULL);
INSERT INTO point VALUES (5865, 187, '2', NULL, NULL);
INSERT INTO point VALUES (5866, 636, '27', NULL, NULL);
INSERT INTO point VALUES (5867, 615, '9', NULL, NULL);
INSERT INTO point VALUES (5868, 50, '37', NULL, NULL);
INSERT INTO point VALUES (5869, 483, '15', NULL, NULL);
INSERT INTO point VALUES (5870, 435, '24', NULL, NULL);
INSERT INTO point VALUES (5871, 47, '27', NULL, NULL);
INSERT INTO point VALUES (5872, 283, '13', NULL, NULL);
INSERT INTO point VALUES (5873, 111, '19', NULL, NULL);
INSERT INTO point VALUES (5874, 562, '19', NULL, NULL);
INSERT INTO point VALUES (5875, 477, '5', NULL, NULL);
INSERT INTO point VALUES (5876, 311, '9', NULL, NULL);
INSERT INTO point VALUES (5877, 51, '32', NULL, NULL);
INSERT INTO point VALUES (5878, 511, '2', NULL, NULL);
INSERT INTO point VALUES (5879, 639, '14', NULL, NULL);
INSERT INTO point VALUES (5880, 168, '11', NULL, NULL);
INSERT INTO point VALUES (5881, 415, '1', NULL, NULL);
INSERT INTO point VALUES (5882, 621, '10', NULL, NULL);
INSERT INTO point VALUES (5883, 274, '12', NULL, NULL);
INSERT INTO point VALUES (5884, 67, '94', NULL, NULL);
INSERT INTO point VALUES (5885, 265, '11', NULL, NULL);
INSERT INTO point VALUES (5886, 352, '32', NULL, NULL);
INSERT INTO point VALUES (5887, 569, '49', NULL, NULL);
INSERT INTO point VALUES (5888, 435, '66', NULL, NULL);
INSERT INTO point VALUES (5889, 394, '7', NULL, NULL);
INSERT INTO point VALUES (5890, 663, '9', NULL, NULL);
INSERT INTO point VALUES (5891, 607, '15', NULL, NULL);
INSERT INTO point VALUES (5892, 208, '9', NULL, NULL);
INSERT INTO point VALUES (5893, 100, '97', NULL, NULL);
INSERT INTO point VALUES (5894, 111, '1', NULL, NULL);
INSERT INTO point VALUES (5895, 511, '5', NULL, NULL);
INSERT INTO point VALUES (5896, 562, '1', NULL, NULL);
INSERT INTO point VALUES (5897, 668, '19', NULL, NULL);
INSERT INTO point VALUES (5898, 205, '6', NULL, NULL);
INSERT INTO point VALUES (5899, 464, '48', NULL, NULL);
INSERT INTO point VALUES (5900, 25, '36', NULL, NULL);
INSERT INTO point VALUES (5901, 610, '33', NULL, NULL);
INSERT INTO point VALUES (5902, 191, '34', NULL, NULL);
INSERT INTO point VALUES (5903, 197, '6', NULL, NULL);
INSERT INTO point VALUES (5904, 61, '20', NULL, NULL);
INSERT INTO point VALUES (5905, 169, '30', NULL, NULL);
INSERT INTO point VALUES (5906, 670, '29', NULL, NULL);
INSERT INTO point VALUES (5907, 415, '19', NULL, NULL);
INSERT INTO point VALUES (5908, 670, '61', NULL, NULL);
INSERT INTO point VALUES (5909, 566, '17А', NULL, NULL);
INSERT INTO point VALUES (5910, 560, '61', NULL, NULL);
INSERT INTO point VALUES (5911, 176, '65', NULL, NULL);
INSERT INTO point VALUES (5912, 389, '6', NULL, NULL);
INSERT INTO point VALUES (5913, 246, '10', NULL, NULL);
INSERT INTO point VALUES (5914, 549, '12А', NULL, NULL);
INSERT INTO point VALUES (5915, 448, '13', NULL, NULL);
INSERT INTO point VALUES (5916, 477, '2', NULL, NULL);
INSERT INTO point VALUES (5917, 210, '8', NULL, NULL);
INSERT INTO point VALUES (5918, 208, '26', NULL, NULL);
INSERT INTO point VALUES (5919, 409, '6', NULL, NULL);
INSERT INTO point VALUES (5920, 693, '2/3', NULL, NULL);
INSERT INTO point VALUES (5921, 342, '23', NULL, NULL);
INSERT INTO point VALUES (5922, 695, '24', NULL, NULL);
INSERT INTO point VALUES (5923, 183, '13', NULL, NULL);
INSERT INTO point VALUES (5924, 166, '39А', NULL, NULL);
INSERT INTO point VALUES (5925, 192, '15', NULL, NULL);
INSERT INTO point VALUES (5926, 653, '55', NULL, NULL);
INSERT INTO point VALUES (5927, 21, '15А', NULL, NULL);
INSERT INTO point VALUES (5928, 528, '9', NULL, NULL);
INSERT INTO point VALUES (5929, 378, '5', NULL, NULL);
INSERT INTO point VALUES (5930, 139, '7А', NULL, NULL);
INSERT INTO point VALUES (5931, 120, '35', NULL, NULL);
INSERT INTO point VALUES (5932, 40, '17', NULL, NULL);
INSERT INTO point VALUES (5933, 182, '17', NULL, NULL);
INSERT INTO point VALUES (5934, 610, '24', NULL, NULL);
INSERT INTO point VALUES (5935, 531, '86', NULL, NULL);
INSERT INTO point VALUES (5936, 663, '26', NULL, NULL);
INSERT INTO point VALUES (5937, 277, '17', NULL, NULL);
INSERT INTO point VALUES (5938, 183, '52', NULL, NULL);
INSERT INTO point VALUES (5939, 67, '10', NULL, NULL);
INSERT INTO point VALUES (5940, 25, '18', NULL, NULL);
INSERT INTO point VALUES (5941, 250, '4', NULL, NULL);
INSERT INTO point VALUES (5942, 74, '5', NULL, NULL);
INSERT INTO point VALUES (5943, 406, '15', NULL, NULL);
INSERT INTO point VALUES (5944, 170, '4/2', NULL, NULL);
INSERT INTO point VALUES (5945, 544, '9', NULL, NULL);
INSERT INTO point VALUES (5946, 92, '1', NULL, NULL);
INSERT INTO point VALUES (5947, 334, '15', NULL, NULL);
INSERT INTO point VALUES (5948, 531, '252А', NULL, NULL);
INSERT INTO point VALUES (5949, 222, '1', NULL, NULL);
INSERT INTO point VALUES (5950, 152, '3', NULL, NULL);
INSERT INTO point VALUES (5951, 265, '29/1', NULL, NULL);
INSERT INTO point VALUES (5952, 688, '10', NULL, NULL);
INSERT INTO point VALUES (5953, 475, '3', NULL, NULL);
INSERT INTO point VALUES (5954, 55, '28', NULL, NULL);
INSERT INTO point VALUES (5955, 536, '3', NULL, NULL);
INSERT INTO point VALUES (5956, 374, '28', NULL, NULL);
INSERT INTO point VALUES (5957, 294, '100', NULL, NULL);
INSERT INTO point VALUES (5958, 462, '3', NULL, NULL);
INSERT INTO point VALUES (5959, 100, '99', NULL, NULL);
INSERT INTO point VALUES (5960, 582, '34', NULL, NULL);
INSERT INTO point VALUES (5961, 390, '14', NULL, NULL);
INSERT INTO point VALUES (5962, 169, '40', NULL, NULL);
INSERT INTO point VALUES (5963, 87, '40', NULL, NULL);
INSERT INTO point VALUES (5964, 67, '104', NULL, NULL);
INSERT INTO point VALUES (5965, 564, '5', NULL, NULL);
INSERT INTO point VALUES (5966, 598, '20А', NULL, NULL);
INSERT INTO point VALUES (5967, 236, '72', NULL, NULL);
INSERT INTO point VALUES (5968, 269, '10', NULL, NULL);
INSERT INTO point VALUES (5969, 657, '13', NULL, NULL);
INSERT INTO point VALUES (5970, 394, '32', NULL, NULL);
INSERT INTO point VALUES (5971, 601, '90', NULL, NULL);
INSERT INTO point VALUES (5972, 435, '42', NULL, NULL);
INSERT INTO point VALUES (5973, 496, '37А', NULL, NULL);
INSERT INTO point VALUES (5974, 600, '42', NULL, NULL);
INSERT INTO point VALUES (5975, 224, '7', NULL, NULL);
INSERT INTO point VALUES (5976, 265, '50', NULL, NULL);
INSERT INTO point VALUES (5977, 277, '39', NULL, NULL);
INSERT INTO point VALUES (5978, 509, '5', NULL, NULL);
INSERT INTO point VALUES (5979, 643, '27', NULL, NULL);
INSERT INTO point VALUES (5980, 604, '216', NULL, NULL);
INSERT INTO point VALUES (5981, 374, '153', NULL, NULL);
INSERT INTO point VALUES (5982, 451, '58/1', NULL, NULL);
INSERT INTO point VALUES (5983, 277, '102', NULL, NULL);
INSERT INTO point VALUES (5984, 433, '58', NULL, NULL);
INSERT INTO point VALUES (5985, 329, '37', NULL, NULL);
INSERT INTO point VALUES (5986, 166, '13', NULL, NULL);
INSERT INTO point VALUES (5987, 235, '48', NULL, NULL);
INSERT INTO point VALUES (5988, 445, '62', NULL, NULL);
INSERT INTO point VALUES (5989, 531, '98', NULL, NULL);
INSERT INTO point VALUES (5990, 268, '11', NULL, NULL);
INSERT INTO point VALUES (5991, 102, '4', NULL, NULL);
INSERT INTO point VALUES (5992, 544, '26', NULL, NULL);
INSERT INTO point VALUES (5993, 44, '19', NULL, NULL);
INSERT INTO point VALUES (5994, 74, '2', NULL, NULL);
INSERT INTO point VALUES (5995, 465, '60', NULL, NULL);
INSERT INTO point VALUES (5996, 548, '52', NULL, NULL);
INSERT INTO point VALUES (5997, 12, '175', NULL, NULL);
INSERT INTO point VALUES (5998, 658, '10', NULL, NULL);
INSERT INTO point VALUES (5999, 213, '41', NULL, NULL);
INSERT INTO point VALUES (6000, 236, '100', NULL, NULL);
INSERT INTO point VALUES (6001, 566, '26А', NULL, NULL);
INSERT INTO point VALUES (6002, 39, '7А', NULL, NULL);
INSERT INTO point VALUES (6003, 664, '6А/1', NULL, NULL);
INSERT INTO point VALUES (6004, 262, '19А', NULL, NULL);
INSERT INTO point VALUES (6005, 572, '23', NULL, NULL);
INSERT INTO point VALUES (6006, 496, '17/2', NULL, NULL);
INSERT INTO point VALUES (6007, 213, '31', NULL, NULL);
INSERT INTO point VALUES (6008, 561, '9', NULL, NULL);
INSERT INTO point VALUES (6009, 477, '26', NULL, NULL);
INSERT INTO point VALUES (6010, 311, '2', NULL, NULL);
INSERT INTO point VALUES (6011, 675, '16', NULL, NULL);
INSERT INTO point VALUES (6012, 342, '25', NULL, NULL);
INSERT INTO point VALUES (6013, 250, '49', NULL, NULL);
INSERT INTO point VALUES (6014, 57, '3', NULL, NULL);
INSERT INTO point VALUES (6015, 531, '22', NULL, NULL);
INSERT INTO point VALUES (6016, 565, '36', NULL, NULL);
INSERT INTO point VALUES (6017, 294, '68', NULL, NULL);
INSERT INTO point VALUES (6018, 372, '10', NULL, NULL);
INSERT INTO point VALUES (6019, 496, '55', NULL, NULL);
INSERT INTO point VALUES (6020, 191, '17', NULL, NULL);
INSERT INTO point VALUES (6021, 682, '10', NULL, NULL);
INSERT INTO point VALUES (6022, 366, '31', NULL, NULL);
INSERT INTO point VALUES (6023, 279, '53', NULL, NULL);
INSERT INTO point VALUES (6024, 585, '22', NULL, NULL);
INSERT INTO point VALUES (6025, 277, '34', NULL, NULL);
INSERT INTO point VALUES (6026, 663, '2', NULL, NULL);
INSERT INTO point VALUES (6027, 528, '5', NULL, NULL);
INSERT INTO point VALUES (6028, 415, '73А', NULL, NULL);
INSERT INTO point VALUES (6029, 531, '240А', NULL, NULL);
INSERT INTO point VALUES (6030, 378, '9', NULL, NULL);
INSERT INTO point VALUES (6031, 295, '12', NULL, NULL);
INSERT INTO point VALUES (6032, 513, '23', NULL, NULL);
INSERT INTO point VALUES (6033, 548, '14', NULL, NULL);
INSERT INTO point VALUES (6034, 202, '36', NULL, NULL);
INSERT INTO point VALUES (6035, 370, '8', NULL, NULL);
INSERT INTO point VALUES (6036, 694, '18', NULL, NULL);
INSERT INTO point VALUES (6037, 283, '14', NULL, NULL);
INSERT INTO point VALUES (6038, 208, '2', NULL, NULL);
INSERT INTO point VALUES (6039, 157, '6А', NULL, NULL);
INSERT INTO point VALUES (6040, 294, '70', NULL, NULL);
INSERT INTO point VALUES (6041, 342, '32', NULL, NULL);
INSERT INTO point VALUES (6042, 464, '46', NULL, NULL);
INSERT INTO point VALUES (6043, 496, '73', NULL, NULL);
INSERT INTO point VALUES (6044, 12, '57', NULL, NULL);
INSERT INTO point VALUES (6045, 508, '3', NULL, NULL);
INSERT INTO point VALUES (6046, 236, '70', NULL, NULL);
INSERT INTO point VALUES (6047, 321, '39', NULL, NULL);
INSERT INTO point VALUES (6048, 451, '48', NULL, NULL);
INSERT INTO point VALUES (6049, 183, '14', NULL, NULL);
INSERT INTO point VALUES (6050, 285, '28', NULL, NULL);
INSERT INTO point VALUES (6051, 347, '43', NULL, NULL);
INSERT INTO point VALUES (6052, 25, '27', NULL, NULL);
INSERT INTO point VALUES (6053, 477, '9', NULL, NULL);
INSERT INTO point VALUES (6054, 311, '5', NULL, NULL);
INSERT INTO point VALUES (6055, 261, '4', NULL, NULL);
INSERT INTO point VALUES (6056, 572, '7', NULL, NULL);
INSERT INTO point VALUES (6057, 353, '53', NULL, NULL);
INSERT INTO point VALUES (6058, 236, '68', NULL, NULL);
INSERT INTO point VALUES (6059, 84, '19', NULL, NULL);
INSERT INTO point VALUES (6060, 290, '15', NULL, NULL);
INSERT INTO point VALUES (6061, 205, '16', NULL, NULL);
INSERT INTO point VALUES (6062, 521, '1', NULL, NULL);
INSERT INTO point VALUES (6063, 208, '5', NULL, NULL);
INSERT INTO point VALUES (6064, 180, '8', NULL, NULL);
INSERT INTO point VALUES (6065, 563, '12', NULL, NULL);
INSERT INTO point VALUES (6066, 483, '22', NULL, NULL);
INSERT INTO point VALUES (6067, 183, '52/10', NULL, NULL);
INSERT INTO point VALUES (6068, 663, '5', NULL, NULL);
INSERT INTO point VALUES (6069, 389, '16', NULL, NULL);
INSERT INTO point VALUES (6070, 163, '24', NULL, NULL);
INSERT INTO point VALUES (6071, 554, '91', NULL, NULL);
INSERT INTO point VALUES (6072, 46, '4', NULL, NULL);
INSERT INTO point VALUES (6073, 569, '7А', NULL, NULL);
INSERT INTO point VALUES (6074, 304, '38', NULL, NULL);
INSERT INTO point VALUES (6075, 434, '40', NULL, NULL);
INSERT INTO point VALUES (6076, 220, '22/3', NULL, NULL);
INSERT INTO point VALUES (6077, 171, '21', NULL, NULL);
INSERT INTO point VALUES (6078, 374, '23/8', NULL, NULL);
INSERT INTO point VALUES (6079, 394, '23', NULL, NULL);
INSERT INTO point VALUES (6080, 227, '21', NULL, NULL);
INSERT INTO point VALUES (6081, 566, '38', NULL, NULL);
INSERT INTO point VALUES (6082, 548, '71', NULL, NULL);
INSERT INTO point VALUES (6083, 358, '18', NULL, NULL);
INSERT INTO point VALUES (6084, 205, '20', NULL, NULL);
INSERT INTO point VALUES (6085, 544, '2', NULL, NULL);
INSERT INTO point VALUES (6086, 572, '25', NULL, NULL);
INSERT INTO point VALUES (6087, 389, '20', NULL, NULL);
INSERT INTO point VALUES (6088, 233, '4', NULL, NULL);
INSERT INTO point VALUES (6089, 27, '28', NULL, NULL);
INSERT INTO point VALUES (6090, 34, '17', NULL, NULL);
INSERT INTO point VALUES (6091, 99, '13', NULL, NULL);
INSERT INTO point VALUES (6092, 94, '13', NULL, NULL);
INSERT INTO point VALUES (6093, 568, '7', NULL, NULL);
INSERT INTO point VALUES (6094, 374, '151', NULL, NULL);
INSERT INTO point VALUES (6095, 291, '6', NULL, NULL);
INSERT INTO point VALUES (6096, 465, '96', NULL, NULL);
INSERT INTO point VALUES (6097, 598, '29', NULL, NULL);
INSERT INTO point VALUES (6098, 236, '87', NULL, NULL);
INSERT INTO point VALUES (6099, 561, '5', NULL, NULL);
INSERT INTO point VALUES (6100, 259, '6', NULL, NULL);
INSERT INTO point VALUES (6101, 569, '4', NULL, NULL);
INSERT INTO point VALUES (6102, 279, '51', NULL, NULL);
INSERT INTO point VALUES (6103, 531, '162', NULL, NULL);
INSERT INTO point VALUES (6104, 245, '43', NULL, NULL);
INSERT INTO point VALUES (6105, 374, '123/1', NULL, NULL);
INSERT INTO point VALUES (6106, 434, '30', NULL, NULL);
INSERT INTO point VALUES (6107, 232, '18', NULL, NULL);
INSERT INTO point VALUES (6108, 692, '18', NULL, NULL);
INSERT INTO point VALUES (6109, 360, '2', NULL, NULL);
INSERT INTO point VALUES (6110, 509, '26', NULL, NULL);
INSERT INTO point VALUES (6111, 257, '7', NULL, NULL);
INSERT INTO point VALUES (6112, 161, '29', NULL, NULL);
INSERT INTO point VALUES (6113, 546, '15/1', NULL, NULL);
INSERT INTO point VALUES (6114, 342, '7', NULL, NULL);
INSERT INTO point VALUES (6115, 235, '46', NULL, NULL);
INSERT INTO point VALUES (6116, 181, '38', NULL, NULL);
INSERT INTO point VALUES (6117, 364, '32', NULL, NULL);
INSERT INTO point VALUES (6118, 499, '4', NULL, NULL);
INSERT INTO point VALUES (6119, 234, '12', NULL, NULL);
INSERT INTO point VALUES (6120, 67, '84', NULL, NULL);
INSERT INTO point VALUES (6121, 398, '11', NULL, NULL);
INSERT INTO point VALUES (6122, 572, '32', NULL, NULL);
INSERT INTO point VALUES (6123, 100, '35', NULL, NULL);
INSERT INTO point VALUES (6124, 315, '12', NULL, NULL);
INSERT INTO point VALUES (6125, 544, '5', NULL, NULL);
INSERT INTO point VALUES (6126, 628, '40', NULL, NULL);
INSERT INTO point VALUES (6127, 74, '9', NULL, NULL);
INSERT INTO point VALUES (6128, 6, '9', NULL, NULL);
INSERT INTO point VALUES (6129, 509, '9', NULL, NULL);
INSERT INTO point VALUES (6130, 451, '60/2', NULL, NULL);
INSERT INTO point VALUES (6131, 467, '7', NULL, NULL);
INSERT INTO point VALUES (6132, 360, '5', NULL, NULL);
INSERT INTO point VALUES (6133, 654, '11', NULL, NULL);
INSERT INTO point VALUES (6134, 202, '22/1', NULL, NULL);
INSERT INTO point VALUES (6135, 176, '29', NULL, NULL);
INSERT INTO point VALUES (6136, 176, '61', NULL, NULL);
INSERT INTO point VALUES (6137, 516, '9', NULL, NULL);
INSERT INTO point VALUES (6138, 560, '65', NULL, NULL);
INSERT INTO point VALUES (6139, 202, '18', NULL, NULL);
INSERT INTO point VALUES (6140, 431, '29', NULL, NULL);
INSERT INTO point VALUES (6141, 670, '65', NULL, NULL);
INSERT INTO point VALUES (6142, 75, '2', NULL, NULL);
INSERT INTO point VALUES (6143, 166, '14', NULL, NULL);
INSERT INTO point VALUES (6144, 564, '9', NULL, NULL);
INSERT INTO point VALUES (6145, 601, '58', NULL, NULL);
INSERT INTO point VALUES (6146, 220, '2', NULL, NULL);
INSERT INTO point VALUES (6147, 334, '22', NULL, NULL);
INSERT INTO point VALUES (6148, 496, '113 ка', NULL, NULL);
INSERT INTO point VALUES (6149, 215, '75', NULL, NULL);
INSERT INTO point VALUES (6150, 560, '78', NULL, NULL);
INSERT INTO point VALUES (6151, 620, '3', NULL, NULL);
INSERT INTO point VALUES (6152, 96, '4', NULL, NULL);
INSERT INTO point VALUES (6153, 560, '64', NULL, NULL);
INSERT INTO point VALUES (6154, 277, '29А', NULL, NULL);
INSERT INTO point VALUES (6155, 128, '2/2', NULL, NULL);
INSERT INTO point VALUES (6156, 214, '3', NULL, NULL);
INSERT INTO point VALUES (6157, 76, '22', NULL, NULL);
INSERT INTO point VALUES (6158, 120, '17', NULL, NULL);
INSERT INTO point VALUES (6159, 682, '6', NULL, NULL);
INSERT INTO point VALUES (6160, 397, '3', NULL, NULL);
INSERT INTO point VALUES (6161, 472, '5', NULL, NULL);
INSERT INTO point VALUES (6162, 153, '95', NULL, NULL);
INSERT INTO point VALUES (6163, 465, '28', NULL, NULL);
INSERT INTO point VALUES (6164, 277, '35', NULL, NULL);
INSERT INTO point VALUES (6165, 512, '4/2', NULL, NULL);
INSERT INTO point VALUES (6166, 419, '18', NULL, NULL);
INSERT INTO point VALUES (6167, 131, '18/2', NULL, NULL);
INSERT INTO point VALUES (6168, 181, '54', NULL, NULL);
INSERT INTO point VALUES (6169, 233, '11', NULL, NULL);
INSERT INTO point VALUES (6170, 81, '16', NULL, NULL);
INSERT INTO point VALUES (6171, 362, '26', NULL, NULL);
INSERT INTO point VALUES (6172, 389, '48Б', NULL, NULL);
INSERT INTO point VALUES (6173, 100, '81', NULL, NULL);
INSERT INTO point VALUES (6174, 598, '5', NULL, NULL);
INSERT INTO point VALUES (6175, 639, '1', NULL, NULL);
INSERT INTO point VALUES (6176, 372, '6', NULL, NULL);
INSERT INTO point VALUES (6177, 84, '13', NULL, NULL);
INSERT INTO point VALUES (6178, 180, '23', NULL, NULL);
INSERT INTO point VALUES (6179, 658, '20', NULL, NULL);
INSERT INTO point VALUES (6180, 223, '15', NULL, NULL);
INSERT INTO point VALUES (6181, 665, '17', NULL, NULL);
INSERT INTO point VALUES (6182, 304, '31', NULL, NULL);
INSERT INTO point VALUES (6183, 431, '2', NULL, NULL);
INSERT INTO point VALUES (6184, 636, '18', NULL, NULL);
INSERT INTO point VALUES (6185, 163, '42', NULL, NULL);
INSERT INTO point VALUES (6186, 569, '11', NULL, NULL);
INSERT INTO point VALUES (6187, 601, '112', NULL, NULL);
INSERT INTO point VALUES (6188, 384, '3', NULL, NULL);
INSERT INTO point VALUES (6189, 110, '46', NULL, NULL);
INSERT INTO point VALUES (6190, 294, '25б', NULL, NULL);
INSERT INTO point VALUES (6191, 464, '30', NULL, NULL);
INSERT INTO point VALUES (6192, 488, '13', NULL, NULL);
INSERT INTO point VALUES (6193, 304, '41', NULL, NULL);
INSERT INTO point VALUES (6194, 175, '9', NULL, NULL);
INSERT INTO point VALUES (6195, 57, '28', NULL, NULL);
INSERT INTO point VALUES (6196, 161, '5', NULL, NULL);
INSERT INTO point VALUES (6197, 499, '11', NULL, NULL);
INSERT INTO point VALUES (6198, 472, '2', NULL, NULL);
INSERT INTO point VALUES (6199, 352, '8', NULL, NULL);
INSERT INTO point VALUES (6200, 210, '25', NULL, NULL);
INSERT INTO point VALUES (6201, 111, '14', NULL, NULL);
INSERT INTO point VALUES (6202, 20, '12', NULL, NULL);
INSERT INTO point VALUES (6203, 562, '14', NULL, NULL);
INSERT INTO point VALUES (6204, 566, '34/1', NULL, NULL);
INSERT INTO point VALUES (6205, 260, '15', NULL, NULL);
INSERT INTO point VALUES (6206, 473, '31', NULL, NULL);
INSERT INTO point VALUES (6207, 362, '9', NULL, NULL);
INSERT INTO point VALUES (6208, 473, '41', NULL, NULL);
INSERT INTO point VALUES (6209, 501, '16', NULL, NULL);
INSERT INTO point VALUES (6210, 125, '18', NULL, NULL);
INSERT INTO point VALUES (6211, 639, '19', NULL, NULL);
INSERT INTO point VALUES (6212, 660, '8', NULL, NULL);
INSERT INTO point VALUES (6213, 518, '12', NULL, NULL);
INSERT INTO point VALUES (6214, 464, '28Е', NULL, NULL);
INSERT INTO point VALUES (6215, 544, '29', NULL, NULL);
INSERT INTO point VALUES (6216, 617, '27', NULL, NULL);
INSERT INTO point VALUES (6217, 106, '3', NULL, NULL);
INSERT INTO point VALUES (6218, 235, '40', NULL, NULL);
INSERT INTO point VALUES (6219, 269, '20', NULL, NULL);
INSERT INTO point VALUES (6220, 654, '4', NULL, NULL);
INSERT INTO point VALUES (6221, 354, '16', NULL, NULL);
INSERT INTO point VALUES (6222, 53, '86', NULL, NULL);
INSERT INTO point VALUES (6223, 679, '4', NULL, NULL);
INSERT INTO point VALUES (6224, 496, '48/2', NULL, NULL);
INSERT INTO point VALUES (6225, 693, '23', NULL, NULL);
INSERT INTO point VALUES (6226, 558, '20', NULL, NULL);
INSERT INTO point VALUES (6227, 199, '6', NULL, NULL);
INSERT INTO point VALUES (6228, 92, '14', NULL, NULL);
INSERT INTO point VALUES (6229, 468, '18', NULL, NULL);
INSERT INTO point VALUES (6230, 548, '50А', NULL, NULL);
INSERT INTO point VALUES (6231, 210, '7', NULL, NULL);
INSERT INTO point VALUES (6232, 375, '48', NULL, NULL);
INSERT INTO point VALUES (6233, 455, '24', NULL, NULL);
INSERT INTO point VALUES (6234, 265, '29/2', NULL, NULL);
INSERT INTO point VALUES (6235, 61, '10', NULL, NULL);
INSERT INTO point VALUES (6236, 277, '74', NULL, NULL);
INSERT INTO point VALUES (6237, 502, '8', NULL, NULL);
INSERT INTO point VALUES (6238, 236, '37', NULL, NULL);
INSERT INTO point VALUES (6239, 335, '3', NULL, NULL);
INSERT INTO point VALUES (6240, 88, '43', NULL, NULL);
INSERT INTO point VALUES (6241, 560, '9', NULL, NULL);
INSERT INTO point VALUES (6242, 44, '14', NULL, NULL);
INSERT INTO point VALUES (6243, 670, '9', NULL, NULL);
INSERT INTO point VALUES (6244, 354, '20', NULL, NULL);
INSERT INTO point VALUES (6245, 291, '10', NULL, NULL);
INSERT INTO point VALUES (6246, 558, '16', NULL, NULL);
INSERT INTO point VALUES (6247, 405, '12', NULL, NULL);
INSERT INTO point VALUES (6248, 164, '4', NULL, NULL);
INSERT INTO point VALUES (6249, 615, '5', NULL, NULL);
INSERT INTO point VALUES (6250, 67, '16', NULL, NULL);
INSERT INTO point VALUES (6251, 539, '37', NULL, NULL);
INSERT INTO point VALUES (6252, 27, '3', NULL, NULL);
INSERT INTO point VALUES (6253, 71, '3А', NULL, NULL);
INSERT INTO point VALUES (6254, 696, '11', NULL, NULL);
INSERT INTO point VALUES (6255, 304, '54', NULL, NULL);
INSERT INTO point VALUES (6256, 415, '71', NULL, NULL);
INSERT INTO point VALUES (6257, 137, '12', NULL, NULL);
INSERT INTO point VALUES (6258, 374, '149', NULL, NULL);
INSERT INTO point VALUES (6259, 259, '10', NULL, NULL);
INSERT INTO point VALUES (6260, 447, '23', NULL, NULL);
INSERT INTO point VALUES (6261, 389, '45А', NULL, NULL);
INSERT INTO point VALUES (6262, 235, '30', NULL, NULL);
INSERT INTO point VALUES (6263, 688, '16', NULL, NULL);
INSERT INTO point VALUES (6264, 501, '20', NULL, NULL);
INSERT INTO point VALUES (6265, 458, '73', NULL, NULL);
INSERT INTO point VALUES (6266, 607, '22', NULL, NULL);
INSERT INTO point VALUES (6267, 169, '21', NULL, NULL);
INSERT INTO point VALUES (6268, 480, '36', NULL, NULL);
INSERT INTO point VALUES (6269, 658, '16', NULL, NULL);
INSERT INTO point VALUES (6270, 566, '41', NULL, NULL);
INSERT INTO point VALUES (6271, 261, '11', NULL, NULL);
INSERT INTO point VALUES (6272, 382, '12', NULL, NULL);
INSERT INTO point VALUES (6273, 556, '41', NULL, NULL);
INSERT INTO point VALUES (6274, 120, '39', NULL, NULL);
INSERT INTO point VALUES (6275, 338, '22', NULL, NULL);
INSERT INTO point VALUES (6276, 434, '46', NULL, NULL);
INSERT INTO point VALUES (6277, 111, '36/1', NULL, NULL);
INSERT INTO point VALUES (6278, 496, '127Б', NULL, NULL);
INSERT INTO point VALUES (6279, 23, '11а', NULL, NULL);
INSERT INTO point VALUES (6280, 94, '19', NULL, NULL);
INSERT INTO point VALUES (6281, 601, '138', NULL, NULL);
INSERT INTO point VALUES (6282, 464, '40', NULL, NULL);
INSERT INTO point VALUES (6283, 425, '86', NULL, NULL);
INSERT INTO point VALUES (6284, 615, '2', NULL, NULL);
INSERT INTO point VALUES (6285, 478, '55', NULL, NULL);
INSERT INTO point VALUES (6286, 496, '17/3', NULL, NULL);
INSERT INTO point VALUES (6287, 489, '27', NULL, NULL);
INSERT INTO point VALUES (6288, 345, '5', NULL, NULL);
INSERT INTO point VALUES (6289, 46, '11', NULL, NULL);
INSERT INTO point VALUES (6290, 169, '12', NULL, NULL);
INSERT INTO point VALUES (6291, 87, '12', NULL, NULL);
INSERT INTO point VALUES (6292, 362, '34', NULL, NULL);
INSERT INTO point VALUES (6293, 395, '15/1', NULL, NULL);
INSERT INTO point VALUES (6294, 236, '55', NULL, NULL);
INSERT INTO point VALUES (6295, 335, '15', NULL, NULL);
INSERT INTO point VALUES (6296, 480, '8', NULL, NULL);
INSERT INTO point VALUES (6297, 183, '49', NULL, NULL);
INSERT INTO point VALUES (6298, 394, '36', NULL, NULL);
INSERT INTO point VALUES (6299, 201, '36А', NULL, NULL);
INSERT INTO point VALUES (6300, 531, '149', NULL, NULL);
INSERT INTO point VALUES (6301, 601, '48', NULL, NULL);
INSERT INTO point VALUES (6302, 137, '21', NULL, NULL);
INSERT INTO point VALUES (6303, 193, '6', NULL, NULL);
INSERT INTO point VALUES (6304, 221, '23', NULL, NULL);
INSERT INTO point VALUES (6305, 419, '8', NULL, NULL);
INSERT INTO point VALUES (6306, 220, '17', NULL, NULL);
INSERT INTO point VALUES (6307, 176, '17', NULL, NULL);
INSERT INTO point VALUES (6308, 405, '21', NULL, NULL);
INSERT INTO point VALUES (6309, 566, '16', NULL, NULL);
INSERT INTO point VALUES (6310, 250, '64А', NULL, NULL);
INSERT INTO point VALUES (6311, 643, '23', NULL, NULL);
INSERT INTO point VALUES (6312, 411, '33', NULL, NULL);
INSERT INTO point VALUES (6313, 525, '5А', NULL, NULL);
INSERT INTO point VALUES (6314, 601, '79', NULL, NULL);
INSERT INTO point VALUES (6315, 499, '13', NULL, NULL);
INSERT INTO point VALUES (6316, 586, '95', NULL, NULL);
INSERT INTO point VALUES (6317, 254, '46', NULL, NULL);
INSERT INTO point VALUES (6318, 213, '10', NULL, NULL);
INSERT INTO point VALUES (6319, 521, '11', NULL, NULL);
INSERT INTO point VALUES (6320, 658, '31', NULL, NULL);
INSERT INTO point VALUES (6321, 27, '15', NULL, NULL);
INSERT INTO point VALUES (6322, 431, '17', NULL, NULL);
INSERT INTO point VALUES (6323, 390, '4', NULL, NULL);
INSERT INTO point VALUES (6324, 49, '42', NULL, NULL);
INSERT INTO point VALUES (6325, 235, '53', NULL, NULL);
INSERT INTO point VALUES (6326, 569, '13', NULL, NULL);
INSERT INTO point VALUES (6327, 352, '18', NULL, NULL);
INSERT INTO point VALUES (6328, 374, '95/2', NULL, NULL);
INSERT INTO point VALUES (6329, 125, '8', NULL, NULL);
INSERT INTO point VALUES (6330, 488, '11', NULL, NULL);
INSERT INTO point VALUES (6331, 598, '17', NULL, NULL);
INSERT INTO point VALUES (6332, 67, '31', NULL, NULL);
INSERT INTO point VALUES (6333, 62, '4', NULL, NULL);
INSERT INTO point VALUES (6334, 465, '86', NULL, NULL);
INSERT INTO point VALUES (6335, 472, '17', NULL, NULL);
INSERT INTO point VALUES (6336, 120, '5', NULL, NULL);
INSERT INTO point VALUES (6337, 236, '73', NULL, NULL);
INSERT INTO point VALUES (6338, 473, '20', NULL, NULL);
INSERT INTO point VALUES (6339, 374, '165', NULL, NULL);
INSERT INTO point VALUES (6340, 549, '2', NULL, NULL);
INSERT INTO point VALUES (6341, 548, '49', NULL, NULL);
INSERT INTO point VALUES (6342, 525, '1А', NULL, NULL);
INSERT INTO point VALUES (6343, 310, '2', NULL, NULL);
INSERT INTO point VALUES (6344, 126, '35', NULL, NULL);
INSERT INTO point VALUES (6345, 665, '5', NULL, NULL);
INSERT INTO point VALUES (6346, 572, '27', NULL, NULL);
INSERT INTO point VALUES (6347, 445, '44', NULL, NULL);
INSERT INTO point VALUES (6348, 95, '38', NULL, NULL);
INSERT INTO point VALUES (6349, 433, '40', NULL, NULL);
INSERT INTO point VALUES (6350, 294, '55', NULL, NULL);
INSERT INTO point VALUES (6351, 161, '17', NULL, NULL);
INSERT INTO point VALUES (6352, 139, '14', NULL, NULL);
INSERT INTO point VALUES (6353, 99, '4', NULL, NULL);
INSERT INTO point VALUES (6354, 84, '11', NULL, NULL);
INSERT INTO point VALUES (6355, 594, '29', NULL, NULL);
INSERT INTO point VALUES (6356, 529, '18', NULL, NULL);
INSERT INTO point VALUES (6357, 269, '31', NULL, NULL);
INSERT INTO point VALUES (6358, 468, '8', NULL, NULL);
INSERT INTO point VALUES (6359, 575, '8', NULL, NULL);
INSERT INTO point VALUES (6360, 375, '58', NULL, NULL);
INSERT INTO point VALUES (6361, 352, '36', NULL, NULL);
INSERT INTO point VALUES (6362, 496, '87', NULL, NULL);
INSERT INTO point VALUES (6363, 178, '6', NULL, NULL);
INSERT INTO point VALUES (6364, 398, '1', NULL, NULL);
INSERT INTO point VALUES (6365, 509, '35', NULL, NULL);
INSERT INTO point VALUES (6366, 189, '8', NULL, NULL);
INSERT INTO point VALUES (6367, 42, '18', NULL, NULL);
INSERT INTO point VALUES (6368, 502, '18', NULL, NULL);
INSERT INTO point VALUES (6369, 46, '13', NULL, NULL);
INSERT INTO point VALUES (6370, 78, '9', NULL, NULL);
INSERT INTO point VALUES (6371, 598, '39', NULL, NULL);
INSERT INTO point VALUES (6372, 526, '6', NULL, NULL);
INSERT INTO point VALUES (6373, 523, '6', NULL, NULL);
INSERT INTO point VALUES (6374, 100, '9', NULL, NULL);
INSERT INTO point VALUES (6375, 638, '9', NULL, NULL);
INSERT INTO point VALUES (6376, 25, '25', NULL, NULL);
INSERT INTO point VALUES (6377, 51, '36', NULL, NULL);
INSERT INTO point VALUES (6378, 425, '28', NULL, NULL);
INSERT INTO point VALUES (6379, 223, '3', NULL, NULL);
INSERT INTO point VALUES (6380, 272, '3', NULL, NULL);
INSERT INTO point VALUES (6381, 389, '47', NULL, NULL);
INSERT INTO point VALUES (6382, 158, '9', NULL, NULL);
INSERT INTO point VALUES (6383, 345, '17', NULL, NULL);
INSERT INTO point VALUES (6384, 473, '16', NULL, NULL);
INSERT INTO point VALUES (6385, 131, '20/4', NULL, NULL);
INSERT INTO point VALUES (6386, 433, '30', NULL, NULL);
INSERT INTO point VALUES (6387, 696, '13', NULL, NULL);
INSERT INTO point VALUES (6388, 464, '53', NULL, NULL);
INSERT INTO point VALUES (6389, 577, '15', NULL, NULL);
INSERT INTO point VALUES (6390, 157, '24', NULL, NULL);
INSERT INTO point VALUES (6391, 451, '74Б', NULL, NULL);
INSERT INTO point VALUES (6392, 265, '50А', NULL, NULL);
INSERT INTO point VALUES (6393, 235, '51', NULL, NULL);
INSERT INTO point VALUES (6394, 19, '19', NULL, NULL);
INSERT INTO point VALUES (6395, 398, '19', NULL, NULL);
INSERT INTO point VALUES (6396, 269, '25/1', NULL, NULL);
INSERT INTO point VALUES (6397, 339, '10', NULL, NULL);
INSERT INTO point VALUES (6398, 639, '4', NULL, NULL);
INSERT INTO point VALUES (6399, 604, '196', NULL, NULL);
INSERT INTO point VALUES (6400, 394, '18', NULL, NULL);
INSERT INTO point VALUES (6401, 213, '43', NULL, NULL);
INSERT INTO point VALUES (6402, 303, '8', NULL, NULL);
INSERT INTO point VALUES (6403, 191, '29', NULL, NULL);
INSERT INTO point VALUES (6404, 67, '54', NULL, NULL);
INSERT INTO point VALUES (6405, 260, '3', NULL, NULL);
INSERT INTO point VALUES (6406, 389, '38', NULL, NULL);
INSERT INTO point VALUES (6407, 250, '71', NULL, NULL);
INSERT INTO point VALUES (6408, 25, '32', NULL, NULL);
INSERT INTO point VALUES (6409, 119, '10', NULL, NULL);
INSERT INTO point VALUES (6410, 554, '88', NULL, NULL);
INSERT INTO point VALUES (6411, 176, '39', NULL, NULL);
INSERT INTO point VALUES (6412, 188, '3', NULL, NULL);
INSERT INTO point VALUES (6413, 600, '59', NULL, NULL);
INSERT INTO point VALUES (6414, 452, '15', NULL, NULL);
INSERT INTO point VALUES (6415, 431, '39', NULL, NULL);
INSERT INTO point VALUES (6416, 531, '60', NULL, NULL);
INSERT INTO point VALUES (6417, 654, '19', NULL, NULL);
INSERT INTO point VALUES (6418, 157, '33', NULL, NULL);
INSERT INTO point VALUES (6419, 285, '15', NULL, NULL);
INSERT INTO point VALUES (6420, 342, '27', NULL, NULL);
INSERT INTO point VALUES (6421, 142, '37', NULL, NULL);
INSERT INTO point VALUES (6422, 435, '59', NULL, NULL);
INSERT INTO point VALUES (6423, 649, '28', NULL, NULL);
INSERT INTO point VALUES (6424, 191, '2', NULL, NULL);
INSERT INTO point VALUES (6425, 489, '25', NULL, NULL);
INSERT INTO point VALUES (6426, 635, '22', NULL, NULL);
INSERT INTO point VALUES (6427, 389, '54', NULL, NULL);
INSERT INTO point VALUES (6428, 572, '4А', NULL, NULL);
INSERT INTO point VALUES (6429, 525, '12', NULL, NULL);
INSERT INTO point VALUES (6430, 589, '20', NULL, NULL);
INSERT INTO point VALUES (6431, 91, '19', NULL, NULL);
INSERT INTO point VALUES (6432, 451, '39Б', NULL, NULL);
INSERT INTO point VALUES (6433, 666, '33', NULL, NULL);
INSERT INTO point VALUES (6434, 499, '1', NULL, NULL);
INSERT INTO point VALUES (6435, 477, '34', NULL, NULL);
INSERT INTO point VALUES (6436, 311, '17', NULL, NULL);
INSERT INTO point VALUES (6437, 285, '16Б', NULL, NULL);
INSERT INTO point VALUES (6438, 435, '62', NULL, NULL);
INSERT INTO point VALUES (6439, 464, '28Г', NULL, NULL);
INSERT INTO point VALUES (6440, 208, '17', NULL, NULL);
INSERT INTO point VALUES (6441, 377, '16', NULL, NULL);
INSERT INTO point VALUES (6442, 75, '39', NULL, NULL);
INSERT INTO point VALUES (6443, 487, '53', NULL, NULL);
INSERT INTO point VALUES (6444, 396, '30', NULL, NULL);
INSERT INTO point VALUES (6445, 26, '37', NULL, NULL);
INSERT INTO point VALUES (6446, 40, '26', NULL, NULL);
INSERT INTO point VALUES (6447, 558, '38', NULL, NULL);
INSERT INTO point VALUES (6448, 694, '8', NULL, NULL);
INSERT INTO point VALUES (6449, 338, '60', NULL, NULL);
INSERT INTO point VALUES (6450, 569, '19', NULL, NULL);
INSERT INTO point VALUES (6451, 531, '151', NULL, NULL);
INSERT INTO point VALUES (6452, 413, '7', NULL, NULL);
INSERT INTO point VALUES (6453, 663, '17', NULL, NULL);
INSERT INTO point VALUES (6454, 362, '35', NULL, NULL);
INSERT INTO point VALUES (6455, 294, '133', NULL, NULL);
INSERT INTO point VALUES (6456, 277, '26', NULL, NULL);
INSERT INTO point VALUES (6457, 168, '14', NULL, NULL);
INSERT INTO point VALUES (6458, 415, '49', NULL, NULL);
INSERT INTO point VALUES (6459, 445, '42', NULL, NULL);
INSERT INTO point VALUES (6460, 425, '45', NULL, NULL);
INSERT INTO point VALUES (6461, 411, '42', NULL, NULL);
INSERT INTO point VALUES (6462, 98, '8/1', NULL, NULL);
INSERT INTO point VALUES (6463, 480, '23', NULL, NULL);
INSERT INTO point VALUES (6464, 572, '2б', NULL, NULL);
INSERT INTO point VALUES (6465, 23, '12', NULL, NULL);
INSERT INTO point VALUES (6466, 499, '19', NULL, NULL);
INSERT INTO point VALUES (6467, 617, '7', NULL, NULL);
INSERT INTO point VALUES (6468, 201, '73', NULL, NULL);
INSERT INTO point VALUES (6469, 666, '44', NULL, NULL);
INSERT INTO point VALUES (6470, 451, '58', NULL, NULL);
INSERT INTO point VALUES (6471, 254, '30', NULL, NULL);
INSERT INTO point VALUES (6472, 40, '9', NULL, NULL);
INSERT INTO point VALUES (6473, 277, '80', NULL, NULL);
INSERT INTO point VALUES (6474, 389, '28А', NULL, NULL);
INSERT INTO point VALUES (6475, 636, '23', NULL, NULL);
INSERT INTO point VALUES (6476, 277, '9', NULL, NULL);
INSERT INTO point VALUES (6477, 169, '1А', NULL, NULL);
INSERT INTO point VALUES (6478, 180, '18', NULL, NULL);
INSERT INTO point VALUES (6479, 451, '12', NULL, NULL);
INSERT INTO point VALUES (6480, 658, '38', NULL, NULL);
INSERT INTO point VALUES (6481, 49, '44', NULL, NULL);
INSERT INTO point VALUES (6482, 696, '18Б', NULL, NULL);
INSERT INTO point VALUES (6483, 560, '74', NULL, NULL);
INSERT INTO point VALUES (6484, 47, '9А', NULL, NULL);
INSERT INTO point VALUES (6485, 234, '21', NULL, NULL);
INSERT INTO point VALUES (6486, 458, '68', NULL, NULL);
INSERT INTO point VALUES (6487, 394, '32Б', NULL, NULL);
INSERT INTO point VALUES (6488, 178, '10', NULL, NULL);
INSERT INTO point VALUES (6489, 389, '31', NULL, NULL);
INSERT INTO point VALUES (6490, 496, '37', NULL, NULL);
INSERT INTO point VALUES (6491, 268, '14', NULL, NULL);
INSERT INTO point VALUES (6492, 624, '70', NULL, NULL);
INSERT INTO point VALUES (6493, 114, '41', NULL, NULL);
INSERT INTO point VALUES (6494, 582, '5', NULL, NULL);
INSERT INTO point VALUES (6495, 261, '1', NULL, NULL);
INSERT INTO point VALUES (6496, 254, '40', NULL, NULL);
INSERT INTO point VALUES (6497, 654, '13', NULL, NULL);
INSERT INTO point VALUES (6498, 451, '57', NULL, NULL);
INSERT INTO point VALUES (6499, 544, '17', NULL, NULL);
INSERT INTO point VALUES (6500, 678, '24', NULL, NULL);
INSERT INTO point VALUES (6501, 679, '13', NULL, NULL);
INSERT INTO point VALUES (6502, 114, '31', NULL, NULL);
INSERT INTO point VALUES (6503, 526, '10', NULL, NULL);
INSERT INTO point VALUES (6504, 451, '60/4', NULL, NULL);
INSERT INTO point VALUES (6505, 425, '3', NULL, NULL);
INSERT INTO point VALUES (6506, 389, '41', NULL, NULL);
INSERT INTO point VALUES (6507, 57, '15', NULL, NULL);
INSERT INTO point VALUES (6508, 280, '72', NULL, NULL);
INSERT INTO point VALUES (6509, 46, '1', NULL, NULL);
INSERT INTO point VALUES (6510, 523, '10', NULL, NULL);
INSERT INTO point VALUES (6511, 624, '68', NULL, NULL);
INSERT INTO point VALUES (6512, 487, '51', NULL, NULL);
INSERT INTO point VALUES (6513, 7, '1А', NULL, NULL);
INSERT INTO point VALUES (6514, 12, '79', NULL, NULL);
INSERT INTO point VALUES (6515, 531, '220', NULL, NULL);
INSERT INTO point VALUES (6516, 180, '36', NULL, NULL);
INSERT INTO point VALUES (6517, 172, '22;12', NULL, NULL);
INSERT INTO point VALUES (6518, 226, '9', NULL, NULL);
INSERT INTO point VALUES (6519, 210, '27', NULL, NULL);
INSERT INTO point VALUES (6520, 692, '8', NULL, NULL);
INSERT INTO point VALUES (6521, 374, '22', NULL, NULL);
INSERT INTO point VALUES (6522, 2, '5', NULL, NULL);
INSERT INTO point VALUES (6523, 521, '4', NULL, NULL);
INSERT INTO point VALUES (6524, 13, '9', NULL, NULL);
INSERT INTO point VALUES (6525, 398, '13', NULL, NULL);
INSERT INTO point VALUES (6526, 696, '19', NULL, NULL);
INSERT INTO point VALUES (6527, 604, '202', NULL, NULL);
INSERT INTO point VALUES (6528, 614, '5', NULL, NULL);
INSERT INTO point VALUES (6529, 339, '6', NULL, NULL);
INSERT INTO point VALUES (6530, 261, '19', NULL, NULL);
INSERT INTO point VALUES (6531, 390, '11', NULL, NULL);
INSERT INTO point VALUES (6532, 374, '93', NULL, NULL);
INSERT INTO point VALUES (6533, 489, '7', NULL, NULL);
INSERT INTO point VALUES (6534, 433, '46', NULL, NULL);
INSERT INTO point VALUES (6535, 643, '11А', NULL, NULL);
INSERT INTO point VALUES (6536, 133, '30', NULL, NULL);
INSERT INTO point VALUES (6537, 582, '2', NULL, NULL);
INSERT INTO point VALUES (6538, 505, '5', NULL, NULL);
INSERT INTO point VALUES (6539, 34, '5', NULL, NULL);
INSERT INTO point VALUES (6540, 571, '25Б', NULL, NULL);
INSERT INTO point VALUES (6541, 604, '15/200а', NULL, NULL);
INSERT INTO point VALUES (6542, 664, '14', NULL, NULL);
INSERT INTO point VALUES (6543, 670, '35', NULL, NULL);
INSERT INTO point VALUES (6544, 539, '35/1', NULL, NULL);
INSERT INTO point VALUES (6545, 560, '35', NULL, NULL);
INSERT INTO point VALUES (6546, 75, '17', NULL, NULL);
INSERT INTO point VALUES (6547, 208, '39', NULL, NULL);
INSERT INTO point VALUES (6548, 119, '6', NULL, NULL);
INSERT INTO point VALUES (6549, 561, '17', NULL, NULL);
INSERT INTO point VALUES (6550, 76, '60', NULL, NULL);
INSERT INTO point VALUES (6551, 495, '12', NULL, NULL);
INSERT INTO point VALUES (6552, 94, '11', NULL, NULL);
INSERT INTO point VALUES (6553, 696, '1', NULL, NULL);
INSERT INTO point VALUES (6554, 100, '83Г', NULL, NULL);
INSERT INTO point VALUES (6555, 290, '3', NULL, NULL);
INSERT INTO point VALUES (6556, 277, '64', NULL, NULL);
INSERT INTO point VALUES (6557, 277, '78', NULL, NULL);
INSERT INTO point VALUES (6558, 447, '18', NULL, NULL);
INSERT INTO point VALUES (6559, 152, '15', NULL, NULL);
INSERT INTO point VALUES (6560, 115, '4', NULL, NULL);
INSERT INTO point VALUES (6561, 536, '15', NULL, NULL);
INSERT INTO point VALUES (6562, 47, '25', NULL, NULL);
INSERT INTO point VALUES (6563, 183, '11', NULL, NULL);
INSERT INTO point VALUES (6564, 604, '195', NULL, NULL);
INSERT INTO point VALUES (6565, 377, '6', NULL, NULL);
INSERT INTO point VALUES (6566, 339, '20', NULL, NULL);
INSERT INTO point VALUES (6567, 585, '28', NULL, NULL);
INSERT INTO point VALUES (6568, 213, '16', NULL, NULL);
INSERT INTO point VALUES (6569, 636, '25', NULL, NULL);
INSERT INTO point VALUES (6570, 495, '11/1', NULL, NULL);
INSERT INTO point VALUES (6571, 161, '35', NULL, NULL);
INSERT INTO point VALUES (6572, 578, '10', NULL, NULL);
INSERT INTO point VALUES (6573, 304, '43', NULL, NULL);
INSERT INTO point VALUES (6574, 100, '89', NULL, NULL);
INSERT INTO point VALUES (6575, 361, '5', NULL, NULL);
INSERT INTO point VALUES (6576, 464, '34/3', NULL, NULL);
INSERT INTO point VALUES (6577, 406, '3', NULL, NULL);
INSERT INTO point VALUES (6578, 334, '3', NULL, NULL);
INSERT INTO point VALUES (6579, 531, '153', NULL, NULL);
INSERT INTO point VALUES (6580, 416, '6', NULL, NULL);
INSERT INTO point VALUES (6581, 547, '10', NULL, NULL);
INSERT INTO point VALUES (6582, 262, '1А', NULL, NULL);
INSERT INTO point VALUES (6583, 119, '20', NULL, NULL);
INSERT INTO point VALUES (6584, 598, '29А', NULL, NULL);
INSERT INTO point VALUES (6585, 447, '27', NULL, NULL);
INSERT INTO point VALUES (6586, 480, '25', NULL, NULL);
INSERT INTO point VALUES (6587, 277, '5', NULL, NULL);
INSERT INTO point VALUES (6588, 32, '6', NULL, NULL);
INSERT INTO point VALUES (6589, 598, '35', NULL, NULL);
INSERT INTO point VALUES (6590, 448, '11', NULL, NULL);
INSERT INTO point VALUES (6591, 303, '7', NULL, NULL);
INSERT INTO point VALUES (6592, 40, '5', NULL, NULL);
INSERT INTO point VALUES (6593, 531, '28', NULL, NULL);
INSERT INTO point VALUES (6594, 489, '8А', NULL, NULL);
INSERT INTO point VALUES (6595, 87, '51', NULL, NULL);
INSERT INTO point VALUES (6596, 389, '32 кб', NULL, NULL);
INSERT INTO point VALUES (6597, 477, '17', NULL, NULL);
INSERT INTO point VALUES (6598, 78, '29', NULL, NULL);
INSERT INTO point VALUES (6599, 176, '35', NULL, NULL);
INSERT INTO point VALUES (6600, 144, '11', NULL, NULL);
INSERT INTO point VALUES (6601, 44, '4', NULL, NULL);
INSERT INTO point VALUES (6602, 265, '13', NULL, NULL);
INSERT INTO point VALUES (6603, 389, '45/3', NULL, NULL);
INSERT INTO point VALUES (6604, 483, '28', NULL, NULL);
INSERT INTO point VALUES (6605, 280, '68', NULL, NULL);
INSERT INTO point VALUES (6606, 61, '31', NULL, NULL);
INSERT INTO point VALUES (6607, 92, '4', NULL, NULL);
INSERT INTO point VALUES (6608, 687, '14А', NULL, NULL);
INSERT INTO point VALUES (6609, 431, '35', NULL, NULL);
INSERT INTO point VALUES (6610, 191, '26', NULL, NULL);
INSERT INTO point VALUES (6611, 437, '8', NULL, NULL);
INSERT INTO point VALUES (6612, 210, '18', NULL, NULL);
INSERT INTO point VALUES (6613, 277, '2', NULL, NULL);
INSERT INTO point VALUES (6614, 624, '72', NULL, NULL);
INSERT INTO point VALUES (6615, 117, '42', NULL, NULL);
INSERT INTO point VALUES (6616, 548, '11', NULL, NULL);
INSERT INTO point VALUES (6617, 489, '23', NULL, NULL);
INSERT INTO point VALUES (6618, 480, '32', NULL, NULL);
INSERT INTO point VALUES (6619, 425, '60', NULL, NULL);
INSERT INTO point VALUES (6620, 630, 'Отель', NULL, NULL);
INSERT INTO point VALUES (6621, 182, '2', NULL, NULL);
INSERT INTO point VALUES (6622, 67, '26А', NULL, NULL);
INSERT INTO point VALUES (6623, 283, '11', NULL, NULL);
INSERT INTO point VALUES (6624, 374, '98', NULL, NULL);
INSERT INTO point VALUES (6625, 100, '29', NULL, NULL);
INSERT INTO point VALUES (6626, 189, '7', NULL, NULL);
INSERT INTO point VALUES (6627, 280, '70', NULL, NULL);
INSERT INTO point VALUES (6628, 455, '56А', NULL, NULL);
INSERT INTO point VALUES (6629, 302, '3', NULL, NULL);
INSERT INTO point VALUES (6630, 464, '12', NULL, NULL);
INSERT INTO point VALUES (6631, 473, '43', NULL, NULL);
INSERT INTO point VALUES (6632, 285, '22', NULL, NULL);
INSERT INTO point VALUES (6633, 168, '13', NULL, NULL);
INSERT INTO point VALUES (6634, 174, '4', NULL, NULL);
INSERT INTO point VALUES (6635, 505, '9', NULL, NULL);
INSERT INTO point VALUES (6636, 582, '26', NULL, NULL);
INSERT INTO point VALUES (6637, 25, '8', NULL, NULL);
INSERT INTO point VALUES (6638, 19, '14', NULL, NULL);
INSERT INTO point VALUES (6639, 369, '45', NULL, NULL);
INSERT INTO point VALUES (6640, 562, '4', NULL, NULL);
INSERT INTO point VALUES (6641, 183, '50', NULL, NULL);
INSERT INTO point VALUES (6642, 372, '38', NULL, NULL);
INSERT INTO point VALUES (6643, 131, '6/1', NULL, NULL);
INSERT INTO point VALUES (6644, 607, '3', NULL, NULL);
INSERT INTO point VALUES (6645, 88, '31', NULL, NULL);
INSERT INTO point VALUES (6646, 601, '40', NULL, NULL);
INSERT INTO point VALUES (6647, 554, '19', NULL, NULL);
INSERT INTO point VALUES (6648, 166, '11', NULL, NULL);
INSERT INTO point VALUES (6649, 79, '12', NULL, NULL);
INSERT INTO point VALUES (6650, 589, '56', NULL, NULL);
INSERT INTO point VALUES (6651, 654, '14', NULL, NULL);
INSERT INTO point VALUES (6652, 13, '2', NULL, NULL);
INSERT INTO point VALUES (6653, 554, '137', NULL, NULL);
INSERT INTO point VALUES (6654, 273, '12', NULL, NULL);
INSERT INTO point VALUES (6655, 87, '53', NULL, NULL);
INSERT INTO point VALUES (6656, 88, '41', NULL, NULL);
INSERT INTO point VALUES (6657, 268, '13', NULL, NULL);
INSERT INTO point VALUES (6658, 560, '69', NULL, NULL);
INSERT INTO point VALUES (6659, 2, '26', NULL, NULL);
INSERT INTO point VALUES (6660, 219, '12', NULL, NULL);
INSERT INTO point VALUES (6661, 27, '22', NULL, NULL);
INSERT INTO point VALUES (6662, 180, '27', NULL, NULL);
INSERT INTO point VALUES (6663, 334, '45', NULL, NULL);
INSERT INTO point VALUES (6664, 657, '11', NULL, NULL);
INSERT INTO point VALUES (6665, 338, '3', NULL, NULL);
INSERT INTO point VALUES (6666, 373, '20', NULL, NULL);
INSERT INTO point VALUES (6667, 366, '6', NULL, NULL);
INSERT INTO point VALUES (6668, 235, '58', NULL, NULL);
INSERT INTO point VALUES (6669, 604, '15/200', NULL, NULL);
INSERT INTO point VALUES (6670, 294, '114', NULL, NULL);
INSERT INTO point VALUES (6671, 544, '34', NULL, NULL);
INSERT INTO point VALUES (6672, 386, '10Б', NULL, NULL);
INSERT INTO point VALUES (6673, 433, '48', NULL, NULL);
INSERT INTO point VALUES (6674, 582, '9', NULL, NULL);
INSERT INTO point VALUES (6675, 292, '22', NULL, NULL);
INSERT INTO point VALUES (6676, 374, '86', NULL, NULL);
INSERT INTO point VALUES (6677, 96, '14', NULL, NULL);
INSERT INTO point VALUES (6678, 480, '7', NULL, NULL);
INSERT INTO point VALUES (6679, 180, '12Б', NULL, NULL);
INSERT INTO point VALUES (6680, 693, '27', NULL, NULL);
INSERT INTO point VALUES (6681, 566, '43', NULL, NULL);
INSERT INTO point VALUES (6682, 339, '16', NULL, NULL);
INSERT INTO point VALUES (6683, 213, '20', NULL, NULL);
INSERT INTO point VALUES (6684, 226, '5', NULL, NULL);
INSERT INTO point VALUES (6685, 2, '9', NULL, NULL);
INSERT INTO point VALUES (6686, 304, '10', NULL, NULL);
INSERT INTO point VALUES (6687, 556, '43', NULL, NULL);
INSERT INTO point VALUES (6688, 6, '17', NULL, NULL);
INSERT INTO point VALUES (6689, 220, '22/7', NULL, NULL);
INSERT INTO point VALUES (6690, 548, '50', NULL, NULL);
INSERT INTO point VALUES (6691, 594, '26', NULL, NULL);
INSERT INTO point VALUES (6692, 509, '17', NULL, NULL);
INSERT INTO point VALUES (6693, 235, '12', NULL, NULL);
INSERT INTO point VALUES (6694, 39, '1', NULL, NULL);
INSERT INTO point VALUES (6695, 53, '60', NULL, NULL);
INSERT INTO point VALUES (6696, 192, '3', NULL, NULL);
INSERT INTO point VALUES (6697, 653, '37', NULL, NULL);
INSERT INTO point VALUES (6698, 419, '7', NULL, NULL);
INSERT INTO point VALUES (6699, 472, '34', NULL, NULL);
INSERT INTO point VALUES (6700, 377, '10', NULL, NULL);
INSERT INTO point VALUES (6701, 120, '9', NULL, NULL);
INSERT INTO point VALUES (6702, 61, '38', NULL, NULL);
INSERT INTO point VALUES (6703, 531, '3', NULL, NULL);
INSERT INTO point VALUES (6704, 110, '12', NULL, NULL);
INSERT INTO point VALUES (6705, 598, '34', NULL, NULL);
INSERT INTO point VALUES (6706, 601, '46', NULL, NULL);
INSERT INTO point VALUES (6707, 388, '4', NULL, NULL);
INSERT INTO point VALUES (6708, 566, '6', NULL, NULL);
INSERT INTO point VALUES (6709, 294, '11Б', NULL, NULL);
INSERT INTO point VALUES (6710, 499, '14', NULL, NULL);
INSERT INTO point VALUES (6711, 416, '10', NULL, NULL);
INSERT INTO point VALUES (6712, 517, '18', NULL, NULL);
INSERT INTO point VALUES (6713, 547, '6', NULL, NULL);
INSERT INTO point VALUES (6714, 376, '37', NULL, NULL);
INSERT INTO point VALUES (6715, 578, '6', NULL, NULL);
INSERT INTO point VALUES (6716, 111, '11', NULL, NULL);
INSERT INTO point VALUES (6717, 562, '11', NULL, NULL);
INSERT INTO point VALUES (6718, 563, '30', NULL, NULL);
INSERT INTO point VALUES (6719, 133, '21', NULL, NULL);
INSERT INTO point VALUES (6720, 76, '28', NULL, NULL);
INSERT INTO point VALUES (6721, 342, '18', NULL, NULL);
INSERT INTO point VALUES (6722, 279, '21', NULL, NULL);
INSERT INTO point VALUES (6723, 161, '34', NULL, NULL);
INSERT INTO point VALUES (6724, 12, '40', NULL, NULL);
INSERT INTO point VALUES (6725, 535, '7', NULL, NULL);
INSERT INTO point VALUES (6726, 489, '8', NULL, NULL);
INSERT INTO point VALUES (6727, 131, '8', NULL, NULL);
INSERT INTO point VALUES (6728, 389, '13/2', NULL, NULL);
INSERT INTO point VALUES (6729, 170, '15', NULL, NULL);
INSERT INTO point VALUES (6730, 265, '19', NULL, NULL);
INSERT INTO point VALUES (6731, 117, '24', NULL, NULL);
INSERT INTO point VALUES (6732, 665, '9', NULL, NULL);
INSERT INTO point VALUES (6733, 30, '3', NULL, NULL);
INSERT INTO point VALUES (6734, 333, '6', NULL, NULL);
INSERT INTO point VALUES (6735, 565, '7', NULL, NULL);
INSERT INTO point VALUES (6736, 374, '15', NULL, NULL);
INSERT INTO point VALUES (6737, 310, '26', NULL, NULL);
INSERT INTO point VALUES (6738, 465, '22', NULL, NULL);
INSERT INTO point VALUES (6739, 643, '25', NULL, NULL);
INSERT INTO point VALUES (6740, 415, '11', NULL, NULL);
INSERT INTO point VALUES (6741, 178, '20', NULL, NULL);
INSERT INTO point VALUES (6742, 139, '13', NULL, NULL);
INSERT INTO point VALUES (6743, 657, '4', NULL, NULL);
INSERT INTO point VALUES (6744, 560, '39', NULL, NULL);
INSERT INTO point VALUES (6745, 670, '39', NULL, NULL);
INSERT INTO point VALUES (6746, 277, '2А', NULL, NULL);
INSERT INTO point VALUES (6747, 117, '44', NULL, NULL);
INSERT INTO point VALUES (6748, 451, '51', NULL, NULL);
INSERT INTO point VALUES (6749, 183, '7А', NULL, NULL);
INSERT INTO point VALUES (6750, 362, '17', NULL, NULL);
INSERT INTO point VALUES (6751, 598, '20Б', NULL, NULL);
INSERT INTO point VALUES (6752, 431, '34', NULL, NULL);
INSERT INTO point VALUES (6753, 523, '20', NULL, NULL);
INSERT INTO point VALUES (6754, 277, '23/1', NULL, NULL);
INSERT INTO point VALUES (6755, 326, '15', NULL, NULL);
INSERT INTO point VALUES (6756, 347, '31', NULL, NULL);
INSERT INTO point VALUES (6757, 483, '3', NULL, NULL);
INSERT INTO point VALUES (6758, 334, '39/1', NULL, NULL);
INSERT INTO point VALUES (6759, 664, '18Б', NULL, NULL);
INSERT INTO point VALUES (6760, 601, '130', NULL, NULL);
INSERT INTO point VALUES (6761, 262, '12', NULL, NULL);
INSERT INTO point VALUES (6762, 646, '21', NULL, NULL);
INSERT INTO point VALUES (6763, 569, '14', NULL, NULL);
INSERT INTO point VALUES (6764, 572, '36', NULL, NULL);
INSERT INTO point VALUES (6765, 265, '1', NULL, NULL);
INSERT INTO point VALUES (6766, 176, '34', NULL, NULL);
INSERT INTO point VALUES (6767, 464, '46А', NULL, NULL);
INSERT INTO point VALUES (6768, 221, '25', NULL, NULL);
INSERT INTO point VALUES (6769, 340, '21', NULL, NULL);
INSERT INTO point VALUES (6770, 670, '17', NULL, NULL);
INSERT INTO point VALUES (6771, 560, '17', NULL, NULL);
INSERT INTO point VALUES (6772, 75, '35', NULL, NULL);
INSERT INTO point VALUES (6773, 523, '16', NULL, NULL);
INSERT INTO point VALUES (6774, 250, '52', NULL, NULL);
INSERT INTO point VALUES (6775, 420, 'Советская', NULL, NULL);
INSERT INTO point VALUES (6776, 448, '3/2', NULL, NULL);
INSERT INTO point VALUES (6777, 245, '41', NULL, NULL);
INSERT INTO point VALUES (6778, 115, '11', NULL, NULL);
INSERT INTO point VALUES (6779, 447, '31А', NULL, NULL);
INSERT INTO point VALUES (6780, 268, '1', NULL, NULL);
INSERT INTO point VALUES (6781, 183, '4', NULL, NULL);
INSERT INTO point VALUES (6782, 607, '28', NULL, NULL);
INSERT INTO point VALUES (6783, 304, '56', NULL, NULL);
INSERT INTO point VALUES (6784, 202, '32', NULL, NULL);
INSERT INTO point VALUES (6785, 542, '45', NULL, NULL);
INSERT INTO point VALUES (6786, 178, '16', NULL, NULL);
INSERT INTO point VALUES (6787, 451, '54А', NULL, NULL);
INSERT INTO point VALUES (6788, 46, '14', NULL, NULL);
INSERT INTO point VALUES (6789, 531, '96', NULL, NULL);
INSERT INTO point VALUES (6790, 565, '32', NULL, NULL);
INSERT INTO point VALUES (6791, 483, '45', NULL, NULL);
INSERT INTO point VALUES (6792, 496, '72', NULL, NULL);
INSERT INTO point VALUES (6793, 277, '29', NULL, NULL);
INSERT INTO point VALUES (6794, 170, '12/1', NULL, NULL);
INSERT INTO point VALUES (6795, 40, '29', NULL, NULL);
INSERT INTO point VALUES (6796, 59, '46В', NULL, NULL);
INSERT INTO point VALUES (6797, 572, '18', NULL, NULL);
INSERT INTO point VALUES (6798, 571, '33', NULL, NULL);
INSERT INTO point VALUES (6799, 70, '18', NULL, NULL);
INSERT INTO point VALUES (6800, 396, '21', NULL, NULL);
INSERT INTO point VALUES (6801, 78, '5', NULL, NULL);
INSERT INTO point VALUES (6802, 25, '23', NULL, NULL);
INSERT INTO point VALUES (6803, 554, '13', NULL, NULL);
INSERT INTO point VALUES (6804, 531, '45', NULL, NULL);
INSERT INTO point VALUES (6805, 552, '28', NULL, NULL);
INSERT INTO point VALUES (6806, 92, '11', NULL, NULL);
INSERT INTO point VALUES (6807, 589, '10', NULL, NULL);
INSERT INTO point VALUES (6808, 451, '53', NULL, NULL);
INSERT INTO point VALUES (6809, 283, '23А', NULL, NULL);
INSERT INTO point VALUES (6810, 560, '67', NULL, NULL);
INSERT INTO point VALUES (6811, 487, '49А', NULL, NULL);
INSERT INTO point VALUES (6812, 694, '7', NULL, NULL);
INSERT INTO point VALUES (6813, 130, '4', NULL, NULL);
INSERT INTO point VALUES (6814, 324, '30', NULL, NULL);
INSERT INTO point VALUES (6815, 283, '4', NULL, NULL);
INSERT INTO point VALUES (6816, 434, '12', NULL, NULL);
INSERT INTO point VALUES (6817, 48, '24', NULL, NULL);
INSERT INTO point VALUES (6818, 338, '28', NULL, NULL);
INSERT INTO point VALUES (6819, 170, '10/3', NULL, NULL);
INSERT INTO point VALUES (6820, 100, '5', NULL, NULL);
INSERT INTO point VALUES (6821, 544, '35', NULL, NULL);
INSERT INTO point VALUES (6822, 638, '5', NULL, NULL);
INSERT INTO point VALUES (6823, 12, '30', NULL, NULL);
INSERT INTO point VALUES (6824, 696, '14', NULL, NULL);
INSERT INTO point VALUES (6825, 185, '3', NULL, NULL);
INSERT INTO point VALUES (6826, 496, '100', NULL, NULL);
INSERT INTO point VALUES (6827, 304, '6', NULL, NULL);
INSERT INTO point VALUES (6828, 472, '23', NULL, NULL);
INSERT INTO point VALUES (6829, 184, '45', NULL, NULL);
INSERT INTO point VALUES (6830, 464, '67А', NULL, NULL);
INSERT INTO point VALUES (6831, 23, '20', NULL, NULL);
INSERT INTO point VALUES (6832, 598, '23', NULL, NULL);
INSERT INTO point VALUES (6833, 236, '52', NULL, NULL);
INSERT INTO point VALUES (6834, 311, '8', NULL, NULL);
INSERT INTO point VALUES (6835, 372, '40', NULL, NULL);
INSERT INTO point VALUES (6836, 496, '4', NULL, NULL);
INSERT INTO point VALUES (6837, 582, '36', NULL, NULL);
INSERT INTO point VALUES (6838, 53, '62', NULL, NULL);
INSERT INTO point VALUES (6839, 374, '44', NULL, NULL);
INSERT INTO point VALUES (6840, 235, '56', NULL, NULL);
INSERT INTO point VALUES (6841, 643, '67', NULL, NULL);
INSERT INTO point VALUES (6842, 161, '23', NULL, NULL);
INSERT INTO point VALUES (6843, 202, '39', NULL, NULL);
INSERT INTO point VALUES (6844, 451, '20', NULL, NULL);
INSERT INTO point VALUES (6845, 694, '17', NULL, NULL);
INSERT INTO point VALUES (6846, 496, '23А', NULL, NULL);
INSERT INTO point VALUES (6847, 663, '8', NULL, NULL);
INSERT INTO point VALUES (6848, 334, '6А', NULL, NULL);
INSERT INTO point VALUES (6849, 183, '44А', NULL, NULL);
INSERT INTO point VALUES (6850, 170, '12/4', NULL, NULL);
INSERT INTO point VALUES (6851, 435, '3', NULL, NULL);
INSERT INTO point VALUES (6852, 208, '8', NULL, NULL);
INSERT INTO point VALUES (6853, 180, '5', NULL, NULL);
INSERT INTO point VALUES (6854, 105, '13', NULL, NULL);
INSERT INTO point VALUES (6855, 273, '6', NULL, NULL);
INSERT INTO point VALUES (6856, 601, '38', NULL, NULL);
INSERT INTO point VALUES (6857, 693, '2', NULL, NULL);
INSERT INTO point VALUES (6858, 431, '8А', NULL, NULL);
INSERT INTO point VALUES (6859, 598, '38А', NULL, NULL);
INSERT INTO point VALUES (6860, 386, '6А', NULL, NULL);
INSERT INTO point VALUES (6861, 678, '22', NULL, NULL);
INSERT INTO point VALUES (6862, 664, '6Б', NULL, NULL);
INSERT INTO point VALUES (6863, 525, '20', NULL, NULL);
INSERT INTO point VALUES (6864, 323, '30', NULL, NULL);
INSERT INTO point VALUES (6865, 294, '152', NULL, NULL);
INSERT INTO point VALUES (6866, 626, '11', NULL, NULL);
INSERT INTO point VALUES (6867, 495, '16', NULL, NULL);
INSERT INTO point VALUES (6868, 150, '1', NULL, NULL);
INSERT INTO point VALUES (6869, 112, '3', NULL, NULL);
INSERT INTO point VALUES (6870, 374, '33', NULL, NULL);
INSERT INTO point VALUES (6871, 589, '12', NULL, NULL);
INSERT INTO point VALUES (6872, 170, '33', NULL, NULL);
INSERT INTO point VALUES (6873, 604, '10', NULL, NULL);
INSERT INTO point VALUES (6874, 601, '161', NULL, NULL);
INSERT INTO point VALUES (6875, 370, '5', NULL, NULL);
INSERT INTO point VALUES (6876, 431, '23', NULL, NULL);
INSERT INTO point VALUES (6877, 210, '9', NULL, NULL);
INSERT INTO point VALUES (6878, 594, '36', NULL, NULL);
INSERT INTO point VALUES (6879, 589, '58', NULL, NULL);
INSERT INTO point VALUES (6880, 434, '10', NULL, NULL);
INSERT INTO point VALUES (6881, 629, '11', NULL, NULL);
INSERT INTO point VALUES (6882, 389, '21', NULL, NULL);
INSERT INTO point VALUES (6883, 117, '15', NULL, NULL);
INSERT INTO point VALUES (6884, 458, '11', NULL, NULL);
INSERT INTO point VALUES (6885, 110, '43', NULL, NULL);
INSERT INTO point VALUES (6886, 693, '5', NULL, NULL);
INSERT INTO point VALUES (6887, 531, '135', NULL, NULL);
INSERT INTO point VALUES (6888, 528, '8', NULL, NULL);
INSERT INTO point VALUES (6889, 670, '7', NULL, NULL);
INSERT INTO point VALUES (6890, 235, '6', NULL, NULL);
INSERT INTO point VALUES (6891, 59, '14', NULL, NULL);
INSERT INTO point VALUES (6892, 176, '23', NULL, NULL);
INSERT INTO point VALUES (6893, 67, '118/1', NULL, NULL);
INSERT INTO point VALUES (6894, 114, '21', NULL, NULL);
INSERT INTO point VALUES (6895, 643, '17', NULL, NULL);
INSERT INTO point VALUES (6896, 3, '19', NULL, NULL);
INSERT INTO point VALUES (6897, 234, '41', NULL, NULL);
INSERT INTO point VALUES (6898, 544, '8', NULL, NULL);
INSERT INTO point VALUES (6899, 377, '12', NULL, NULL);
INSERT INTO point VALUES (6900, 425, '62', NULL, NULL);
INSERT INTO point VALUES (6901, 110, '10', NULL, NULL);
INSERT INTO point VALUES (6902, 256, '3', NULL, NULL);
INSERT INTO point VALUES (6903, 294, '13', NULL, NULL);
INSERT INTO point VALUES (6904, 614, '18', NULL, NULL);
INSERT INTO point VALUES (6905, 67, '96А', NULL, NULL);
INSERT INTO point VALUES (6906, 531, '160', NULL, NULL);
INSERT INTO point VALUES (6907, 464, '56', NULL, NULL);
INSERT INTO point VALUES (6908, 569, '55', NULL, NULL);
INSERT INTO point VALUES (6909, 252, '11', NULL, NULL);
INSERT INTO point VALUES (6910, 26, '4', NULL, NULL);
INSERT INTO point VALUES (6911, 615, '9А', NULL, NULL);
INSERT INTO point VALUES (6912, 447, '5', NULL, NULL);
INSERT INTO point VALUES (6913, 692, '17', NULL, NULL);
INSERT INTO point VALUES (6914, 531, '258', NULL, NULL);
INSERT INTO point VALUES (6915, 374, '127/1', NULL, NULL);
INSERT INTO point VALUES (6916, 687, '42', NULL, NULL);
INSERT INTO point VALUES (6917, 525, '16', NULL, NULL);
INSERT INTO point VALUES (6918, 40, '27', NULL, NULL);
INSERT INTO point VALUES (6919, 643, '39', NULL, NULL);
INSERT INTO point VALUES (6920, 351, '6', NULL, NULL);
INSERT INTO point VALUES (6921, 32, '12', NULL, NULL);
INSERT INTO point VALUES (6922, 670, '25', NULL, NULL);
INSERT INTO point VALUES (6923, 617, '35', NULL, NULL);
INSERT INTO point VALUES (6924, 565, '17', NULL, NULL);
INSERT INTO point VALUES (6925, 25, '34', NULL, NULL);
INSERT INTO point VALUES (6926, 191, '36', NULL, NULL);
INSERT INTO point VALUES (6927, 3, '1', NULL, NULL);
INSERT INTO point VALUES (6928, 451, '16', NULL, NULL);
INSERT INTO point VALUES (6929, 67, '83', NULL, NULL);
INSERT INTO point VALUES (6930, 541, '4', NULL, NULL);
INSERT INTO point VALUES (6931, 496, '7А', NULL, NULL);
INSERT INTO point VALUES (6932, 443, '3', NULL, NULL);
INSERT INTO point VALUES (6933, 582, '18', NULL, NULL);
INSERT INTO point VALUES (6934, 201, '1', NULL, NULL);
INSERT INTO point VALUES (6935, 535, '17', NULL, NULL);
INSERT INTO point VALUES (6936, 184, '3', NULL, NULL);
INSERT INTO point VALUES (6937, 24, '3', NULL, NULL);
INSERT INTO point VALUES (6938, 372, '30', NULL, NULL);
INSERT INTO point VALUES (6939, 175, '7', NULL, NULL);
INSERT INTO point VALUES (6940, 653, '49', NULL, NULL);
INSERT INTO point VALUES (6941, 169, '18А', NULL, NULL);
INSERT INTO point VALUES (6942, 389, '45/2', NULL, NULL);
INSERT INTO point VALUES (6943, 236, '13', NULL, NULL);
INSERT INTO point VALUES (6944, 566, '1А', NULL, NULL);
INSERT INTO point VALUES (6945, 478, '50', NULL, NULL);
INSERT INTO point VALUES (6946, 389, '48', NULL, NULL);
INSERT INTO point VALUES (6947, 142, '11', NULL, NULL);
INSERT INTO point VALUES (6948, 435, '45', NULL, NULL);
INSERT INTO point VALUES (6949, 271, '6А', NULL, NULL);
INSERT INTO point VALUES (6950, 325, '11', NULL, NULL);
INSERT INTO point VALUES (6951, 75, '8', NULL, NULL);
INSERT INTO point VALUES (6952, 561, '8', NULL, NULL);
INSERT INTO point VALUES (6953, 458, '50', NULL, NULL);
INSERT INTO point VALUES (6954, 170, '21А', NULL, NULL);
INSERT INTO point VALUES (6955, 278, '3', NULL, NULL);
INSERT INTO point VALUES (6956, 467, '9', NULL, NULL);
INSERT INTO point VALUES (6957, 294, '242', NULL, NULL);
INSERT INTO point VALUES (6958, 269, '13А', NULL, NULL);
INSERT INTO point VALUES (6959, 37, '66', NULL, NULL);
INSERT INTO point VALUES (6960, 120, '18', NULL, NULL);
INSERT INTO point VALUES (6961, 435, '28', NULL, NULL);
INSERT INTO point VALUES (6962, 509, '7', NULL, NULL);
INSERT INTO point VALUES (6963, 495, '18А', NULL, NULL);
INSERT INTO point VALUES (6964, 496, '50', NULL, NULL);
INSERT INTO point VALUES (6965, 224, '5', NULL, NULL);
INSERT INTO point VALUES (6966, 376, '49', NULL, NULL);
INSERT INTO point VALUES (6967, 220, '8', NULL, NULL);
INSERT INTO point VALUES (6968, 602, '20', NULL, NULL);
INSERT INTO point VALUES (6969, 105, '1', NULL, NULL);
INSERT INTO point VALUES (6970, 303, '39', NULL, NULL);
INSERT INTO point VALUES (6971, 419, '17', NULL, NULL);
INSERT INTO point VALUES (6972, 480, '17', NULL, NULL);
INSERT INTO point VALUES (6973, 537, '4', NULL, NULL);
INSERT INTO point VALUES (6974, 157, '22', NULL, NULL);
INSERT INTO point VALUES (6975, 516, '7', NULL, NULL);
INSERT INTO point VALUES (6976, 487, '6', NULL, NULL);
INSERT INTO point VALUES (6977, 67, '79', NULL, NULL);
INSERT INTO point VALUES (6978, 564, '7', NULL, NULL);
INSERT INTO point VALUES (6979, 600, '28', NULL, NULL);
INSERT INTO point VALUES (6980, 27, '2/1', NULL, NULL);
INSERT INTO point VALUES (6981, 464, '43', NULL, NULL);
INSERT INTO point VALUES (6982, 225, '1', NULL, NULL);
INSERT INTO point VALUES (6983, 342, '9', NULL, NULL);
INSERT INTO point VALUES (6984, 601, '72А', NULL, NULL);
INSERT INTO point VALUES (6985, 15, '24А', NULL, NULL);
INSERT INTO point VALUES (6986, 252, '4', NULL, NULL);
INSERT INTO point VALUES (6987, 26, '11', NULL, NULL);
INSERT INTO point VALUES (6988, 431, '8', NULL, NULL);
INSERT INTO point VALUES (6989, 374, '42', NULL, NULL);
INSERT INTO point VALUES (6990, 511, '25', NULL, NULL);
INSERT INTO point VALUES (6991, 79, '10', NULL, NULL);
INSERT INTO point VALUES (6992, 269, '11 к1', NULL, NULL);
INSERT INTO point VALUES (6993, 665, '18', NULL, NULL);
INSERT INTO point VALUES (6994, 477, '32', NULL, NULL);
INSERT INTO point VALUES (6995, 176, '8', NULL, NULL);
INSERT INTO point VALUES (6996, 273, '10', NULL, NULL);
INSERT INTO point VALUES (6997, 465, '76', NULL, NULL);
INSERT INTO point VALUES (6998, 447, '61', NULL, NULL);
INSERT INTO point VALUES (6999, 47, '17', NULL, NULL);
INSERT INTO point VALUES (7000, 74, '7', NULL, NULL);
INSERT INTO point VALUES (7001, 55, '42', NULL, NULL);
INSERT INTO point VALUES (7002, 9, '77', NULL, NULL);
INSERT INTO point VALUES (7003, 304, '58', NULL, NULL);
INSERT INTO point VALUES (7004, 87, '20', NULL, NULL);
INSERT INTO point VALUES (7005, 541, '11', NULL, NULL);
INSERT INTO point VALUES (7006, 643, '69', NULL, NULL);
INSERT INTO point VALUES (7007, 169, '20', NULL, NULL);
INSERT INTO point VALUES (7008, 78, '27', NULL, NULL);
INSERT INTO point VALUES (7009, 472, '8', NULL, NULL);
INSERT INTO point VALUES (7010, 604, '6', NULL, NULL);
INSERT INTO point VALUES (7011, 572, '33А', NULL, NULL);
INSERT INTO point VALUES (7012, 219, '14/1', NULL, NULL);
INSERT INTO point VALUES (7013, 660, '2', NULL, NULL);
INSERT INTO point VALUES (7014, 663, '23', NULL, NULL);
INSERT INTO point VALUES (7015, 337, '3', NULL, NULL);
INSERT INTO point VALUES (7016, 161, '8', NULL, NULL);
INSERT INTO point VALUES (7017, 601, '31', NULL, NULL);
INSERT INTO point VALUES (7018, 434, '6', NULL, NULL);
INSERT INTO point VALUES (7019, 513, '2', NULL, NULL);
INSERT INTO point VALUES (7020, 681, '31', NULL, NULL);
INSERT INTO point VALUES (7021, 310, '18', NULL, NULL);
INSERT INTO point VALUES (7022, 342, '26', NULL, NULL);
INSERT INTO point VALUES (7023, 438, '14', NULL, NULL);
INSERT INTO point VALUES (7024, 393, '15', NULL, NULL);
INSERT INTO point VALUES (7025, 598, '46Б', NULL, NULL);
INSERT INTO point VALUES (7026, 235, '10', NULL, NULL);
INSERT INTO point VALUES (7027, 374, '109', NULL, NULL);
INSERT INTO point VALUES (7028, 325, '4', NULL, NULL);
INSERT INTO point VALUES (7029, 100, '27', NULL, NULL);
INSERT INTO point VALUES (7030, 150, '13', NULL, NULL);
INSERT INTO point VALUES (7031, 477, '25', NULL, NULL);
INSERT INTO point VALUES (7032, 220, '22/4', NULL, NULL);
INSERT INTO point VALUES (7033, 599, '11', NULL, NULL);
INSERT INTO point VALUES (7034, 566, '12', NULL, NULL);
INSERT INTO point VALUES (7035, 601, '28А', NULL, NULL);
INSERT INTO point VALUES (7036, 384, '2/1', NULL, NULL);
INSERT INTO point VALUES (7037, 329, '14', NULL, NULL);
INSERT INTO point VALUES (7038, 393, '14А', NULL, NULL);
INSERT INTO point VALUES (7039, 613, '1', NULL, NULL);
INSERT INTO point VALUES (7040, 304, '57', NULL, NULL);
INSERT INTO point VALUES (7041, 394, '5', NULL, NULL);
INSERT INTO point VALUES (7042, 213, '51', NULL, NULL);
INSERT INTO point VALUES (7043, 269, '21', NULL, NULL);
INSERT INTO point VALUES (7044, 496, '11', NULL, NULL);
INSERT INTO point VALUES (7045, 42, '2', NULL, NULL);
INSERT INTO point VALUES (7046, 236, '19', NULL, NULL);
INSERT INTO point VALUES (7047, 433, '26А', NULL, NULL);
INSERT INTO point VALUES (7048, 169, '16', NULL, NULL);
INSERT INTO point VALUES (7049, 604, '208', NULL, NULL);
INSERT INTO point VALUES (7050, 695, '3', NULL, NULL);
INSERT INTO point VALUES (7051, 231, '20', NULL, NULL);
INSERT INTO point VALUES (7052, 628, '56', NULL, NULL);
INSERT INTO point VALUES (7053, 325, '7А', NULL, NULL);
INSERT INTO point VALUES (7054, 364, '9', NULL, NULL);
INSERT INTO point VALUES (7055, 310, '36', NULL, NULL);
INSERT INTO point VALUES (7056, 234, '47', NULL, NULL);
INSERT INTO point VALUES (7057, 372, '46', NULL, NULL);
INSERT INTO point VALUES (7058, 477, '7', NULL, NULL);
INSERT INTO point VALUES (7059, 569, '113 ка', NULL, NULL);
INSERT INTO point VALUES (7060, 374, '66', NULL, NULL);
INSERT INTO point VALUES (7061, 299, '14', NULL, NULL);
INSERT INTO point VALUES (7062, 180, '29', NULL, NULL);
INSERT INTO point VALUES (7063, 280, '49', NULL, NULL);
INSERT INTO point VALUES (7064, 561, '23', NULL, NULL);
INSERT INTO point VALUES (7065, 395, '15', NULL, NULL);
INSERT INTO point VALUES (7066, 572, '9', NULL, NULL);
INSERT INTO point VALUES (7067, 351, '10', NULL, NULL);
INSERT INTO point VALUES (7068, 12, '38', NULL, NULL);
INSERT INTO point VALUES (7069, 67, '21', NULL, NULL);
INSERT INTO point VALUES (7070, 531, '76А', NULL, NULL);
INSERT INTO point VALUES (7071, 282, '4', NULL, NULL);
INSERT INTO point VALUES (7072, 624, '4', NULL, NULL);
INSERT INTO point VALUES (7073, 120, '36', NULL, NULL);
INSERT INTO point VALUES (7074, 303, '17', NULL, NULL);
INSERT INTO point VALUES (7075, 374, '84А', NULL, NULL);
INSERT INTO point VALUES (7076, 42, '5', NULL, NULL);
INSERT INTO point VALUES (7077, 502, '5', NULL, NULL);
INSERT INTO point VALUES (7078, 509, '25', NULL, NULL);
INSERT INTO point VALUES (7079, 378, '7', NULL, NULL);
INSERT INTO point VALUES (7080, 544, '23', NULL, NULL);
INSERT INTO point VALUES (7081, 236, '1', NULL, NULL);
INSERT INTO point VALUES (7082, 71, '4', NULL, NULL);
INSERT INTO point VALUES (7083, 40, '4А', NULL, NULL);
INSERT INTO point VALUES (7084, 658, '21', NULL, NULL);
INSERT INTO point VALUES (7085, 480, '39', NULL, NULL);
INSERT INTO point VALUES (7086, 215, '109', NULL, NULL);
INSERT INTO point VALUES (7087, 285, '2/1', NULL, NULL);
INSERT INTO point VALUES (7088, 427, '28', NULL, NULL);
INSERT INTO point VALUES (7089, 458, '4', NULL, NULL);
INSERT INTO point VALUES (7090, 539, '1', NULL, NULL);
INSERT INTO point VALUES (7091, 294, '19', NULL, NULL);
INSERT INTO point VALUES (7092, 531, '126', NULL, NULL);
INSERT INTO point VALUES (7093, 601, '54', NULL, NULL);
INSERT INTO point VALUES (7094, 693, '29', NULL, NULL);
INSERT INTO point VALUES (7095, 566, '34/3', NULL, NULL);
INSERT INTO point VALUES (7096, 572, '26', NULL, NULL);
INSERT INTO point VALUES (7097, 294, '137', NULL, NULL);
INSERT INTO point VALUES (7098, 615, '8', NULL, NULL);
INSERT INTO point VALUES (7099, 364, '26', NULL, NULL);
INSERT INTO point VALUES (7100, 3, '13', NULL, NULL);
INSERT INTO point VALUES (7101, 687, '24', NULL, NULL);
INSERT INTO point VALUES (7102, 178, '12', NULL, NULL);
INSERT INTO point VALUES (7103, 663, '25', NULL, NULL);
INSERT INTO point VALUES (7104, 257, '5', NULL, NULL);
INSERT INTO point VALUES (7105, 467, '2', NULL, NULL);
INSERT INTO point VALUES (7106, 538, '14', NULL, NULL);
INSERT INTO point VALUES (7107, 352, '26', NULL, NULL);
INSERT INTO point VALUES (7108, 604, '190', NULL, NULL);
INSERT INTO point VALUES (7109, 374, '2/1', NULL, NULL);
INSERT INTO point VALUES (7110, 526, '12', NULL, NULL);
INSERT INTO point VALUES (7111, 183, '37', NULL, NULL);
INSERT INTO point VALUES (7112, 477, '23', NULL, NULL);
INSERT INTO point VALUES (7113, 643, '35', NULL, NULL);
INSERT INTO point VALUES (7114, 219, '16/2', NULL, NULL);
INSERT INTO point VALUES (7115, 531, '62', NULL, NULL);
INSERT INTO point VALUES (7116, 464, '26Б', NULL, NULL);
INSERT INTO point VALUES (7117, 561, '7', NULL, NULL);
INSERT INTO point VALUES (7118, 682, '21', NULL, NULL);
INSERT INTO point VALUES (7119, 53, '82', NULL, NULL);
INSERT INTO point VALUES (7120, 568, '5', NULL, NULL);
INSERT INTO point VALUES (7121, 372, '21', NULL, NULL);
INSERT INTO point VALUES (7122, 342, '2', NULL, NULL);
INSERT INTO point VALUES (7123, 451, '100/1', NULL, NULL);
INSERT INTO point VALUES (7124, 262, '20', NULL, NULL);
INSERT INTO point VALUES (7125, 504, '3', NULL, NULL);
INSERT INTO point VALUES (7126, 48, '22', NULL, NULL);
INSERT INTO point VALUES (7127, 489, '17', NULL, NULL);
INSERT INTO point VALUES (7128, 15, '23А', NULL, NULL);
INSERT INTO point VALUES (7129, 329, '51А', NULL, NULL);
INSERT INTO point VALUES (7130, 434, '16', NULL, NULL);
INSERT INTO point VALUES (7131, 183, '52/19', NULL, NULL);
INSERT INTO point VALUES (7132, 16, '5', NULL, NULL);
INSERT INTO point VALUES (7133, 150, '14', NULL, NULL);
INSERT INTO point VALUES (7134, 199, '21', NULL, NULL);
INSERT INTO point VALUES (7135, 49, '15', NULL, NULL);
INSERT INTO point VALUES (7136, 699, '8', NULL, NULL);
INSERT INTO point VALUES (7137, 480, '34', NULL, NULL);
INSERT INTO point VALUES (7138, 362, '8', NULL, NULL);
INSERT INTO point VALUES (7139, 110, '20', NULL, NULL);
INSERT INTO point VALUES (7140, 375, '56', NULL, NULL);
INSERT INTO point VALUES (7141, 660, '9', NULL, NULL);
INSERT INTO point VALUES (7142, 604, '194', NULL, NULL);
INSERT INTO point VALUES (7143, 208, '32', NULL, NULL);
INSERT INTO point VALUES (7144, 511, '23', NULL, NULL);
INSERT INTO point VALUES (7145, 220, '22/2', NULL, NULL);
INSERT INTO point VALUES (7146, 257, '2', NULL, NULL);
INSERT INTO point VALUES (7147, 329, '52', NULL, NULL);
INSERT INTO point VALUES (7148, 467, '5', NULL, NULL);
INSERT INTO point VALUES (7149, 360, '7', NULL, NULL);
INSERT INTO point VALUES (7150, 571, '22', NULL, NULL);
INSERT INTO point VALUES (7151, 648, '5', NULL, NULL);
INSERT INTO point VALUES (7152, 618, '10', NULL, NULL);
INSERT INTO point VALUES (7153, 389, '48В', NULL, NULL);
INSERT INTO point VALUES (7154, 374, '23/7', NULL, NULL);
INSERT INTO point VALUES (7155, 525, '43', NULL, NULL);
INSERT INTO point VALUES (7156, 617, '39', NULL, NULL);
INSERT INTO point VALUES (7157, 478, '49', NULL, NULL);
INSERT INTO point VALUES (7158, 494, '11', NULL, NULL);
INSERT INTO point VALUES (7159, 548, '37', NULL, NULL);
INSERT INTO point VALUES (7160, 604, '16', NULL, NULL);
INSERT INTO point VALUES (7161, 74, '9А', NULL, NULL);
INSERT INTO point VALUES (7162, 496, '121', NULL, NULL);
INSERT INTO point VALUES (7163, 131, '18/1', NULL, NULL);
INSERT INTO point VALUES (7164, 169, '6', NULL, NULL);
INSERT INTO point VALUES (7165, 87, '6', NULL, NULL);
INSERT INTO point VALUES (7166, 347, '21', NULL, NULL);
INSERT INTO point VALUES (7167, 299, '13', NULL, NULL);
INSERT INTO point VALUES (7168, 525, '10', NULL, NULL);
INSERT INTO point VALUES (7169, 186, '3', NULL, NULL);
INSERT INTO point VALUES (7170, 42, '9', NULL, NULL);
INSERT INTO point VALUES (7171, 502, '9', NULL, NULL);
INSERT INTO point VALUES (7172, 643, '74', NULL, NULL);
INSERT INTO point VALUES (7173, 560, '8', NULL, NULL);
INSERT INTO point VALUES (7174, 528, '7', NULL, NULL);
INSERT INTO point VALUES (7175, 389, '30', NULL, NULL);
INSERT INTO point VALUES (7176, 203, '1', NULL, NULL);
INSERT INTO point VALUES (7177, 78, '18', NULL, NULL);
INSERT INTO point VALUES (7178, 451, '34А', NULL, NULL);
INSERT INTO point VALUES (7179, 447, '65', NULL, NULL);
INSERT INTO point VALUES (7180, 303, '34', NULL, NULL);
INSERT INTO point VALUES (7181, 458, '91', NULL, NULL);
INSERT INTO point VALUES (7182, 434, '20', NULL, NULL);
INSERT INTO point VALUES (7183, 617, '17', NULL, NULL);
INSERT INTO point VALUES (7184, 110, '16', NULL, NULL);
INSERT INTO point VALUES (7185, 384, '42', NULL, NULL);
INSERT INTO point VALUES (7186, 544, '25', NULL, NULL);
INSERT INTO point VALUES (7187, 509, '23', NULL, NULL);
INSERT INTO point VALUES (7188, 166, '37', NULL, NULL);
INSERT INTO point VALUES (7189, 572, '2', NULL, NULL);
INSERT INTO point VALUES (7190, 158, '18', NULL, NULL);
INSERT INTO point VALUES (7191, 425, '82', NULL, NULL);
INSERT INTO point VALUES (7192, 50, '1', NULL, NULL);
INSERT INTO point VALUES (7193, 98, '3', NULL, NULL);
INSERT INTO point VALUES (7194, 3, '14', NULL, NULL);
INSERT INTO point VALUES (7195, 502, '26', NULL, NULL);
INSERT INTO point VALUES (7196, 678, '15', NULL, NULL);
INSERT INTO point VALUES (7197, 70, '2', NULL, NULL);
INSERT INTO point VALUES (7198, 394, '9', NULL, NULL);
INSERT INTO point VALUES (7199, 663, '7', NULL, NULL);
INSERT INTO point VALUES (7200, 23, '10', NULL, NULL);
INSERT INTO point VALUES (7201, 674, '3', NULL, NULL);
INSERT INTO point VALUES (7202, 279, '41', NULL, NULL);
INSERT INTO point VALUES (7203, 208, '7', NULL, NULL);
INSERT INTO point VALUES (7204, 561, '25', NULL, NULL);
INSERT INTO point VALUES (7205, 203, '19', NULL, NULL);
INSERT INTO point VALUES (7206, 487, '20', NULL, NULL);
INSERT INTO point VALUES (7207, 120, '27', NULL, NULL);
INSERT INTO point VALUES (7208, 531, '246', NULL, NULL);
INSERT INTO point VALUES (7209, 496, '48А', NULL, NULL);
INSERT INTO point VALUES (7210, 572, '5', NULL, NULL);
INSERT INTO point VALUES (7211, 117, '22', NULL, NULL);
INSERT INTO point VALUES (7212, 544, '32', NULL, NULL);
INSERT INTO point VALUES (7213, 100, '95', NULL, NULL);
INSERT INTO point VALUES (7214, 311, '7', NULL, NULL);
INSERT INTO point VALUES (7215, 464, '32/1', NULL, NULL);
INSERT INTO point VALUES (7216, 530, '11', NULL, NULL);
INSERT INTO point VALUES (7217, 465, '24', NULL, NULL);
INSERT INTO point VALUES (7218, 364, '5', NULL, NULL);
INSERT INTO point VALUES (7219, 433, '38', NULL, NULL);
INSERT INTO point VALUES (7220, 469, '14А', NULL, NULL);
INSERT INTO point VALUES (7221, 430, '1', NULL, NULL);
INSERT INTO point VALUES (7222, 51, '64', NULL, NULL);
INSERT INTO point VALUES (7223, 582, '27', NULL, NULL);
INSERT INTO point VALUES (7224, 562, '37', NULL, NULL);
INSERT INTO point VALUES (7225, 265, '15А', NULL, NULL);
INSERT INTO point VALUES (7226, 670, '25А', NULL, NULL);
INSERT INTO point VALUES (7227, 161, '32', NULL, NULL);
INSERT INTO point VALUES (7228, 515, '11', NULL, NULL);
INSERT INTO point VALUES (7229, 431, '25', NULL, NULL);
INSERT INTO point VALUES (7230, 429, '4', NULL, NULL);
INSERT INTO point VALUES (7231, 531, '141', NULL, NULL);
INSERT INTO point VALUES (7232, 254, '38', NULL, NULL);
INSERT INTO point VALUES (7233, 248, '13', NULL, NULL);
INSERT INTO point VALUES (7234, 219, '16', NULL, NULL);
INSERT INTO point VALUES (7235, 176, '25', NULL, NULL);
INSERT INTO point VALUES (7236, 615, '7', NULL, NULL);
INSERT INTO point VALUES (7237, 598, '32', NULL, NULL);
INSERT INTO point VALUES (7238, 473, '51', NULL, NULL);
INSERT INTO point VALUES (7239, 303, '74', NULL, NULL);
INSERT INTO point VALUES (7240, 291, '48', NULL, NULL);
INSERT INTO point VALUES (7241, 225, '14', NULL, NULL);
INSERT INTO point VALUES (7242, 425, '76А', NULL, NULL);
INSERT INTO point VALUES (7243, 658, '30', NULL, NULL);
INSERT INTO point VALUES (7244, 472, '32', NULL, NULL);
INSERT INTO point VALUES (7245, 426, '18', NULL, NULL);
INSERT INTO point VALUES (7246, 438, '19', NULL, NULL);
INSERT INTO point VALUES (7247, 210, '5', NULL, NULL);
INSERT INTO point VALUES (7248, 180, '26', NULL, NULL);
INSERT INTO point VALUES (7249, 370, '9', NULL, NULL);
INSERT INTO point VALUES (7250, 270, '3', NULL, NULL);
INSERT INTO point VALUES (7251, 465, '66', NULL, NULL);
INSERT INTO point VALUES (7252, 464, '20', NULL, NULL);
INSERT INTO point VALUES (7253, 496, '24А', NULL, NULL);
INSERT INTO point VALUES (7254, 374, '117', NULL, NULL);
INSERT INTO point VALUES (7255, 339, '12', NULL, NULL);
INSERT INTO point VALUES (7256, 304, '51', NULL, NULL);
INSERT INTO point VALUES (7257, 601, '134', NULL, NULL);
INSERT INTO point VALUES (7258, 161, '25', NULL, NULL);
INSERT INTO point VALUES (7259, 88, '21', NULL, NULL);
INSERT INTO point VALUES (7260, 411, '15', NULL, NULL);
INSERT INTO point VALUES (7261, 389, '27/1', NULL, NULL);
INSERT INTO point VALUES (7262, 389, '45/4', NULL, NULL);
INSERT INTO point VALUES (7263, 520, '22', NULL, NULL);
INSERT INTO point VALUES (7264, 477, '8', NULL, NULL);
INSERT INTO point VALUES (7265, 176, '32', NULL, NULL);
INSERT INTO point VALUES (7266, 496, '91', NULL, NULL);
INSERT INTO point VALUES (7267, 415, '37', NULL, NULL);
INSERT INTO point VALUES (7268, 220, '22/9', NULL, NULL);
INSERT INTO point VALUES (7269, 693, '26', NULL, NULL);
INSERT INTO point VALUES (7270, 231, '10', NULL, NULL);
INSERT INTO point VALUES (7271, 236, '71', NULL, NULL);
INSERT INTO point VALUES (7272, 40, '18', NULL, NULL);
INSERT INTO point VALUES (7273, 572, '29', NULL, NULL);
INSERT INTO point VALUES (7274, 182, '18', NULL, NULL);
INSERT INTO point VALUES (7275, 269, '30', NULL, NULL);
INSERT INTO point VALUES (7276, 87, '43', NULL, NULL);
INSERT INTO point VALUES (7277, 472, '25', NULL, NULL);
INSERT INTO point VALUES (7278, 119, '12', NULL, NULL);
INSERT INTO point VALUES (7279, 210, '2', NULL, NULL);
INSERT INTO point VALUES (7280, 277, '18', NULL, NULL);
INSERT INTO point VALUES (7281, 180, '9', NULL, NULL);
INSERT INTO point VALUES (7282, 27, '24', NULL, NULL);
INSERT INTO point VALUES (7283, 598, '25', NULL, NULL);
INSERT INTO point VALUES (7284, 447, '78', NULL, NULL);
INSERT INTO point VALUES (7285, 594, '27', NULL, NULL);
INSERT INTO point VALUES (7286, 480, '35', NULL, NULL);
INSERT INTO point VALUES (7287, 161, '7', NULL, NULL);
INSERT INTO point VALUES (7288, 250, '55', NULL, NULL);
INSERT INTO point VALUES (7289, 169, '10', NULL, NULL);
INSERT INTO point VALUES (7290, 87, '10', NULL, NULL);
INSERT INTO point VALUES (7291, 180, '33А', NULL, NULL);
INSERT INTO point VALUES (7292, 613, '14', NULL, NULL);
INSERT INTO point VALUES (7293, 525, '6', NULL, NULL);
INSERT INTO point VALUES (7294, 542, '59', NULL, NULL);
INSERT INTO point VALUES (7295, 384, '44', NULL, NULL);
INSERT INTO point VALUES (7296, 604, '15/210', NULL, NULL);
INSERT INTO point VALUES (7297, 451, '56', NULL, NULL);
INSERT INTO point VALUES (7298, 503, '15', NULL, NULL);
INSERT INTO point VALUES (7299, 50, '13', NULL, NULL);
INSERT INTO point VALUES (7300, 163, '28', NULL, NULL);
INSERT INTO point VALUES (7301, 25, '17', NULL, NULL);
INSERT INTO point VALUES (7302, 294, '110', NULL, NULL);
INSERT INTO point VALUES (7303, 157, '15', NULL, NULL);
INSERT INTO point VALUES (7304, 496, '49', NULL, NULL);
INSERT INTO point VALUES (7305, 376, '50', NULL, NULL);
INSERT INTO point VALUES (7306, 455, '45', NULL, NULL);
INSERT INTO point VALUES (7307, 565, '34', NULL, NULL);
INSERT INTO point VALUES (7308, 558, '40', NULL, NULL);
INSERT INTO point VALUES (7309, 303, '35', NULL, NULL);
INSERT INTO point VALUES (7310, 598, '7', NULL, NULL);
INSERT INTO point VALUES (7311, 472, '7', NULL, NULL);
INSERT INTO point VALUES (7312, 277, '36', NULL, NULL);
INSERT INTO point VALUES (7313, 294, '14', NULL, NULL);
INSERT INTO point VALUES (7314, 447, '26', NULL, NULL);
INSERT INTO point VALUES (7315, 203, '13', NULL, NULL);
INSERT INTO point VALUES (7316, 285, '24', NULL, NULL);
INSERT INTO point VALUES (7317, 213, '12', NULL, NULL);
INSERT INTO point VALUES (7318, 61, '21', NULL, NULL);
INSERT INTO point VALUES (7319, 389, '13/1', NULL, NULL);
INSERT INTO point VALUES (7320, 374, '76', NULL, NULL);
INSERT INTO point VALUES (7321, 202, '34', NULL, NULL);
INSERT INTO point VALUES (7322, 235, '20', NULL, NULL);
INSERT INTO point VALUES (7323, 449, '17', NULL, NULL);
INSERT INTO point VALUES (7324, 23, '6', NULL, NULL);
INSERT INTO point VALUES (7325, 304, '53', NULL, NULL);
INSERT INTO point VALUES (7326, 323, '83', NULL, NULL);
INSERT INTO point VALUES (7327, 329, '19', NULL, NULL);
INSERT INTO point VALUES (7328, 531, '59', NULL, NULL);
INSERT INTO point VALUES (7329, 435, '60', NULL, NULL);
INSERT INTO point VALUES (7330, 353, '38', NULL, NULL);
INSERT INTO point VALUES (7331, 176, '7', NULL, NULL);
INSERT INTO point VALUES (7332, 338, '62', NULL, NULL);
INSERT INTO point VALUES (7333, 191, '27', NULL, NULL);
INSERT INTO point VALUES (7334, 670, '23', NULL, NULL);
INSERT INTO point VALUES (7335, 236, '14', NULL, NULL);
INSERT INTO point VALUES (7336, 464, '16', NULL, NULL);
INSERT INTO point VALUES (7337, 74, '8', NULL, NULL);
INSERT INTO point VALUES (7338, 250, '73', NULL, NULL);
INSERT INTO point VALUES (7339, 451, '6', NULL, NULL);
INSERT INTO point VALUES (7340, 236, '110', NULL, NULL);
INSERT INTO point VALUES (7341, 389, '46', NULL, NULL);
INSERT INTO point VALUES (7342, 99, '5-3', NULL, NULL);
INSERT INTO point VALUES (7343, 220, '7', NULL, NULL);
INSERT INTO point VALUES (7344, 539, '14', NULL, NULL);
INSERT INTO point VALUES (7345, 494, '4', NULL, NULL);
INSERT INTO point VALUES (7346, 468, '35', NULL, NULL);
INSERT INTO point VALUES (7347, 299, '19', NULL, NULL);
INSERT INTO point VALUES (7348, 316, '13', NULL, NULL);
INSERT INTO point VALUES (7349, 447, '80', NULL, NULL);
INSERT INTO point VALUES (7350, 15, '11', NULL, NULL);
INSERT INTO point VALUES (7351, 384, '24', NULL, NULL);
INSERT INTO point VALUES (7352, 27, '21А', NULL, NULL);
INSERT INTO point VALUES (7353, 564, '8', NULL, NULL);
INSERT INTO point VALUES (7354, 342, '29', NULL, NULL);
INSERT INTO point VALUES (7355, 447, '9', NULL, NULL);
INSERT INTO point VALUES (7356, 435, '26', NULL, NULL);
INSERT INTO point VALUES (7357, 210, '3', NULL, NULL);
INSERT INTO point VALUES (7358, 346, '8', NULL, NULL);
INSERT INTO point VALUES (7359, 250, '6', NULL, NULL);
INSERT INTO point VALUES (7360, 163, '29', NULL, NULL);
INSERT INTO point VALUES (7361, 496, '79', NULL, NULL);
INSERT INTO point VALUES (7362, 270, '5', NULL, NULL);
INSERT INTO point VALUES (7363, 569, '16', NULL, NULL);
INSERT INTO point VALUES (7364, 345, '24', NULL, NULL);
INSERT INTO point VALUES (7365, 26, '21', NULL, NULL);
INSERT INTO point VALUES (7366, 3, '12', NULL, NULL);
INSERT INTO point VALUES (7367, 376, '40', NULL, NULL);
INSERT INTO point VALUES (7368, 531, '140А', NULL, NULL);
INSERT INTO point VALUES (7369, 335, '7', NULL, NULL);
INSERT INTO point VALUES (7370, 425, '92', NULL, NULL);
INSERT INTO point VALUES (7371, 67, '50', NULL, NULL);
INSERT INTO point VALUES (7372, 600, '26', NULL, NULL);
INSERT INTO point VALUES (7373, 277, '62', NULL, NULL);
INSERT INTO point VALUES (7374, 496, '48', NULL, NULL);
INSERT INTO point VALUES (7375, 27, '7', NULL, NULL);
INSERT INTO point VALUES (7376, 572, '1б', NULL, NULL);
INSERT INTO point VALUES (7377, 506, '18', NULL, NULL);
INSERT INTO point VALUES (7378, 236, '5А', NULL, NULL);
INSERT INTO point VALUES (7379, 449, '15', NULL, NULL);
INSERT INTO point VALUES (7380, 455, '2', NULL, NULL);
INSERT INTO point VALUES (7381, 496, '45/2', NULL, NULL);
INSERT INTO point VALUES (7382, 37, '23', NULL, NULL);
INSERT INTO point VALUES (7383, 384, '32', NULL, NULL);
INSERT INTO point VALUES (7384, 531, '200', NULL, NULL);
INSERT INTO point VALUES (7385, 283, '17А', NULL, NULL);
INSERT INTO point VALUES (7386, 568, '4/2', NULL, NULL);
INSERT INTO point VALUES (7387, 497, '25', NULL, NULL);
INSERT INTO point VALUES (7388, 46, '20', NULL, NULL);
INSERT INTO point VALUES (7389, 552, '36', NULL, NULL);
INSERT INTO point VALUES (7390, 165, '40', NULL, NULL);
INSERT INTO point VALUES (7391, 263, '4А', NULL, NULL);
INSERT INTO point VALUES (7392, 390, '38', NULL, NULL);
INSERT INTO point VALUES (7393, 292, '7', NULL, NULL);
INSERT INTO point VALUES (7394, 467, '28', NULL, NULL);
INSERT INTO point VALUES (7395, 267, '11', NULL, NULL);
INSERT INTO point VALUES (7396, 425, '86/1', NULL, NULL);
INSERT INTO point VALUES (7397, 397, '25', NULL, NULL);
INSERT INTO point VALUES (7398, 601, '68', NULL, NULL);
INSERT INTO point VALUES (7399, 636, '22', NULL, NULL);
INSERT INTO point VALUES (7400, 499, '16', NULL, NULL);
INSERT INTO point VALUES (7401, 338, '36', NULL, NULL);
INSERT INTO point VALUES (7402, 131, '14Б', NULL, NULL);
INSERT INTO point VALUES (7403, 447, '60', NULL, NULL);
INSERT INTO point VALUES (7404, 451, '55', NULL, NULL);
INSERT INTO point VALUES (7405, 277, '13Б', NULL, NULL);
INSERT INTO point VALUES (7406, 503, '17', NULL, NULL);
INSERT INTO point VALUES (7407, 566, '13', NULL, NULL);
INSERT INTO point VALUES (7408, 304, '52', NULL, NULL);
INSERT INTO point VALUES (7409, 342, '28', NULL, NULL);
INSERT INTO point VALUES (7410, 25, '15', NULL, NULL);
INSERT INTO point VALUES (7411, 52, '9', NULL, NULL);
INSERT INTO point VALUES (7412, 601, '70', NULL, NULL);
INSERT INTO point VALUES (7413, 76, '18', NULL, NULL);
INSERT INTO point VALUES (7414, 334, '18', NULL, NULL);
INSERT INTO point VALUES (7415, 157, '17', NULL, NULL);
INSERT INTO point VALUES (7416, 203, '51', NULL, NULL);
INSERT INTO point VALUES (7417, 620, '7', NULL, NULL);
INSERT INTO point VALUES (7418, 292, '25', NULL, NULL);
INSERT INTO point VALUES (7419, 499, '20', NULL, NULL);
INSERT INTO point VALUES (7420, 67, '11', NULL, NULL);
INSERT INTO point VALUES (7421, 214, '7', NULL, NULL);
INSERT INTO point VALUES (7422, 696, '16', NULL, NULL);
INSERT INTO point VALUES (7423, 183, '52/1', NULL, NULL);
INSERT INTO point VALUES (7424, 366, '1', NULL, NULL);
INSERT INTO point VALUES (7425, 598, '44', NULL, NULL);
INSERT INTO point VALUES (7426, 688, '11', NULL, NULL);
INSERT INTO point VALUES (7427, 225, '1А', NULL, NULL);
INSERT INTO point VALUES (7428, 657, '17А', NULL, NULL);
INSERT INTO point VALUES (7429, 447, '75', NULL, NULL);
INSERT INTO point VALUES (7430, 397, '7', NULL, NULL);
INSERT INTO point VALUES (7431, 150, '12', NULL, NULL);
INSERT INTO point VALUES (7432, 236, '85', NULL, NULL);
INSERT INTO point VALUES (7433, 299, '11/1', NULL, NULL);
INSERT INTO point VALUES (7434, 176, '24', NULL, NULL);
INSERT INTO point VALUES (7435, 278, '9', NULL, NULL);
INSERT INTO point VALUES (7436, 304, '13', NULL, NULL);
INSERT INTO point VALUES (7437, 496, '21', NULL, NULL);
INSERT INTO point VALUES (7438, 664, '6 ка', NULL, NULL);
INSERT INTO point VALUES (7439, 27, '32', NULL, NULL);
INSERT INTO point VALUES (7440, 445, '17', NULL, NULL);
INSERT INTO point VALUES (7441, 303, '22', NULL, NULL);
INSERT INTO point VALUES (7442, 411, '17', NULL, NULL);
INSERT INTO point VALUES (7443, 269, '11', NULL, NULL);
INSERT INTO point VALUES (7444, 110, '42/1', NULL, NULL);
INSERT INTO point VALUES (7445, 39, '6', NULL, NULL);
INSERT INTO point VALUES (7446, 176, '33', NULL, NULL);
INSERT INTO point VALUES (7447, 280, '40', NULL, NULL);
INSERT INTO point VALUES (7448, 294, '232', NULL, NULL);
INSERT INTO point VALUES (7449, 664, '10', NULL, NULL);
INSERT INTO point VALUES (7450, 554, '6', NULL, NULL);
INSERT INTO point VALUES (7451, 496, '32А', NULL, NULL);
INSERT INTO point VALUES (7452, 384, '7', NULL, NULL);
INSERT INTO point VALUES (7453, 431, '33', NULL, NULL);
INSERT INTO point VALUES (7454, 76, '36', NULL, NULL);
INSERT INTO point VALUES (7455, 393, '12А', NULL, NULL);
INSERT INTO point VALUES (7456, 184, '9', NULL, NULL);
INSERT INTO point VALUES (7457, 24, '9', NULL, NULL);
INSERT INTO point VALUES (7458, 218, '2', NULL, NULL);
INSERT INTO point VALUES (7459, 181, '52', NULL, NULL);
INSERT INTO point VALUES (7460, 294, '124', NULL, NULL);
INSERT INTO point VALUES (7461, 607, '18', NULL, NULL);
INSERT INTO point VALUES (7462, 435, '64', NULL, NULL);
INSERT INTO point VALUES (7463, 526, '14', NULL, NULL);
INSERT INTO point VALUES (7464, 197, '4', NULL, NULL);
INSERT INTO point VALUES (7465, 161, '24', NULL, NULL);
INSERT INTO point VALUES (7466, 170, '8А', NULL, NULL);
INSERT INTO point VALUES (7467, 664, '14/1', NULL, NULL);
INSERT INTO point VALUES (7468, 178, '14', NULL, NULL);
INSERT INTO point VALUES (7469, 577, '7', NULL, NULL);
INSERT INTO point VALUES (7470, 117, '34', NULL, NULL);
INSERT INTO point VALUES (7471, 268, '10', NULL, NULL);
INSERT INTO point VALUES (7472, 366, '19', NULL, NULL);
INSERT INTO point VALUES (7473, 389, '4', NULL, NULL);
INSERT INTO point VALUES (7474, 46, '16', NULL, NULL);
INSERT INTO point VALUES (7475, 538, '12', NULL, NULL);
INSERT INTO point VALUES (7476, 601, '118а', NULL, NULL);
INSERT INTO point VALUES (7477, 598, '33', NULL, NULL);
INSERT INTO point VALUES (7478, 285, '7', NULL, NULL);
INSERT INTO point VALUES (7479, 658, '11', NULL, NULL);
INSERT INTO point VALUES (7480, 409, '4', NULL, NULL);
INSERT INTO point VALUES (7481, 472, '24', NULL, NULL);
INSERT INTO point VALUES (7482, 664, '12В', NULL, NULL);
INSERT INTO point VALUES (7483, 560, '76', NULL, NULL);
INSERT INTO point VALUES (7484, 389, '23А', NULL, NULL);
INSERT INTO point VALUES (7485, 172, '9А', NULL, NULL);
INSERT INTO point VALUES (7486, 693, '2/2', NULL, NULL);
INSERT INTO point VALUES (7487, 572, '28', NULL, NULL);
INSERT INTO point VALUES (7488, 183, '26А', NULL, NULL);
INSERT INTO point VALUES (7489, 256, '9', NULL, NULL);
INSERT INTO point VALUES (7490, 569, '20', NULL, NULL);
INSERT INTO point VALUES (7491, 27, '25', NULL, NULL);
INSERT INTO point VALUES (7492, 598, '24', NULL, NULL);
INSERT INTO point VALUES (7493, 152, '8', NULL, NULL);
INSERT INTO point VALUES (7494, 9, '67', NULL, NULL);
INSERT INTO point VALUES (7495, 531, '145', NULL, NULL);
INSERT INTO point VALUES (7496, 497, '7', NULL, NULL);
INSERT INTO point VALUES (7497, 261, '16', NULL, NULL);
INSERT INTO point VALUES (7498, 473, '13', NULL, NULL);
INSERT INTO point VALUES (7499, 462, '8', NULL, NULL);
INSERT INTO point VALUES (7500, 468, '22', NULL, NULL);
INSERT INTO point VALUES (7501, 364, '28', NULL, NULL);
INSERT INTO point VALUES (7502, 203, '53', NULL, NULL);
INSERT INTO point VALUES (7503, 161, '33', NULL, NULL);
INSERT INTO point VALUES (7504, 504, '5', NULL, NULL);
INSERT INTO point VALUES (7505, 223, '27', NULL, NULL);
INSERT INTO point VALUES (7506, 395, '9Б', NULL, NULL);
INSERT INTO point VALUES (7507, 236, '12', NULL, NULL);
INSERT INTO point VALUES (7508, 19, '20', NULL, NULL);
INSERT INTO point VALUES (7509, 643, '22', NULL, NULL);
INSERT INTO point VALUES (7510, 566, '19', NULL, NULL);
INSERT INTO point VALUES (7511, 688, '4', NULL, NULL);
INSERT INTO point VALUES (7512, 687, '23', NULL, NULL);
INSERT INTO point VALUES (7513, 554, '94', NULL, NULL);
INSERT INTO point VALUES (7514, 568, '3', NULL, NULL);
INSERT INTO point VALUES (7515, 168, '6', NULL, NULL);
INSERT INTO point VALUES (7516, 544, '33', NULL, NULL);
INSERT INTO point VALUES (7517, 269, '4', NULL, NULL);
INSERT INTO point VALUES (7518, 139, '10', NULL, NULL);
INSERT INTO point VALUES (7519, 654, '20', NULL, NULL);
INSERT INTO point VALUES (7520, 131, '14А', NULL, NULL);
INSERT INTO point VALUES (7521, 465, '32', NULL, NULL);
INSERT INTO point VALUES (7522, 534, '4', NULL, NULL);
INSERT INTO point VALUES (7523, 451, '60/3', NULL, NULL);
INSERT INTO point VALUES (7524, 653, '30', NULL, NULL);
INSERT INTO point VALUES (7525, 678, '17', NULL, NULL);
INSERT INTO point VALUES (7526, 544, '24', NULL, NULL);
INSERT INTO point VALUES (7527, 558, '4', NULL, NULL);
INSERT INTO point VALUES (7528, 67, '23А', NULL, NULL);
INSERT INTO point VALUES (7529, 496, '100А', NULL, NULL);
INSERT INTO point VALUES (7530, 435, '65', NULL, NULL);
INSERT INTO point VALUES (7531, 236, '58', NULL, NULL);
INSERT INTO point VALUES (7532, 539, '12', NULL, NULL);
INSERT INTO point VALUES (7533, 257, '3', NULL, NULL);
INSERT INTO point VALUES (7534, 617, '15', NULL, NULL);
INSERT INTO point VALUES (7535, 694, '22', NULL, NULL);
INSERT INTO point VALUES (7536, 114, '11', NULL, NULL);
INSERT INTO point VALUES (7537, 57, '25', NULL, NULL);
INSERT INTO point VALUES (7538, 131, '12/6', NULL, NULL);
INSERT INTO point VALUES (7539, 245, '49', NULL, NULL);
INSERT INTO point VALUES (7540, 547, '1', NULL, NULL);
INSERT INTO point VALUES (7541, 294, '58', NULL, NULL);
INSERT INTO point VALUES (7542, 205, '11', NULL, NULL);
INSERT INTO point VALUES (7543, 96, '20', NULL, NULL);
INSERT INTO point VALUES (7544, 265, '22А', NULL, NULL);
INSERT INTO point VALUES (7545, 23, '4/1', NULL, NULL);
INSERT INTO point VALUES (7546, 504, '2', NULL, NULL);
INSERT INTO point VALUES (7547, 389, '11', NULL, NULL);
INSERT INTO point VALUES (7548, 613, '12', NULL, NULL);
INSERT INTO point VALUES (7549, 32, '13', NULL, NULL);
INSERT INTO point VALUES (7550, 30, '18', NULL, NULL);
INSERT INTO point VALUES (7551, 458, '21', NULL, NULL);
INSERT INTO point VALUES (7552, 131, '12/1', NULL, NULL);
INSERT INTO point VALUES (7553, 566, '1', NULL, NULL);
INSERT INTO point VALUES (7554, 325, '13А', NULL, NULL);
INSERT INTO point VALUES (7555, 585, '18', NULL, NULL);
INSERT INTO point VALUES (7556, 346, '9А', NULL, NULL);
INSERT INTO point VALUES (7557, 433, '72', NULL, NULL);
INSERT INTO point VALUES (7558, 467, '3', NULL, NULL);
INSERT INTO point VALUES (7559, 333, '1', NULL, NULL);
INSERT INTO point VALUES (7560, 433, '40Б', NULL, NULL);
INSERT INTO point VALUES (7561, 648, '3', NULL, NULL);
INSERT INTO point VALUES (7562, 329, '51', NULL, NULL);
INSERT INTO point VALUES (7563, 294, '112', NULL, NULL);
INSERT INTO point VALUES (7564, 49, '39', NULL, NULL);
INSERT INTO point VALUES (7565, 531, '18', NULL, NULL);
INSERT INTO point VALUES (7566, 643, '93', NULL, NULL);
INSERT INTO point VALUES (7567, 75, '33', NULL, NULL);
INSERT INTO point VALUES (7568, 658, '4', NULL, NULL);
INSERT INTO point VALUES (7569, 548, '45/3', NULL, NULL);
INSERT INTO point VALUES (7570, 626, '21', NULL, NULL);
INSERT INTO point VALUES (7571, 635, '8', NULL, NULL);
INSERT INTO point VALUES (7572, 294, '12', NULL, NULL);
INSERT INTO point VALUES (7573, 170, '11А', NULL, NULL);
INSERT INTO point VALUES (7574, 16, '3', NULL, NULL);
INSERT INTO point VALUES (7575, 213, '14', NULL, NULL);
INSERT INTO point VALUES (7576, 590, '1', NULL, NULL);
INSERT INTO point VALUES (7577, 663, '24', NULL, NULL);
INSERT INTO point VALUES (7578, 531, '132', NULL, NULL);
INSERT INTO point VALUES (7579, 473, '19', NULL, NULL);
INSERT INTO point VALUES (7580, 57, '7', NULL, NULL);
INSERT INTO point VALUES (7581, 326, '8', NULL, NULL);
INSERT INTO point VALUES (7582, 218, '2А', NULL, NULL);
INSERT INTO point VALUES (7583, 621, '4', NULL, NULL);
INSERT INTO point VALUES (7584, 643, '77', NULL, NULL);
INSERT INTO point VALUES (7585, 695, '26', NULL, NULL);
INSERT INTO point VALUES (7586, 339, '14', NULL, NULL);
INSERT INTO point VALUES (7587, 208, '24', NULL, NULL);
INSERT INTO point VALUES (7588, 496, '19А', NULL, NULL);
INSERT INTO point VALUES (7589, 585, '36', NULL, NULL);
INSERT INTO point VALUES (7590, 554, '104', NULL, NULL);
INSERT INTO point VALUES (7591, 366, '13', NULL, NULL);
INSERT INTO point VALUES (7592, 96, '16', NULL, NULL);
INSERT INTO point VALUES (7593, 186, '5', NULL, NULL);
INSERT INTO point VALUES (7594, 601, '37', NULL, NULL);
INSERT INTO point VALUES (7595, 294, '138', NULL, NULL);
INSERT INTO point VALUES (7596, 49, '17', NULL, NULL);
INSERT INTO point VALUES (7597, 674, '2', NULL, NULL);
INSERT INTO point VALUES (7598, 172, '8', NULL, NULL);
INSERT INTO point VALUES (7599, 536, '23', NULL, NULL);
INSERT INTO point VALUES (7600, 598, '42', NULL, NULL);
INSERT INTO point VALUES (7601, 664, '6', NULL, NULL);
INSERT INTO point VALUES (7602, 152, '23', NULL, NULL);
INSERT INTO point VALUES (7603, 170, '8', NULL, NULL);
INSERT INTO point VALUES (7604, 389, '50', NULL, NULL);
INSERT INTO point VALUES (7605, 478, '48', NULL, NULL);
INSERT INTO point VALUES (7606, 654, '16', NULL, NULL);
INSERT INTO point VALUES (7607, 695, '9', NULL, NULL);
INSERT INTO point VALUES (7608, 55, '8', NULL, NULL);
INSERT INTO point VALUES (7609, 696, '18А', NULL, NULL);
INSERT INTO point VALUES (7610, 374, '8', NULL, NULL);
INSERT INTO point VALUES (7611, 364, '3', NULL, NULL);
INSERT INTO point VALUES (7612, 232, '22', NULL, NULL);
INSERT INTO point VALUES (7613, 496, '83', NULL, NULL);
INSERT INTO point VALUES (7614, 431, '42', NULL, NULL);
INSERT INTO point VALUES (7615, 572, '3', NULL, NULL);
INSERT INTO point VALUES (7616, 489, '15', NULL, NULL);
INSERT INTO point VALUES (7617, 610, '9', NULL, NULL);
INSERT INTO point VALUES (7618, 236, '138', NULL, NULL);
INSERT INTO point VALUES (7619, 304, '19', NULL, NULL);
INSERT INTO point VALUES (7620, 672, '5', NULL, NULL);
INSERT INTO point VALUES (7621, 329, '53', NULL, NULL);
INSERT INTO point VALUES (7622, 674, '5', NULL, NULL);
INSERT INTO point VALUES (7623, 117, '35', NULL, NULL);
INSERT INTO point VALUES (7624, 250, '43', NULL, NULL);
INSERT INTO point VALUES (7625, 373, '71', NULL, NULL);
INSERT INTO point VALUES (7626, 628, '37А', NULL, NULL);
INSERT INTO point VALUES (7627, 76, '36Б', NULL, NULL);
INSERT INTO point VALUES (7628, 51, '60', NULL, NULL);
INSERT INTO point VALUES (7629, 19, '16', NULL, NULL);
INSERT INTO point VALUES (7630, 236, '57', NULL, NULL);
INSERT INTO point VALUES (7631, 225, '12', NULL, NULL);
INSERT INTO point VALUES (7632, 98, '5', NULL, NULL);
INSERT INTO point VALUES (7633, 501, '4', NULL, NULL);
INSERT INTO point VALUES (7634, 279, '37', NULL, NULL);
INSERT INTO point VALUES (7635, 285, '8', NULL, NULL);
INSERT INTO point VALUES (7636, 425, '3а', NULL, NULL);
INSERT INTO point VALUES (7637, 262, '3А', NULL, NULL);
INSERT INTO point VALUES (7638, 374, '127', NULL, NULL);
INSERT INTO point VALUES (7639, 271, '4А', NULL, NULL);
INSERT INTO point VALUES (7640, 475, '7', NULL, NULL);
INSERT INTO point VALUES (7641, 536, '7', NULL, NULL);
INSERT INTO point VALUES (7642, 152, '7', NULL, NULL);
INSERT INTO point VALUES (7643, 157, '35', NULL, NULL);
INSERT INTO point VALUES (7644, 451, '6Б', NULL, NULL);
INSERT INTO point VALUES (7645, 250, '72/1', NULL, NULL);
INSERT INTO point VALUES (7646, 462, '7', NULL, NULL);
INSERT INTO point VALUES (7647, 303, '15', NULL, NULL);
INSERT INTO point VALUES (7648, 569, '10', NULL, NULL);
INSERT INTO point VALUES (7649, 389, '48А', NULL, NULL);
INSERT INTO point VALUES (7650, 280, '79', NULL, NULL);
INSERT INTO point VALUES (7651, 277, '82', NULL, NULL);
INSERT INTO point VALUES (7652, 250, '16А', NULL, NULL);
INSERT INTO point VALUES (7653, 577, '8', NULL, NULL);
INSERT INTO point VALUES (7654, 168, '16', NULL, NULL);
INSERT INTO point VALUES (7655, 687, '32', NULL, NULL);
INSERT INTO point VALUES (7656, 146, '19', NULL, NULL);
INSERT INTO point VALUES (7657, 598, '24Б', NULL, NULL);
INSERT INTO point VALUES (7658, 548, '54', NULL, NULL);
INSERT INTO point VALUES (7659, 104, '1', NULL, NULL);
INSERT INTO point VALUES (7660, 147, '31', NULL, NULL);
INSERT INTO point VALUES (7661, 499, '10', NULL, NULL);
INSERT INTO point VALUES (7662, 213, '13', NULL, NULL);
INSERT INTO point VALUES (7663, 250, '84', NULL, NULL);
INSERT INTO point VALUES (7664, 278, '29', NULL, NULL);
INSERT INTO point VALUES (7665, 67, '91', NULL, NULL);
INSERT INTO point VALUES (7666, 509, '24', NULL, NULL);
INSERT INTO point VALUES (7667, 44, '38', NULL, NULL);
INSERT INTO point VALUES (7668, 183, '34/1', NULL, NULL);
INSERT INTO point VALUES (7669, 496, '30', NULL, NULL);
INSERT INTO point VALUES (7670, 377, '14', NULL, NULL);
INSERT INTO point VALUES (7671, 12, '100', NULL, NULL);
INSERT INTO point VALUES (7672, 388, '31', NULL, NULL);
INSERT INTO point VALUES (7673, 395, '17', NULL, NULL);
INSERT INTO point VALUES (7674, 337, '5', NULL, NULL);
INSERT INTO point VALUES (7675, 166, '41', NULL, NULL);
INSERT INTO point VALUES (7676, 184, '29', NULL, NULL);
INSERT INTO point VALUES (7677, 693, '28', NULL, NULL);
INSERT INTO point VALUES (7678, 620, '8', NULL, NULL);
INSERT INTO point VALUES (7679, 294, '196', NULL, NULL);
INSERT INTO point VALUES (7680, 560, '42', NULL, NULL);
INSERT INTO point VALUES (7681, 88, '11', NULL, NULL);
INSERT INTO point VALUES (7682, 545, '27', NULL, NULL);
INSERT INTO point VALUES (7683, 664, '20', NULL, NULL);
INSERT INTO point VALUES (7684, 509, '33', NULL, NULL);
INSERT INTO point VALUES (7685, 166, '31', NULL, NULL);
INSERT INTO point VALUES (7686, 496, '40', NULL, NULL);
INSERT INTO point VALUES (7687, 126, '33', NULL, NULL);
INSERT INTO point VALUES (7688, 531, '92', NULL, NULL);
INSERT INTO point VALUES (7689, 511, '33', NULL, NULL);
INSERT INTO point VALUES (7690, 610, '5', NULL, NULL);
INSERT INTO point VALUES (7691, 96, '6', NULL, NULL);
INSERT INTO point VALUES (7692, 589, '14', NULL, NULL);
INSERT INTO point VALUES (7693, 163, '26', NULL, NULL);
INSERT INTO point VALUES (7694, 61, '11', NULL, NULL);
INSERT INTO point VALUES (7695, 435, '29', NULL, NULL);
INSERT INTO point VALUES (7696, 682, '4', NULL, NULL);
INSERT INTO point VALUES (7697, 664, '16', NULL, NULL);
INSERT INTO point VALUES (7698, 649, '36', NULL, NULL);
INSERT INTO point VALUES (7699, 435, '61', NULL, NULL);
INSERT INTO point VALUES (7700, 149, '22', NULL, NULL);
INSERT INTO point VALUES (7701, 144, '31', NULL, NULL);
INSERT INTO point VALUES (7702, 600, '29', NULL, NULL);
INSERT INTO point VALUES (7703, 393, '17', NULL, NULL);
INSERT INTO point VALUES (7704, 695, '5', NULL, NULL);
INSERT INTO point VALUES (7705, 433, '68', NULL, NULL);
INSERT INTO point VALUES (7706, 487, '55', NULL, NULL);
INSERT INTO point VALUES (7707, 372, '4', NULL, NULL);
INSERT INTO point VALUES (7708, 415, '47', NULL, NULL);
INSERT INTO point VALUES (7709, 98, '9', NULL, NULL);
INSERT INTO point VALUES (7710, 386, '4А', NULL, NULL);
INSERT INTO point VALUES (7711, 339, '13', NULL, NULL);
INSERT INTO point VALUES (7712, 59, '12', NULL, NULL);
INSERT INTO point VALUES (7713, 548, '41', NULL, NULL);
INSERT INTO point VALUES (7714, 292, '8', NULL, NULL);
INSERT INTO point VALUES (7715, 394, '3', NULL, NULL);
INSERT INTO point VALUES (7716, 696, '10', NULL, NULL);
INSERT INTO point VALUES (7717, 447, '28', NULL, NULL);
INSERT INTO point VALUES (7718, 542, '12Б', NULL, NULL);
INSERT INTO point VALUES (7719, 496, '48В', NULL, NULL);
INSERT INTO point VALUES (7720, 674, '9', NULL, NULL);
INSERT INTO point VALUES (7721, 376, '48', NULL, NULL);
INSERT INTO point VALUES (7722, 687, '7', NULL, NULL);
INSERT INTO point VALUES (7723, 523, '19', NULL, NULL);
INSERT INTO point VALUES (7724, 433, '70', NULL, NULL);
INSERT INTO point VALUES (7725, 19, '22А', NULL, NULL);
INSERT INTO point VALUES (7726, 672, '9', NULL, NULL);
INSERT INTO point VALUES (7727, 531, '27', NULL, NULL);
INSERT INTO point VALUES (7728, 67, '115', NULL, NULL);
INSERT INTO point VALUES (7729, 478, '46', NULL, NULL);
INSERT INTO point VALUES (7730, 27, '8', NULL, NULL);
INSERT INTO point VALUES (7731, 183, '41', NULL, NULL);
INSERT INTO point VALUES (7732, 15, '21', NULL, NULL);
INSERT INTO point VALUES (7733, 445, '35', NULL, NULL);
INSERT INTO point VALUES (7734, 100, '77А', NULL, NULL);
INSERT INTO point VALUES (7735, 531, '74А', NULL, NULL);
INSERT INTO point VALUES (7736, 458, '46', NULL, NULL);
INSERT INTO point VALUES (7737, 183, '31', NULL, NULL);
INSERT INTO point VALUES (7738, 168, '20', NULL, NULL);
INSERT INTO point VALUES (7739, 610, '2', NULL, NULL);
INSERT INTO point VALUES (7740, 483, '27', NULL, NULL);
INSERT INTO point VALUES (7741, 620, '11А', NULL, NULL);
INSERT INTO point VALUES (7742, 536, '25', NULL, NULL);
INSERT INTO point VALUES (7743, 139, '25/2', NULL, NULL);
INSERT INTO point VALUES (7744, 47, '15', NULL, NULL);
INSERT INTO point VALUES (7745, 166, '34/1', NULL, NULL);
INSERT INTO point VALUES (7746, 346, '7', NULL, NULL);
INSERT INTO point VALUES (7747, 96, '22А', NULL, NULL);
INSERT INTO point VALUES (7748, 265, '20', NULL, NULL);
INSERT INTO point VALUES (7749, 419, '15', NULL, NULL);
INSERT INTO point VALUES (7750, 560, '66', NULL, NULL);
INSERT INTO point VALUES (7751, 186, '9', NULL, NULL);
INSERT INTO point VALUES (7752, 45, '4', NULL, NULL);
INSERT INTO point VALUES (7753, 554, '84', NULL, NULL);
INSERT INTO point VALUES (7754, 42, '3', NULL, NULL);
INSERT INTO point VALUES (7755, 502, '3', NULL, NULL);
INSERT INTO point VALUES (7756, 335, '8', NULL, NULL);
INSERT INTO point VALUES (7757, 679, '6', NULL, NULL);
INSERT INTO point VALUES (7758, 268, '16', NULL, NULL);
INSERT INTO point VALUES (7759, 46, '10', NULL, NULL);
INSERT INTO point VALUES (7760, 25, '22', NULL, NULL);
INSERT INTO point VALUES (7761, 477, '24', NULL, NULL);
INSERT INTO point VALUES (7762, 139, '16', NULL, NULL);
INSERT INTO point VALUES (7763, 9, '81', NULL, NULL);
INSERT INTO point VALUES (7764, 180, '3', NULL, NULL);
INSERT INTO point VALUES (7765, 670, '33', NULL, NULL);
INSERT INTO point VALUES (7766, 233, '6', NULL, NULL);
INSERT INTO point VALUES (7767, 67, '116/1', NULL, NULL);
INSERT INTO point VALUES (7768, 285, '8А', NULL, NULL);
INSERT INTO point VALUES (7769, 600, '5', NULL, NULL);
INSERT INTO point VALUES (7770, 372, '11', NULL, NULL);
INSERT INTO point VALUES (7771, 352, '28', NULL, NULL);
INSERT INTO point VALUES (7772, 304, '71', NULL, NULL);
INSERT INTO point VALUES (7773, 682, '11', NULL, NULL);
INSERT INTO point VALUES (7774, 294, '202', NULL, NULL);
INSERT INTO point VALUES (7775, 291, '4', NULL, NULL);
INSERT INTO point VALUES (7776, 384, '23', NULL, NULL);
INSERT INTO point VALUES (7777, 565, '15', NULL, NULL);
INSERT INTO point VALUES (7778, 496, '46', NULL, NULL);
INSERT INTO point VALUES (7779, 259, '4', NULL, NULL);
INSERT INTO point VALUES (7780, 569, '6', NULL, NULL);
INSERT INTO point VALUES (7781, 531, '63', NULL, NULL);
INSERT INTO point VALUES (7782, 170, '7', NULL, NULL);
INSERT INTO point VALUES (7783, 630, '9', NULL, NULL);
INSERT INTO point VALUES (7784, 139, '9/2', NULL, NULL);
INSERT INTO point VALUES (7785, 548, '50/1', NULL, NULL);
INSERT INTO point VALUES (7786, 52, '5', NULL, NULL);
INSERT INTO point VALUES (7787, 374, '7', NULL, NULL);
INSERT INTO point VALUES (7788, 111, '28А', NULL, NULL);
INSERT INTO point VALUES (7789, 236, '51', NULL, NULL);
INSERT INTO point VALUES (7790, 560, '24', NULL, NULL);
INSERT INTO point VALUES (7791, 425, '36', NULL, NULL);
INSERT INTO point VALUES (7792, 397, '23', NULL, NULL);
INSERT INTO point VALUES (7793, 213, '19', NULL, NULL);
INSERT INTO point VALUES (7794, 67, '87/1', NULL, NULL);
INSERT INTO point VALUES (7795, 692, '15', NULL, NULL);
INSERT INTO point VALUES (7796, 447, '45', NULL, NULL);
INSERT INTO point VALUES (7797, 117, '39', NULL, NULL);
INSERT INTO point VALUES (7798, 600, '2', NULL, NULL);
INSERT INTO point VALUES (7799, 496, '10А', NULL, NULL);
INSERT INTO point VALUES (7800, 245, '11', NULL, NULL);
INSERT INTO point VALUES (7801, 294, '51', NULL, NULL);
INSERT INTO point VALUES (7802, 146, '13', NULL, NULL);
INSERT INTO point VALUES (7803, 499, '6', NULL, NULL);
INSERT INTO point VALUES (7804, 554, '101', NULL, NULL);
INSERT INTO point VALUES (7805, 461, '6', NULL, NULL);
INSERT INTO point VALUES (7806, 389, '49', NULL, NULL);
INSERT INTO point VALUES (7807, 552, '27', NULL, NULL);
INSERT INTO point VALUES (7808, 131, '22', NULL, NULL);
INSERT INTO point VALUES (7809, 693, '3', NULL, NULL);
INSERT INTO point VALUES (7810, 329, '12', NULL, NULL);
INSERT INTO point VALUES (7811, 370, '3', NULL, NULL);
INSERT INTO point VALUES (7812, 497, '23', NULL, NULL);
INSERT INTO point VALUES (7813, 270, '9', NULL, NULL);
INSERT INTO point VALUES (7814, 478, '40', NULL, NULL);
INSERT INTO point VALUES (7815, 53, '18', NULL, NULL);
INSERT INTO point VALUES (7816, 433, '37', NULL, NULL);
INSERT INTO point VALUES (7817, 329, '58', NULL, NULL);
INSERT INTO point VALUES (7818, 458, '40', NULL, NULL);
INSERT INTO point VALUES (7819, 112, '5', NULL, NULL);
INSERT INTO point VALUES (7820, 45, '11', NULL, NULL);
INSERT INTO point VALUES (7821, 554, '143', NULL, NULL);
INSERT INTO point VALUES (7822, 496, '13/1', NULL, NULL);
INSERT INTO point VALUES (7823, 531, '76В', NULL, NULL);
INSERT INTO point VALUES (7824, 548, '47', NULL, NULL);
INSERT INTO point VALUES (7825, 323, '11', NULL, NULL);
INSERT INTO point VALUES (7826, 415, '41', NULL, NULL);
INSERT INTO point VALUES (7827, 183, '38', NULL, NULL);
INSERT INTO point VALUES (7828, 27, '23', NULL, NULL);
INSERT INTO point VALUES (7829, 117, '17', NULL, NULL);
INSERT INTO point VALUES (7830, 317, '7', NULL, NULL);
INSERT INTO point VALUES (7831, 339, '1', NULL, NULL);
INSERT INTO point VALUES (7832, 172, '25', NULL, NULL);
INSERT INTO point VALUES (7833, 236, '90', NULL, NULL);
INSERT INTO point VALUES (7834, 542, '4А', NULL, NULL);
INSERT INTO point VALUES (7835, 415, '31', NULL, NULL);
INSERT INTO point VALUES (7836, 664, '16А', NULL, NULL);
INSERT INTO point VALUES (7837, 37, '7', NULL, NULL);
INSERT INTO point VALUES (7838, 496, '27/1', NULL, NULL);
INSERT INTO point VALUES (7839, 496, '45/4', NULL, NULL);
INSERT INTO point VALUES (7840, 601, '72', NULL, NULL);
INSERT INTO point VALUES (7841, 606, '19', NULL, NULL);
INSERT INTO point VALUES (7842, 447, '3', NULL, NULL);
INSERT INTO point VALUES (7843, 696, '6', NULL, NULL);
INSERT INTO point VALUES (7844, 53, '36', NULL, NULL);
INSERT INTO point VALUES (7845, 55, '32', NULL, NULL);
INSERT INTO point VALUES (7846, 334, '27', NULL, NULL);
INSERT INTO point VALUES (7847, 374, '32', NULL, NULL);
INSERT INTO point VALUES (7848, 99, '17А', NULL, NULL);
INSERT INTO point VALUES (7849, 408, '8', NULL, NULL);
INSERT INTO point VALUES (7850, 670, '21А', NULL, NULL);
INSERT INTO point VALUES (7851, 236, '53', NULL, NULL);
INSERT INTO point VALUES (7852, 455, '64', NULL, NULL);
INSERT INTO point VALUES (7853, 347, '11', NULL, NULL);
INSERT INTO point VALUES (7854, 24, '2', NULL, NULL);
INSERT INTO point VALUES (7855, 256, '5', NULL, NULL);
INSERT INTO point VALUES (7856, 427, '2', NULL, NULL);
INSERT INTO point VALUES (7857, 692, '14А', NULL, NULL);
INSERT INTO point VALUES (7858, 8, '4А', NULL, NULL);
INSERT INTO point VALUES (7859, 294, '53', NULL, NULL);
INSERT INTO point VALUES (7860, 278, '5', NULL, NULL);
INSERT INTO point VALUES (7861, 566, '36/1', NULL, NULL);
INSERT INTO point VALUES (7862, 694, '15', NULL, NULL);
INSERT INTO point VALUES (7863, 49, '35', NULL, NULL);
INSERT INTO point VALUES (7864, 111, '31', NULL, NULL);
INSERT INTO point VALUES (7865, 250, '20', NULL, NULL);
INSERT INTO point VALUES (7866, 562, '31', NULL, NULL);
INSERT INTO point VALUES (7867, 601, '100', NULL, NULL);
INSERT INTO point VALUES (7868, 562, '41', NULL, NULL);
INSERT INTO point VALUES (7869, 664, '18А', NULL, NULL);
INSERT INTO point VALUES (7870, 180, '45', NULL, NULL);
INSERT INTO point VALUES (7871, 262, '15А', NULL, NULL);
INSERT INTO point VALUES (7872, 374, '25', NULL, NULL);
INSERT INTO point VALUES (7873, 531, '127/5', NULL, NULL);
INSERT INTO point VALUES (7874, 139, '20', NULL, NULL);
INSERT INTO point VALUES (7875, 183, '47', NULL, NULL);
INSERT INTO point VALUES (7876, 654, '10', NULL, NULL);
INSERT INTO point VALUES (7877, 294, '90', NULL, NULL);
INSERT INTO point VALUES (7878, 256, '2', NULL, NULL);
INSERT INTO point VALUES (7879, 184, '5', NULL, NULL);
INSERT INTO point VALUES (7880, 362, '24', NULL, NULL);
INSERT INTO point VALUES (7881, 24, '5', NULL, NULL);
INSERT INTO point VALUES (7882, 292, '23', NULL, NULL);
INSERT INTO point VALUES (7883, 170, '25', NULL, NULL);
INSERT INTO point VALUES (7884, 548, '38', NULL, NULL);
INSERT INTO point VALUES (7885, 294, '127А', NULL, NULL);
INSERT INTO point VALUES (7886, 178, '13', NULL, NULL);
INSERT INTO point VALUES (7887, 235, '55', NULL, NULL);
INSERT INTO point VALUES (7888, 294, '167', NULL, NULL);
INSERT INTO point VALUES (7889, 411, '34', NULL, NULL);
INSERT INTO point VALUES (7890, 443, '5', NULL, NULL);
INSERT INTO point VALUES (7891, 46, '6', NULL, NULL);
INSERT INTO point VALUES (7892, 571, '39', NULL, NULL);
INSERT INTO point VALUES (7893, 679, '10', NULL, NULL);
INSERT INTO point VALUES (7894, 262, '1Б', NULL, NULL);
INSERT INTO point VALUES (7895, 280, '83', NULL, NULL);
INSERT INTO point VALUES (7896, 666, '35', NULL, NULL);
INSERT INTO point VALUES (7897, 495, '13', NULL, NULL);
INSERT INTO point VALUES (7898, 506, '2А', NULL, NULL);
INSERT INTO point VALUES (7899, 349, '10', NULL, NULL);
INSERT INTO point VALUES (7900, 8, '2', NULL, NULL);
INSERT INTO point VALUES (7901, 604, '15/187', NULL, NULL);
INSERT INTO point VALUES (7902, 111, '40', NULL, NULL);
INSERT INTO point VALUES (7903, 565, '44', NULL, NULL);
INSERT INTO point VALUES (7904, 96, '12', NULL, NULL);
INSERT INTO point VALUES (7905, 44, '30', NULL, NULL);
INSERT INTO point VALUES (7906, 610, '27', NULL, NULL);
INSERT INTO point VALUES (7907, 30, '5', NULL, NULL);
INSERT INTO point VALUES (7908, 250, '90', NULL, NULL);
INSERT INTO point VALUES (7909, 100, '45', NULL, NULL);
INSERT INTO point VALUES (7910, 138, '8', NULL, NULL);
INSERT INTO point VALUES (7911, 496, '38', NULL, NULL);
INSERT INTO point VALUES (7912, 374, '39', NULL, NULL);
INSERT INTO point VALUES (7913, 232, '24', NULL, NULL);
INSERT INTO point VALUES (7914, 435, '63', NULL, NULL);
INSERT INTO point VALUES (7915, 692, '24', NULL, NULL);
INSERT INTO point VALUES (7916, 279, '49', NULL, NULL);
INSERT INTO point VALUES (7917, 163, '36', NULL, NULL);
INSERT INTO point VALUES (7918, 215, '67', NULL, NULL);
INSERT INTO point VALUES (7919, 202, '44', NULL, NULL);
INSERT INTO point VALUES (7920, 304, '73', NULL, NULL);
INSERT INTO point VALUES (7921, 117, '30А', NULL, NULL);
INSERT INTO point VALUES (7922, 48, '32', NULL, NULL);
INSERT INTO point VALUES (7923, 478, '54', NULL, NULL);
INSERT INTO point VALUES (7924, 142, '41', NULL, NULL);
INSERT INTO point VALUES (7925, 451, '39А', NULL, NULL);
INSERT INTO point VALUES (7926, 303, '42', NULL, NULL);
INSERT INTO point VALUES (7927, 235, '14', NULL, NULL);
INSERT INTO point VALUES (7928, 59, '6', NULL, NULL);
INSERT INTO point VALUES (7929, 542, '2', NULL, NULL);
INSERT INTO point VALUES (7930, 632, '7', NULL, NULL);
INSERT INTO point VALUES (7931, 40, '28', NULL, NULL);
INSERT INTO point VALUES (7932, 531, '5', NULL, NULL);
INSERT INTO point VALUES (7933, 250, '53', NULL, NULL);
INSERT INTO point VALUES (7934, 618, '13', NULL, NULL);
INSERT INTO point VALUES (7935, 231, '1', NULL, NULL);
INSERT INTO point VALUES (7936, 601, '4', NULL, NULL);
INSERT INTO point VALUES (7937, 294, '143', NULL, NULL);
INSERT INTO point VALUES (7938, 464, '36/1', NULL, NULL);
INSERT INTO point VALUES (7939, 571, '32', NULL, NULL);
INSERT INTO point VALUES (7940, 234, '11', NULL, NULL);
INSERT INTO point VALUES (7941, 208, '22', NULL, NULL);
INSERT INTO point VALUES (7942, 236, '20', NULL, NULL);
INSERT INTO point VALUES (7943, 483, '5', NULL, NULL);
INSERT INTO point VALUES (7944, 518, '4', NULL, NULL);
INSERT INTO point VALUES (7945, 585, '2', NULL, NULL);
INSERT INTO point VALUES (7946, 663, '22', NULL, NULL);
INSERT INTO point VALUES (7947, 19, '12', NULL, NULL);
INSERT INTO point VALUES (7948, 315, '11', NULL, NULL);
INSERT INTO point VALUES (7949, 225, '16', NULL, NULL);
INSERT INTO point VALUES (7950, 30, '2', NULL, NULL);
INSERT INTO point VALUES (7951, 202, '24', NULL, NULL);
INSERT INTO point VALUES (7952, 531, '2', NULL, NULL);
INSERT INTO point VALUES (7953, 670, '15', NULL, NULL);
INSERT INTO point VALUES (7954, 473, '3А', NULL, NULL);
INSERT INTO point VALUES (7955, 560, '15', NULL, NULL);
INSERT INTO point VALUES (7956, 273, '14', NULL, NULL);
INSERT INTO point VALUES (7957, 172, '39', NULL, NULL);
INSERT INTO point VALUES (7958, 207, '6', NULL, NULL);
INSERT INTO point VALUES (7959, 219, '14', NULL, NULL);
INSERT INTO point VALUES (7960, 451, '52', NULL, NULL);
INSERT INTO point VALUES (7961, 202, '33', NULL, NULL);
INSERT INTO point VALUES (7962, 48, '25', NULL, NULL);
INSERT INTO point VALUES (7963, 679, '12', NULL, NULL);
INSERT INTO point VALUES (7964, 539, '20', NULL, NULL);
INSERT INTO point VALUES (7965, 542, '17Б', NULL, NULL);
INSERT INTO point VALUES (7966, 304, '55', NULL, NULL);
INSERT INTO point VALUES (7967, 639, '21', NULL, NULL);
INSERT INTO point VALUES (7968, 542, '5', NULL, NULL);
INSERT INTO point VALUES (7969, 496, '47', NULL, NULL);
INSERT INTO point VALUES (7970, 531, '212', NULL, NULL);
INSERT INTO point VALUES (7971, 561, '22', NULL, NULL);
INSERT INTO point VALUES (7972, 271, '2А', NULL, NULL);
INSERT INTO point VALUES (7973, 52, '3 к3', NULL, NULL);
INSERT INTO point VALUES (7974, 374, '67', NULL, NULL);
INSERT INTO point VALUES (7975, 587, '5', NULL, NULL);
INSERT INTO point VALUES (7976, 620, '38а', NULL, NULL);
INSERT INTO point VALUES (7977, 169, '19', NULL, NULL);
INSERT INTO point VALUES (7978, 87, '19', NULL, NULL);
INSERT INTO point VALUES (7979, 405, '4', NULL, NULL);
INSERT INTO point VALUES (7980, 316, '6', NULL, NULL);
INSERT INTO point VALUES (7981, 384, '1/1', NULL, NULL);
INSERT INTO point VALUES (7982, 539, '16', NULL, NULL);
INSERT INTO point VALUES (7983, 48, '7', NULL, NULL);
INSERT INTO point VALUES (7984, 98, '18', NULL, NULL);
INSERT INTO point VALUES (7985, 334, '29', NULL, NULL);
INSERT INTO point VALUES (7986, 554, '90', NULL, NULL);
INSERT INTO point VALUES (7987, 137, '4', NULL, NULL);
INSERT INTO point VALUES (7988, 295, '11', NULL, NULL);
INSERT INTO point VALUES (7989, 303, '66', NULL, NULL);
INSERT INTO point VALUES (7990, 464, '14', NULL, NULL);
INSERT INTO point VALUES (7991, 674, '18', NULL, NULL);
INSERT INTO point VALUES (7992, 117, '25', NULL, NULL);
INSERT INTO point VALUES (7993, 294, '190', NULL, NULL);
INSERT INTO point VALUES (7994, 250, '51', NULL, NULL);
INSERT INTO point VALUES (7995, 49, '8', NULL, NULL);
INSERT INTO point VALUES (7996, 447, '82', NULL, NULL);
INSERT INTO point VALUES (7997, 260, '9', NULL, NULL);
INSERT INTO point VALUES (7998, 362, '15', NULL, NULL);
INSERT INTO point VALUES (7999, 183, '46', NULL, NULL);
INSERT INTO point VALUES (8000, 465, '74', NULL, NULL);
INSERT INTO point VALUES (8001, 643, '24', NULL, NULL);
INSERT INTO point VALUES (8002, 98, '16/1', NULL, NULL);
INSERT INTO point VALUES (8003, 100, '3', NULL, NULL);
INSERT INTO point VALUES (8004, 94, '21', NULL, NULL);
INSERT INTO point VALUES (8005, 203, '6', NULL, NULL);
INSERT INTO point VALUES (8006, 638, '3', NULL, NULL);
INSERT INTO point VALUES (8007, 26, '47', NULL, NULL);
INSERT INTO point VALUES (8008, 223, '9', NULL, NULL);
INSERT INTO point VALUES (8009, 374, '58/2', NULL, NULL);
INSERT INTO point VALUES (8010, 111, '30', NULL, NULL);
INSERT INTO point VALUES (8011, 170, '17', NULL, NULL);
INSERT INTO point VALUES (8012, 227, '13', NULL, NULL);
INSERT INTO point VALUES (8013, 329, '10', NULL, NULL);
INSERT INTO point VALUES (8014, 294, '16', NULL, NULL);
INSERT INTO point VALUES (8015, 169, '1', NULL, NULL);
INSERT INTO point VALUES (8016, 87, '1', NULL, NULL);
INSERT INTO point VALUES (8017, 44, '40', NULL, NULL);
INSERT INTO point VALUES (8018, 374, '17', NULL, NULL);
INSERT INTO point VALUES (8019, 548, '46', NULL, NULL);
INSERT INTO point VALUES (8020, 382, '4', NULL, NULL);
INSERT INTO point VALUES (8021, 547, '3А', NULL, NULL);
INSERT INTO point VALUES (8022, 525, '13', NULL, NULL);
INSERT INTO point VALUES (8023, 421, '24А', NULL, NULL);
INSERT INTO point VALUES (8024, 445, '23', NULL, NULL);
INSERT INTO point VALUES (8025, 294, '194', NULL, NULL);
INSERT INTO point VALUES (8026, 643, '33', NULL, NULL);
INSERT INTO point VALUES (8027, 411, '23', NULL, NULL);
INSERT INTO point VALUES (8028, 469, '8', NULL, NULL);
INSERT INTO point VALUES (8029, 78, '3', NULL, NULL);
INSERT INTO point VALUES (8030, 117, '32', NULL, NULL);
INSERT INTO point VALUES (8031, 480, '42', NULL, NULL);
INSERT INTO point VALUES (8032, 544, '22', NULL, NULL);
INSERT INTO point VALUES (8033, 308, '26', NULL, NULL);
INSERT INTO point VALUES (8034, 78, '10;1', NULL, NULL);
INSERT INTO point VALUES (8035, 40, '3', NULL, NULL);
INSERT INTO point VALUES (8036, 182, '3', NULL, NULL);
INSERT INTO point VALUES (8037, 496, '72А', NULL, NULL);
INSERT INTO point VALUES (8038, 465, '34', NULL, NULL);
INSERT INTO point VALUES (8039, 277, '3', NULL, NULL);
INSERT INTO point VALUES (8040, 231, '13', NULL, NULL);
INSERT INTO point VALUES (8041, 604, '14', NULL, NULL);
INSERT INTO point VALUES (8042, 349, '6', NULL, NULL);
INSERT INTO point VALUES (8043, 566, '1Б', NULL, NULL);
INSERT INTO point VALUES (8044, 6, '15', NULL, NULL);
INSERT INTO point VALUES (8045, 362, '17/1', NULL, NULL);
INSERT INTO point VALUES (8046, 509, '15', NULL, NULL);
INSERT INTO point VALUES (8047, 468, '33', NULL, NULL);
INSERT INTO point VALUES (8048, 405, '11', NULL, NULL);
INSERT INTO point VALUES (8049, 161, '22', NULL, NULL);
INSERT INTO point VALUES (8050, 386, '2', NULL, NULL);
INSERT INTO point VALUES (8051, 183, '40', NULL, NULL);
INSERT INTO point VALUES (8052, 464, '50А', NULL, NULL);
INSERT INTO point VALUES (8053, 334, '5', NULL, NULL);
INSERT INTO point VALUES (8054, 374, '23/9', NULL, NULL);
INSERT INTO point VALUES (8055, 601, '50', NULL, NULL);
INSERT INTO point VALUES (8056, 59, '10', NULL, NULL);
INSERT INTO point VALUES (8057, 468, '24', NULL, NULL);
INSERT INTO point VALUES (8058, 565, '42', NULL, NULL);
INSERT INTO point VALUES (8059, 506, '2', NULL, NULL);
INSERT INTO point VALUES (8060, 74, '15', NULL, NULL);
INSERT INTO point VALUES (8061, 361, '3', NULL, NULL);
INSERT INTO point VALUES (8062, 406, '5', NULL, NULL);
INSERT INTO point VALUES (8063, 137, '11', NULL, NULL);
INSERT INTO point VALUES (8064, 285, '12А', NULL, NULL);
INSERT INTO point VALUES (8065, 560, '98', NULL, NULL);
INSERT INTO point VALUES (8066, 472, '22', NULL, NULL);
INSERT INTO point VALUES (8067, 434, '14', NULL, NULL);
INSERT INTO point VALUES (8068, 150, '16', NULL, NULL);
INSERT INTO point VALUES (8069, 250, '88А', NULL, NULL);
INSERT INTO point VALUES (8070, 374, '103/1', NULL, NULL);
INSERT INTO point VALUES (8071, 598, '22', NULL, NULL);
INSERT INTO point VALUES (8072, 31, '4', NULL, NULL);
INSERT INTO point VALUES (8073, 215, '69', NULL, NULL);
INSERT INTO point VALUES (8074, 67, '70', NULL, NULL);
INSERT INTO point VALUES (8075, 496, '31', NULL, NULL);
INSERT INTO point VALUES (8076, 303, '33', NULL, NULL);
INSERT INTO point VALUES (8077, 386, '5', NULL, NULL);
INSERT INTO point VALUES (8078, 278, '27', NULL, NULL);
INSERT INTO point VALUES (8079, 302, '5', NULL, NULL);
INSERT INTO point VALUES (8080, 84, '21', NULL, NULL);
INSERT INTO point VALUES (8081, 176, '22', NULL, NULL);
INSERT INTO point VALUES (8082, 389, '37', NULL, NULL);
INSERT INTO point VALUES (8083, 374, '105', NULL, NULL);
INSERT INTO point VALUES (8084, 431, '22', NULL, NULL);
INSERT INTO point VALUES (8085, 496, '41', NULL, NULL);
INSERT INTO point VALUES (8086, 3, '20', NULL, NULL);
INSERT INTO point VALUES (8087, 375, '13', NULL, NULL);
INSERT INTO point VALUES (8088, 374, '97', NULL, NULL);
INSERT INTO point VALUES (8089, 563, '4', NULL, NULL);
INSERT INTO point VALUES (8090, 393, '7', NULL, NULL);
INSERT INTO point VALUES (8091, 166, '30', NULL, NULL);
INSERT INTO point VALUES (8092, 157, '8', NULL, NULL);
INSERT INTO point VALUES (8093, 610, '4А', NULL, NULL);
INSERT INTO point VALUES (8094, 67, '68', NULL, NULL);
INSERT INTO point VALUES (8095, 207, '10', NULL, NULL);
INSERT INTO point VALUES (8096, 425, '78', NULL, NULL);
INSERT INTO point VALUES (8097, 425, '64', NULL, NULL);
INSERT INTO point VALUES (8098, 184, '27', NULL, NULL);
INSERT INTO point VALUES (8099, 220, '22', NULL, NULL);
INSERT INTO point VALUES (8100, 334, '2', NULL, NULL);
INSERT INTO point VALUES (8101, 248, '10', NULL, NULL);
INSERT INTO point VALUES (8102, 46, '12', NULL, NULL);
INSERT INTO point VALUES (8103, 548, '40', NULL, NULL);
INSERT INTO point VALUES (8104, 503, '8', NULL, NULL);
INSERT INTO point VALUES (8105, 538, '16', NULL, NULL);
INSERT INTO point VALUES (8106, 76, '2', NULL, NULL);
INSERT INTO point VALUES (8107, 406, '2', NULL, NULL);
INSERT INTO point VALUES (8108, 374, '102А', NULL, NULL);
INSERT INTO point VALUES (8109, 496, '3Б', NULL, NULL);
INSERT INTO point VALUES (8110, 67, '115/4', NULL, NULL);
INSERT INTO point VALUES (8111, 560, '86', NULL, NULL);
INSERT INTO point VALUES (8112, 435, '27', NULL, NULL);
INSERT INTO point VALUES (8113, 578, '4/1', NULL, NULL);
INSERT INTO point VALUES (8114, 604, '15/90', NULL, NULL);
INSERT INTO point VALUES (8115, 460, '7', NULL, NULL);
INSERT INTO point VALUES (8116, 139, '23/2', NULL, NULL);
INSERT INTO point VALUES (8117, 192, '2', NULL, NULL);
INSERT INTO point VALUES (8118, 67, '87', NULL, NULL);
INSERT INTO point VALUES (8119, 538, '20', NULL, NULL);
INSERT INTO point VALUES (8120, 607, '5', NULL, NULL);
INSERT INTO point VALUES (8121, 183, '52/23', NULL, NULL);
INSERT INTO point VALUES (8122, 478, '47', NULL, NULL);
INSERT INTO point VALUES (8123, 480, '33', NULL, NULL);
INSERT INTO point VALUES (8124, 477, '15', NULL, NULL);
INSERT INTO point VALUES (8125, 425, '26', NULL, NULL);
INSERT INTO point VALUES (8126, 496, '28А', NULL, NULL);
INSERT INTO point VALUES (8127, 569, '12', NULL, NULL);
INSERT INTO point VALUES (8128, 433, '24А', NULL, NULL);
INSERT INTO point VALUES (8129, 227, '19', NULL, NULL);
INSERT INTO point VALUES (8130, 496, '95/1', NULL, NULL);
INSERT INTO point VALUES (8131, 338, '2', NULL, NULL);
INSERT INTO point VALUES (8132, 171, '19', NULL, NULL);
INSERT INTO point VALUES (8133, 548, '30', NULL, NULL);
INSERT INTO point VALUES (8134, 531, '29', NULL, NULL);
INSERT INTO point VALUES (8135, 3, '16', NULL, NULL);
INSERT INTO point VALUES (8136, 29, '5', NULL, NULL);
INSERT INTO point VALUES (8137, 277, '96', NULL, NULL);
INSERT INTO point VALUES (8138, 601, '11', NULL, NULL);
INSERT INTO point VALUES (8139, 567, '7', NULL, NULL);
INSERT INTO point VALUES (8140, 12, '4', NULL, NULL);
INSERT INTO point VALUES (8141, 329, '56', NULL, NULL);
INSERT INTO point VALUES (8142, 445, '8', NULL, NULL);
INSERT INTO point VALUES (8143, 411, '8', NULL, NULL);
INSERT INTO point VALUES (8144, 499, '12', NULL, NULL);
INSERT INTO point VALUES (8145, 203, '10', NULL, NULL);
INSERT INTO point VALUES (8146, 496, '54', NULL, NULL);
INSERT INTO point VALUES (8147, 192, '5', NULL, NULL);
INSERT INTO point VALUES (8148, 236, '84', NULL, NULL);
INSERT INTO point VALUES (8149, 20, '11', NULL, NULL);
INSERT INTO point VALUES (8150, 183, '30', NULL, NULL);
INSERT INTO point VALUES (8151, 226, '3', NULL, NULL);
INSERT INTO point VALUES (8152, 483, '29', NULL, NULL);
INSERT INTO point VALUES (8153, 315, '4', NULL, NULL);
INSERT INTO point VALUES (8154, 112, '17 к1', NULL, NULL);
INSERT INTO point VALUES (8155, 329, '6', NULL, NULL);
INSERT INTO point VALUES (8156, 525, '1', NULL, NULL);
INSERT INTO point VALUES (8157, 110, '14', NULL, NULL);
INSERT INTO point VALUES (8158, 518, '11', NULL, NULL);
INSERT INTO point VALUES (8159, 542, '61', NULL, NULL);
INSERT INTO point VALUES (8160, 569, '49А', NULL, NULL);
INSERT INTO point VALUES (8161, 376, '26А', NULL, NULL);
INSERT INTO point VALUES (8162, 536, '17', NULL, NULL);
INSERT INTO point VALUES (8163, 458, '38', NULL, NULL);
INSERT INTO point VALUES (8164, 469, '8А', NULL, NULL);
INSERT INTO point VALUES (8165, 455, '36', NULL, NULL);
INSERT INTO point VALUES (8166, 152, '17', NULL, NULL);
INSERT INTO point VALUES (8167, 26, '41', NULL, NULL);
INSERT INTO point VALUES (8168, 243, '6Б', NULL, NULL);
INSERT INTO point VALUES (8169, 548, '45/6', NULL, NULL);
INSERT INTO point VALUES (8170, 169, '13', NULL, NULL);
INSERT INTO point VALUES (8171, 87, '13', NULL, NULL);
INSERT INTO point VALUES (8172, 27, '12А', NULL, NULL);
INSERT INTO point VALUES (8173, 94, '19А', NULL, NULL);
INSERT INTO point VALUES (8174, 531, '139', NULL, NULL);
INSERT INTO point VALUES (8175, 478, '38', NULL, NULL);
INSERT INTO point VALUES (8176, 49, '23', NULL, NULL);
INSERT INTO point VALUES (8177, 338, '5', NULL, NULL);
INSERT INTO point VALUES (8178, 26, '31', NULL, NULL);
INSERT INTO point VALUES (8179, 95, '37', NULL, NULL);
INSERT INTO point VALUES (8180, 542, '29', NULL, NULL);
INSERT INTO point VALUES (8181, 374, '99', NULL, NULL);
INSERT INTO point VALUES (8182, 390, '30', NULL, NULL);
INSERT INTO point VALUES (8183, 496, '129', NULL, NULL);
INSERT INTO point VALUES (8184, 531, '65', NULL, NULL);
INSERT INTO point VALUES (8185, 561, '15', NULL, NULL);
INSERT INTO point VALUES (8186, 223, '29', NULL, NULL);
INSERT INTO point VALUES (8187, 434, '13', NULL, NULL);
INSERT INTO point VALUES (8188, 274, '4', NULL, NULL);
INSERT INTO point VALUES (8189, 444, '4', NULL, NULL);
INSERT INTO point VALUES (8190, 469, '7', NULL, NULL);
INSERT INTO point VALUES (8191, 386, '9', NULL, NULL);
INSERT INTO point VALUES (8192, 395, '9А', NULL, NULL);
INSERT INTO point VALUES (8193, 687, '34', NULL, NULL);
INSERT INTO point VALUES (8194, 150, '6', NULL, NULL);
INSERT INTO point VALUES (8195, 133, '11', NULL, NULL);
INSERT INTO point VALUES (8196, 76, '26', NULL, NULL);
INSERT INTO point VALUES (8197, 554, '112', NULL, NULL);
INSERT INTO point VALUES (8198, 299, '20', NULL, NULL);
INSERT INTO point VALUES (8199, 111, '21', NULL, NULL);
INSERT INTO point VALUES (8200, 601, '108', NULL, NULL);
INSERT INTO point VALUES (8201, 617, '33', NULL, NULL);
INSERT INTO point VALUES (8202, 653, '41', NULL, NULL);
INSERT INTO point VALUES (8203, 338, '64', NULL, NULL);
INSERT INTO point VALUES (8204, 374, '74', NULL, NULL);
INSERT INTO point VALUES (8205, 653, '31', NULL, NULL);
INSERT INTO point VALUES (8206, 604, '13', NULL, NULL);
INSERT INTO point VALUES (8207, 89, '3', NULL, NULL);
INSERT INTO point VALUES (8208, 280, '107', NULL, NULL);
INSERT INTO point VALUES (8209, 362, '22', NULL, NULL);
INSERT INTO point VALUES (8210, 280, '38', NULL, NULL);
INSERT INTO point VALUES (8211, 310, '28', NULL, NULL);
INSERT INTO point VALUES (8212, 421, '11', NULL, NULL);
INSERT INTO point VALUES (8213, 208, '14А', NULL, NULL);
INSERT INTO point VALUES (8214, 48, '8', NULL, NULL);
INSERT INTO point VALUES (8215, 234, '49', NULL, NULL);
INSERT INTO point VALUES (8216, 538, '6', NULL, NULL);
INSERT INTO point VALUES (8217, 280, '47', NULL, NULL);
INSERT INTO point VALUES (8218, 120, '28', NULL, NULL);
INSERT INTO point VALUES (8219, 531, '214', NULL, NULL);
INSERT INTO point VALUES (8220, 356, '8', NULL, NULL);
INSERT INTO point VALUES (8221, 654, '51', NULL, NULL);
INSERT INTO point VALUES (8222, 294, '94', NULL, NULL);
INSERT INTO point VALUES (8223, 49, '7', NULL, NULL);
INSERT INTO point VALUES (8224, 474, '4', NULL, NULL);
INSERT INTO point VALUES (8225, 79, '1', NULL, NULL);
INSERT INTO point VALUES (8226, 235, '19', NULL, NULL);
INSERT INTO point VALUES (8227, 88, '37', NULL, NULL);
INSERT INTO point VALUES (8228, 58, '7', NULL, NULL);
INSERT INTO point VALUES (8229, 273, '1', NULL, NULL);
INSERT INTO point VALUES (8230, 250, '57', NULL, NULL);
INSERT INTO point VALUES (8231, 544, '15', NULL, NULL);
INSERT INTO point VALUES (8232, 406, '9', NULL, NULL);
INSERT INTO point VALUES (8233, 57, '17', NULL, NULL);
INSERT INTO point VALUES (8234, 225, '10', NULL, NULL);
INSERT INTO point VALUES (8235, 334, '9', NULL, NULL);
INSERT INTO point VALUES (8236, 531, '164', NULL, NULL);
INSERT INTO point VALUES (8237, 415, '21', NULL, NULL);
INSERT INTO point VALUES (8238, 552, '9', NULL, NULL);
INSERT INTO point VALUES (8239, 201, '6', NULL, NULL);
INSERT INTO point VALUES (8240, 542, '53А', NULL, NULL);
INSERT INTO point VALUES (8241, 649, '29', NULL, NULL);
INSERT INTO point VALUES (8242, 531, '20А', NULL, NULL);
INSERT INTO point VALUES (8243, 250, '12', NULL, NULL);
INSERT INTO point VALUES (8244, 447, '62', NULL, NULL);
INSERT INTO point VALUES (8245, 49, '25', NULL, NULL);
INSERT INTO point VALUES (8246, 496, '45/3', NULL, NULL);
INSERT INTO point VALUES (8247, 393, '8А', NULL, NULL);
INSERT INTO point VALUES (8248, 254, '11', NULL, NULL);
INSERT INTO point VALUES (8249, 625, '11', NULL, NULL);
INSERT INTO point VALUES (8250, 656, '11', NULL, NULL);
INSERT INTO point VALUES (8251, 236, '104', NULL, NULL);
INSERT INTO point VALUES (8252, 61, '37', NULL, NULL);
INSERT INTO point VALUES (8253, 465, '39', NULL, NULL);
INSERT INTO point VALUES (8254, 262, '13', NULL, NULL);
INSERT INTO point VALUES (8255, 432, '11', NULL, NULL);
INSERT INTO point VALUES (8256, 192, '9', NULL, NULL);
INSERT INTO point VALUES (8257, 3, '6', NULL, NULL);
INSERT INTO point VALUES (8258, 290, '2', NULL, NULL);
INSERT INTO point VALUES (8259, 519, '11', NULL, NULL);
INSERT INTO point VALUES (8260, 170, '29А', NULL, NULL);
INSERT INTO point VALUES (8261, 303, '76', NULL, NULL);
INSERT INTO point VALUES (8262, 338, '9', NULL, NULL);
INSERT INTO point VALUES (8263, 464, '1', NULL, NULL);
INSERT INTO point VALUES (8264, 425, '5', NULL, NULL);
INSERT INTO point VALUES (8265, 261, '11/1', NULL, NULL);
INSERT INTO point VALUES (8266, 67, '72', NULL, NULL);
INSERT INTO point VALUES (8267, 170, '35', NULL, NULL);
INSERT INTO point VALUES (8268, 489, '33', NULL, NULL);
INSERT INTO point VALUES (8269, 582, '3', NULL, NULL);
INSERT INTO point VALUES (8270, 374, '35', NULL, NULL);
INSERT INTO point VALUES (8271, 374, '155', NULL, NULL);
INSERT INTO point VALUES (8272, 408, '17', NULL, NULL);
INSERT INTO point VALUES (8273, 269, '4Б', NULL, NULL);
INSERT INTO point VALUES (8274, 539, '10', NULL, NULL);
INSERT INTO point VALUES (8275, 299, '16', NULL, NULL);
INSERT INTO point VALUES (8276, 208, '15', NULL, NULL);
INSERT INTO point VALUES (8277, 604, '201А', NULL, NULL);
INSERT INTO point VALUES (8278, 290, '5', NULL, NULL);
INSERT INTO point VALUES (8279, 286, '8', NULL, NULL);
INSERT INTO point VALUES (8280, 601, '48А', NULL, NULL);
INSERT INTO point VALUES (8281, 390, '40', NULL, NULL);
INSERT INTO point VALUES (8282, 169, '14', NULL, NULL);
INSERT INTO point VALUES (8283, 373, '73', NULL, NULL);
INSERT INTO point VALUES (8284, 613, '10', NULL, NULL);
INSERT INTO point VALUES (8285, 552, '26', NULL, NULL);
INSERT INTO point VALUES (8286, 415, '79', NULL, NULL);
INSERT INTO point VALUES (8287, 21, '38', NULL, NULL);
INSERT INTO point VALUES (8288, 49, '32', NULL, NULL);
INSERT INTO point VALUES (8289, 663, '15', NULL, NULL);
INSERT INTO point VALUES (8290, 505, '3', NULL, NULL);
INSERT INTO point VALUES (8291, 67, '100', NULL, NULL);
INSERT INTO point VALUES (8292, 110, '13', NULL, NULL);
INSERT INTO point VALUES (8293, 294, '104', NULL, NULL);
INSERT INTO point VALUES (8294, 29, '9', NULL, NULL);
INSERT INTO point VALUES (8295, 465, '102', NULL, NULL);
INSERT INTO point VALUES (8296, 376, '47', NULL, NULL);
INSERT INTO point VALUES (8297, 277, '60', NULL, NULL);
INSERT INTO point VALUES (8298, 496, '32 кб', NULL, NULL);
INSERT INTO point VALUES (8299, 374, '41/2', NULL, NULL);
INSERT INTO point VALUES (8300, 138, '7', NULL, NULL);
INSERT INTO point VALUES (8301, 338, '26', NULL, NULL);
INSERT INTO point VALUES (8302, 604, '15/12', NULL, NULL);
INSERT INTO point VALUES (8303, 614, '3', NULL, NULL);
INSERT INTO point VALUES (8304, 294, '10', NULL, NULL);
INSERT INTO point VALUES (8305, 170, '41/2', NULL, NULL);
INSERT INTO point VALUES (8306, 604, '193', NULL, NULL);
INSERT INTO point VALUES (8307, 59, '16', NULL, NULL);
INSERT INTO point VALUES (8308, 604, '1', NULL, NULL);
INSERT INTO point VALUES (8309, 497, '17', NULL, NULL);
INSERT INTO point VALUES (8310, 653, '47', NULL, NULL);
INSERT INTO point VALUES (8311, 294, '208', NULL, NULL);
INSERT INTO point VALUES (8312, 483, '9', NULL, NULL);
INSERT INTO point VALUES (8313, 48, '23', NULL, NULL);
INSERT INTO point VALUES (8314, 585, '26', NULL, NULL);
INSERT INTO point VALUES (8315, 549, '3', NULL, NULL);
INSERT INTO point VALUES (8316, 455, '52А', NULL, NULL);
INSERT INTO point VALUES (8317, 452, '17', NULL, NULL);
INSERT INTO point VALUES (8318, 374, '1/1', NULL, NULL);
INSERT INTO point VALUES (8319, 157, '26а', NULL, NULL);
INSERT INTO point VALUES (8320, 448, '21', NULL, NULL);
INSERT INTO point VALUES (8321, 163, '27', NULL, NULL);
INSERT INTO point VALUES (8322, 285, '17', NULL, NULL);
INSERT INTO point VALUES (8323, 569, '53', NULL, NULL);
INSERT INTO point VALUES (8324, 235, '13', NULL, NULL);
INSERT INTO point VALUES (8325, 519, '4', NULL, NULL);
INSERT INTO point VALUES (8326, 150, '10', NULL, NULL);
INSERT INTO point VALUES (8327, 51, '62', NULL, NULL);
INSERT INTO point VALUES (8328, 643, '76', NULL, NULL);
INSERT INTO point VALUES (8329, 25, '33', NULL, NULL);
INSERT INTO point VALUES (8330, 656, '4', NULL, NULL);
INSERT INTO point VALUES (8331, 577, '17', NULL, NULL);
INSERT INTO point VALUES (8332, 451, '36/1', NULL, NULL);
INSERT INTO point VALUES (8333, 25, '24', NULL, NULL);
INSERT INTO point VALUES (8334, 388, '13А', NULL, NULL);
INSERT INTO point VALUES (8335, 477, '22', NULL, NULL);
INSERT INTO point VALUES (8336, 664, '12', NULL, NULL);
INSERT INTO point VALUES (8337, 531, '26', NULL, NULL);
INSERT INTO point VALUES (8338, 183, '21', NULL, NULL);
INSERT INTO point VALUES (8339, 495, '14', NULL, NULL);
INSERT INTO point VALUES (8340, 434, '1', NULL, NULL);
INSERT INTO point VALUES (8341, 250, '72Б', NULL, NULL);
INSERT INTO point VALUES (8342, 5, '11', NULL, NULL);
INSERT INTO point VALUES (8343, 149, '24', NULL, NULL);
INSERT INTO point VALUES (8344, 395, '8', NULL, NULL);
INSERT INTO point VALUES (8345, 345, '15', NULL, NULL);
INSERT INTO point VALUES (8346, 30, '9', NULL, NULL);
INSERT INTO point VALUES (8347, 283, '21', NULL, NULL);
INSERT INTO point VALUES (8348, 268, '12', NULL, NULL);
INSERT INTO point VALUES (8349, 219, '13', NULL, NULL);
INSERT INTO point VALUES (8350, 445, '7', NULL, NULL);
INSERT INTO point VALUES (8351, 191, '28', NULL, NULL);
INSERT INTO point VALUES (8352, 105, '6', NULL, NULL);
INSERT INTO point VALUES (8353, 483, '26', NULL, NULL);
INSERT INTO point VALUES (8354, 447, '59', NULL, NULL);
INSERT INTO point VALUES (8355, 538, '10', NULL, NULL);
INSERT INTO point VALUES (8356, 575, '2/1', NULL, NULL);
INSERT INTO point VALUES (8357, 687, '12А', NULL, NULL);
INSERT INTO point VALUES (8358, 120, '3', NULL, NULL);
INSERT INTO point VALUES (8359, 531, '9', NULL, NULL);
INSERT INTO point VALUES (8360, 390, '46', NULL, NULL);
INSERT INTO point VALUES (8361, 620, '17', NULL, NULL);
INSERT INTO point VALUES (8362, 225, '6', NULL, NULL);
INSERT INTO point VALUES (8363, 531, '238А', NULL, NULL);
INSERT INTO point VALUES (8364, 434, '19', NULL, NULL);
INSERT INTO point VALUES (8365, 433, '11', NULL, NULL);
INSERT INTO point VALUES (8366, 460, '8', NULL, NULL);
INSERT INTO point VALUES (8367, 601, '139А', NULL, NULL);
INSERT INTO point VALUES (8368, 464, '52', NULL, NULL);
INSERT INTO point VALUES (8369, 67, '172', NULL, NULL);
INSERT INTO point VALUES (8370, 188, '2', NULL, NULL);
INSERT INTO point VALUES (8371, 393, '8', NULL, NULL);
INSERT INTO point VALUES (8372, 582, '28', NULL, NULL);
INSERT INTO point VALUES (8373, 236, '6', NULL, NULL);
INSERT INTO point VALUES (8374, 272, '5', NULL, NULL);
INSERT INTO point VALUES (8375, 55, '34', NULL, NULL);
INSERT INTO point VALUES (8376, 223, '5', NULL, NULL);
INSERT INTO point VALUES (8377, 201, '10', NULL, NULL);
INSERT INTO point VALUES (8378, 170, '9Б', NULL, NULL);
INSERT INTO point VALUES (8379, 157, '7', NULL, NULL);
INSERT INTO point VALUES (8380, 144, '10/1', NULL, NULL);
INSERT INTO point VALUES (8381, 3, '10', NULL, NULL);
INSERT INTO point VALUES (8382, 168, '12', NULL, NULL);
INSERT INTO point VALUES (8383, 279, '4', NULL, NULL);
INSERT INTO point VALUES (8384, 496, '123', NULL, NULL);
INSERT INTO point VALUES (8385, 166, '21', NULL, NULL);
INSERT INTO point VALUES (8386, 445, '25', NULL, NULL);
INSERT INTO point VALUES (8387, 161, '15', NULL, NULL);
INSERT INTO point VALUES (8388, 569, '51', NULL, NULL);
INSERT INTO point VALUES (8389, 411, '25', NULL, NULL);
INSERT INTO point VALUES (8390, 110, '19', NULL, NULL);
INSERT INTO point VALUES (8391, 503, '7', NULL, NULL);
INSERT INTO point VALUES (8392, 509, '22', NULL, NULL);
INSERT INTO point VALUES (8393, 492, '4', NULL, NULL);
INSERT INTO point VALUES (8394, 23, '14', NULL, NULL);
INSERT INTO point VALUES (8395, 242, '6', NULL, NULL);
INSERT INTO point VALUES (8396, 236, '144', NULL, NULL);
INSERT INTO point VALUES (8397, 294, '147', NULL, NULL);
INSERT INTO point VALUES (8398, 347, '37', NULL, NULL);
INSERT INTO point VALUES (8399, 263, '5', NULL, NULL);
INSERT INTO point VALUES (8400, 554, '85', NULL, NULL);
INSERT INTO point VALUES (8401, 262, '1', NULL, NULL);
INSERT INTO point VALUES (8402, 539, '6', NULL, NULL);
INSERT INTO point VALUES (8403, 248, '20', NULL, NULL);
INSERT INTO point VALUES (8404, 571, '25А', NULL, NULL);
INSERT INTO point VALUES (8405, 260, '2', NULL, NULL);
INSERT INTO point VALUES (8406, 598, '15', NULL, NULL);
INSERT INTO point VALUES (8407, 421, '4', NULL, NULL);
INSERT INTO point VALUES (8408, 294, '244', NULL, NULL);
INSERT INTO point VALUES (8409, 2, '28', NULL, NULL);
INSERT INTO point VALUES (8410, 472, '15', NULL, NULL);
INSERT INTO point VALUES (8411, 388, '21', NULL, NULL);
INSERT INTO point VALUES (8412, 100, '75', NULL, NULL);
INSERT INTO point VALUES (8413, 695, '18', NULL, NULL);
INSERT INTO point VALUES (8414, 176, '15', NULL, NULL);
INSERT INTO point VALUES (8415, 299, '16А', NULL, NULL);
INSERT INTO point VALUES (8416, 376, '41', NULL, NULL);
INSERT INTO point VALUES (8417, 614, '28', NULL, NULL);
INSERT INTO point VALUES (8418, 188, '5', NULL, NULL);
INSERT INTO point VALUES (8419, 110, '1', NULL, NULL);
INSERT INTO point VALUES (8420, 531, '141А', NULL, NULL);
INSERT INTO point VALUES (8421, 27, '17', NULL, NULL);
INSERT INTO point VALUES (8422, 548, '45/2', NULL, NULL);
INSERT INTO point VALUES (8423, 149, '21А', NULL, NULL);
INSERT INTO point VALUES (8424, 613, '6', NULL, NULL);
INSERT INTO point VALUES (8425, 431, '15', NULL, NULL);
INSERT INTO point VALUES (8426, 548, '48', NULL, NULL);
INSERT INTO point VALUES (8427, 525, '14', NULL, NULL);
INSERT INTO point VALUES (8428, 411, '32', NULL, NULL);
INSERT INTO point VALUES (8429, 203, '16', NULL, NULL);
INSERT INTO point VALUES (8430, 496, '13/2', NULL, NULL);
INSERT INTO point VALUES (8431, 262, '19', NULL, NULL);
INSERT INTO point VALUES (8432, 260, '5', NULL, NULL);
INSERT INTO point VALUES (8433, 433, '50', NULL, NULL);
INSERT INTO point VALUES (8434, 335, '17', NULL, NULL);
INSERT INTO point VALUES (8435, 101, '15А', NULL, NULL);
INSERT INTO point VALUES (8436, 236, '56', NULL, NULL);
INSERT INTO point VALUES (8437, 395, '11А', NULL, NULL);
INSERT INTO point VALUES (8438, 594, '28', NULL, NULL);
INSERT INTO point VALUES (8439, 294, '6', NULL, NULL);
INSERT INTO point VALUES (8440, 131, '20/2', NULL, NULL);
INSERT INTO point VALUES (8441, 531, '78', NULL, NULL);
INSERT INTO point VALUES (8442, 235, '52', NULL, NULL);
INSERT INTO point VALUES (8443, 657, '21', NULL, NULL);
INSERT INTO point VALUES (8444, 531, '64', NULL, NULL);
INSERT INTO point VALUES (8445, 220, '15', NULL, NULL);
INSERT INTO point VALUES (8446, 263, '2', NULL, NULL);
INSERT INTO point VALUES (8447, 558, '18', NULL, NULL);
INSERT INTO point VALUES (8448, 395, '11Б', NULL, NULL);
INSERT INTO point VALUES (8449, 176, '12', NULL, NULL);
INSERT INTO point VALUES (8450, 338, '11', NULL, NULL);
INSERT INTO point VALUES (8451, 277, '30', NULL, NULL);
INSERT INTO point VALUES (8452, 468, '16', NULL, NULL);
INSERT INTO point VALUES (8453, 432, '9', NULL, NULL);
INSERT INTO point VALUES (8454, 192, '11', NULL, NULL);
INSERT INTO point VALUES (8455, 170, '1', NULL, NULL);
INSERT INTO point VALUES (8456, 536, '13', NULL, NULL);
INSERT INTO point VALUES (8457, 234, '29', NULL, NULL);
INSERT INTO point VALUES (8458, 169, '17', NULL, NULL);
INSERT INTO point VALUES (8459, 254, '9', NULL, NULL);
INSERT INTO point VALUES (8460, 625, '9', NULL, NULL);
INSERT INTO point VALUES (8461, 374, '1', NULL, NULL);
INSERT INTO point VALUES (8462, 220, '12', NULL, NULL);
INSERT INTO point VALUES (8463, 538, '24', NULL, NULL);
INSERT INTO point VALUES (8464, 424, '14', NULL, NULL);
INSERT INTO point VALUES (8465, 236, '66', NULL, NULL);
INSERT INTO point VALUES (8466, 29, '11', NULL, NULL);
INSERT INTO point VALUES (8467, 334, '50', NULL, NULL);
INSERT INTO point VALUES (8468, 601, '5', NULL, NULL);
INSERT INTO point VALUES (8469, 531, '4', NULL, NULL);
INSERT INTO point VALUES (8470, 180, '38', NULL, NULL);
INSERT INTO point VALUES (8471, 388, '3', NULL, NULL);
INSERT INTO point VALUES (8472, 76, '50', NULL, NULL);
INSERT INTO point VALUES (8473, 419, '20', NULL, NULL);
INSERT INTO point VALUES (8474, 30, '4', NULL, NULL);
INSERT INTO point VALUES (8475, 82, '7', NULL, NULL);
INSERT INTO point VALUES (8476, 374, '19', NULL, NULL);
INSERT INTO point VALUES (8477, 548, '45', NULL, NULL);
INSERT INTO point VALUES (8478, 170, '19', NULL, NULL);
INSERT INTO point VALUES (8479, 472, '12', NULL, NULL);
INSERT INTO point VALUES (8480, 67, '95', NULL, NULL);
INSERT INTO point VALUES (8481, 326, '1', NULL, NULL);
INSERT INTO point VALUES (8482, 682, '27', NULL, NULL);
INSERT INTO point VALUES (8483, 455, '68', NULL, NULL);
INSERT INTO point VALUES (8484, 389, '1/2', NULL, NULL);
INSERT INTO point VALUES (8485, 333, '8', NULL, NULL);
INSERT INTO point VALUES (8486, 421, '9', NULL, NULL);
INSERT INTO point VALUES (8487, 51, '54', NULL, NULL);
INSERT INTO point VALUES (8488, 338, '50', NULL, NULL);
INSERT INTO point VALUES (8489, 434, '34', NULL, NULL);
INSERT INTO point VALUES (8490, 489, '6', NULL, NULL);
INSERT INTO point VALUES (8491, 547, '8', NULL, NULL);
INSERT INTO point VALUES (8492, 389, '32Б', NULL, NULL);
INSERT INTO point VALUES (8493, 578, '8', NULL, NULL);
INSERT INTO point VALUES (8494, 386, '11', NULL, NULL);
INSERT INTO point VALUES (8495, 665, '21', NULL, NULL);
INSERT INTO point VALUES (8496, 235, '35', NULL, NULL);
INSERT INTO point VALUES (8497, 636, '16', NULL, NULL);
INSERT INTO point VALUES (8498, 548, '3', NULL, NULL);
INSERT INTO point VALUES (8499, 334, '11', NULL, NULL);
INSERT INTO point VALUES (8500, 615, '12', NULL, NULL);
INSERT INTO point VALUES (8501, 376, '62', NULL, NULL);
INSERT INTO point VALUES (8502, 501, '18', NULL, NULL);
INSERT INTO point VALUES (8503, 125, '16', NULL, NULL);
INSERT INTO point VALUES (8504, 346, '13', NULL, NULL);
INSERT INTO point VALUES (8505, 376, '63/1', NULL, NULL);
INSERT INTO point VALUES (8506, 87, '39', NULL, NULL);
INSERT INTO point VALUES (8507, 201, '44', NULL, NULL);
INSERT INTO point VALUES (8508, 448, '3', NULL, NULL);
INSERT INTO point VALUES (8509, 133, '26', NULL, NULL);
INSERT INTO point VALUES (8510, 294, '109', NULL, NULL);
INSERT INTO point VALUES (8511, 294, '142', NULL, NULL);
INSERT INTO point VALUES (8512, 111, '28', NULL, NULL);
INSERT INTO point VALUES (8513, 304, '23', NULL, NULL);
INSERT INTO point VALUES (8514, 208, '12', NULL, NULL);
INSERT INTO point VALUES (8515, 563, '5', NULL, NULL);
INSERT INTO point VALUES (8516, 191, '48', NULL, NULL);
INSERT INTO point VALUES (8517, 222, '3', NULL, NULL);
INSERT INTO point VALUES (8518, 628, '35', NULL, NULL);
INSERT INTO point VALUES (8519, 542, '50', NULL, NULL);
INSERT INTO point VALUES (8520, 617, '10', NULL, NULL);
INSERT INTO point VALUES (8521, 670, '53', NULL, NULL);
INSERT INTO point VALUES (8522, 376, '59', NULL, NULL);
INSERT INTO point VALUES (8523, 506, '4', NULL, NULL);
INSERT INTO point VALUES (8524, 152, '1', NULL, NULL);
INSERT INTO point VALUES (8525, 335, '14', NULL, NULL);
INSERT INTO point VALUES (8526, 88, '27', NULL, NULL);
INSERT INTO point VALUES (8527, 594, '21', NULL, NULL);
INSERT INTO point VALUES (8528, 525, '17', NULL, NULL);
INSERT INTO point VALUES (8529, 389, '36', NULL, NULL);
INSERT INTO point VALUES (8530, 25, '6', NULL, NULL);
INSERT INTO point VALUES (8531, 694, '20', NULL, NULL);
INSERT INTO point VALUES (8532, 279, '20А', NULL, NULL);
INSERT INTO point VALUES (8533, 415, '45', NULL, NULL);
INSERT INTO point VALUES (8534, 406, '4', NULL, NULL);
INSERT INTO point VALUES (8535, 295, '5', NULL, NULL);
INSERT INTO point VALUES (8536, 59, '52Б', NULL, NULL);
INSERT INTO point VALUES (8537, 152, '19', NULL, NULL);
INSERT INTO point VALUES (8538, 23, '17', NULL, NULL);
INSERT INTO point VALUES (8539, 473, '23', NULL, NULL);
INSERT INTO point VALUES (8540, 202, '16', NULL, NULL);
INSERT INTO point VALUES (8541, 172, '13', NULL, NULL);
INSERT INTO point VALUES (8542, 352, '38', NULL, NULL);
INSERT INTO point VALUES (8543, 45, '4А', NULL, NULL);
INSERT INTO point VALUES (8544, 496, '6А', NULL, NULL);
INSERT INTO point VALUES (8545, 262, '12А', NULL, NULL);
INSERT INTO point VALUES (8546, 12, '2', NULL, NULL);
INSERT INTO point VALUES (8547, 32, '8', NULL, NULL);
INSERT INTO point VALUES (8548, 191, '21', NULL, NULL);
INSERT INTO point VALUES (8549, 451, '39', NULL, NULL);
INSERT INTO point VALUES (8550, 131, '10', NULL, NULL);
INSERT INTO point VALUES (8551, 271, '4', NULL, NULL);
INSERT INTO point VALUES (8552, 486, '14', NULL, NULL);
INSERT INTO point VALUES (8553, 539, '33', NULL, NULL);
INSERT INTO point VALUES (8554, 415, '3', NULL, NULL);
INSERT INTO point VALUES (8555, 594, '48', NULL, NULL);
INSERT INTO point VALUES (8556, 483, '11', NULL, NULL);
INSERT INTO point VALUES (8557, 571, '37А', NULL, NULL);
INSERT INTO point VALUES (8558, 544, '12', NULL, NULL);
INSERT INTO point VALUES (8559, 377, '8', NULL, NULL);
INSERT INTO point VALUES (8560, 265, '17/1', NULL, NULL);
INSERT INTO point VALUES (8561, 562, '3', NULL, NULL);
INSERT INTO point VALUES (8562, 201, '42', NULL, NULL);
INSERT INTO point VALUES (8563, 232, '20', NULL, NULL);
INSERT INTO point VALUES (8564, 601, '61', NULL, NULL);
INSERT INTO point VALUES (8565, 433, '9', NULL, NULL);
INSERT INTO point VALUES (8566, 437, '6', NULL, NULL);
INSERT INTO point VALUES (8567, 178, '7', NULL, NULL);
INSERT INTO point VALUES (8568, 294, '158', NULL, NULL);
INSERT INTO point VALUES (8569, 681, '29', NULL, NULL);
INSERT INTO point VALUES (8570, 183, '28', NULL, NULL);
INSERT INTO point VALUES (8571, 554, '15', NULL, NULL);
INSERT INTO point VALUES (8572, 205, '18', NULL, NULL);
INSERT INTO point VALUES (8573, 174, '45', NULL, NULL);
INSERT INTO point VALUES (8574, 607, '4', NULL, NULL);
INSERT INTO point VALUES (8575, 100, '83Д', NULL, NULL);
INSERT INTO point VALUES (8576, 260, '11', NULL, NULL);
INSERT INTO point VALUES (8577, 48, '3А', NULL, NULL);
INSERT INTO point VALUES (8578, 563, '26', NULL, NULL);
INSERT INTO point VALUES (8579, 464, '67', NULL, NULL);
INSERT INTO point VALUES (8580, 499, '15', NULL, NULL);
INSERT INTO point VALUES (8581, 459, '2', NULL, NULL);
INSERT INTO point VALUES (8582, 27, '13', NULL, NULL);
INSERT INTO point VALUES (8583, 25, '16', NULL, NULL);
INSERT INTO point VALUES (8584, 235, '39', NULL, NULL);
INSERT INTO point VALUES (8585, 696, '14А', NULL, NULL);
INSERT INTO point VALUES (8586, 184, '37', NULL, NULL);
INSERT INTO point VALUES (8587, 531, '210', NULL, NULL);
INSERT INTO point VALUES (8588, 389, '48/1', NULL, NULL);
INSERT INTO point VALUES (8589, 329, '66', NULL, NULL);
INSERT INTO point VALUES (8590, 310, '30', NULL, NULL);
INSERT INTO point VALUES (8591, 390, '28', NULL, NULL);
INSERT INTO point VALUES (8592, 189, '10', NULL, NULL);
INSERT INTO point VALUES (8593, 304, '32', NULL, NULL);
INSERT INTO point VALUES (8594, 170, '14', NULL, NULL);
INSERT INTO point VALUES (8595, 606, '8', NULL, NULL);
INSERT INTO point VALUES (8596, 176, '51', NULL, NULL);
INSERT INTO point VALUES (8597, 294, '76', NULL, NULL);
INSERT INTO point VALUES (8598, 215, '71', NULL, NULL);
INSERT INTO point VALUES (8599, 202, '6', NULL, NULL);
INSERT INTO point VALUES (8600, 473, '32', NULL, NULL);
INSERT INTO point VALUES (8601, 220, '22/10', NULL, NULL);
INSERT INTO point VALUES (8602, 449, '16', NULL, NULL);
INSERT INTO point VALUES (8603, 87, '35', NULL, NULL);
INSERT INTO point VALUES (8604, 119, '8', NULL, NULL);
INSERT INTO point VALUES (8605, 566, '7', NULL, NULL);
INSERT INTO point VALUES (8606, 478, '59', NULL, NULL);
INSERT INTO point VALUES (8607, 569, '15', NULL, NULL);
INSERT INTO point VALUES (8608, 277, '48', NULL, NULL);
INSERT INTO point VALUES (8609, 303, '10', NULL, NULL);
INSERT INTO point VALUES (8610, 67, '63', NULL, NULL);
INSERT INTO point VALUES (8611, 664, '22', NULL, NULL);
INSERT INTO point VALUES (8612, 339, '8', NULL, NULL);
INSERT INTO point VALUES (8613, 649, '50', NULL, NULL);
INSERT INTO point VALUES (8614, 652, '6', NULL, NULL);
INSERT INTO point VALUES (8615, 170, '8/4', NULL, NULL);
INSERT INTO point VALUES (8616, 433, '40А', NULL, NULL);
INSERT INTO point VALUES (8617, 279, '2А', NULL, NULL);
INSERT INTO point VALUES (8618, 572, '38', NULL, NULL);
INSERT INTO point VALUES (8619, 149, '20', NULL, NULL);
INSERT INTO point VALUES (8620, 104, '23', NULL, NULL);
INSERT INTO point VALUES (8621, 635, '14', NULL, NULL);
INSERT INTO point VALUES (8622, 419, '10', NULL, NULL);
INSERT INTO point VALUES (8623, 290, '4', NULL, NULL);
INSERT INTO point VALUES (8624, 120, '40', NULL, NULL);
INSERT INTO point VALUES (8625, 620, '13', NULL, NULL);
INSERT INTO point VALUES (8626, 564, '12', NULL, NULL);
INSERT INTO point VALUES (8627, 596, '5', NULL, NULL);
INSERT INTO point VALUES (8628, 106, '13', NULL, NULL);
INSERT INTO point VALUES (8629, 604, '15/2', NULL, NULL);
INSERT INTO point VALUES (8630, 203, '24', NULL, NULL);
INSERT INTO point VALUES (8631, 285, '13', NULL, NULL);
INSERT INTO point VALUES (8632, 100, '83В', NULL, NULL);
INSERT INTO point VALUES (8633, 509, '12', NULL, NULL);
INSERT INTO point VALUES (8634, 74, '12', NULL, NULL);
INSERT INTO point VALUES (8635, 451, '81', NULL, NULL);
INSERT INTO point VALUES (8636, 153, '10', NULL, NULL);
INSERT INTO point VALUES (8637, 277, '21', NULL, NULL);
INSERT INTO point VALUES (8638, 554, '93', NULL, NULL);
INSERT INTO point VALUES (8639, 601, '80', NULL, NULL);
INSERT INTO point VALUES (8640, 340, '2', NULL, NULL);
INSERT INTO point VALUES (8641, 283, '2/2', NULL, NULL);
INSERT INTO point VALUES (8642, 335, '1', NULL, NULL);
INSERT INTO point VALUES (8643, 523, '8', NULL, NULL);
INSERT INTO point VALUES (8644, 571, '36А', NULL, NULL);
INSERT INTO point VALUES (8645, 152, '14', NULL, NULL);
INSERT INTO point VALUES (8646, 451, '35', NULL, NULL);
INSERT INTO point VALUES (8647, 110, '17', NULL, NULL);
INSERT INTO point VALUES (8648, 656, '2', NULL, NULL);
INSERT INTO point VALUES (8649, 170, '10/4', NULL, NULL);
INSERT INTO point VALUES (8650, 94, '3', NULL, NULL);
INSERT INTO point VALUES (8651, 526, '8', NULL, NULL);
INSERT INTO point VALUES (8652, 100, '21', NULL, NULL);
INSERT INTO point VALUES (8653, 468, '6', NULL, NULL);
INSERT INTO point VALUES (8654, 451, '29А', NULL, NULL);
INSERT INTO point VALUES (8655, 496, '47А', NULL, NULL);
INSERT INTO point VALUES (8656, 180, '26А', NULL, NULL);
INSERT INTO point VALUES (8657, 416, '7', NULL, NULL);
INSERT INTO point VALUES (8658, 648, '7/1', NULL, NULL);
INSERT INTO point VALUES (8659, 131, '20', NULL, NULL);
INSERT INTO point VALUES (8660, 670, '57', NULL, NULL);
INSERT INTO point VALUES (8661, 340, '5', NULL, NULL);
INSERT INTO point VALUES (8662, 366, '25', NULL, NULL);
INSERT INTO point VALUES (8663, 518, '9', NULL, NULL);
INSERT INTO point VALUES (8664, 372, '36', NULL, NULL);
INSERT INTO point VALUES (8665, 180, '33Б', NULL, NULL);
INSERT INTO point VALUES (8666, 87, '34', NULL, NULL);
INSERT INTO point VALUES (8667, 362, '12', NULL, NULL);
INSERT INTO point VALUES (8668, 656, '5', NULL, NULL);
INSERT INTO point VALUES (8669, 20, '9', NULL, NULL);
INSERT INTO point VALUES (8670, 191, '30', NULL, NULL);
INSERT INTO point VALUES (8671, 496, '27/3', NULL, NULL);
INSERT INTO point VALUES (8672, 694, '10', NULL, NULL);
INSERT INTO point VALUES (8673, 366, '7', NULL, NULL);
INSERT INTO point VALUES (8674, 137, '9', NULL, NULL);
INSERT INTO point VALUES (8675, 560, '58', NULL, NULL);
INSERT INTO point VALUES (8676, 639, '3', NULL, NULL);
INSERT INTO point VALUES (8677, 398, '15', NULL, NULL);
INSERT INTO point VALUES (8678, 389, '31А', NULL, NULL);
INSERT INTO point VALUES (8679, 542, '49', NULL, NULL);
INSERT INTO point VALUES (8680, 595, '6', NULL, NULL);
INSERT INTO point VALUES (8681, 601, '64', NULL, NULL);
INSERT INTO point VALUES (8682, 682, '18', NULL, NULL);
INSERT INTO point VALUES (8683, 628, '39', NULL, NULL);
INSERT INTO point VALUES (8684, 560, '12', NULL, NULL);
INSERT INTO point VALUES (8685, 451, '74', NULL, NULL);
INSERT INTO point VALUES (8686, 279, '2', NULL, NULL);
INSERT INTO point VALUES (8687, 202, '43', NULL, NULL);
INSERT INTO point VALUES (8688, 497, '19', NULL, NULL);
INSERT INTO point VALUES (8689, 353, '5', NULL, NULL);
INSERT INTO point VALUES (8690, 57, '13', NULL, NULL);
INSERT INTO point VALUES (8691, 342, '54', NULL, NULL);
INSERT INTO point VALUES (8692, 299, '33', NULL, NULL);
INSERT INTO point VALUES (8693, 48, '120', NULL, NULL);
INSERT INTO point VALUES (8694, 594, '30', NULL, NULL);
INSERT INTO point VALUES (8695, 425, '50', NULL, NULL);
INSERT INTO point VALUES (8696, 67, '92', NULL, NULL);
INSERT INTO point VALUES (8697, 643, '10', NULL, NULL);
INSERT INTO point VALUES (8698, 213, '23', NULL, NULL);
INSERT INTO point VALUES (8699, 223, '4', NULL, NULL);
INSERT INTO point VALUES (8700, 272, '4', NULL, NULL);
INSERT INTO point VALUES (8701, 125, '6', NULL, NULL);
INSERT INTO point VALUES (8702, 367, '7', NULL, NULL);
INSERT INTO point VALUES (8703, 75, '51', NULL, NULL);
INSERT INTO point VALUES (8704, 604, '17', NULL, NULL);
INSERT INTO point VALUES (8705, 323, '36', NULL, NULL);
INSERT INTO point VALUES (8706, 133, '5', NULL, NULL);
INSERT INTO point VALUES (8707, 329, '33', NULL, NULL);
INSERT INTO point VALUES (8708, 639, '19/1', NULL, NULL);
INSERT INTO point VALUES (8709, 604, '7', NULL, NULL);
INSERT INTO point VALUES (8710, 694, '12', NULL, NULL);
INSERT INTO point VALUES (8711, 674, '11', NULL, NULL);
INSERT INTO point VALUES (8712, 373, '81', NULL, NULL);
INSERT INTO point VALUES (8713, 445, '19', NULL, NULL);
INSERT INTO point VALUES (8714, 455, '4', NULL, NULL);
INSERT INTO point VALUES (8715, 531, '70', NULL, NULL);


--
-- Name: point_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('point_id_seq', 8715, true);


--
-- Data for Name: price; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO price VALUES (2, 0, 30000, 5000, 50000, '2015-01-01 00:00:00', NULL, NULL);
INSERT INTO price VALUES (3, 1, 50000, 10000, 70000, '2015-01-01 00:00:00', NULL, NULL);


--
-- Name: price_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('price_id_seq', 3, true);


--
-- Data for Name: route; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO route VALUES (1, 1, 1, NULL, 'ул. Лиможа, 28', NULL, NULL, 'ул. Белуша, 24', NULL, NULL, NULL);
INSERT INTO route VALUES (2, 2, 1, NULL, 'просп. Космонавтов, 100', NULL, NULL, 'ул. Максима Горького, 84', NULL, NULL, NULL);
INSERT INTO route VALUES (3, 3, 1, NULL, 'ул. Болдина, 24', NULL, NULL, 'Фолюш, 112', NULL, NULL, NULL);
INSERT INTO route VALUES (4, 4, 1, NULL, 'ул. Кавязина, 23', NULL, NULL, 'ул. Кремко, 12', NULL, NULL, NULL);


--
-- Name: route_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('route_id_seq', 4, true);


--
-- Data for Name: street; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO street VALUES (1, 'Индивидуальная ул.', 1);
INSERT INTO street VALUES (2, 'Каравайная ул.', 1);
INSERT INTO street VALUES (3, 'Песочный пер.', 1);
INSERT INTO street VALUES (4, '2-й пер. Скрынника', 1);
INSERT INTO street VALUES (5, 'Колбасинская ул.', 1);
INSERT INTO street VALUES (6, 'ул. Духинского', 1);
INSERT INTO street VALUES (7, 'Пороховой пер.', 1);
INSERT INTO street VALUES (8, 'ул. Фомичёва', 1);
INSERT INTO street VALUES (9, 'Городенская ул.', 1);
INSERT INTO street VALUES (10, 'Линейная ул.', 1);
INSERT INTO street VALUES (11, 'Весёлая ул.', 1);
INSERT INTO street VALUES (12, 'Грандичская ул.', 1);
INSERT INTO street VALUES (13, 'Малая ул.', 1);
INSERT INTO street VALUES (14, 'Октябрьская ул.', 1);
INSERT INTO street VALUES (15, 'ул. Манюшко', 1);
INSERT INTO street VALUES (16, 'ул. Некрасова', 1);
INSERT INTO street VALUES (17, 'Прогулочная ул.', 1);
INSERT INTO street VALUES (18, '1-й пер. Белуша', 1);
INSERT INTO street VALUES (19, 'ул. Пожарского', 1);
INSERT INTO street VALUES (20, 'Краснознамённая ул.', 1);
INSERT INTO street VALUES (21, 'Ткацкая ул.', 1);
INSERT INTO street VALUES (22, '3-й пер. Ольги Соломовой', 1);
INSERT INTO street VALUES (23, 'Индурское шоссе', 1);
INSERT INTO street VALUES (24, 'ул. Шевченко', 1);
INSERT INTO street VALUES (25, 'ул. Альхимовича', 1);
INSERT INTO street VALUES (26, 'ул. Кутузова', 1);
INSERT INTO street VALUES (27, 'ул. Ленина', 1);
INSERT INTO street VALUES (28, 'Пролетарский пер.', 1);
INSERT INTO street VALUES (29, 'пер. Дарвина', 1);
INSERT INTO street VALUES (30, '6-й Дальний пер.', 1);
INSERT INTO street VALUES (31, 'Комбайнёрская ул.', 1);
INSERT INTO street VALUES (32, '3-й пер. Калинина', 1);
INSERT INTO street VALUES (33, 'Умелая ул.', 1);
INSERT INTO street VALUES (34, 'Малая Троицкая ул.', 1);
INSERT INTO street VALUES (35, 'Чародейная ул.', 1);
INSERT INTO street VALUES (36, 'ул. Петра Милонега', 1);
INSERT INTO street VALUES (37, 'ул. Серафимовича', 1);
INSERT INTO street VALUES (38, 'Папоротниковая ул.', 1);
INSERT INTO street VALUES (39, 'урочище Пышки', 1);
INSERT INTO street VALUES (40, 'Вишнёвая ул.', 1);
INSERT INTO street VALUES (41, '3-й пер. Чернышевского', 1);
INSERT INTO street VALUES (42, 'ул. Парижской Коммуны', 1);
INSERT INTO street VALUES (43, 'Каштановая ул.', 1);
INSERT INTO street VALUES (44, 'Горная ул.', 1);
INSERT INTO street VALUES (45, 'Молодёжная ул.', 1);
INSERT INTO street VALUES (46, '5-й Дальний пер.', 1);
INSERT INTO street VALUES (47, 'ул. Великая Ольшанка', 1);
INSERT INTO street VALUES (48, 'Гожская ул.', 1);
INSERT INTO street VALUES (49, 'Ягодная ул.', 1);
INSERT INTO street VALUES (50, 'ул. Рогачевского', 1);
INSERT INTO street VALUES (51, 'Блакитная ул.', 1);
INSERT INTO street VALUES (52, 'Доминиканская ул.', 1);
INSERT INTO street VALUES (53, 'Калачевская ул.', 1);
INSERT INTO street VALUES (54, 'Фабричная ул.', 1);
INSERT INTO street VALUES (55, 'Ржаная ул.', 1);
INSERT INTO street VALUES (56, 'ул. Жуковского', 1);
INSERT INTO street VALUES (57, 'ул. Розанова', 1);
INSERT INTO street VALUES (58, 'Железная ул.', 1);
INSERT INTO street VALUES (59, 'Отечественная ул.', 1);
INSERT INTO street VALUES (60, 'ул. Маслакова', 1);
INSERT INTO street VALUES (61, 'Творческая ул.', 1);
INSERT INTO street VALUES (62, 'Брестская ул.', 1);
INSERT INTO street VALUES (63, 'ул. Меречская застава', 1);
INSERT INTO street VALUES (64, '4-й Подольный пер.', 1);
INSERT INTO street VALUES (65, 'ул. Заслонова', 1);
INSERT INTO street VALUES (66, 'ул. Минейки', 1);
INSERT INTO street VALUES (67, 'ул. Советских Пограничников', 1);
INSERT INTO street VALUES (68, 'Тенистая ул.', 1);
INSERT INTO street VALUES (69, 'Замковый тупик', 1);
INSERT INTO street VALUES (70, 'ул. Вир', 1);
INSERT INTO street VALUES (71, 'ул. Богуцкого', 1);
INSERT INTO street VALUES (72, 'Гарбарский пер.', 1);
INSERT INTO street VALUES (73, 'ул. Осипенко', 1);
INSERT INTO street VALUES (74, 'ул. Мира', 1);
INSERT INTO street VALUES (75, 'ул. Фурсенко', 1);
INSERT INTO street VALUES (76, 'ул. Пестрака', 1);
INSERT INTO street VALUES (77, 'пер. Фолюш', 1);
INSERT INTO street VALUES (78, 'Советская ул.', 1);
INSERT INTO street VALUES (79, 'ул. Коложа', 1);
INSERT INTO street VALUES (80, 'ул. Ивлиева', 1);
INSERT INTO street VALUES (81, 'ул. Орджоникидзе', 1);
INSERT INTO street VALUES (82, 'ул. Богдана Хмельницкого', 1);
INSERT INTO street VALUES (83, 'Комсомольская ул.', 1);
INSERT INTO street VALUES (84, 'ул. Шидловского', 1);
INSERT INTO street VALUES (85, '2-й Победоносный пер.', 1);
INSERT INTO street VALUES (86, 'Сухая ул.', 1);
INSERT INTO street VALUES (87, 'ул. Балицкого', 1);
INSERT INTO street VALUES (88, 'Жнивеньская ул.', 1);
INSERT INTO street VALUES (89, '2-я Трудовая ул.', 1);
INSERT INTO street VALUES (90, 'Железный пер.', 1);
INSERT INTO street VALUES (91, 'Лесная ул.', 1);
INSERT INTO street VALUES (92, '1-й пер. Калинина', 1);
INSERT INTO street VALUES (93, 'ул. Островок', 1);
INSERT INTO street VALUES (94, '2-й пер. Дзержинского', 1);
INSERT INTO street VALUES (95, 'Левонабережная ул.', 1);
INSERT INTO street VALUES (96, 'Телеграфная ул.', 1);
INSERT INTO street VALUES (97, '6-й Пригородный пер.', 1);
INSERT INTO street VALUES (98, 'ул. Кветко', 1);
INSERT INTO street VALUES (99, 'ул. Славинского', 1);
INSERT INTO street VALUES (100, 'Осенняя ул.', 1);
INSERT INTO street VALUES (101, 'Окрестная ул.', 1);
INSERT INTO street VALUES (102, 'Железнодорожный пер.', 1);
INSERT INTO street VALUES (103, 'ул. Пугачёва', 1);
INSERT INTO street VALUES (104, 'ул. Попова', 1);
INSERT INTO street VALUES (105, 'Туманная ул.', 1);
INSERT INTO street VALUES (106, 'ул. Богдановича', 1);
INSERT INTO street VALUES (107, 'ул. Волкова', 1);
INSERT INTO street VALUES (108, 'ул. Кармелюка', 1);
INSERT INTO street VALUES (109, 'ул. Бабина Гора', 1);
INSERT INTO street VALUES (110, 'ул. Пучкова', 1);
INSERT INTO street VALUES (111, 'ул. Карла Маркса', 1);
INSERT INTO street VALUES (112, 'пер. Победы', 1);
INSERT INTO street VALUES (113, 'ул. Переселка', 1);
INSERT INTO street VALUES (114, 'ул. Рожанского', 1);
INSERT INTO street VALUES (115, 'Шоссейный пер.', 1);
INSERT INTO street VALUES (116, 'Промысловый проезд', 1);
INSERT INTO street VALUES (117, 'ул. Щорса', 1);
INSERT INTO street VALUES (118, 'Тракторная ул.', 1);
INSERT INTO street VALUES (119, 'Дачная ул.', 1);
INSERT INTO street VALUES (120, 'Беловежская ул.', 1);
INSERT INTO street VALUES (121, 'Бусловая ул.', 1);
INSERT INTO street VALUES (122, '1-й Грандичский пер.', 1);
INSERT INTO street VALUES (123, 'Друскеницкий тупик', 1);
INSERT INTO street VALUES (124, 'Вокзальная ул.', 1);
INSERT INTO street VALUES (125, 'ул. Крылова', 1);
INSERT INTO street VALUES (126, 'Железнодорожная ул.', 1);
INSERT INTO street VALUES (127, 'Вербовая ул.', 1);
INSERT INTO street VALUES (128, 'Кирпичная ул.', 1);
INSERT INTO street VALUES (129, '7-й Пригородный пер.', 1);
INSERT INTO street VALUES (130, 'ул. Белинского', 1);
INSERT INTO street VALUES (131, 'Господарчая ул.', 1);
INSERT INTO street VALUES (132, 'Королино', 1);
INSERT INTO street VALUES (133, 'Вересковая ул.', 1);
INSERT INTO street VALUES (134, 'Блакитный пер.', 1);
INSERT INTO street VALUES (135, '1-й пер. Куйбышева', 1);
INSERT INTO street VALUES (136, '2-й пер. Карского', 1);
INSERT INTO street VALUES (137, 'Широкая ул.', 1);
INSERT INTO street VALUES (138, 'Цветочная ул.', 1);
INSERT INTO street VALUES (139, 'ул. Брикеля', 1);
INSERT INTO street VALUES (140, '2-й пер. Серафимовича', 1);
INSERT INTO street VALUES (141, 'ул. Немцевича', 1);
INSERT INTO street VALUES (142, 'Серебряная ул.', 1);
INSERT INTO street VALUES (143, 'Тарусичский пер.', 1);
INSERT INTO street VALUES (144, 'ул. Тимирязева', 1);
INSERT INTO street VALUES (145, '2-й пер. Ивлиева', 1);
INSERT INTO street VALUES (146, 'Калюжная ул.', 1);
INSERT INTO street VALUES (147, 'ул. Куйбышева', 1);
INSERT INTO street VALUES (148, 'Калиновая ул.', 1);
INSERT INTO street VALUES (149, 'Рощинская ул.', 1);
INSERT INTO street VALUES (150, 'Отрадная ул.', 1);
INSERT INTO street VALUES (151, '1-я Трудовая ул.', 1);
INSERT INTO street VALUES (152, 'ул. Ельского', 1);
INSERT INTO street VALUES (153, 'Рабочая ул.', 1);
INSERT INTO street VALUES (154, '1-й пер. Карского', 1);
INSERT INTO street VALUES (155, '5-й Подольный пер.', 1);
INSERT INTO street VALUES (156, 'Заветная ул.', 1);
INSERT INTO street VALUES (157, 'Озёрское шоссе', 1);
INSERT INTO street VALUES (158, 'Полесская ул.', 1);
INSERT INTO street VALUES (159, 'ул. Головача', 1);
INSERT INTO street VALUES (160, 'Кирпичный пер.', 1);
INSERT INTO street VALUES (161, 'пер. Декабристов', 1);
INSERT INTO street VALUES (162, 'Колбасинский пер.', 1);
INSERT INTO street VALUES (163, 'Светлая ул.', 1);
INSERT INTO street VALUES (164, '1-й пер. Серафимовича', 1);
INSERT INTO street VALUES (165, 'ул. Лососна', 1);
INSERT INTO street VALUES (166, 'ул. Менделеева', 1);
INSERT INTO street VALUES (167, 'ул. Чюрлёниса', 1);
INSERT INTO street VALUES (168, 'ул. Лынькова', 1);
INSERT INTO street VALUES (169, 'ул. Шарипова', 1);
INSERT INTO street VALUES (170, 'ул. Кабяка', 1);
INSERT INTO street VALUES (171, 'Стрелковая ул.', 1);
INSERT INTO street VALUES (172, 'ул. Лермонтова', 1);
INSERT INTO street VALUES (173, 'Нёманский пер.', 1);
INSERT INTO street VALUES (174, 'Олимпийская ул.', 1);
INSERT INTO street VALUES (175, 'Счастливая ул.', 1);
INSERT INTO street VALUES (176, 'Асфальтная ул.', 1);
INSERT INTO street VALUES (177, 'Виленский пер.', 1);
INSERT INTO street VALUES (178, 'ул. Григоровича', 1);
INSERT INTO street VALUES (179, 'Пчелиная ул.', 1);
INSERT INTO street VALUES (180, 'ул. Кирова', 1);
INSERT INTO street VALUES (181, 'ул. Кириченко', 1);
INSERT INTO street VALUES (182, 'ул. Свердлова', 1);
INSERT INTO street VALUES (183, 'бульвар Ленинского Комсомола', 1);
INSERT INTO street VALUES (184, 'ул. Дуброва', 1);
INSERT INTO street VALUES (185, 'Криничный пер.', 1);
INSERT INTO street VALUES (186, 'Летняя ул.', 1);
INSERT INTO street VALUES (187, 'Тесная ул.', 1);
INSERT INTO street VALUES (188, 'Коммунальный тупик', 1);
INSERT INTO street VALUES (189, '2-й пер. Калинина', 1);
INSERT INTO street VALUES (190, '4-й пер. Чернышевского', 1);
INSERT INTO street VALUES (191, 'ул. Панченко', 1);
INSERT INTO street VALUES (192, 'ул. Михася Чарота', 1);
INSERT INTO street VALUES (193, '2-й пер. Ольги Соломовой', 1);
INSERT INTO street VALUES (194, 'Еловая ул.', 1);
INSERT INTO street VALUES (195, 'Лагодная ул.', 1);
INSERT INTO street VALUES (196, '4-й Пригородный пер.', 1);
INSERT INTO street VALUES (197, 'Стахановская ул.', 1);
INSERT INTO street VALUES (198, 'Встречная ул.', 1);
INSERT INTO street VALUES (199, 'Речная ул.', 1);
INSERT INTO street VALUES (200, 'ул. Друцк', 1);
INSERT INTO street VALUES (201, 'ул. Горновых', 1);
INSERT INTO street VALUES (202, 'ул. Огинского', 1);
INSERT INTO street VALUES (203, 'Праздничная ул.', 1);
INSERT INTO street VALUES (204, 'Узкая ул.', 1);
INSERT INTO street VALUES (205, 'ул. Заменгофа', 1);
INSERT INTO street VALUES (206, 'Огородная ул.', 1);
INSERT INTO street VALUES (207, 'ул. Тельмана', 1);
INSERT INTO street VALUES (208, 'Звёздная ул.', 1);
INSERT INTO street VALUES (209, 'Пригородная ул.', 1);
INSERT INTO street VALUES (210, 'ул. Гастелло', 1);
INSERT INTO street VALUES (211, 'Братская ул.', 1);
INSERT INTO street VALUES (212, 'Добрая ул.', 1);
INSERT INTO street VALUES (213, 'ул. Соколовского', 1);
INSERT INTO street VALUES (214, 'ул. Найдуса', 1);
INSERT INTO street VALUES (215, 'Заречная ул.', 1);
INSERT INTO street VALUES (216, 'ул. Солы', 1);
INSERT INTO street VALUES (217, '2-й Осенний пер.', 1);
INSERT INTO street VALUES (218, 'Индустриальная ул.', 1);
INSERT INTO street VALUES (219, 'Школьная ул.', 1);
INSERT INTO street VALUES (220, 'ул. Островского', 1);
INSERT INTO street VALUES (221, 'ул. Бакштанского', 1);
INSERT INTO street VALUES (222, 'Первоцветная ул.', 1);
INSERT INTO street VALUES (223, 'просп. Строителей', 1);
INSERT INTO street VALUES (224, 'ул. Заверщизна', 1);
INSERT INTO street VALUES (225, 'ул. Сераковского', 1);
INSERT INTO street VALUES (226, '2-й Каравайный пер.', 1);
INSERT INTO street VALUES (227, 'Черничная ул.', 1);
INSERT INTO street VALUES (228, 'ул. Гинтовта', 1);
INSERT INTO street VALUES (229, 'Чудесная ул.', 1);
INSERT INTO street VALUES (230, '1-й Подольный пер.', 1);
INSERT INTO street VALUES (231, 'ул. Калинина', 1);
INSERT INTO street VALUES (232, 'ул. Дарвина', 1);
INSERT INTO street VALUES (233, 'Медовая ул.', 1);
INSERT INTO street VALUES (234, 'ул. Павлова', 1);
INSERT INTO street VALUES (235, 'Новосельная ул.', 1);
INSERT INTO street VALUES (236, 'ул. Садакова', 1);
INSERT INTO street VALUES (237, 'Покровская ул.', 1);
INSERT INTO street VALUES (238, '1-й Новый пер.', 1);
INSERT INTO street VALUES (239, 'Кстинская ул.', 1);
INSERT INTO street VALUES (240, 'ул. Данилова', 1);
INSERT INTO street VALUES (241, 'пер. Менделеева', 1);
INSERT INTO street VALUES (242, 'Ореховая ул.', 1);
INSERT INTO street VALUES (243, 'пер. Свердлова', 1);
INSERT INTO street VALUES (244, '5-й пер. Куйбышева', 1);
INSERT INTO street VALUES (245, 'Одельская ул.', 1);
INSERT INTO street VALUES (246, 'пер. Поповича', 1);
INSERT INTO street VALUES (247, 'Зерновая ул.', 1);
INSERT INTO street VALUES (248, 'Мясницкая ул.', 1);
INSERT INTO street VALUES (249, 'Нектарная ул.', 1);
INSERT INTO street VALUES (250, 'просп. Янки Купалы', 1);
INSERT INTO street VALUES (251, 'ул. Садовникова Гора', 1);
INSERT INTO street VALUES (252, 'ул. Пестеля', 1);
INSERT INTO street VALUES (253, 'ул. Льва Бакста', 1);
INSERT INTO street VALUES (254, 'ул. Александровича', 1);
INSERT INTO street VALUES (255, 'ул. Новики', 1);
INSERT INTO street VALUES (256, 'ул. Пушкова', 1);
INSERT INTO street VALUES (257, 'Сказочная ул.', 1);
INSERT INTO street VALUES (258, 'пер. Пучкова', 1);
INSERT INTO street VALUES (259, 'Звонковая ул.', 1);
INSERT INTO street VALUES (260, 'ул. Волжецкого', 1);
INSERT INTO street VALUES (261, 'ул. Горы', 1);
INSERT INTO street VALUES (262, 'Южная ул.', 1);
INSERT INTO street VALUES (263, 'Портовая ул.', 1);
INSERT INTO street VALUES (264, 'Вежливая ул.', 1);
INSERT INTO street VALUES (265, 'ул. Терешковой', 1);
INSERT INTO street VALUES (266, 'Ранишняя ул.', 1);
INSERT INTO street VALUES (267, 'ул. Заславского', 1);
INSERT INTO street VALUES (268, 'Гданьская ул.', 1);
INSERT INTO street VALUES (269, 'ул. Антонова', 1);
INSERT INTO street VALUES (270, 'ул. Сергея Лазо', 1);
INSERT INTO street VALUES (271, 'пер. Доватора', 1);
INSERT INTO street VALUES (272, 'пер. Добролюбова', 1);
INSERT INTO street VALUES (273, 'Коллективная ул.', 1);
INSERT INTO street VALUES (274, 'Поворотная ул.', 1);
INSERT INTO street VALUES (275, 'Млынарная ул.', 1);
INSERT INTO street VALUES (276, '3-й Осенний пер.', 1);
INSERT INTO street VALUES (277, 'просп. Клецкова', 1);
INSERT INTO street VALUES (278, 'Краевидная ул.', 1);
INSERT INTO street VALUES (279, 'ул. Белуша', 1);
INSERT INTO street VALUES (280, 'Молодая ул.', 1);
INSERT INTO street VALUES (281, 'ул. Бажоры', 1);
INSERT INTO street VALUES (282, 'Издательская ул.', 1);
INSERT INTO street VALUES (283, 'ул. Доватора', 1);
INSERT INTO street VALUES (284, 'Румлёвский просп.', 1);
INSERT INTO street VALUES (285, 'ул. 1 Мая', 1);
INSERT INTO street VALUES (286, 'ул. Зернова', 1);
INSERT INTO street VALUES (287, '2-й пер. Чернышевского', 1);
INSERT INTO street VALUES (288, 'Бобровый пер.', 1);
INSERT INTO street VALUES (289, 'Уютная ул.', 1);
INSERT INTO street VALUES (290, 'Бурштыновая ул.', 1);
INSERT INTO street VALUES (291, 'Советская площадь', 1);
INSERT INTO street VALUES (292, 'Яблоневая ул.', 1);
INSERT INTO street VALUES (293, 'Дроздовая ул.', 1);
INSERT INTO street VALUES (294, 'ул. Суворова', 1);
INSERT INTO street VALUES (295, 'Дружная ул.', 1);
INSERT INTO street VALUES (296, 'Межсовхозная ул.', 1);
INSERT INTO street VALUES (297, 'Славная ул.', 1);
INSERT INTO street VALUES (298, 'Чистая ул.', 1);
INSERT INTO street VALUES (299, 'Мазовецкая ул.', 1);
INSERT INTO street VALUES (300, '3-й Пригородный пер.', 1);
INSERT INTO street VALUES (301, 'Дубровенская ул.', 1);
INSERT INTO street VALUES (302, 'площадь Тизенгауза', 1);
INSERT INTO street VALUES (303, 'ул. Лелевеля', 1);
INSERT INTO street VALUES (304, 'ул. Николаева', 1);
INSERT INTO street VALUES (305, 'Сельская ул.', 1);
INSERT INTO street VALUES (306, 'пер. Манюшко', 1);
INSERT INTO street VALUES (307, 'Суничная ул.', 1);
INSERT INTO street VALUES (308, 'Санаторная ул.', 1);
INSERT INTO street VALUES (309, 'Ясная ул.', 1);
INSERT INTO street VALUES (310, 'Верхняя ул.', 1);
INSERT INTO street VALUES (311, 'ул. Сергея Ланского', 1);
INSERT INTO street VALUES (312, '5-й Пригородный пер.', 1);
INSERT INTO street VALUES (313, '3-й Каравайный пер.', 1);
INSERT INTO street VALUES (314, 'Малыщинский пер.', 1);
INSERT INTO street VALUES (315, 'ул. Зана', 1);
INSERT INTO street VALUES (316, 'ул. Разина', 1);
INSERT INTO street VALUES (317, 'Автомобильная ул.', 1);
INSERT INTO street VALUES (318, 'ул. Стефана Батория', 1);
INSERT INTO street VALUES (319, '1-й пер. Ивлиева', 1);
INSERT INTO street VALUES (320, '2-й Пригородный пер.', 1);
INSERT INTO street VALUES (321, 'Совхозная ул.', 1);
INSERT INTO street VALUES (322, 'Грюнвальдская ул.', 1);
INSERT INTO street VALUES (323, 'Новая ул.', 1);
INSERT INTO street VALUES (324, 'Загородный пер.', 1);
INSERT INTO street VALUES (325, 'ул. Мицкевича', 1);
INSERT INTO street VALUES (326, 'Окульная ул.', 1);
INSERT INTO street VALUES (327, 'ул. Возрождения', 1);
INSERT INTO street VALUES (328, 'Ученическая ул.', 1);
INSERT INTO street VALUES (329, 'Социалистическая ул.', 1);
INSERT INTO street VALUES (330, 'ул. Меловые горы', 1);
INSERT INTO street VALUES (331, 'Переломская ул.', 1);
INSERT INTO street VALUES (332, '1-й Тихий пер.', 1);
INSERT INTO street VALUES (333, 'ул. Гартного', 1);
INSERT INTO street VALUES (334, 'ул. Бертеля', 1);
INSERT INTO street VALUES (335, 'Холмистая ул.', 1);
INSERT INTO street VALUES (336, 'Белостокский пер.', 1);
INSERT INTO street VALUES (337, 'Букетная ул.', 1);
INSERT INTO street VALUES (338, 'Гонионская ул.', 1);
INSERT INTO street VALUES (339, 'ул. Баранцевича', 1);
INSERT INTO street VALUES (340, '3-й Дальний пер.', 1);
INSERT INTO street VALUES (341, 'Искристая ул.', 1);
INSERT INTO street VALUES (342, 'Богатая ул.', 1);
INSERT INTO street VALUES (343, 'Озёрный пер.', 1);
INSERT INTO street VALUES (344, 'Хлебная ул.', 1);
INSERT INTO street VALUES (345, 'Экзотическая ул.', 1);
INSERT INTO street VALUES (346, 'Объездная ул.', 1);
INSERT INTO street VALUES (347, 'Июльская ул.', 1);
INSERT INTO street VALUES (348, '1-й пер. Чернышевского', 1);
INSERT INTO street VALUES (349, 'Васильковая ул.', 1);
INSERT INTO street VALUES (350, 'пер. Заслонова', 1);
INSERT INTO street VALUES (351, 'Сопоцкинская ул.', 1);
INSERT INTO street VALUES (352, 'Северная ул.', 1);
INSERT INTO street VALUES (353, 'Нёманская ул.', 1);
INSERT INTO street VALUES (354, 'ул. Льва Толстого', 1);
INSERT INTO street VALUES (355, 'Кольцевой пер.', 1);
INSERT INTO street VALUES (356, 'ул. Герцена', 1);
INSERT INTO street VALUES (357, 'ул. Чопчица', 1);
INSERT INTO street VALUES (358, 'ул. 11 Липеня', 1);
INSERT INTO street VALUES (359, 'Рамесны въезд', 1);
INSERT INTO street VALUES (360, 'Лососнянский пер.', 1);
INSERT INTO street VALUES (361, 'Соломенковская ул.', 1);
INSERT INTO street VALUES (362, 'ул. Победы', 1);
INSERT INTO street VALUES (363, 'Кольцевая ул.', 1);
INSERT INTO street VALUES (364, 'ул. Карбышева', 1);
INSERT INTO street VALUES (365, 'Ботаническая ул.', 1);
INSERT INTO street VALUES (366, '3-й Подольный пер.', 1);
INSERT INTO street VALUES (367, 'ул. Маяковского', 1);
INSERT INTO street VALUES (368, 'ул. Скоморошки', 1);
INSERT INTO street VALUES (369, 'ул. Сивачёва', 1);
INSERT INTO street VALUES (370, 'ул. Артёма', 1);
INSERT INTO street VALUES (371, 'Гаражная ул.', 1);
INSERT INTO street VALUES (372, 'ул. Реймонта', 1);
INSERT INTO street VALUES (373, 'Красноармейская ул.', 1);
INSERT INTO street VALUES (374, 'ул. Дзержинского', 1);
INSERT INTO street VALUES (375, 'ул. Будённого', 1);
INSERT INTO street VALUES (376, 'ул. Калиновского', 1);
INSERT INTO street VALUES (377, 'ул. Санфировой', 1);
INSERT INTO street VALUES (378, '1-й Заречный пер.', 1);
INSERT INTO street VALUES (379, 'Давняя ул.', 1);
INSERT INTO street VALUES (380, 'пер. Василька', 1);
INSERT INTO street VALUES (381, 'Фабричный пер.', 1);
INSERT INTO street VALUES (382, 'Южный пер.', 1);
INSERT INTO street VALUES (383, 'ул. Смирнова', 1);
INSERT INTO street VALUES (384, 'Дальняя ул.', 1);
INSERT INTO street VALUES (385, 'Капличная ул.', 1);
INSERT INTO street VALUES (386, 'ул. Болдина', 1);
INSERT INTO street VALUES (387, 'ул. Головичи', 1);
INSERT INTO street VALUES (388, 'ул. Словацкого', 1);
INSERT INTO street VALUES (389, 'ул. Лиможа', 1);
INSERT INTO street VALUES (390, 'ул. Сухомбаева', 1);
INSERT INTO street VALUES (391, '1-й пер. Ольги Соломовой', 1);
INSERT INTO street VALUES (392, 'пер. Якуба Коласа', 1);
INSERT INTO street VALUES (393, 'ул. Кремко', 1);
INSERT INTO street VALUES (394, 'Кульбакская ул.', 1);
INSERT INTO street VALUES (395, 'ул. Павловского', 1);
INSERT INTO street VALUES (396, 'Городничанская ул.', 1);
INSERT INTO street VALUES (397, 'Колхозная ул.', 1);
INSERT INTO street VALUES (398, 'ул. Чкалова', 1);
INSERT INTO street VALUES (399, 'ул. Франтишка Богушевича', 1);
INSERT INTO street VALUES (400, 'Магистральная ул.', 1);
INSERT INTO street VALUES (401, 'ул. Гедроица', 1);
INSERT INTO street VALUES (402, 'ул. Заболоть', 1);
INSERT INTO street VALUES (403, 'Чаборовая ул.', 1);
INSERT INTO street VALUES (404, 'Озёрная ул.', 1);
INSERT INTO street VALUES (405, 'ул. Котовского', 1);
INSERT INTO street VALUES (406, 'Туманный пер.', 1);
INSERT INTO street VALUES (407, '2-й Песочный пер.', 1);
INSERT INTO street VALUES (408, 'Удачная ул.', 1);
INSERT INTO street VALUES (409, 'Хлебосольный пер.', 1);
INSERT INTO street VALUES (410, 'Соколиная ул.', 1);
INSERT INTO street VALUES (411, 'Хлебосольная ул.', 1);
INSERT INTO street VALUES (412, 'Запрудная ул.', 1);
INSERT INTO street VALUES (413, 'ул. Заболоцкого', 1);
INSERT INTO street VALUES (414, '1-й Каравайный пер.', 1);
INSERT INTO street VALUES (415, 'ул. Белые Росы', 1);
INSERT INTO street VALUES (416, 'Серая ул.', 1);
INSERT INTO street VALUES (417, 'Ручеевая ул.', 1);
INSERT INTO street VALUES (418, 'Круговая ул.', 1);
INSERT INTO street VALUES (419, 'ул. Сулистровского', 1);
INSERT INTO street VALUES (420, 'п. Пограничный', 1);
INSERT INTO street VALUES (421, 'Сокольская ул.', 1);
INSERT INTO street VALUES (422, '2-й Тихий пер.', 1);
INSERT INTO street VALUES (423, 'Белорусская ул.', 1);
INSERT INTO street VALUES (424, 'ул. Матросова', 1);
INSERT INTO street VALUES (425, 'ул. Врублевского', 1);
INSERT INTO street VALUES (426, 'Малиновая ул.', 1);
INSERT INTO street VALUES (427, 'Погоранская ул.', 1);
INSERT INTO street VALUES (428, 'ул. Минаева', 1);
INSERT INTO street VALUES (429, '4-й Дальний пер.', 1);
INSERT INTO street VALUES (430, 'Биологическая ул.', 1);
INSERT INTO street VALUES (431, 'ул. Элизы Ожешко', 1);
INSERT INTO street VALUES (432, 'Жнивеньский пер.', 1);
INSERT INTO street VALUES (433, 'Криничная ул.', 1);
INSERT INTO street VALUES (434, 'Коллективный пер.', 1);
INSERT INTO street VALUES (435, 'Лапенковская ул.', 1);
INSERT INTO street VALUES (436, 'ул. Якуба Коласа', 1);
INSERT INTO street VALUES (437, 'ул. Герасимовича', 1);
INSERT INTO street VALUES (438, 'ул. Добролюбова', 1);
INSERT INTO street VALUES (439, 'Главная ул.', 1);
INSERT INTO street VALUES (440, '1-й Победоносный пер.', 1);
INSERT INTO street VALUES (441, 'Берёзовая ул.', 1);
INSERT INTO street VALUES (442, 'Тенистый пер.', 1);
INSERT INTO street VALUES (443, 'ул. Демченко', 1);
INSERT INTO street VALUES (444, 'Поэтическая ул.', 1);
INSERT INTO street VALUES (445, 'ул. Абремского', 1);
INSERT INTO street VALUES (446, 'Бобровая ул.', 1);
INSERT INTO street VALUES (447, 'ул. Гоголя', 1);
INSERT INTO street VALUES (448, 'Скосная ул.', 1);
INSERT INTO street VALUES (449, 'ул. Чехова', 1);
INSERT INTO street VALUES (450, 'ул. Лисиная Горка', 1);
INSERT INTO street VALUES (451, 'просп. Космонавтов', 1);
INSERT INTO street VALUES (452, 'ул. Чернышевского', 1);
INSERT INTO street VALUES (453, 'Изумрудная ул.', 1);
INSERT INTO street VALUES (454, 'ул. Подкрыжаки', 1);
INSERT INTO street VALUES (455, 'Подольная ул.', 1);
INSERT INTO street VALUES (456, 'Магистральный пер.', 1);
INSERT INTO street VALUES (457, 'Гожий пер.', 1);
INSERT INTO street VALUES (458, 'Архитектурная ул.', 1);
INSERT INTO street VALUES (459, 'Заводская ул.', 1);
INSERT INTO street VALUES (460, 'ул. Софьи Налковской', 1);
INSERT INTO street VALUES (461, 'ул. Черняховского', 1);
INSERT INTO street VALUES (462, 'ул. Волковича', 1);
INSERT INTO street VALUES (463, '2-й Грандичский пер.', 1);
INSERT INTO street VALUES (464, 'ул. Тавлая', 1);
INSERT INTO street VALUES (465, 'Старомалыщинская ул.', 1);
INSERT INTO street VALUES (466, 'Телеграфный пер.', 1);
INSERT INTO street VALUES (467, 'Купальская ул.', 1);
INSERT INTO street VALUES (468, 'ул. Домейко', 1);
INSERT INTO street VALUES (469, 'ул. Наполеона Орды', 1);
INSERT INTO street VALUES (470, 'ул. Шишкина', 1);
INSERT INTO street VALUES (471, '4-й пер. Куйбышева', 1);
INSERT INTO street VALUES (472, 'Гонионский пер.', 1);
INSERT INTO street VALUES (473, 'Коммунальная ул.', 1);
INSERT INTO street VALUES (474, 'Холодная ул.', 1);
INSERT INTO street VALUES (475, 'Лучистая ул.', 1);
INSERT INTO street VALUES (476, 'Оптимистическая ул.', 1);
INSERT INTO street VALUES (477, 'Адамовичская ул.', 1);
INSERT INTO street VALUES (478, 'ул. Казановского', 1);
INSERT INTO street VALUES (479, 'Хвойная ул.', 1);
INSERT INTO street VALUES (480, 'Шоссейная ул.', 1);
INSERT INTO street VALUES (481, 'Тихая ул.', 1);
INSERT INTO street VALUES (482, 'ул. Аксёнова', 1);
INSERT INTO street VALUES (483, 'Барановичская ул.', 1);
INSERT INTO street VALUES (484, 'Короткая ул.', 1);
INSERT INTO street VALUES (485, 'Переходный пер.', 1);
INSERT INTO street VALUES (486, 'Тополевая ул.', 1);
INSERT INTO street VALUES (487, 'ул. Карского', 1);
INSERT INTO street VALUES (488, 'Отцовская ул.', 1);
INSERT INTO street VALUES (489, 'ул. Рылеева', 1);
INSERT INTO street VALUES (612, 'Деревенская ул.', 1);
INSERT INTO street VALUES (490, 'Агрономическая ул.', 1);
INSERT INTO street VALUES (491, 'Полевая ул.', 1);
INSERT INTO street VALUES (492, 'ул. Розы Люксембург', 1);
INSERT INTO street VALUES (493, 'Профсоюзная ул.', 1);
INSERT INTO street VALUES (494, 'Свитальная ул.', 1);
INSERT INTO street VALUES (495, 'Татарская ул.', 1);
INSERT INTO street VALUES (496, 'ул. Максима Горького', 1);
INSERT INTO street VALUES (497, '5-й пер. Калинина', 1);
INSERT INTO street VALUES (498, 'ул. Девятовка', 1);
INSERT INTO street VALUES (499, 'ул. Грабовского', 1);
INSERT INTO street VALUES (500, 'ул. Дмитриевка', 1);
INSERT INTO street VALUES (501, 'Мелодичная ул.', 1);
INSERT INTO street VALUES (502, 'ул. Ногина', 1);
INSERT INTO street VALUES (503, 'пер. Реймонта', 1);
INSERT INTO street VALUES (504, 'ул. Кавязина', 1);
INSERT INTO street VALUES (505, 'Королихинская ул.', 1);
INSERT INTO street VALUES (506, 'Вишневецкая ул.', 1);
INSERT INTO street VALUES (507, 'ул. Старая Ольшанка', 1);
INSERT INTO street VALUES (508, 'Мопровская ул.', 1);
INSERT INTO street VALUES (509, 'Славянская ул.', 1);
INSERT INTO street VALUES (510, 'Друскеницкая ул.', 1);
INSERT INTO street VALUES (511, 'ул. Костюшко', 1);
INSERT INTO street VALUES (512, 'ул. Полиграфистов', 1);
INSERT INTO street VALUES (513, 'Победоносная ул.', 1);
INSERT INTO street VALUES (514, 'Дорожная ул.', 1);
INSERT INTO street VALUES (515, 'Королинская ул.', 1);
INSERT INTO street VALUES (516, 'ул. Дубко', 1);
INSERT INTO street VALUES (517, 'Гожая ул.', 1);
INSERT INTO street VALUES (518, 'Калючинская ул.', 1);
INSERT INTO street VALUES (519, 'ул. Литовского', 1);
INSERT INTO street VALUES (520, 'Скидельское шоссе', 1);
INSERT INTO street VALUES (521, 'ул. Веры Хоружей', 1);
INSERT INTO street VALUES (522, 'Агрэстовая ул.', 1);
INSERT INTO street VALUES (523, 'Весенняя ул.', 1);
INSERT INTO street VALUES (524, 'Гончарная ул.', 1);
INSERT INTO street VALUES (525, 'ул. Репина', 1);
INSERT INTO street VALUES (526, 'Средний пер.', 1);
INSERT INTO street VALUES (527, 'Соседняя ул.', 1);
INSERT INTO street VALUES (528, 'Купальский пер.', 1);
INSERT INTO street VALUES (529, 'Золотистая ул.', 1);
INSERT INTO street VALUES (530, 'ул. Гротгера', 1);
INSERT INTO street VALUES (531, 'Замковая ул.', 1);
INSERT INTO street VALUES (532, 'Полянная ул.', 1);
INSERT INTO street VALUES (533, 'Аульская ул.', 1);
INSERT INTO street VALUES (534, 'площадь Декабристов', 1);
INSERT INTO street VALUES (535, 'ул. Курбатова', 1);
INSERT INTO street VALUES (536, 'ул. Тетки', 1);
INSERT INTO street VALUES (537, '1-й пер. Скрынника', 1);
INSERT INTO street VALUES (538, 'Фестивальная ул.', 1);
INSERT INTO street VALUES (539, 'Кленовая ул.', 1);
INSERT INTO street VALUES (540, 'Молодёжный пер.', 1);
INSERT INTO street VALUES (541, 'ул. Усова', 1);
INSERT INTO street VALUES (542, 'ул. 17 Сентября', 1);
INSERT INTO street VALUES (543, '1-й Пригородный пер.', 1);
INSERT INTO street VALUES (544, 'Садовая ул.', 1);
INSERT INTO street VALUES (545, 'ул. Счастного', 1);
INSERT INTO street VALUES (546, 'Фолюш', 1);
INSERT INTO street VALUES (547, 'ул. Химиков', 1);
INSERT INTO street VALUES (548, 'Пролетарская ул.', 1);
INSERT INTO street VALUES (549, '2-й пер. Белуша', 1);
INSERT INTO street VALUES (550, 'Подгорная ул.', 1);
INSERT INTO street VALUES (551, 'просп. Дзержинского', 1);
INSERT INTO street VALUES (552, 'ул. Захарова', 1);
INSERT INTO street VALUES (553, 'Малый тупик', 1);
INSERT INTO street VALUES (554, 'Центральная ул.', 1);
INSERT INTO street VALUES (555, 'тропа Здоровья', 1);
INSERT INTO street VALUES (556, 'Белостокская ул.', 1);
INSERT INTO street VALUES (557, 'пер. Веры Хоружей', 1);
INSERT INTO street VALUES (558, 'ул. Ваньковича', 1);
INSERT INTO street VALUES (559, 'Затишная ул.', 1);
INSERT INTO street VALUES (560, 'Краснопартизанская ул.', 1);
INSERT INTO street VALUES (561, 'ул. Юрия Олеши', 1);
INSERT INTO street VALUES (562, 'ул. Скрынника', 1);
INSERT INTO street VALUES (563, 'ул. Комарова', 1);
INSERT INTO street VALUES (564, 'Рыбацкая ул.', 1);
INSERT INTO street VALUES (565, 'Рябиновая ул.', 1);
INSERT INTO street VALUES (566, 'ул. Курчатова', 1);
INSERT INTO street VALUES (567, 'Спартаковская ул.', 1);
INSERT INTO street VALUES (568, 'Дружеская ул.', 1);
INSERT INTO street VALUES (569, 'пер. Дзержинского', 1);
INSERT INTO street VALUES (570, 'Пороховая ул.', 1);
INSERT INTO street VALUES (571, 'Виленская ул.', 1);
INSERT INTO street VALUES (572, 'ул. Поповича', 1);
INSERT INTO street VALUES (573, 'пер. Тимирязева', 1);
INSERT INTO street VALUES (574, '3-й пер. Скрынника', 1);
INSERT INTO street VALUES (575, 'ул. Давида Городенского', 1);
INSERT INTO street VALUES (576, 'ул. Короткевича', 1);
INSERT INTO street VALUES (577, 'пер. Курбатова', 1);
INSERT INTO street VALUES (578, 'Миговская ул.', 1);
INSERT INTO street VALUES (579, 'Февральская ул.', 1);
INSERT INTO street VALUES (580, 'Красногвардейская ул.', 1);
INSERT INTO street VALUES (581, 'ул. Обухова', 1);
INSERT INTO street VALUES (582, 'Радужная ул.', 1);
INSERT INTO street VALUES (583, 'Щедрая ул.', 1);
INSERT INTO street VALUES (584, 'Западная ул.', 1);
INSERT INTO street VALUES (585, 'Межевая ул.', 1);
INSERT INTO street VALUES (586, 'Гродненская ул.', 1);
INSERT INTO street VALUES (587, 'ул. Юндила', 1);
INSERT INTO street VALUES (588, 'пер. Лососна', 1);
INSERT INTO street VALUES (589, 'Городская ул.', 1);
INSERT INTO street VALUES (590, 'Юбилейная ул.', 1);
INSERT INTO street VALUES (591, 'Студенческая ул.', 1);
INSERT INTO street VALUES (592, '1-й Осенний пер.', 1);
INSERT INTO street VALUES (593, 'ул. Милевича', 1);
INSERT INTO street VALUES (594, 'Ромашковая ул.', 1);
INSERT INTO street VALUES (595, 'Красная ул.', 1);
INSERT INTO street VALUES (596, 'Давний пер.', 1);
INSERT INTO street VALUES (597, 'Перстуньская ул.', 1);
INSERT INTO street VALUES (598, 'ул. Пушкина', 1);
INSERT INTO street VALUES (599, 'Транспортная ул.', 1);
INSERT INTO street VALUES (600, 'Большая Троицкая ул.', 1);
INSERT INTO street VALUES (601, 'ул. Ольги Соломовой', 1);
INSERT INTO street VALUES (602, 'ул. Ожешко', 1);
INSERT INTO street VALUES (603, 'пер. Жуковского', 1);
INSERT INTO street VALUES (604, 'ул. Фолюш', 1);
INSERT INTO street VALUES (605, 'ул. 8 Марта', 1);
INSERT INTO street VALUES (606, 'Понемуньская ул.', 1);
INSERT INTO street VALUES (607, 'Аксамитная ул.', 1);
INSERT INTO street VALUES (608, 'ул. Чещавляны', 1);
INSERT INTO street VALUES (609, 'Краснофлотская ул.', 1);
INSERT INTO street VALUES (610, 'Малыщинская ул.', 1);
INSERT INTO street VALUES (611, '2-й Подольный пер.', 1);
INSERT INTO street VALUES (613, 'Молочная ул.', 1);
INSERT INTO street VALUES (614, 'Грибная ул.', 1);
INSERT INTO street VALUES (615, 'ул. Бабкина', 1);
INSERT INTO street VALUES (616, 'Зелёная ул.', 1);
INSERT INTO street VALUES (617, '1-й Дальний пер.', 1);
INSERT INTO street VALUES (618, 'Кстинский пер.', 1);
INSERT INTO street VALUES (619, 'ул. Мичурина', 1);
INSERT INTO street VALUES (620, 'Новооктябрьская ул.', 1);
INSERT INTO street VALUES (621, 'Сосновая ул.', 1);
INSERT INTO street VALUES (622, '2-й пер. Куйбышева', 1);
INSERT INTO street VALUES (623, 'Лабенская ул.', 1);
INSERT INTO street VALUES (624, 'Малаховичская ул.', 1);
INSERT INTO street VALUES (625, 'ул. Павла Бобровского', 1);
INSERT INTO street VALUES (626, 'Восточная ул.', 1);
INSERT INTO street VALUES (627, 'Мануфактурная ул.', 1);
INSERT INTO street VALUES (628, 'Мостовая ул.', 1);
INSERT INTO street VALUES (629, 'Мирная ул.', 1);
INSERT INTO street VALUES (630, 'ул. Пышки', 1);
INSERT INTO street VALUES (631, 'Волейбольная ул.', 1);
INSERT INTO street VALUES (632, 'Гарбарская ул.', 1);
INSERT INTO street VALUES (633, '3-й пер. Куйбышева', 1);
INSERT INTO street VALUES (634, 'Мулярская ул.', 1);
INSERT INTO street VALUES (635, 'пер. Суворова', 1);
INSERT INTO street VALUES (636, 'ул. Щедрина', 1);
INSERT INTO street VALUES (637, 'Венечная ул.', 1);
INSERT INTO street VALUES (638, 'Парковая ул.', 1);
INSERT INTO street VALUES (639, 'Солнечная ул.', 1);
INSERT INTO street VALUES (640, 'Ковальская ул.', 1);
INSERT INTO street VALUES (641, 'Песчаная ул.', 1);
INSERT INTO street VALUES (642, 'Сокольский пер.', 1);
INSERT INTO street VALUES (643, 'ул. Титова', 1);
INSERT INTO street VALUES (644, 'Ближняя ул.', 1);
INSERT INTO street VALUES (645, 'Новый пер.', 1);
INSERT INTO street VALUES (646, 'Старозамковая ул.', 1);
INSERT INTO street VALUES (647, 'Береговая ул.', 1);
INSERT INTO street VALUES (648, 'Пионерская ул.', 1);
INSERT INTO street VALUES (649, 'Живописный пер.', 1);
INSERT INTO street VALUES (650, 'Промысловая ул.', 1);
INSERT INTO street VALUES (651, '1-й Малаховичский пер.', 1);
INSERT INTO street VALUES (652, 'Осавиахимовская ул.', 1);
INSERT INTO street VALUES (653, 'Песочная ул.', 1);
INSERT INTO street VALUES (654, 'ул. Лизы Чайкиной', 1);
INSERT INTO street VALUES (655, '3-й Победоносный пер.', 1);
INSERT INTO street VALUES (656, 'ул. Ватутина', 1);
INSERT INTO street VALUES (657, 'ул. Гая', 1);
INSERT INTO street VALUES (658, 'Лидская ул.', 1);
INSERT INTO street VALUES (659, 'Лидский пер.', 1);
INSERT INTO street VALUES (660, 'ул. Зои Космодемьянской', 1);
INSERT INTO street VALUES (661, 'Луговая ул.', 1);
INSERT INTO street VALUES (662, 'ул. Бондовского', 1);
INSERT INTO street VALUES (663, 'ул. Кохановского', 1);
INSERT INTO street VALUES (664, 'ул. Томина', 1);
INSERT INTO street VALUES (665, 'ул. Желковского', 1);
INSERT INTO street VALUES (666, 'Крайний пер.', 1);
INSERT INTO street VALUES (667, 'Подкрыжацкая ул.', 1);
INSERT INTO street VALUES (668, 'ул. Морозова', 1);
INSERT INTO street VALUES (669, '4-й пер. Скрынника', 1);
INSERT INTO street VALUES (670, 'ул. Домбровского', 1);
INSERT INTO street VALUES (671, 'пер. Шишкина', 1);
INSERT INTO street VALUES (672, 'Ранняя ул.', 1);
INSERT INTO street VALUES (673, 'ул. Вишневец', 1);
INSERT INTO street VALUES (674, '2-й Дальний пер.', 1);
INSERT INTO street VALUES (675, 'Академическая ул.', 1);
INSERT INTO street VALUES (676, 'Первый пер.', 1);
INSERT INTO street VALUES (677, 'Крайняя ул.', 1);
INSERT INTO street VALUES (678, 'Светлый пер.', 1);
INSERT INTO street VALUES (679, 'Желанная ул.', 1);
INSERT INTO street VALUES (680, 'Тарусичская ул.', 1);
INSERT INTO street VALUES (681, '3-й пер. Серафимовича', 1);
INSERT INTO street VALUES (682, 'ул. Сырокомли', 1);
INSERT INTO street VALUES (683, 'Яснополянская ул.', 1);
INSERT INTO street VALUES (684, 'ул. Сангина', 1);
INSERT INTO street VALUES (685, 'Достойная ул.', 1);
INSERT INTO street VALUES (686, 'Супольная ул.', 1);
INSERT INTO street VALUES (687, 'ул. Василька', 1);
INSERT INTO street VALUES (688, '4-й пер. Калинина', 1);
INSERT INTO street VALUES (689, 'Правонабережная ул.', 1);
INSERT INTO street VALUES (690, 'Урожайная ул.', 1);
INSERT INTO street VALUES (691, 'Райгородская ул.', 1);
INSERT INTO street VALUES (692, 'ул. Урицкого', 1);
INSERT INTO street VALUES (693, 'ул. Декабристов', 1);
INSERT INTO street VALUES (694, '7-й Дальний пер.', 1);
INSERT INTO street VALUES (695, 'ул. Фрунзе', 1);
INSERT INTO street VALUES (696, 'ул. Гагарина', 1);
INSERT INTO street VALUES (697, 'Рощинский пер.', 1);
INSERT INTO street VALUES (698, 'ул. Подпереселка', 1);
INSERT INTO street VALUES (699, 'Заречный пер.', 1);
INSERT INTO street VALUES (700, 'Трюковая с трамплинами', 1);


--
-- Name: street_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('street_id_seq', 700, true);


--
-- Data for Name: user_account; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO user_account VALUES (2, 'vasili', 'vasili', 'vasili@email.com', NULL);
INSERT INTO user_account VALUES (1, 'petrov', 'petrov', 'petrov@petrov.com', NULL);


--
-- Name: user_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('user_account_id_seq', 1, false);


--
-- Data for Name: user_profile; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO user_profile VALUES (1, 'Петя', 'Петров', '375291234567', NULL);
INSERT INTO user_profile VALUES (2, 'Василий', 'Быстроходов', '375291234560', NULL);
INSERT INTO user_profile VALUES (3, 'Николай', NULL, '375010101011', NULL);
INSERT INTO user_profile VALUES (5, 'Пётр', 'Бегунов', '375172660987', NULL);
INSERT INTO user_profile VALUES (7, 'Алексей', NULL, '375451545455', NULL);
INSERT INTO user_profile VALUES (8, 'Сергей', NULL, '375237654322', NULL);


--
-- Name: user_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('user_profile_id_seq', 8, true);


--
-- Data for Name: user_role; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO user_role VALUES (1, 1, 3);
INSERT INTO user_role VALUES (2, 2, 2);
INSERT INTO user_role VALUES (3, 3, 3);
INSERT INTO user_role VALUES (4, 5, 2);
INSERT INTO user_role VALUES (5, 7, 3);
INSERT INTO user_role VALUES (6, 8, 2);


--
-- Name: user_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('user_role_id_seq', 6, true);


--
-- Name: autos_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY autos
    ADD CONSTRAINT autos_pk PRIMARY KEY (id);


--
-- Name: autos_uk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY autos
    ADD CONSTRAINT autos_uk UNIQUE (car_id, driver_id);


--
-- Name: car_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY car
    ADD CONSTRAINT car_pk PRIMARY KEY (id);


--
-- Name: car_uk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY car
    ADD CONSTRAINT car_uk UNIQUE (reg_num);


--
-- Name: cities_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY city
    ADD CONSTRAINT cities_pk PRIMARY KEY (id);


--
-- Name: city_uk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY city
    ADD CONSTRAINT city_uk UNIQUE (name);


--
-- Name: customer_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customer
    ADD CONSTRAINT customer_pk PRIMARY KEY (id);


--
-- Name: driver_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY driver
    ADD CONSTRAINT driver_pk PRIMARY KEY (id);


--
-- Name: oraders_timetable_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY orders_timetable
    ADD CONSTRAINT oraders_timetable_pk PRIMARY KEY (id);


--
-- Name: orders_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT orders_pk PRIMARY KEY (id);


--
-- Name: person_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_profile
    ADD CONSTRAINT person_pk PRIMARY KEY (id);


--
-- Name: point_uk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY point
    ADD CONSTRAINT point_uk UNIQUE (street_id, name);


--
-- Name: points_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY point
    ADD CONSTRAINT points_pk PRIMARY KEY (id);


--
-- Name: price_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY price
    ADD CONSTRAINT price_pk PRIMARY KEY (id);


--
-- Name: price_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY price
    ADD CONSTRAINT price_uniq UNIQUE (car_type, begin_date);


--
-- Name: routes_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY route
    ADD CONSTRAINT routes_pk PRIMARY KEY (id);


--
-- Name: street_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY street
    ADD CONSTRAINT street_pk PRIMARY KEY (id);


--
-- Name: street_uk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY street
    ADD CONSTRAINT street_uk UNIQUE (city_id, name);


--
-- Name: user_account_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_account
    ADD CONSTRAINT user_account_pk PRIMARY KEY (id);


--
-- Name: user_account_uk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_account
    ADD CONSTRAINT user_account_uk UNIQUE (name, email);


--
-- Name: user_profile_uk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_profile
    ADD CONSTRAINT user_profile_uk UNIQUE (tel_num);


--
-- Name: user_role_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_role
    ADD CONSTRAINT user_role_pk PRIMARY KEY (id);


--
-- Name: user_role_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_role
    ADD CONSTRAINT user_role_uniq UNIQUE (user_profile_id, app_role);


--
-- Name: autos_car_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY autos
    ADD CONSTRAINT autos_car_fk FOREIGN KEY (car_id) REFERENCES car(id);


--
-- Name: autos_driver_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY autos
    ADD CONSTRAINT autos_driver_fk FOREIGN KEY (driver_id) REFERENCES driver(id);


--
-- Name: customer_user_profile_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customer
    ADD CONSTRAINT customer_user_profile_fk FOREIGN KEY (id) REFERENCES user_profile(id);


--
-- Name: driver_user_profile_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY driver
    ADD CONSTRAINT driver_user_profile_fk FOREIGN KEY (id) REFERENCES user_profile(id);


--
-- Name: oraders_timetable_order_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY orders_timetable
    ADD CONSTRAINT oraders_timetable_order_fk FOREIGN KEY (orders_id) REFERENCES orders(id);


--
-- Name: orders_autos_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT orders_autos_fk FOREIGN KEY (autos_id) REFERENCES autos(id);


--
-- Name: orders_customer_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT orders_customer_fk FOREIGN KEY (customer_id) REFERENCES customer(id);


--
-- Name: orders_price_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT orders_price_fk FOREIGN KEY (price_id) REFERENCES price(id);


--
-- Name: points_streets_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY point
    ADD CONSTRAINT points_streets_fk FOREIGN KEY (street_id) REFERENCES street(id);


--
-- Name: route_orders_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY route
    ADD CONSTRAINT route_orders_fk FOREIGN KEY (orders_id) REFERENCES orders(id);


--
-- Name: route_point_dst_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY route
    ADD CONSTRAINT route_point_dst_fk FOREIGN KEY (dst_point_id) REFERENCES point(id);


--
-- Name: route_point_src_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY route
    ADD CONSTRAINT route_point_src_fk FOREIGN KEY (src_point_id) REFERENCES point(id);


--
-- Name: street_city_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY street
    ADD CONSTRAINT street_city_fk FOREIGN KEY (city_id) REFERENCES city(id);


--
-- Name: user_account_user_role_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_account
    ADD CONSTRAINT user_account_user_role_fk FOREIGN KEY (id) REFERENCES user_role(id);


--
-- Name: user_role_user_profile_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_role
    ADD CONSTRAINT user_role_user_profile_fk FOREIGN KEY (user_profile_id) REFERENCES user_profile(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: -
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM test;
GRANT ALL ON SCHEMA public TO test;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

